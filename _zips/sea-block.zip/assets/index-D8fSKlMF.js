var _v=Object.defineProperty;var xv=(i,e,t)=>e in i?_v(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var E=(i,e,t)=>xv(i,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();class tt{constructor(){E(this,"flatConfig")}refreshConfig(){this.flatConfig=b_(this.tree)}static register(e,t){if(e in this._registry)throw new Error(`configurable already registered: '${e}'`);this._registry[e]=t}static create(e){const t=this._registry[e],n=t();return n.refreshConfig(),n}}E(tt,"_registry",{});function b_(i,e={}){for(const[t,n]of Object.entries(i.children))"action"in n||("value"in n?e[t]=n.value:b_(n,e));return e}const Ot={min:0,max:1,step:.01},yv={enabled:{children:{"sound-hover":{...Ot,value:.05},"sound-unhover":{...Ot,value:.05},"sound-click":{...Ot,value:.04},"sound-unclick":{...Ot,value:.03},"sound-collapse":{...Ot,value:.1},"sound-smStart":{...Ot,value:.2},"sound-smNav":{...Ot,value:.2},"sound-settingsOpen":{...Ot,value:.2},"sound-settingsClose":{...Ot,value:.2},"sound-chessClick":{...Ot,value:.05},"sound-chessCancel":{...Ot,value:.08},"sound-chessLand":{...Ot,value:.2},"sound-chessGoodCapture":{...Ot,value:.2},"sound-chessBadCapture":{...Ot,value:.5},"sound-chessJump":{...Ot,value:.07},"sound-chessCelebrate":{...Ot,value:.08}}}};var Cr=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},_c={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var Rp;function vv(){return Rp||(Rp=1,function(i){(function(){var e=function(){this.init()};e.prototype={init:function(){var a=this||t;return a._counter=1e3,a._html5AudioPool=[],a.html5PoolSize=10,a._codecs={},a._howls=[],a._muted=!1,a._volume=1,a._canPlayEvent="canplaythrough",a._navigator=typeof window<"u"&&window.navigator?window.navigator:null,a.masterGain=null,a.noAudio=!1,a.usingWebAudio=!0,a.autoSuspend=!0,a.ctx=null,a.autoUnlock=!0,a._setup(),a},volume:function(a){var h=this||t;if(a=parseFloat(a),h.ctx||d(),typeof a<"u"&&a>=0&&a<=1){if(h._volume=a,h._muted)return h;h.usingWebAudio&&h.masterGain.gain.setValueAtTime(a,t.ctx.currentTime);for(var f=0;f<h._howls.length;f++)if(!h._howls[f]._webAudio)for(var g=h._howls[f]._getSoundIds(),_=0;_<g.length;_++){var m=h._howls[f]._soundById(g[_]);m&&m._node&&(m._node.volume=m._volume*a)}return h}return h._volume},mute:function(a){var h=this||t;h.ctx||d(),h._muted=a,h.usingWebAudio&&h.masterGain.gain.setValueAtTime(a?0:h._volume,t.ctx.currentTime);for(var f=0;f<h._howls.length;f++)if(!h._howls[f]._webAudio)for(var g=h._howls[f]._getSoundIds(),_=0;_<g.length;_++){var m=h._howls[f]._soundById(g[_]);m&&m._node&&(m._node.muted=a?!0:m._muted)}return h},stop:function(){for(var a=this||t,h=0;h<a._howls.length;h++)a._howls[h].stop();return a},unload:function(){for(var a=this||t,h=a._howls.length-1;h>=0;h--)a._howls[h].unload();return a.usingWebAudio&&a.ctx&&typeof a.ctx.close<"u"&&(a.ctx.close(),a.ctx=null,d()),a},codecs:function(a){return(this||t)._codecs[a.replace(/^x-/,"")]},_setup:function(){var a=this||t;if(a.state=a.ctx&&a.ctx.state||"suspended",a._autoSuspend(),!a.usingWebAudio)if(typeof Audio<"u")try{var h=new Audio;typeof h.oncanplaythrough>"u"&&(a._canPlayEvent="canplay")}catch{a.noAudio=!0}else a.noAudio=!0;try{var h=new Audio;h.muted&&(a.noAudio=!0)}catch{}return a.noAudio||a._setupCodecs(),a},_setupCodecs:function(){var a=this||t,h=null;try{h=typeof Audio<"u"?new Audio:null}catch{return a}if(!h||typeof h.canPlayType!="function")return a;var f=h.canPlayType("audio/mpeg;").replace(/^no$/,""),g=a._navigator?a._navigator.userAgent:"",_=g.match(/OPR\/(\d+)/g),m=_&&parseInt(_[0].split("/")[1],10)<33,p=g.indexOf("Safari")!==-1&&g.indexOf("Chrome")===-1,x=g.match(/Version\/(.*?) /),b=p&&x&&parseInt(x[1],10)<15;return a._codecs={mp3:!!(!m&&(f||h.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!f,opus:!!h.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!h.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!h.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(h.canPlayType('audio/wav; codecs="1"')||h.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!h.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!h.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(h.canPlayType("audio/x-m4a;")||h.canPlayType("audio/m4a;")||h.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(h.canPlayType("audio/x-m4b;")||h.canPlayType("audio/m4b;")||h.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(h.canPlayType("audio/x-mp4;")||h.canPlayType("audio/mp4;")||h.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!b&&h.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!b&&h.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!h.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(h.canPlayType("audio/x-flac;")||h.canPlayType("audio/flac;")).replace(/^no$/,"")},a},_unlockAudio:function(){var a=this||t;if(!(a._audioUnlocked||!a.ctx)){a._audioUnlocked=!1,a.autoUnlock=!1,!a._mobileUnloaded&&a.ctx.sampleRate!==44100&&(a._mobileUnloaded=!0,a.unload()),a._scratchBuffer=a.ctx.createBuffer(1,1,22050);var h=function(f){for(;a._html5AudioPool.length<a.html5PoolSize;)try{var g=new Audio;g._unlocked=!0,a._releaseHtml5Audio(g)}catch{a.noAudio=!0;break}for(var _=0;_<a._howls.length;_++)if(!a._howls[_]._webAudio)for(var m=a._howls[_]._getSoundIds(),p=0;p<m.length;p++){var x=a._howls[_]._soundById(m[p]);x&&x._node&&!x._node._unlocked&&(x._node._unlocked=!0,x._node.load())}a._autoResume();var b=a.ctx.createBufferSource();b.buffer=a._scratchBuffer,b.connect(a.ctx.destination),typeof b.start>"u"?b.noteOn(0):b.start(0),typeof a.ctx.resume=="function"&&a.ctx.resume(),b.onended=function(){b.disconnect(0),a._audioUnlocked=!0,document.removeEventListener("touchstart",h,!0),document.removeEventListener("touchend",h,!0),document.removeEventListener("click",h,!0),document.removeEventListener("keydown",h,!0);for(var v=0;v<a._howls.length;v++)a._howls[v]._emit("unlock")}};return document.addEventListener("touchstart",h,!0),document.addEventListener("touchend",h,!0),document.addEventListener("click",h,!0),document.addEventListener("keydown",h,!0),a}},_obtainHtml5Audio:function(){var a=this||t;if(a._html5AudioPool.length)return a._html5AudioPool.pop();var h=new Audio().play();return h&&typeof Promise<"u"&&(h instanceof Promise||typeof h.then=="function")&&h.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(a){var h=this||t;return a._unlocked&&h._html5AudioPool.push(a),h},_autoSuspend:function(){var a=this;if(!(!a.autoSuspend||!a.ctx||typeof a.ctx.suspend>"u"||!t.usingWebAudio)){for(var h=0;h<a._howls.length;h++)if(a._howls[h]._webAudio){for(var f=0;f<a._howls[h]._sounds.length;f++)if(!a._howls[h]._sounds[f]._paused)return a}return a._suspendTimer&&clearTimeout(a._suspendTimer),a._suspendTimer=setTimeout(function(){if(a.autoSuspend){a._suspendTimer=null,a.state="suspending";var g=function(){a.state="suspended",a._resumeAfterSuspend&&(delete a._resumeAfterSuspend,a._autoResume())};a.ctx.suspend().then(g,g)}},3e4),a}},_autoResume:function(){var a=this;if(!(!a.ctx||typeof a.ctx.resume>"u"||!t.usingWebAudio))return a.state==="running"&&a.ctx.state!=="interrupted"&&a._suspendTimer?(clearTimeout(a._suspendTimer),a._suspendTimer=null):a.state==="suspended"||a.state==="running"&&a.ctx.state==="interrupted"?(a.ctx.resume().then(function(){a.state="running";for(var h=0;h<a._howls.length;h++)a._howls[h]._emit("resume")}),a._suspendTimer&&(clearTimeout(a._suspendTimer),a._suspendTimer=null)):a.state==="suspending"&&(a._resumeAfterSuspend=!0),a}};var t=new e,n=function(a){var h=this;if(!a.src||a.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}h.init(a)};n.prototype={init:function(a){var h=this;return t.ctx||d(),h._autoplay=a.autoplay||!1,h._format=typeof a.format!="string"?a.format:[a.format],h._html5=a.html5||!1,h._muted=a.mute||!1,h._loop=a.loop||!1,h._pool=a.pool||5,h._preload=typeof a.preload=="boolean"||a.preload==="metadata"?a.preload:!0,h._rate=a.rate||1,h._sprite=a.sprite||{},h._src=typeof a.src!="string"?a.src:[a.src],h._volume=a.volume!==void 0?a.volume:1,h._xhr={method:a.xhr&&a.xhr.method?a.xhr.method:"GET",headers:a.xhr&&a.xhr.headers?a.xhr.headers:null,withCredentials:a.xhr&&a.xhr.withCredentials?a.xhr.withCredentials:!1},h._duration=0,h._state="unloaded",h._sounds=[],h._endTimers={},h._queue=[],h._playLock=!1,h._onend=a.onend?[{fn:a.onend}]:[],h._onfade=a.onfade?[{fn:a.onfade}]:[],h._onload=a.onload?[{fn:a.onload}]:[],h._onloaderror=a.onloaderror?[{fn:a.onloaderror}]:[],h._onplayerror=a.onplayerror?[{fn:a.onplayerror}]:[],h._onpause=a.onpause?[{fn:a.onpause}]:[],h._onplay=a.onplay?[{fn:a.onplay}]:[],h._onstop=a.onstop?[{fn:a.onstop}]:[],h._onmute=a.onmute?[{fn:a.onmute}]:[],h._onvolume=a.onvolume?[{fn:a.onvolume}]:[],h._onrate=a.onrate?[{fn:a.onrate}]:[],h._onseek=a.onseek?[{fn:a.onseek}]:[],h._onunlock=a.onunlock?[{fn:a.onunlock}]:[],h._onresume=[],h._webAudio=t.usingWebAudio&&!h._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(h),h._autoplay&&h._queue.push({event:"play",action:function(){h.play()}}),h._preload&&h._preload!=="none"&&h.load(),h},load:function(){var a=this,h=null;if(t.noAudio){a._emit("loaderror",null,"No audio support.");return}typeof a._src=="string"&&(a._src=[a._src]);for(var f=0;f<a._src.length;f++){var g,_;if(a._format&&a._format[f])g=a._format[f];else{if(_=a._src[f],typeof _!="string"){a._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}g=/^data:audio\/([^;,]+);/i.exec(_),g||(g=/\.([^.]+)$/.exec(_.split("?",1)[0])),g&&(g=g[1].toLowerCase())}if(g||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),g&&t.codecs(g)){h=a._src[f];break}}if(!h){a._emit("loaderror",null,"No codec support for selected audio sources.");return}return a._src=h,a._state="loading",window.location.protocol==="https:"&&h.slice(0,5)==="http:"&&(a._html5=!0,a._webAudio=!1),new s(a),a._webAudio&&o(a),a},play:function(a,h){var f=this,g=null;if(typeof a=="number")g=a,a=null;else{if(typeof a=="string"&&f._state==="loaded"&&!f._sprite[a])return null;if(typeof a>"u"&&(a="__default",!f._playLock)){for(var _=0,m=0;m<f._sounds.length;m++)f._sounds[m]._paused&&!f._sounds[m]._ended&&(_++,g=f._sounds[m]._id);_===1?a=null:g=null}}var p=g?f._soundById(g):f._inactiveSound();if(!p)return null;if(g&&!a&&(a=p._sprite||"__default"),f._state!=="loaded"){p._sprite=a,p._ended=!1;var x=p._id;return f._queue.push({event:"play",action:function(){f.play(x)}}),x}if(g&&!p._paused)return h||f._loadQueue("play"),p._id;f._webAudio&&t._autoResume();var b=Math.max(0,p._seek>0?p._seek:f._sprite[a][0]/1e3),v=Math.max(0,(f._sprite[a][0]+f._sprite[a][1])/1e3-b),P=v*1e3/Math.abs(p._rate),C=f._sprite[a][0]/1e3,T=(f._sprite[a][0]+f._sprite[a][1])/1e3;p._sprite=a,p._ended=!1;var D=function(){p._paused=!1,p._seek=b,p._start=C,p._stop=T,p._loop=!!(p._loop||f._sprite[a][2])};if(b>=T){f._ended(p);return}var w=p._node;if(f._webAudio){var M=function(){f._playLock=!1,D(),f._refreshBuffer(p);var V=p._muted||f._muted?0:p._volume;w.gain.setValueAtTime(V,t.ctx.currentTime),p._playStart=t.ctx.currentTime,typeof w.bufferSource.start>"u"?p._loop?w.bufferSource.noteGrainOn(0,b,86400):w.bufferSource.noteGrainOn(0,b,v):p._loop?w.bufferSource.start(0,b,86400):w.bufferSource.start(0,b,v),P!==1/0&&(f._endTimers[p._id]=setTimeout(f._ended.bind(f,p),P)),h||setTimeout(function(){f._emit("play",p._id),f._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?M():(f._playLock=!0,f.once("resume",M),f._clearTimer(p._id))}else{var I=function(){w.currentTime=b,w.muted=p._muted||f._muted||t._muted||w.muted,w.volume=p._volume*t.volume(),w.playbackRate=p._rate;try{var V=w.play();if(V&&typeof Promise<"u"&&(V instanceof Promise||typeof V.then=="function")?(f._playLock=!0,D(),V.then(function(){f._playLock=!1,w._unlocked=!0,h?f._loadQueue():f._emit("play",p._id)}).catch(function(){f._playLock=!1,f._emit("playerror",p._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),p._ended=!0,p._paused=!0})):h||(f._playLock=!1,D(),f._emit("play",p._id)),w.playbackRate=p._rate,w.paused){f._emit("playerror",p._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}a!=="__default"||p._loop?f._endTimers[p._id]=setTimeout(f._ended.bind(f,p),P):(f._endTimers[p._id]=function(){f._ended(p),w.removeEventListener("ended",f._endTimers[p._id],!1)},w.addEventListener("ended",f._endTimers[p._id],!1))}catch(Y){f._emit("playerror",p._id,Y)}};w.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(w.src=f._src,w.load());var B=window&&window.ejecta||!w.readyState&&t._navigator.isCocoonJS;if(w.readyState>=3||B)I();else{f._playLock=!0,f._state="loading";var N=function(){f._state="loaded",I(),w.removeEventListener(t._canPlayEvent,N,!1)};w.addEventListener(t._canPlayEvent,N,!1),f._clearTimer(p._id)}}return p._id},pause:function(a){var h=this;if(h._state!=="loaded"||h._playLock)return h._queue.push({event:"pause",action:function(){h.pause(a)}}),h;for(var f=h._getSoundIds(a),g=0;g<f.length;g++){h._clearTimer(f[g]);var _=h._soundById(f[g]);if(_&&!_._paused&&(_._seek=h.seek(f[g]),_._rateSeek=0,_._paused=!0,h._stopFade(f[g]),_._node))if(h._webAudio){if(!_._node.bufferSource)continue;typeof _._node.bufferSource.stop>"u"?_._node.bufferSource.noteOff(0):_._node.bufferSource.stop(0),h._cleanBuffer(_._node)}else(!isNaN(_._node.duration)||_._node.duration===1/0)&&_._node.pause();arguments[1]||h._emit("pause",_?_._id:null)}return h},stop:function(a,h){var f=this;if(f._state!=="loaded"||f._playLock)return f._queue.push({event:"stop",action:function(){f.stop(a)}}),f;for(var g=f._getSoundIds(a),_=0;_<g.length;_++){f._clearTimer(g[_]);var m=f._soundById(g[_]);m&&(m._seek=m._start||0,m._rateSeek=0,m._paused=!0,m._ended=!0,f._stopFade(g[_]),m._node&&(f._webAudio?m._node.bufferSource&&(typeof m._node.bufferSource.stop>"u"?m._node.bufferSource.noteOff(0):m._node.bufferSource.stop(0),f._cleanBuffer(m._node)):(!isNaN(m._node.duration)||m._node.duration===1/0)&&(m._node.currentTime=m._start||0,m._node.pause(),m._node.duration===1/0&&f._clearSound(m._node))),h||f._emit("stop",m._id))}return f},mute:function(a,h){var f=this;if(f._state!=="loaded"||f._playLock)return f._queue.push({event:"mute",action:function(){f.mute(a,h)}}),f;if(typeof h>"u")if(typeof a=="boolean")f._muted=a;else return f._muted;for(var g=f._getSoundIds(h),_=0;_<g.length;_++){var m=f._soundById(g[_]);m&&(m._muted=a,m._interval&&f._stopFade(m._id),f._webAudio&&m._node?m._node.gain.setValueAtTime(a?0:m._volume,t.ctx.currentTime):m._node&&(m._node.muted=t._muted?!0:a),f._emit("mute",m._id))}return f},volume:function(){var a=this,h=arguments,f,g;if(h.length===0)return a._volume;if(h.length===1||h.length===2&&typeof h[1]>"u"){var _=a._getSoundIds(),m=_.indexOf(h[0]);m>=0?g=parseInt(h[0],10):f=parseFloat(h[0])}else h.length>=2&&(f=parseFloat(h[0]),g=parseInt(h[1],10));var p;if(typeof f<"u"&&f>=0&&f<=1){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"volume",action:function(){a.volume.apply(a,h)}}),a;typeof g>"u"&&(a._volume=f),g=a._getSoundIds(g);for(var x=0;x<g.length;x++)p=a._soundById(g[x]),p&&(p._volume=f,h[2]||a._stopFade(g[x]),a._webAudio&&p._node&&!p._muted?p._node.gain.setValueAtTime(f,t.ctx.currentTime):p._node&&!p._muted&&(p._node.volume=f*t.volume()),a._emit("volume",p._id))}else return p=g?a._soundById(g):a._sounds[0],p?p._volume:0;return a},fade:function(a,h,f,g){var _=this;if(_._state!=="loaded"||_._playLock)return _._queue.push({event:"fade",action:function(){_.fade(a,h,f,g)}}),_;a=Math.min(Math.max(0,parseFloat(a)),1),h=Math.min(Math.max(0,parseFloat(h)),1),f=parseFloat(f),_.volume(a,g);for(var m=_._getSoundIds(g),p=0;p<m.length;p++){var x=_._soundById(m[p]);if(x){if(g||_._stopFade(m[p]),_._webAudio&&!x._muted){var b=t.ctx.currentTime,v=b+f/1e3;x._volume=a,x._node.gain.setValueAtTime(a,b),x._node.gain.linearRampToValueAtTime(h,v)}_._startFadeInterval(x,a,h,f,m[p],typeof g>"u")}}return _},_startFadeInterval:function(a,h,f,g,_,m){var p=this,x=h,b=f-h,v=Math.abs(b/.01),P=Math.max(4,v>0?g/v:g),C=Date.now();a._fadeTo=f,a._interval=setInterval(function(){var T=(Date.now()-C)/g;C=Date.now(),x+=b*T,x=Math.round(x*100)/100,b<0?x=Math.max(f,x):x=Math.min(f,x),p._webAudio?a._volume=x:p.volume(x,a._id,!0),m&&(p._volume=x),(f<h&&x<=f||f>h&&x>=f)&&(clearInterval(a._interval),a._interval=null,a._fadeTo=null,p.volume(f,a._id),p._emit("fade",a._id))},P)},_stopFade:function(a){var h=this,f=h._soundById(a);return f&&f._interval&&(h._webAudio&&f._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(f._interval),f._interval=null,h.volume(f._fadeTo,a),f._fadeTo=null,h._emit("fade",a)),h},loop:function(){var a=this,h=arguments,f,g,_;if(h.length===0)return a._loop;if(h.length===1)if(typeof h[0]=="boolean")f=h[0],a._loop=f;else return _=a._soundById(parseInt(h[0],10)),_?_._loop:!1;else h.length===2&&(f=h[0],g=parseInt(h[1],10));for(var m=a._getSoundIds(g),p=0;p<m.length;p++)_=a._soundById(m[p]),_&&(_._loop=f,a._webAudio&&_._node&&_._node.bufferSource&&(_._node.bufferSource.loop=f,f&&(_._node.bufferSource.loopStart=_._start||0,_._node.bufferSource.loopEnd=_._stop,a.playing(m[p])&&(a.pause(m[p],!0),a.play(m[p],!0)))));return a},rate:function(){var a=this,h=arguments,f,g;if(h.length===0)g=a._sounds[0]._id;else if(h.length===1){var _=a._getSoundIds(),m=_.indexOf(h[0]);m>=0?g=parseInt(h[0],10):f=parseFloat(h[0])}else h.length===2&&(f=parseFloat(h[0]),g=parseInt(h[1],10));var p;if(typeof f=="number"){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"rate",action:function(){a.rate.apply(a,h)}}),a;typeof g>"u"&&(a._rate=f),g=a._getSoundIds(g);for(var x=0;x<g.length;x++)if(p=a._soundById(g[x]),p){a.playing(g[x])&&(p._rateSeek=a.seek(g[x]),p._playStart=a._webAudio?t.ctx.currentTime:p._playStart),p._rate=f,a._webAudio&&p._node&&p._node.bufferSource?p._node.bufferSource.playbackRate.setValueAtTime(f,t.ctx.currentTime):p._node&&(p._node.playbackRate=f);var b=a.seek(g[x]),v=(a._sprite[p._sprite][0]+a._sprite[p._sprite][1])/1e3-b,P=v*1e3/Math.abs(p._rate);(a._endTimers[g[x]]||!p._paused)&&(a._clearTimer(g[x]),a._endTimers[g[x]]=setTimeout(a._ended.bind(a,p),P)),a._emit("rate",p._id)}}else return p=a._soundById(g),p?p._rate:a._rate;return a},seek:function(){var a=this,h=arguments,f,g;if(h.length===0)a._sounds.length&&(g=a._sounds[0]._id);else if(h.length===1){var _=a._getSoundIds(),m=_.indexOf(h[0]);m>=0?g=parseInt(h[0],10):a._sounds.length&&(g=a._sounds[0]._id,f=parseFloat(h[0]))}else h.length===2&&(f=parseFloat(h[0]),g=parseInt(h[1],10));if(typeof g>"u")return 0;if(typeof f=="number"&&(a._state!=="loaded"||a._playLock))return a._queue.push({event:"seek",action:function(){a.seek.apply(a,h)}}),a;var p=a._soundById(g);if(p)if(typeof f=="number"&&f>=0){var x=a.playing(g);x&&a.pause(g,!0),p._seek=f,p._ended=!1,a._clearTimer(g),!a._webAudio&&p._node&&!isNaN(p._node.duration)&&(p._node.currentTime=f);var b=function(){x&&a.play(g,!0),a._emit("seek",g)};if(x&&!a._webAudio){var v=function(){a._playLock?setTimeout(v,0):b()};setTimeout(v,0)}else b()}else if(a._webAudio){var P=a.playing(g)?t.ctx.currentTime-p._playStart:0,C=p._rateSeek?p._rateSeek-p._seek:0;return p._seek+(C+P*Math.abs(p._rate))}else return p._node.currentTime;return a},playing:function(a){var h=this;if(typeof a=="number"){var f=h._soundById(a);return f?!f._paused:!1}for(var g=0;g<h._sounds.length;g++)if(!h._sounds[g]._paused)return!0;return!1},duration:function(a){var h=this,f=h._duration,g=h._soundById(a);return g&&(f=h._sprite[g._sprite][1]/1e3),f},state:function(){return this._state},unload:function(){for(var a=this,h=a._sounds,f=0;f<h.length;f++)h[f]._paused||a.stop(h[f]._id),a._webAudio||(a._clearSound(h[f]._node),h[f]._node.removeEventListener("error",h[f]._errorFn,!1),h[f]._node.removeEventListener(t._canPlayEvent,h[f]._loadFn,!1),h[f]._node.removeEventListener("ended",h[f]._endFn,!1),t._releaseHtml5Audio(h[f]._node)),delete h[f]._node,a._clearTimer(h[f]._id);var g=t._howls.indexOf(a);g>=0&&t._howls.splice(g,1);var _=!0;for(f=0;f<t._howls.length;f++)if(t._howls[f]._src===a._src||a._src.indexOf(t._howls[f]._src)>=0){_=!1;break}return r&&_&&delete r[a._src],t.noAudio=!1,a._state="unloaded",a._sounds=[],a=null,null},on:function(a,h,f,g){var _=this,m=_["_on"+a];return typeof h=="function"&&m.push(g?{id:f,fn:h,once:g}:{id:f,fn:h}),_},off:function(a,h,f){var g=this,_=g["_on"+a],m=0;if(typeof h=="number"&&(f=h,h=null),h||f)for(m=0;m<_.length;m++){var p=f===_[m].id;if(h===_[m].fn&&p||!h&&p){_.splice(m,1);break}}else if(a)g["_on"+a]=[];else{var x=Object.keys(g);for(m=0;m<x.length;m++)x[m].indexOf("_on")===0&&Array.isArray(g[x[m]])&&(g[x[m]]=[])}return g},once:function(a,h,f){var g=this;return g.on(a,h,f,1),g},_emit:function(a,h,f){for(var g=this,_=g["_on"+a],m=_.length-1;m>=0;m--)(!_[m].id||_[m].id===h||a==="load")&&(setTimeout((function(p){p.call(this,h,f)}).bind(g,_[m].fn),0),_[m].once&&g.off(a,_[m].fn,_[m].id));return g._loadQueue(a),g},_loadQueue:function(a){var h=this;if(h._queue.length>0){var f=h._queue[0];f.event===a&&(h._queue.shift(),h._loadQueue()),a||f.action()}return h},_ended:function(a){var h=this,f=a._sprite;if(!h._webAudio&&a._node&&!a._node.paused&&!a._node.ended&&a._node.currentTime<a._stop)return setTimeout(h._ended.bind(h,a),100),h;var g=!!(a._loop||h._sprite[f][2]);if(h._emit("end",a._id),!h._webAudio&&g&&h.stop(a._id,!0).play(a._id),h._webAudio&&g){h._emit("play",a._id),a._seek=a._start||0,a._rateSeek=0,a._playStart=t.ctx.currentTime;var _=(a._stop-a._start)*1e3/Math.abs(a._rate);h._endTimers[a._id]=setTimeout(h._ended.bind(h,a),_)}return h._webAudio&&!g&&(a._paused=!0,a._ended=!0,a._seek=a._start||0,a._rateSeek=0,h._clearTimer(a._id),h._cleanBuffer(a._node),t._autoSuspend()),!h._webAudio&&!g&&h.stop(a._id,!0),h},_clearTimer:function(a){var h=this;if(h._endTimers[a]){if(typeof h._endTimers[a]!="function")clearTimeout(h._endTimers[a]);else{var f=h._soundById(a);f&&f._node&&f._node.removeEventListener("ended",h._endTimers[a],!1)}delete h._endTimers[a]}return h},_soundById:function(a){for(var h=this,f=0;f<h._sounds.length;f++)if(a===h._sounds[f]._id)return h._sounds[f];return null},_inactiveSound:function(){var a=this;a._drain();for(var h=0;h<a._sounds.length;h++)if(a._sounds[h]._ended)return a._sounds[h].reset();return new s(a)},_drain:function(){var a=this,h=a._pool,f=0,g=0;if(!(a._sounds.length<h)){for(g=0;g<a._sounds.length;g++)a._sounds[g]._ended&&f++;for(g=a._sounds.length-1;g>=0;g--){if(f<=h)return;a._sounds[g]._ended&&(a._webAudio&&a._sounds[g]._node&&a._sounds[g]._node.disconnect(0),a._sounds.splice(g,1),f--)}}},_getSoundIds:function(a){var h=this;if(typeof a>"u"){for(var f=[],g=0;g<h._sounds.length;g++)f.push(h._sounds[g]._id);return f}else return[a]},_refreshBuffer:function(a){var h=this;return a._node.bufferSource=t.ctx.createBufferSource(),a._node.bufferSource.buffer=r[h._src],a._panner?a._node.bufferSource.connect(a._panner):a._node.bufferSource.connect(a._node),a._node.bufferSource.loop=a._loop,a._loop&&(a._node.bufferSource.loopStart=a._start||0,a._node.bufferSource.loopEnd=a._stop||0),a._node.bufferSource.playbackRate.setValueAtTime(a._rate,t.ctx.currentTime),h},_cleanBuffer:function(a){var h=this,f=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!a.bufferSource)return h;if(t._scratchBuffer&&a.bufferSource&&(a.bufferSource.onended=null,a.bufferSource.disconnect(0),f))try{a.bufferSource.buffer=t._scratchBuffer}catch{}return a.bufferSource=null,h},_clearSound:function(a){var h=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);h||(a.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var s=function(a){this._parent=a,this.init()};s.prototype={init:function(){var a=this,h=a._parent;return a._muted=h._muted,a._loop=h._loop,a._volume=h._volume,a._rate=h._rate,a._seek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,h._sounds.push(a),a.create(),a},create:function(){var a=this,h=a._parent,f=t._muted||a._muted||a._parent._muted?0:a._volume;return h._webAudio?(a._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),a._node.gain.setValueAtTime(f,t.ctx.currentTime),a._node.paused=!0,a._node.connect(t.masterGain)):t.noAudio||(a._node=t._obtainHtml5Audio(),a._errorFn=a._errorListener.bind(a),a._node.addEventListener("error",a._errorFn,!1),a._loadFn=a._loadListener.bind(a),a._node.addEventListener(t._canPlayEvent,a._loadFn,!1),a._endFn=a._endListener.bind(a),a._node.addEventListener("ended",a._endFn,!1),a._node.src=h._src,a._node.preload=h._preload===!0?"auto":h._preload,a._node.volume=f*t.volume(),a._node.load()),a},reset:function(){var a=this,h=a._parent;return a._muted=h._muted,a._loop=h._loop,a._volume=h._volume,a._rate=h._rate,a._seek=0,a._rateSeek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,a},_errorListener:function(){var a=this;a._parent._emit("loaderror",a._id,a._node.error?a._node.error.code:0),a._node.removeEventListener("error",a._errorFn,!1)},_loadListener:function(){var a=this,h=a._parent;h._duration=Math.ceil(a._node.duration*10)/10,Object.keys(h._sprite).length===0&&(h._sprite={__default:[0,h._duration*1e3]}),h._state!=="loaded"&&(h._state="loaded",h._emit("load"),h._loadQueue()),a._node.removeEventListener(t._canPlayEvent,a._loadFn,!1)},_endListener:function(){var a=this,h=a._parent;h._duration===1/0&&(h._duration=Math.ceil(a._node.duration*10)/10,h._sprite.__default[1]===1/0&&(h._sprite.__default[1]=h._duration*1e3),h._ended(a)),a._node.removeEventListener("ended",a._endFn,!1)}};var r={},o=function(a){var h=a._src;if(r[h]){a._duration=r[h].duration,u(a);return}if(/^data:[^;]+;base64,/.test(h)){for(var f=atob(h.split(",")[1]),g=new Uint8Array(f.length),_=0;_<f.length;++_)g[_]=f.charCodeAt(_);c(g.buffer,a)}else{var m=new XMLHttpRequest;m.open(a._xhr.method,h,!0),m.withCredentials=a._xhr.withCredentials,m.responseType="arraybuffer",a._xhr.headers&&Object.keys(a._xhr.headers).forEach(function(p){m.setRequestHeader(p,a._xhr.headers[p])}),m.onload=function(){var p=(m.status+"")[0];if(p!=="0"&&p!=="2"&&p!=="3"){a._emit("loaderror",null,"Failed loading audio file with status: "+m.status+".");return}c(m.response,a)},m.onerror=function(){a._webAudio&&(a._html5=!0,a._webAudio=!1,a._sounds=[],delete r[h],a.load())},l(m)}},l=function(a){try{a.send()}catch{a.onerror()}},c=function(a,h){var f=function(){h._emit("loaderror",null,"Decoding audio data failed.")},g=function(_){_&&h._sounds.length>0?(r[h._src]=_,u(h,_)):f()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(a).then(g).catch(f):t.ctx.decodeAudioData(a,g,f)},u=function(a,h){h&&!a._duration&&(a._duration=h.duration),Object.keys(a._sprite).length===0&&(a._sprite={__default:[0,a._duration*1e3]}),a._state!=="loaded"&&(a._state="loaded",a._emit("load"),a._loadQueue())},d=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var a=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),h=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),f=h?parseInt(h[1],10):null;if(a&&f&&f<9){var g=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!g&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};i.Howler=t,i.Howl=n,typeof Cr<"u"?(Cr.HowlerGlobal=e,Cr.Howler=t,Cr.Howl=n,Cr.Sound=s):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=n,window.Sound=s)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var n=this;if(!n.ctx||!n.ctx.listener)return n;for(var s=n._howls.length-1;s>=0;s--)n._howls[s].stereo(t);return n},HowlerGlobal.prototype.pos=function(t,n,s){var r=this;if(!r.ctx||!r.ctx.listener)return r;if(n=typeof n!="number"?r._pos[1]:n,s=typeof s!="number"?r._pos[2]:s,typeof t=="number")r._pos=[t,n,s],typeof r.ctx.listener.positionX<"u"?(r.ctx.listener.positionX.setTargetAtTime(r._pos[0],Howler.ctx.currentTime,.1),r.ctx.listener.positionY.setTargetAtTime(r._pos[1],Howler.ctx.currentTime,.1),r.ctx.listener.positionZ.setTargetAtTime(r._pos[2],Howler.ctx.currentTime,.1)):r.ctx.listener.setPosition(r._pos[0],r._pos[1],r._pos[2]);else return r._pos;return r},HowlerGlobal.prototype.orientation=function(t,n,s,r,o,l){var c=this;if(!c.ctx||!c.ctx.listener)return c;var u=c._orientation;if(n=typeof n!="number"?u[1]:n,s=typeof s!="number"?u[2]:s,r=typeof r!="number"?u[3]:r,o=typeof o!="number"?u[4]:o,l=typeof l!="number"?u[5]:l,typeof t=="number")c._orientation=[t,n,s,r,o,l],typeof c.ctx.listener.forwardX<"u"?(c.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),c.ctx.listener.forwardY.setTargetAtTime(n,Howler.ctx.currentTime,.1),c.ctx.listener.forwardZ.setTargetAtTime(s,Howler.ctx.currentTime,.1),c.ctx.listener.upX.setTargetAtTime(r,Howler.ctx.currentTime,.1),c.ctx.listener.upY.setTargetAtTime(o,Howler.ctx.currentTime,.1),c.ctx.listener.upZ.setTargetAtTime(l,Howler.ctx.currentTime,.1)):c.ctx.listener.setOrientation(t,n,s,r,o,l);else return u;return c},Howl.prototype.init=function(t){return function(n){var s=this;return s._orientation=n.orientation||[1,0,0],s._stereo=n.stereo||null,s._pos=n.pos||null,s._pannerAttr={coneInnerAngle:typeof n.coneInnerAngle<"u"?n.coneInnerAngle:360,coneOuterAngle:typeof n.coneOuterAngle<"u"?n.coneOuterAngle:360,coneOuterGain:typeof n.coneOuterGain<"u"?n.coneOuterGain:0,distanceModel:typeof n.distanceModel<"u"?n.distanceModel:"inverse",maxDistance:typeof n.maxDistance<"u"?n.maxDistance:1e4,panningModel:typeof n.panningModel<"u"?n.panningModel:"HRTF",refDistance:typeof n.refDistance<"u"?n.refDistance:1,rolloffFactor:typeof n.rolloffFactor<"u"?n.rolloffFactor:1},s._onstereo=n.onstereo?[{fn:n.onstereo}]:[],s._onpos=n.onpos?[{fn:n.onpos}]:[],s._onorientation=n.onorientation?[{fn:n.onorientation}]:[],t.call(this,n)}}(Howl.prototype.init),Howl.prototype.stereo=function(t,n){var s=this;if(!s._webAudio)return s;if(s._state!=="loaded")return s._queue.push({event:"stereo",action:function(){s.stereo(t,n)}}),s;var r=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof n>"u")if(typeof t=="number")s._stereo=t,s._pos=[t,0,0];else return s._stereo;for(var o=s._getSoundIds(n),l=0;l<o.length;l++){var c=s._soundById(o[l]);if(c)if(typeof t=="number")c._stereo=t,c._pos=[t,0,0],c._node&&(c._pannerAttr.panningModel="equalpower",(!c._panner||!c._panner.pan)&&e(c,r),r==="spatial"?typeof c._panner.positionX<"u"?(c._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),c._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),c._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):c._panner.setPosition(t,0,0):c._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),s._emit("stereo",c._id);else return c._stereo}return s},Howl.prototype.pos=function(t,n,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"pos",action:function(){o.pos(t,n,s,r)}}),o;if(n=typeof n!="number"?0:n,s=typeof s!="number"?-.5:s,typeof r>"u")if(typeof t=="number")o._pos=[t,n,s];else return o._pos;for(var l=o._getSoundIds(r),c=0;c<l.length;c++){var u=o._soundById(l[c]);if(u)if(typeof t=="number")u._pos=[t,n,s],u._node&&((!u._panner||u._panner.pan)&&e(u,"spatial"),typeof u._panner.positionX<"u"?(u._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.positionY.setValueAtTime(n,Howler.ctx.currentTime),u._panner.positionZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setPosition(t,n,s)),o._emit("pos",u._id);else return u._pos}return o},Howl.prototype.orientation=function(t,n,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"orientation",action:function(){o.orientation(t,n,s,r)}}),o;if(n=typeof n!="number"?o._orientation[1]:n,s=typeof s!="number"?o._orientation[2]:s,typeof r>"u")if(typeof t=="number")o._orientation=[t,n,s];else return o._orientation;for(var l=o._getSoundIds(r),c=0;c<l.length;c++){var u=o._soundById(l[c]);if(u)if(typeof t=="number")u._orientation=[t,n,s],u._node&&(u._panner||(u._pos||(u._pos=o._pos||[0,0,-.5]),e(u,"spatial")),typeof u._panner.orientationX<"u"?(u._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.orientationY.setValueAtTime(n,Howler.ctx.currentTime),u._panner.orientationZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setOrientation(t,n,s)),o._emit("orientation",u._id);else return u._orientation}return o},Howl.prototype.pannerAttr=function(){var t=this,n=arguments,s,r,o;if(!t._webAudio)return t;if(n.length===0)return t._pannerAttr;if(n.length===1)if(typeof n[0]=="object")s=n[0],typeof r>"u"&&(s.pannerAttr||(s.pannerAttr={coneInnerAngle:s.coneInnerAngle,coneOuterAngle:s.coneOuterAngle,coneOuterGain:s.coneOuterGain,distanceModel:s.distanceModel,maxDistance:s.maxDistance,refDistance:s.refDistance,rolloffFactor:s.rolloffFactor,panningModel:s.panningModel}),t._pannerAttr={coneInnerAngle:typeof s.pannerAttr.coneInnerAngle<"u"?s.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof s.pannerAttr.coneOuterAngle<"u"?s.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof s.pannerAttr.coneOuterGain<"u"?s.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof s.pannerAttr.distanceModel<"u"?s.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof s.pannerAttr.maxDistance<"u"?s.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof s.pannerAttr.refDistance<"u"?s.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof s.pannerAttr.rolloffFactor<"u"?s.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof s.pannerAttr.panningModel<"u"?s.pannerAttr.panningModel:t._panningModel});else return o=t._soundById(parseInt(n[0],10)),o?o._pannerAttr:t._pannerAttr;else n.length===2&&(s=n[0],r=parseInt(n[1],10));for(var l=t._getSoundIds(r),c=0;c<l.length;c++)if(o=t._soundById(l[c]),o){var u=o._pannerAttr;u={coneInnerAngle:typeof s.coneInnerAngle<"u"?s.coneInnerAngle:u.coneInnerAngle,coneOuterAngle:typeof s.coneOuterAngle<"u"?s.coneOuterAngle:u.coneOuterAngle,coneOuterGain:typeof s.coneOuterGain<"u"?s.coneOuterGain:u.coneOuterGain,distanceModel:typeof s.distanceModel<"u"?s.distanceModel:u.distanceModel,maxDistance:typeof s.maxDistance<"u"?s.maxDistance:u.maxDistance,refDistance:typeof s.refDistance<"u"?s.refDistance:u.refDistance,rolloffFactor:typeof s.rolloffFactor<"u"?s.rolloffFactor:u.rolloffFactor,panningModel:typeof s.panningModel<"u"?s.panningModel:u.panningModel};var d=o._panner;d||(o._pos||(o._pos=t._pos||[0,0,-.5]),e(o,"spatial"),d=o._panner),d.coneInnerAngle=u.coneInnerAngle,d.coneOuterAngle=u.coneOuterAngle,d.coneOuterGain=u.coneOuterGain,d.distanceModel=u.distanceModel,d.maxDistance=u.maxDistance,d.refDistance=u.refDistance,d.rolloffFactor=u.rolloffFactor,d.panningModel=u.panningModel}return t},Sound.prototype.init=function(t){return function(){var n=this,s=n._parent;n._orientation=s._orientation,n._stereo=s._stereo,n._pos=s._pos,n._pannerAttr=s._pannerAttr,t.call(this),n._stereo?s.stereo(n._stereo):n._pos&&s.pos(n._pos[0],n._pos[1],n._pos[2],n._id)}}(Sound.prototype.init),Sound.prototype.reset=function(t){return function(){var n=this,s=n._parent;return n._orientation=s._orientation,n._stereo=s._stereo,n._pos=s._pos,n._pannerAttr=s._pannerAttr,n._stereo?s.stereo(n._stereo):n._pos?s.pos(n._pos[0],n._pos[1],n._pos[2],n._id):n._panner&&(n._panner.disconnect(0),n._panner=void 0,s._refreshBuffer(n)),t.call(this)}}(Sound.prototype.reset);var e=function(t,n){n=n||"spatial",n==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()}(_c)),_c}var cr=vv();const Td=["kenney/back_001.ogg","kenney/back_002.ogg","kenney/back_003.ogg","kenney/back_004.ogg","kenney/bong_001.ogg","chess/celebrate1.ogg","chess/celebrate2.ogg","chess/celebrate3.ogg","chess/celebrate4.ogg","chess/celebrate5.ogg","kenney/click_002.ogg","kenney/click_001.ogg","kenney/click_003.ogg","kenney/click_004.ogg","kenney/click_005.ogg","kenney/close_001.ogg","kenney/close_002.ogg","kenney/close_003.ogg","kenney/close_004.ogg","kenney/drop_001.ogg","kenney/drop_002.ogg","kenney/drop_003.ogg","kenney/drop_004.ogg","kenney/error_004.ogg","kenney/error_005.ogg","kenney/error_001.ogg","kenney/error_002.ogg","kenney/error_003.ogg","kenney/error_006.ogg","kenney/error_007.ogg","kenney/error_008.ogg","kenney/glass_005.ogg","kenney/glass_006.ogg","kenney/glass_001.ogg","kenney/glass_002.ogg","kenney/glass_003.ogg","kenney/glass_004.ogg","kenney/impactWood_medium_000.ogg","kenney/impactWood_medium_001.ogg","kenney/impactWood_medium_002.ogg","kenney/impactWood_medium_003.ogg","kenney/impactWood_medium_004.ogg","kenney/minimize_006.ogg","kenney/minimize_001.ogg","kenney/minimize_002.ogg","kenney/minimize_003.ogg","kenney/minimize_004.ogg","kenney/minimize_005.ogg","kenney/minimize_007.ogg","kenney/minimize_008.ogg","kenney/minimize_009.ogg","kenney/maximize_001.ogg","kenney/maximize_002.ogg","kenney/maximize_003.ogg","kenney/maximize_004.ogg","kenney/maximize_005.ogg","kenney/maximize_006.ogg","kenney/maximize_007.ogg","kenney/maximize_008.ogg","kenney/maximize_009.ogg","kenney/open_001.ogg","kenney/open_002.ogg","kenney/open_003.ogg","kenney/open_004.ogg","kenney/pluck_001.ogg","kenney/pluck_002.ogg","kenney/question_001.ogg","kenney/question_002.ogg","kenney/question_003.ogg","kenney/question_004.ogg","kenney/select_001.ogg","kenney/select_002.ogg","kenney/select_006.ogg","kenney/select_003.ogg","kenney/select_004.ogg","kenney/select_005.ogg","kenney/select_007.ogg","kenney/select_008.ogg","kenney/scratch_001.ogg","kenney/scratch_002.ogg","kenney/scratch_003.ogg","kenney/scratch_004.ogg","kenney/scratch_005.ogg","kenney/scroll_001.ogg","kenney/scroll_002.ogg","kenney/scroll_003.ogg","kenney/scroll_004.ogg","kenney/scroll_005.ogg","kenney/switch_001.ogg","kenney/switch_002.ogg","kenney/switch_003.ogg","kenney/switch_004.ogg","kenney/switch_005.ogg","kenney/switch_006.ogg","kenney/switch_007.ogg","kenney/tick_001.ogg","kenney/tick_002.ogg","kenney/tick_004.ogg","kenney/toggle_001.ogg","kenney/toggle_002.ogg","kenney/toggle_003.ogg","kenney/toggle_004.ogg","kenney/confirmation_001.ogg","kenney/confirmation_002.ogg","kenney/confirmation_003.ogg","kenney/confirmation_004.ogg","kenney/glitch_001.ogg","kenney/glitch_002.ogg","kenney/glitch_003.ogg","kenney/glitch_004.ogg"],cu=new Map;function M_(i){return cu.get(i)}async function bv(){return Td.map(async i=>{cu.set(i,new cr.Howl({src:[`sounds/${i}`],format:["ogg"]}))}),Promise.all(Object.values(cu).map(i=>new Promise((e,t)=>{const n=i;n.once("load",e),n.once("loaderror",t)})))}function Mv(i){const e=i.indexOf("/");return e===-1?"misc":i.slice(0,e)}Object.fromEntries(Td.map(i=>[i.replace(/[./]/g,"_"),[i]]));const wv=Td.reduce((i,e)=>{const t=Mv(e);return i[t]||(i[t]={}),i[t][`sound-${e.replace(/[./]/g,"_")}`]={label:e,action:()=>{const n=M_(e);n.volume(.1),n.play()}},i},{}),Sv=Object.fromEntries(Object.entries(wv).map(([i,e])=>[i,{children:e}])),Ev={children:{musicVolume:{value:.5,min:0,max:1,step:.01},sfxVolume:{value:.5,min:0,max:1,step:.01},...yv,...Sv}},Lf=class Lf extends tt{constructor(){super(...arguments);E(this,"tree",Ev)}};tt.register("audio",()=>new Lf);let Pp=Lf;const Ci=tt.create("audio"),Av=["debussy","satie","mozart","chopin","mendelssohn","retroindiejosh_mysterious-wave"],Cd={debussy:{src:"music/debussy.ogg",volume:.1},satie:{src:"music/satie.ogg",volume:.1},mozart:{src:"music/mozart.ogg",volume:.1},chopin:{src:"music/chopin.ogg",volume:.1},mendelssohn:{src:"music/mendelssohn.ogg",volume:.1},"retroindiejosh_mysterious-wave":{src:"music/retroindiejosh_mysterious-wave.ogg",volume:.2}},ic=["satie","debussy","mozart"],Tv=["chopin"],Cv=["mendelssohn"],Rv=["retroindiejosh_mysterious-wave"];let hu=ic,cl=Cd[Av[0]],vi=null,w_=!1,Ip=-1;function hr(i){i&&(hu=i),w_=!0,S_()}function S_(){if(!w_)return;const i=(Ip+1)%hu.length,e=hu[i];cl=Cd[e];const{src:t}=cl;Ip=i,vi&&(vi.stop(),vi.unload(),vi=null),vi=new cr.Howl({src:[t],format:["ogg"],volume:E_(cl),html5:!0,onend:()=>{S_()}}),vi.play()}function Pv(){vi&&vi.volume(E_(cl))}function E_(i){return i.volume*Ci.tree.children.musicVolume.value}function Rd(i){return Object.entries(i)}const A_={hover:["kenney/glass_005.ogg"],unhover:["kenney/glass_006.ogg"],click:["kenney/select_002.ogg"],unclick:["kenney/select_001.ogg"],collapse:["kenney/minimize_006.ogg"],smStart:["kenney/confirmation_002.ogg"],smNav:["kenney/drop_001.ogg"],settingsOpen:["kenney/maximize_006.ogg"],settingsClose:["kenney/drop_004.ogg"],chessClick:["kenney/click_002.ogg"],chessCancel:["kenney/error_004.ogg"],chessLand:["kenney/impactWood_medium_000.ogg","kenney/impactWood_medium_001.ogg","kenney/impactWood_medium_002.ogg","kenney/impactWood_medium_003.ogg","kenney/impactWood_medium_004.ogg"],chessGoodCapture:["kenney/select_006.ogg"],chessBadCapture:["kenney/error_005.ogg"],chessJump:["kenney/drop_001.ogg"],chessCelebrate:["chess/celebrate1.ogg","chess/celebrate2.ogg","chess/celebrate3.ogg","chess/celebrate4.ogg","chess/celebrate5.ogg"]};function Iv(){for(const[i,e]of Rd(A_))Pd[i]=e.map(t=>M_(t))}const Pd={};function Ye(i){if(cr.Howler.ctx.state==="running"){const e=Pd[i];if(!e||e.length===0)return;const t=e[Math.floor(Math.random()*e.length)],n=Ci.tree.children.enabled.children;t.volume(n[`sound-${i}`].value*Ci.tree.children.sfxVolume.value),t.stop(),t.play()}else cr.Howler.ctx.resume()}function Lv(){for(const i in A_){const e=Dv(i);for(const t of Pd[i])t.volume(e)}}function Dv(i){return Ci.tree.children.enabled.children[`sound-${i}`].value*Ci.tree.children.sfxVolume.value}const Uv={children:{}},Df=class Df extends tt{constructor(){super(...arguments);E(this,"tree",Uv)}};tt.register("chess",()=>new Df);let Lp=Df;tt.create("chess");const Ov=5e-4,Fv=3e-4,Nv=1e-4,kv=1e-4,Bv=1e-5,zv=1,Hv=.2,Vv={tooltip:"settings for spheres and waves",children:{FLORA_FRICTION:{value:Ov,min:0,max:1,step:1e-5,tooltip:"fraction of tile speed lost per step"},FLORA_SPRING:{value:Fv,min:0,max:.01,step:1e-5,tooltip:"springs pushing flora tile towards neighboring tiles' heights"},FLORA_CENTERING:{value:Nv,min:0,max:.01,step:1e-5,tooltip:"spring pushing flora tile towards neutral position"},FLORA_DAMPING:{value:kv,min:0,max:.01,step:1e-5,tooltip:"damping for flora tile springs"},FLORA_TEMPERATURE:{value:Bv,min:0,max:.01,step:1e-5,tooltip:"random acceleration for flora"},FLORA_AMPLITUDE:{value:zv,min:0,max:50,step:.1,tooltip:"multiplier for flora position changes"},FLORA_LIMIT:{value:Hv,min:0,max:50,step:.1,tooltip:"limit for flora position changes"}}},Uf=class Uf extends tt{constructor(){super(...arguments);E(this,"tree",Vv)}};tt.register("flora",()=>new Uf);let Dp=Uf;const T_=tt.create("flora"),Gv={children:{CAM_ACCEL:{value:2e-4,min:0,max:5e-4,step:1e-6,tooltip:"camera movement acceleration"}}},Of=class Of extends tt{constructor(){super(...arguments);E(this,"tree",Gv)}};tt.register("free-cam",()=>new Of);let Up=Of;const as=tt.create("free-cam");/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Id="177",er={ROTATE:0,DOLLY:1,PAN:2},$s={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Wv=0,Op=1,Xv=2,C_=1,$v=2,ii=3,Ri=0,Wt=1,kn=2,Ei=0,tr=1,Fp=2,Np=3,kp=4,Yv=5,qi=100,qv=101,jv=102,Kv=103,Zv=104,Jv=200,Qv=201,e1=202,t1=203,uu=204,du=205,n1=206,i1=207,s1=208,r1=209,o1=210,a1=211,l1=212,c1=213,h1=214,fu=0,pu=1,mu=2,ur=3,gu=4,_u=5,xu=6,yu=7,sc=0,u1=1,d1=2,Ai=0,f1=1,p1=2,m1=3,g1=4,_1=5,x1=6,y1=7,R_=300,dr=301,fr=302,vu=303,bu=304,rc=306,Mu=1e3,ts=1001,wu=1002,ln=1003,v1=1004,Bo=1005,Bn=1006,xc=1007,ns=1008,Wn=1009,P_=1010,I_=1011,lo=1012,Ld=1013,ls=1014,zn=1015,Co=1016,Dd=1017,Ud=1018,co=1020,L_=35902,D_=1021,U_=1022,Rn=1023,ho=1026,uo=1027,Od=1028,Fd=1029,O_=1030,Nd=1031,kd=1033,hl=33776,ul=33777,dl=33778,fl=33779,Su=35840,Eu=35841,Au=35842,Tu=35843,Cu=36196,Ru=37492,Pu=37496,Iu=37808,Lu=37809,Du=37810,Uu=37811,Ou=37812,Fu=37813,Nu=37814,ku=37815,Bu=37816,zu=37817,Hu=37818,Vu=37819,Gu=37820,Wu=37821,pl=36492,Xu=36494,$u=36495,F_=36283,Yu=36284,qu=36285,ju=36286,b1=3200,M1=3201,Bd=0,w1=1,Mi="",on="srgb",pr="srgb-linear",Tl="linear",lt="srgb",Ms=7680,Bp=519,S1=512,E1=513,A1=514,N_=515,T1=516,C1=517,R1=518,P1=519,zp=35044,Hp="300 es",ai=2e3,Cl=2001;class xs{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const Ft=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],ml=Math.PI/180,Ku=180/Math.PI;function Ro(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ft[i&255]+Ft[i>>8&255]+Ft[i>>16&255]+Ft[i>>24&255]+"-"+Ft[e&255]+Ft[e>>8&255]+"-"+Ft[e>>16&15|64]+Ft[e>>24&255]+"-"+Ft[t&63|128]+Ft[t>>8&255]+"-"+Ft[t>>16&255]+Ft[t>>24&255]+Ft[n&255]+Ft[n>>8&255]+Ft[n>>16&255]+Ft[n>>24&255]).toLowerCase()}function Ge(i,e,t){return Math.max(e,Math.min(t,i))}function I1(i,e){return(i%e+e)%e}function yc(i,e,t){return(1-t)*i+t*e}function Rr(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function $t(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const L1={DEG2RAD:ml};class xe{constructor(e=0,t=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),xe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ge(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Pi{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,l){let c=n[s+0],u=n[s+1],d=n[s+2],a=n[s+3];const h=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(l===0){e[t+0]=c,e[t+1]=u,e[t+2]=d,e[t+3]=a;return}if(l===1){e[t+0]=h,e[t+1]=f,e[t+2]=g,e[t+3]=_;return}if(a!==_||c!==h||u!==f||d!==g){let m=1-l;const p=c*h+u*f+d*g+a*_,x=p>=0?1:-1,b=1-p*p;if(b>Number.EPSILON){const P=Math.sqrt(b),C=Math.atan2(P,p*x);m=Math.sin(m*C)/P,l=Math.sin(l*C)/P}const v=l*x;if(c=c*m+h*v,u=u*m+f*v,d=d*m+g*v,a=a*m+_*v,m===1-l){const P=1/Math.sqrt(c*c+u*u+d*d+a*a);c*=P,u*=P,d*=P,a*=P}}e[t]=c,e[t+1]=u,e[t+2]=d,e[t+3]=a}static multiplyQuaternionsFlat(e,t,n,s,r,o){const l=n[s],c=n[s+1],u=n[s+2],d=n[s+3],a=r[o],h=r[o+1],f=r[o+2],g=r[o+3];return e[t]=l*g+d*a+c*f-u*h,e[t+1]=c*g+d*h+u*a-l*f,e[t+2]=u*g+d*f+l*h-c*a,e[t+3]=d*g-l*a-c*h-u*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,o=e._order,l=Math.cos,c=Math.sin,u=l(n/2),d=l(s/2),a=l(r/2),h=c(n/2),f=c(s/2),g=c(r/2);switch(o){case"XYZ":this._x=h*d*a+u*f*g,this._y=u*f*a-h*d*g,this._z=u*d*g+h*f*a,this._w=u*d*a-h*f*g;break;case"YXZ":this._x=h*d*a+u*f*g,this._y=u*f*a-h*d*g,this._z=u*d*g-h*f*a,this._w=u*d*a+h*f*g;break;case"ZXY":this._x=h*d*a-u*f*g,this._y=u*f*a+h*d*g,this._z=u*d*g+h*f*a,this._w=u*d*a-h*f*g;break;case"ZYX":this._x=h*d*a-u*f*g,this._y=u*f*a+h*d*g,this._z=u*d*g-h*f*a,this._w=u*d*a+h*f*g;break;case"YZX":this._x=h*d*a+u*f*g,this._y=u*f*a+h*d*g,this._z=u*d*g-h*f*a,this._w=u*d*a-h*f*g;break;case"XZY":this._x=h*d*a-u*f*g,this._y=u*f*a-h*d*g,this._z=u*d*g+h*f*a,this._w=u*d*a+h*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],l=t[5],c=t[9],u=t[2],d=t[6],a=t[10],h=n+l+a;if(h>0){const f=.5/Math.sqrt(h+1);this._w=.25/f,this._x=(d-c)*f,this._y=(r-u)*f,this._z=(o-s)*f}else if(n>l&&n>a){const f=2*Math.sqrt(1+n-l-a);this._w=(d-c)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+u)/f}else if(l>a){const f=2*Math.sqrt(1+l-n-a);this._w=(r-u)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(c+d)/f}else{const f=2*Math.sqrt(1+a-n-l);this._w=(o-s)/f,this._x=(r+u)/f,this._y=(c+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ge(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,o=e._w,l=t._x,c=t._y,u=t._z,d=t._w;return this._x=n*d+o*l+s*u-r*c,this._y=s*d+o*c+r*l-n*u,this._z=r*d+o*u+n*c-s*l,this._w=o*d-n*l-s*c-r*u,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,s=this._y,r=this._z,o=this._w;let l=o*e._w+n*e._x+s*e._y+r*e._z;if(l<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,l=-l):this.copy(e),l>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;const c=1-l*l;if(c<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}const u=Math.sqrt(c),d=Math.atan2(u,l),a=Math.sin((1-t)*d)/u,h=Math.sin(t*d)/u;return this._w=o*a+this._w*h,this._x=n*a+this._x*h,this._y=s*a+this._y*h,this._z=r*a+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class A{constructor(e=0,t=0,n=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),A.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Vp.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Vp.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,l=e.z,c=e.w,u=2*(o*s-l*n),d=2*(l*t-r*s),a=2*(r*n-o*t);return this.x=t+c*u+o*a-l*d,this.y=n+c*d+l*u-r*a,this.z=s+c*a+r*d-o*u,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this.z=Ge(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this.z=Ge(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,o=t.x,l=t.y,c=t.z;return this.x=s*c-r*l,this.y=r*o-n*c,this.z=n*l-s*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return vc.copy(this).projectOnVector(e),this.sub(vc)}reflect(e){return this.sub(vc.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ge(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const vc=new A,Vp=new Pi;class Be{constructor(e,t,n,s,r,o,l,c,u){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),Be.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,l,c,u)}set(e,t,n,s,r,o,l,c,u){const d=this.elements;return d[0]=e,d[1]=s,d[2]=l,d[3]=t,d[4]=r,d[5]=c,d[6]=n,d[7]=o,d[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],l=n[3],c=n[6],u=n[1],d=n[4],a=n[7],h=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],x=s[1],b=s[4],v=s[7],P=s[2],C=s[5],T=s[8];return r[0]=o*_+l*x+c*P,r[3]=o*m+l*b+c*C,r[6]=o*p+l*v+c*T,r[1]=u*_+d*x+a*P,r[4]=u*m+d*b+a*C,r[7]=u*p+d*v+a*T,r[2]=h*_+f*x+g*P,r[5]=h*m+f*b+g*C,r[8]=h*p+f*v+g*T,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],l=e[5],c=e[6],u=e[7],d=e[8];return t*o*d-t*l*u-n*r*d+n*l*c+s*r*u-s*o*c}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],l=e[5],c=e[6],u=e[7],d=e[8],a=d*o-l*u,h=l*c-d*r,f=u*r-o*c,g=t*a+n*h+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return e[0]=a*_,e[1]=(s*u-d*n)*_,e[2]=(l*n-s*o)*_,e[3]=h*_,e[4]=(d*t-s*c)*_,e[5]=(s*r-l*t)*_,e[6]=f*_,e[7]=(n*c-u*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,l){const c=Math.cos(r),u=Math.sin(r);return this.set(n*c,n*u,-n*(c*o+u*l)+o+e,-s*u,s*c,-s*(-u*o+c*l)+l+t,0,0,1),this}scale(e,t){return this.premultiply(bc.makeScale(e,t)),this}rotate(e){return this.premultiply(bc.makeRotation(-e)),this}translate(e,t){return this.premultiply(bc.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const bc=new Be;function k_(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Rl(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function D1(){const i=Rl("canvas");return i.style.display="block",i}const Gp={};function nr(i){i in Gp||(Gp[i]=!0,console.warn(i))}function U1(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}function O1(i){const e=i.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function F1(i){const e=i.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const Wp=new Be().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Xp=new Be().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function N1(){const i={enabled:!0,workingColorSpace:pr,spaces:{},convert:function(s,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===lt&&(s.r=li(s.r),s.g=li(s.g),s.b=li(s.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===lt&&(s.r=ir(s.r),s.g=ir(s.g),s.b=ir(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Mi?Tl:this.spaces[s].transfer},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return nr("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return nr("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[pr]:{primaries:e,whitePoint:n,transfer:Tl,toXYZ:Wp,fromXYZ:Xp,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:on},outputColorSpaceConfig:{drawingBufferColorSpace:on}},[on]:{primaries:e,whitePoint:n,transfer:lt,toXYZ:Wp,fromXYZ:Xp,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:on}}}),i}const Ke=N1();function li(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ir(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let ws;class k1{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ws===void 0&&(ws=Rl("canvas")),ws.width=e.width,ws.height=e.height;const s=ws.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=ws}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Rl("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=li(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(li(t[n]/255)*255):t[n]=li(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let B1=0;class zd{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:B1++}),this.uuid=Ro(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,l=s.length;o<l;o++)s[o].isDataTexture?r.push(Mc(s[o].image)):r.push(Mc(s[o]))}else r=Mc(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function Mc(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?k1.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let z1=0;const wc=new A;class kt extends xs{constructor(e=kt.DEFAULT_IMAGE,t=kt.DEFAULT_MAPPING,n=ts,s=ts,r=Bn,o=ns,l=Rn,c=Wn,u=kt.DEFAULT_ANISOTROPY,d=Mi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:z1++}),this.uuid=Ro(),this.name="",this.source=new zd(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=u,this.format=l,this.internalFormat=null,this.type=c,this.offset=new xe(0,0),this.repeat=new xe(1,1),this.center=new xe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Be,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(wc).x}get height(){return this.source.getSize(wc).y}get depth(){return this.source.getSize(wc).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==R_)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Mu:e.x=e.x-Math.floor(e.x);break;case ts:e.x=e.x<0?0:1;break;case wu:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Mu:e.y=e.y-Math.floor(e.y);break;case ts:e.y=e.y<0?0:1;break;case wu:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}kt.DEFAULT_IMAGE=null;kt.DEFAULT_MAPPING=R_;kt.DEFAULT_ANISOTROPY=1;class Mt{constructor(e=0,t=0,n=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),Mt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const c=e.elements,u=c[0],d=c[4],a=c[8],h=c[1],f=c[5],g=c[9],_=c[2],m=c[6],p=c[10];if(Math.abs(d-h)<.01&&Math.abs(a-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+h)<.1&&Math.abs(a+_)<.1&&Math.abs(g+m)<.1&&Math.abs(u+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const b=(u+1)/2,v=(f+1)/2,P=(p+1)/2,C=(d+h)/4,T=(a+_)/4,D=(g+m)/4;return b>v&&b>P?b<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(b),s=C/n,r=T/n):v>P?v<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(v),n=C/s,r=D/s):P<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(P),n=T/r,s=D/r),this.set(n,s,r,t),this}let x=Math.sqrt((m-g)*(m-g)+(a-_)*(a-_)+(h-d)*(h-d));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(a-_)/x,this.z=(h-d)/x,this.w=Math.acos((u+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this.z=Ge(this.z,e.z,t.z),this.w=Ge(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this.z=Ge(this.z,e,t),this.w=Ge(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class H1 extends xs{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Bn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Mt(0,0,e,t),this.scissorTest=!1,this.viewport=new Mt(0,0,e,t);const s={width:e,height:t,depth:n.depth},r=new kt(s);this.textures=[];const o=n.count;for(let l=0;l<o;l++)this.textures[l]=r.clone(),this.textures[l].isRenderTargetTexture=!0,this.textures[l].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:Bn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isArrayTexture=this.textures[s].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new zd(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class cs extends H1{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class B_ extends kt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=ln,this.minFilter=ln,this.wrapR=ts,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class V1 extends kt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=ln,this.minFilter=ln,this.wrapR=ts,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Un{constructor(e=new A(1/0,1/0,1/0),t=new A(-1/0,-1/0,-1/0)){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Mn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Mn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Mn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,l=r.count;o<l;o++)e.isMesh===!0?e.getVertexPosition(o,Mn):Mn.fromBufferAttribute(r,o),Mn.applyMatrix4(e.matrixWorld),this.expandByPoint(Mn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),zo.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),zo.copy(n.boundingBox)),zo.applyMatrix4(e.matrixWorld),this.union(zo)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Mn),Mn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Pr),Ho.subVectors(this.max,Pr),Ss.subVectors(e.a,Pr),Es.subVectors(e.b,Pr),As.subVectors(e.c,Pr),ui.subVectors(Es,Ss),di.subVectors(As,Es),Ni.subVectors(Ss,As);let t=[0,-ui.z,ui.y,0,-di.z,di.y,0,-Ni.z,Ni.y,ui.z,0,-ui.x,di.z,0,-di.x,Ni.z,0,-Ni.x,-ui.y,ui.x,0,-di.y,di.x,0,-Ni.y,Ni.x,0];return!Sc(t,Ss,Es,As,Ho)||(t=[1,0,0,0,1,0,0,0,1],!Sc(t,Ss,Es,As,Ho))?!1:(Vo.crossVectors(ui,di),t=[Vo.x,Vo.y,Vo.z],Sc(t,Ss,Es,As,Ho))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Mn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Mn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(qn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),qn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),qn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),qn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),qn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),qn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),qn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),qn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(qn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const qn=[new A,new A,new A,new A,new A,new A,new A,new A],Mn=new A,zo=new Un,Ss=new A,Es=new A,As=new A,ui=new A,di=new A,Ni=new A,Pr=new A,Ho=new A,Vo=new A,ki=new A;function Sc(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){ki.fromArray(i,r);const l=s.x*Math.abs(ki.x)+s.y*Math.abs(ki.y)+s.z*Math.abs(ki.z),c=e.dot(ki),u=t.dot(ki),d=n.dot(ki);if(Math.max(-Math.max(c,u,d),Math.min(c,u,d))>l)return!1}return!0}const G1=new Un,Ir=new A,Ec=new A;class ys{constructor(e=new A,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):G1.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ir.subVectors(e,this.center);const t=Ir.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Ir,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Ec.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ir.copy(e.center).add(Ec)),this.expandByPoint(Ir.copy(e.center).sub(Ec))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const jn=new A,Ac=new A,Go=new A,fi=new A,Tc=new A,Wo=new A,Cc=new A;class Po{constructor(e=new A,t=new A(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,jn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=jn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(jn.copy(this.origin).addScaledVector(this.direction,t),jn.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Ac.copy(e).add(t).multiplyScalar(.5),Go.copy(t).sub(e).normalize(),fi.copy(this.origin).sub(Ac);const r=e.distanceTo(t)*.5,o=-this.direction.dot(Go),l=fi.dot(this.direction),c=-fi.dot(Go),u=fi.lengthSq(),d=Math.abs(1-o*o);let a,h,f,g;if(d>0)if(a=o*c-l,h=o*l-c,g=r*d,a>=0)if(h>=-g)if(h<=g){const _=1/d;a*=_,h*=_,f=a*(a+o*h+2*l)+h*(o*a+h+2*c)+u}else h=r,a=Math.max(0,-(o*h+l)),f=-a*a+h*(h+2*c)+u;else h=-r,a=Math.max(0,-(o*h+l)),f=-a*a+h*(h+2*c)+u;else h<=-g?(a=Math.max(0,-(-o*r+l)),h=a>0?-r:Math.min(Math.max(-r,-c),r),f=-a*a+h*(h+2*c)+u):h<=g?(a=0,h=Math.min(Math.max(-r,-c),r),f=h*(h+2*c)+u):(a=Math.max(0,-(o*r+l)),h=a>0?r:Math.min(Math.max(-r,-c),r),f=-a*a+h*(h+2*c)+u);else h=o>0?-r:r,a=Math.max(0,-(o*h+l)),f=-a*a+h*(h+2*c)+u;return n&&n.copy(this.origin).addScaledVector(this.direction,a),s&&s.copy(Ac).addScaledVector(Go,h),f}intersectSphere(e,t){jn.subVectors(e.center,this.origin);const n=jn.dot(this.direction),s=jn.dot(jn)-n*n,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),l=n-o,c=n+o;return c<0?null:l<0?this.at(c,t):this.at(l,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,l,c;const u=1/this.direction.x,d=1/this.direction.y,a=1/this.direction.z,h=this.origin;return u>=0?(n=(e.min.x-h.x)*u,s=(e.max.x-h.x)*u):(n=(e.max.x-h.x)*u,s=(e.min.x-h.x)*u),d>=0?(r=(e.min.y-h.y)*d,o=(e.max.y-h.y)*d):(r=(e.max.y-h.y)*d,o=(e.min.y-h.y)*d),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),a>=0?(l=(e.min.z-h.z)*a,c=(e.max.z-h.z)*a):(l=(e.max.z-h.z)*a,c=(e.min.z-h.z)*a),n>c||l>s)||((l>n||n!==n)&&(n=l),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,jn)!==null}intersectTriangle(e,t,n,s,r){Tc.subVectors(t,e),Wo.subVectors(n,e),Cc.crossVectors(Tc,Wo);let o=this.direction.dot(Cc),l;if(o>0){if(s)return null;l=1}else if(o<0)l=-1,o=-o;else return null;fi.subVectors(this.origin,e);const c=l*this.direction.dot(Wo.crossVectors(fi,Wo));if(c<0)return null;const u=l*this.direction.dot(Tc.cross(fi));if(u<0||c+u>o)return null;const d=-l*fi.dot(Cc);return d<0?null:this.at(d/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class We{constructor(e,t,n,s,r,o,l,c,u,d,a,h,f,g,_,m){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),We.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,l,c,u,d,a,h,f,g,_,m)}set(e,t,n,s,r,o,l,c,u,d,a,h,f,g,_,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=l,p[13]=c,p[2]=u,p[6]=d,p[10]=a,p[14]=h,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new We().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,s=1/Ts.setFromMatrixColumn(e,0).length(),r=1/Ts.setFromMatrixColumn(e,1).length(),o=1/Ts.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),l=Math.sin(n),c=Math.cos(s),u=Math.sin(s),d=Math.cos(r),a=Math.sin(r);if(e.order==="XYZ"){const h=o*d,f=o*a,g=l*d,_=l*a;t[0]=c*d,t[4]=-c*a,t[8]=u,t[1]=f+g*u,t[5]=h-_*u,t[9]=-l*c,t[2]=_-h*u,t[6]=g+f*u,t[10]=o*c}else if(e.order==="YXZ"){const h=c*d,f=c*a,g=u*d,_=u*a;t[0]=h+_*l,t[4]=g*l-f,t[8]=o*u,t[1]=o*a,t[5]=o*d,t[9]=-l,t[2]=f*l-g,t[6]=_+h*l,t[10]=o*c}else if(e.order==="ZXY"){const h=c*d,f=c*a,g=u*d,_=u*a;t[0]=h-_*l,t[4]=-o*a,t[8]=g+f*l,t[1]=f+g*l,t[5]=o*d,t[9]=_-h*l,t[2]=-o*u,t[6]=l,t[10]=o*c}else if(e.order==="ZYX"){const h=o*d,f=o*a,g=l*d,_=l*a;t[0]=c*d,t[4]=g*u-f,t[8]=h*u+_,t[1]=c*a,t[5]=_*u+h,t[9]=f*u-g,t[2]=-u,t[6]=l*c,t[10]=o*c}else if(e.order==="YZX"){const h=o*c,f=o*u,g=l*c,_=l*u;t[0]=c*d,t[4]=_-h*a,t[8]=g*a+f,t[1]=a,t[5]=o*d,t[9]=-l*d,t[2]=-u*d,t[6]=f*a+g,t[10]=h-_*a}else if(e.order==="XZY"){const h=o*c,f=o*u,g=l*c,_=l*u;t[0]=c*d,t[4]=-a,t[8]=u*d,t[1]=h*a+_,t[5]=o*d,t[9]=f*a-g,t[2]=g*a-f,t[6]=l*d,t[10]=_*a+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(W1,e,X1)}lookAt(e,t,n){const s=this.elements;return tn.subVectors(e,t),tn.lengthSq()===0&&(tn.z=1),tn.normalize(),pi.crossVectors(n,tn),pi.lengthSq()===0&&(Math.abs(n.z)===1?tn.x+=1e-4:tn.z+=1e-4,tn.normalize(),pi.crossVectors(n,tn)),pi.normalize(),Xo.crossVectors(tn,pi),s[0]=pi.x,s[4]=Xo.x,s[8]=tn.x,s[1]=pi.y,s[5]=Xo.y,s[9]=tn.y,s[2]=pi.z,s[6]=Xo.z,s[10]=tn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],l=n[4],c=n[8],u=n[12],d=n[1],a=n[5],h=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],x=n[3],b=n[7],v=n[11],P=n[15],C=s[0],T=s[4],D=s[8],w=s[12],M=s[1],I=s[5],B=s[9],N=s[13],V=s[2],Y=s[6],$=s[10],Q=s[14],G=s[3],ce=s[7],fe=s[11],Re=s[15];return r[0]=o*C+l*M+c*V+u*G,r[4]=o*T+l*I+c*Y+u*ce,r[8]=o*D+l*B+c*$+u*fe,r[12]=o*w+l*N+c*Q+u*Re,r[1]=d*C+a*M+h*V+f*G,r[5]=d*T+a*I+h*Y+f*ce,r[9]=d*D+a*B+h*$+f*fe,r[13]=d*w+a*N+h*Q+f*Re,r[2]=g*C+_*M+m*V+p*G,r[6]=g*T+_*I+m*Y+p*ce,r[10]=g*D+_*B+m*$+p*fe,r[14]=g*w+_*N+m*Q+p*Re,r[3]=x*C+b*M+v*V+P*G,r[7]=x*T+b*I+v*Y+P*ce,r[11]=x*D+b*B+v*$+P*fe,r[15]=x*w+b*N+v*Q+P*Re,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],l=e[5],c=e[9],u=e[13],d=e[2],a=e[6],h=e[10],f=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+r*c*a-s*u*a-r*l*h+n*u*h+s*l*f-n*c*f)+_*(+t*c*f-t*u*h+r*o*h-s*o*f+s*u*d-r*c*d)+m*(+t*u*a-t*l*f-r*o*a+n*o*f+r*l*d-n*u*d)+p*(-s*l*d-t*c*a+t*l*h+s*o*a-n*o*h+n*c*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],l=e[5],c=e[6],u=e[7],d=e[8],a=e[9],h=e[10],f=e[11],g=e[12],_=e[13],m=e[14],p=e[15],x=a*m*u-_*h*u+_*c*f-l*m*f-a*c*p+l*h*p,b=g*h*u-d*m*u-g*c*f+o*m*f+d*c*p-o*h*p,v=d*_*u-g*a*u+g*l*f-o*_*f-d*l*p+o*a*p,P=g*a*c-d*_*c-g*l*h+o*_*h+d*l*m-o*a*m,C=t*x+n*b+s*v+r*P;if(C===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const T=1/C;return e[0]=x*T,e[1]=(_*h*r-a*m*r-_*s*f+n*m*f+a*s*p-n*h*p)*T,e[2]=(l*m*r-_*c*r+_*s*u-n*m*u-l*s*p+n*c*p)*T,e[3]=(a*c*r-l*h*r-a*s*u+n*h*u+l*s*f-n*c*f)*T,e[4]=b*T,e[5]=(d*m*r-g*h*r+g*s*f-t*m*f-d*s*p+t*h*p)*T,e[6]=(g*c*r-o*m*r-g*s*u+t*m*u+o*s*p-t*c*p)*T,e[7]=(o*h*r-d*c*r+d*s*u-t*h*u-o*s*f+t*c*f)*T,e[8]=v*T,e[9]=(g*a*r-d*_*r-g*n*f+t*_*f+d*n*p-t*a*p)*T,e[10]=(o*_*r-g*l*r+g*n*u-t*_*u-o*n*p+t*l*p)*T,e[11]=(d*l*r-o*a*r-d*n*u+t*a*u+o*n*f-t*l*f)*T,e[12]=P*T,e[13]=(d*_*s-g*a*s+g*n*h-t*_*h-d*n*m+t*a*m)*T,e[14]=(g*l*s-o*_*s-g*n*c+t*_*c+o*n*m-t*l*m)*T,e[15]=(o*a*s-d*l*s+d*n*c-t*a*c-o*n*h+t*l*h)*T,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,l=e.y,c=e.z,u=r*o,d=r*l;return this.set(u*o+n,u*l-s*c,u*c+s*l,0,u*l+s*c,d*l+n,d*c-s*o,0,u*c-s*l,d*c+s*o,r*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,o=t._y,l=t._z,c=t._w,u=r+r,d=o+o,a=l+l,h=r*u,f=r*d,g=r*a,_=o*d,m=o*a,p=l*a,x=c*u,b=c*d,v=c*a,P=n.x,C=n.y,T=n.z;return s[0]=(1-(_+p))*P,s[1]=(f+v)*P,s[2]=(g-b)*P,s[3]=0,s[4]=(f-v)*C,s[5]=(1-(h+p))*C,s[6]=(m+x)*C,s[7]=0,s[8]=(g+b)*T,s[9]=(m-x)*T,s[10]=(1-(h+_))*T,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;let r=Ts.set(s[0],s[1],s[2]).length();const o=Ts.set(s[4],s[5],s[6]).length(),l=Ts.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],wn.copy(this);const u=1/r,d=1/o,a=1/l;return wn.elements[0]*=u,wn.elements[1]*=u,wn.elements[2]*=u,wn.elements[4]*=d,wn.elements[5]*=d,wn.elements[6]*=d,wn.elements[8]*=a,wn.elements[9]*=a,wn.elements[10]*=a,t.setFromRotationMatrix(wn),n.x=r,n.y=o,n.z=l,this}makePerspective(e,t,n,s,r,o,l=ai){const c=this.elements,u=2*r/(t-e),d=2*r/(n-s),a=(t+e)/(t-e),h=(n+s)/(n-s);let f,g;if(l===ai)f=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(l===Cl)f=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+l);return c[0]=u,c[4]=0,c[8]=a,c[12]=0,c[1]=0,c[5]=d,c[9]=h,c[13]=0,c[2]=0,c[6]=0,c[10]=f,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,r,o,l=ai){const c=this.elements,u=1/(t-e),d=1/(n-s),a=1/(o-r),h=(t+e)*u,f=(n+s)*d;let g,_;if(l===ai)g=(o+r)*a,_=-2*a;else if(l===Cl)g=r*a,_=-1*a;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+l);return c[0]=2*u,c[4]=0,c[8]=0,c[12]=-h,c[1]=0,c[5]=2*d,c[9]=0,c[13]=-f,c[2]=0,c[6]=0,c[10]=_,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const Ts=new A,wn=new We,W1=new A(0,0,0),X1=new A(1,1,1),pi=new A,Xo=new A,tn=new A,$p=new We,Yp=new Pi;class Ln{constructor(e=0,t=0,n=0,s=Ln.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],o=s[4],l=s[8],c=s[1],u=s[5],d=s[9],a=s[2],h=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Ge(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(h,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Ge(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(l,f),this._z=Math.atan2(c,u)):(this._y=Math.atan2(-a,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ge(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-a,f),this._z=Math.atan2(-o,u)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Ge(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,f),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,u));break;case"YZX":this._z=Math.asin(Ge(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-d,u),this._y=Math.atan2(-a,r)):(this._x=0,this._y=Math.atan2(l,f));break;case"XZY":this._z=Math.asin(-Ge(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(h,u),this._y=Math.atan2(l,r)):(this._x=Math.atan2(-d,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return $p.makeRotationFromQuaternion(e),this.setFromRotationMatrix($p,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Yp.setFromEuler(this),this.setFromQuaternion(Yp,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ln.DEFAULT_ORDER="XYZ";class Hd{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let $1=0;const qp=new A,Cs=new Pi,Kn=new We,$o=new A,Lr=new A,Y1=new A,q1=new Pi,jp=new A(1,0,0),Kp=new A(0,1,0),Zp=new A(0,0,1),Jp={type:"added"},j1={type:"removed"},Rs={type:"childadded",child:null},Rc={type:"childremoved",child:null};class gt extends xs{constructor(){super(),this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isObject3D=!0,Object.defineProperty(this,"id",{value:$1++}),this.uuid=Ro(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=gt.DEFAULT_UP.clone();const e=new A,t=new Ln,n=new Pi,s=new A(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new We},normalMatrix:{value:new Be}}),this.matrix=new We,this.matrixWorld=new We,this.matrixAutoUpdate=gt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=gt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Hd,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Cs.setFromAxisAngle(e,t),this.quaternion.multiply(Cs),this}rotateOnWorldAxis(e,t){return Cs.setFromAxisAngle(e,t),this.quaternion.premultiply(Cs),this}rotateX(e){return this.rotateOnAxis(jp,e)}rotateY(e){return this.rotateOnAxis(Kp,e)}rotateZ(e){return this.rotateOnAxis(Zp,e)}translateOnAxis(e,t){return qp.copy(e).applyQuaternion(this.quaternion),this.position.add(qp.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(jp,e)}translateY(e){return this.translateOnAxis(Kp,e)}translateZ(e){return this.translateOnAxis(Zp,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Kn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?$o.copy(e):$o.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Lr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Kn.lookAt(Lr,$o,this.up):Kn.lookAt($o,Lr,this.up),this.quaternion.setFromRotationMatrix(Kn),s&&(Kn.extractRotation(s.matrixWorld),Cs.setFromRotationMatrix(Kn),this.quaternion.premultiply(Cs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Jp),Rs.child=e,this.dispatchEvent(Rs),Rs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(j1),Rc.child=e,this.dispatchEvent(Rc),Rc.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Kn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Kn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Kn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Jp),Rs.child=e,this.dispatchEvent(Rs),Rs.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,e,Y1),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,q1,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(l=>({...l,boundingBox:l.boundingBox?l.boundingBox.toJSON():void 0,boundingSphere:l.boundingSphere?l.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(l=>({...l})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(l,c){return l[c.uuid]===void 0&&(l[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const l=this.geometry.parameters;if(l!==void 0&&l.shapes!==void 0){const c=l.shapes;if(Array.isArray(c))for(let u=0,d=c.length;u<d;u++){const a=c[u];r(e.shapes,a)}else r(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const l=[];for(let c=0,u=this.material.length;c<u;c++)l.push(r(e.materials,this.material[c]));s.material=l}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let l=0;l<this.children.length;l++)s.children.push(this.children[l].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let l=0;l<this.animations.length;l++){const c=this.animations[l];s.animations.push(r(e.animations,c))}}if(t){const l=o(e.geometries),c=o(e.materials),u=o(e.textures),d=o(e.images),a=o(e.shapes),h=o(e.skeletons),f=o(e.animations),g=o(e.nodes);l.length>0&&(n.geometries=l),c.length>0&&(n.materials=c),u.length>0&&(n.textures=u),d.length>0&&(n.images=d),a.length>0&&(n.shapes=a),h.length>0&&(n.skeletons=h),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(l){const c=[];for(const u in l){const d=l[u];delete d.metadata,c.push(d)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}gt.DEFAULT_UP=new A(0,1,0);gt.DEFAULT_MATRIX_AUTO_UPDATE=!0;gt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Sn=new A,Zn=new A,Pc=new A,Jn=new A,Ps=new A,Is=new A,Qp=new A,Ic=new A,Lc=new A,Dc=new A,Uc=new Mt,Oc=new Mt,Fc=new Mt;class Cn{constructor(e=new A,t=new A,n=new A){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Sn.subVectors(e,t),s.cross(Sn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){Sn.subVectors(s,t),Zn.subVectors(n,t),Pc.subVectors(e,t);const o=Sn.dot(Sn),l=Sn.dot(Zn),c=Sn.dot(Pc),u=Zn.dot(Zn),d=Zn.dot(Pc),a=o*u-l*l;if(a===0)return r.set(0,0,0),null;const h=1/a,f=(u*c-l*d)*h,g=(o*d-l*c)*h;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,Jn)===null?!1:Jn.x>=0&&Jn.y>=0&&Jn.x+Jn.y<=1}static getInterpolation(e,t,n,s,r,o,l,c){return this.getBarycoord(e,t,n,s,Jn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Jn.x),c.addScaledVector(o,Jn.y),c.addScaledVector(l,Jn.z),c)}static getInterpolatedAttribute(e,t,n,s,r,o){return Uc.setScalar(0),Oc.setScalar(0),Fc.setScalar(0),Uc.fromBufferAttribute(e,t),Oc.fromBufferAttribute(e,n),Fc.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Uc,r.x),o.addScaledVector(Oc,r.y),o.addScaledVector(Fc,r.z),o}static isFrontFacing(e,t,n,s){return Sn.subVectors(n,t),Zn.subVectors(e,t),Sn.cross(Zn).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Sn.subVectors(this.c,this.b),Zn.subVectors(this.a,this.b),Sn.cross(Zn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Cn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Cn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return Cn.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return Cn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Cn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let o,l;Ps.subVectors(s,n),Is.subVectors(r,n),Ic.subVectors(e,n);const c=Ps.dot(Ic),u=Is.dot(Ic);if(c<=0&&u<=0)return t.copy(n);Lc.subVectors(e,s);const d=Ps.dot(Lc),a=Is.dot(Lc);if(d>=0&&a<=d)return t.copy(s);const h=c*a-d*u;if(h<=0&&c>=0&&d<=0)return o=c/(c-d),t.copy(n).addScaledVector(Ps,o);Dc.subVectors(e,r);const f=Ps.dot(Dc),g=Is.dot(Dc);if(g>=0&&f<=g)return t.copy(r);const _=f*u-c*g;if(_<=0&&u>=0&&g<=0)return l=u/(u-g),t.copy(n).addScaledVector(Is,l);const m=d*g-f*a;if(m<=0&&a-d>=0&&f-g>=0)return Qp.subVectors(r,s),l=(a-d)/(a-d+(f-g)),t.copy(s).addScaledVector(Qp,l);const p=1/(m+_+h);return o=_*p,l=h*p,t.copy(n).addScaledVector(Ps,o).addScaledVector(Is,l)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const z_={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},mi={h:0,s:0,l:0},Yo={h:0,s:0,l:0};function Nc(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class se{constructor(e,t,n){return this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=on){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ke.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=Ke.workingColorSpace){return this.r=e,this.g=t,this.b=n,Ke.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=Ke.workingColorSpace){if(e=I1(e,1),t=Ge(t,0,1),n=Ge(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=Nc(o,r,e+1/3),this.g=Nc(o,r,e),this.b=Nc(o,r,e-1/3)}return Ke.colorSpaceToWorking(this,s),this}setStyle(e,t=on){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],l=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=on){const n=z_[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=li(e.r),this.g=li(e.g),this.b=li(e.b),this}copyLinearToSRGB(e){return this.r=ir(e.r),this.g=ir(e.g),this.b=ir(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=on){return Ke.workingToColorSpace(Nt.copy(this),e),Math.round(Ge(Nt.r*255,0,255))*65536+Math.round(Ge(Nt.g*255,0,255))*256+Math.round(Ge(Nt.b*255,0,255))}getHexString(e=on){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ke.workingColorSpace){Ke.workingToColorSpace(Nt.copy(this),t);const n=Nt.r,s=Nt.g,r=Nt.b,o=Math.max(n,s,r),l=Math.min(n,s,r);let c,u;const d=(l+o)/2;if(l===o)c=0,u=0;else{const a=o-l;switch(u=d<=.5?a/(o+l):a/(2-o-l),o){case n:c=(s-r)/a+(s<r?6:0);break;case s:c=(r-n)/a+2;break;case r:c=(n-s)/a+4;break}c/=6}return e.h=c,e.s=u,e.l=d,e}getRGB(e,t=Ke.workingColorSpace){return Ke.workingToColorSpace(Nt.copy(this),t),e.r=Nt.r,e.g=Nt.g,e.b=Nt.b,e}getStyle(e=on){Ke.workingToColorSpace(Nt.copy(this),e);const t=Nt.r,n=Nt.g,s=Nt.b;return e!==on?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(mi),this.setHSL(mi.h+e,mi.s+t,mi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(mi),e.getHSL(Yo);const n=yc(mi.h,Yo.h,t),s=yc(mi.s,Yo.s,t),r=yc(mi.l,Yo.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Nt=new se;se.NAMES=z_;let K1=0;class Xn extends xs{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:K1++}),this.uuid=Ro(),this.name="",this.type="Material",this.blending=tr,this.side=Ri,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=uu,this.blendDst=du,this.blendEquation=qi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new se(0,0,0),this.blendAlpha=0,this.depthFunc=ur,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Bp,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ms,this.stencilZFail=Ms,this.stencilZPass=Ms,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==tr&&(n.blending=this.blending),this.side!==Ri&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==uu&&(n.blendSrc=this.blendSrc),this.blendDst!==du&&(n.blendDst=this.blendDst),this.blendEquation!==qi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ur&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Bp&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ms&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ms&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ms&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const o=[];for(const l in r){const c=r[l];delete c.metadata,o.push(c)}return o}if(t){const r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class dt extends Xn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new se(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ln,this.combine=sc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Et=new A,qo=new xe;let Z1=0;class cn{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Z1++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=zp,this.updateRanges=[],this.gpuType=zn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)qo.fromBufferAttribute(this,t),qo.applyMatrix3(e),this.setXY(t,qo.x,qo.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyMatrix3(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyMatrix4(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyNormalMatrix(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.transformDirection(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Rr(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=$t(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Rr(t,this.array)),t}setX(e,t){return this.normalized&&(t=$t(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Rr(t,this.array)),t}setY(e,t){return this.normalized&&(t=$t(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Rr(t,this.array)),t}setZ(e,t){return this.normalized&&(t=$t(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Rr(t,this.array)),t}setW(e,t){return this.normalized&&(t=$t(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=$t(t,this.array),n=$t(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=$t(t,this.array),n=$t(n,this.array),s=$t(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=$t(t,this.array),n=$t(n,this.array),s=$t(s,this.array),r=$t(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==zp&&(e.usage=this.usage),e}}class H_ extends cn{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class V_ extends cn{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class ot extends cn{constructor(e,t,n){super(new Float32Array(e),t,n)}}let J1=0;const fn=new We,kc=new gt,Ls=new A,nn=new Un,Dr=new Un,It=new A;class Ut extends xs{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:J1++}),this.uuid=Ro(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(k_(e)?V_:H_)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Be().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return fn.makeRotationFromQuaternion(e),this.applyMatrix4(fn),this}rotateX(e){return fn.makeRotationX(e),this.applyMatrix4(fn),this}rotateY(e){return fn.makeRotationY(e),this.applyMatrix4(fn),this}rotateZ(e){return fn.makeRotationZ(e),this.applyMatrix4(fn),this}translate(e,t,n){return fn.makeTranslation(e,t,n),this.applyMatrix4(fn),this}scale(e,t,n){return fn.makeScale(e,t,n),this.applyMatrix4(fn),this}lookAt(e){return kc.lookAt(e),kc.updateMatrix(),this.applyMatrix4(kc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ls).negate(),this.translate(Ls.x,Ls.y,Ls.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new ot(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Un);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new A(-1/0,-1/0,-1/0),new A(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];nn.setFromBufferAttribute(r),this.morphTargetsRelative?(It.addVectors(this.boundingBox.min,nn.min),this.boundingBox.expandByPoint(It),It.addVectors(this.boundingBox.max,nn.max),this.boundingBox.expandByPoint(It)):(this.boundingBox.expandByPoint(nn.min),this.boundingBox.expandByPoint(nn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ys);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new A,1/0);return}if(e){const n=this.boundingSphere.center;if(nn.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const l=t[r];Dr.setFromBufferAttribute(l),this.morphTargetsRelative?(It.addVectors(nn.min,Dr.min),nn.expandByPoint(It),It.addVectors(nn.max,Dr.max),nn.expandByPoint(It)):(nn.expandByPoint(Dr.min),nn.expandByPoint(Dr.max))}nn.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)It.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(It));if(t)for(let r=0,o=t.length;r<o;r++){const l=t[r],c=this.morphTargetsRelative;for(let u=0,d=l.count;u<d;u++)It.fromBufferAttribute(l,u),c&&(Ls.fromBufferAttribute(e,u),It.add(Ls)),s=Math.max(s,n.distanceToSquared(It))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new cn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),l=[],c=[];for(let D=0;D<n.count;D++)l[D]=new A,c[D]=new A;const u=new A,d=new A,a=new A,h=new xe,f=new xe,g=new xe,_=new A,m=new A;function p(D,w,M){u.fromBufferAttribute(n,D),d.fromBufferAttribute(n,w),a.fromBufferAttribute(n,M),h.fromBufferAttribute(r,D),f.fromBufferAttribute(r,w),g.fromBufferAttribute(r,M),d.sub(u),a.sub(u),f.sub(h),g.sub(h);const I=1/(f.x*g.y-g.x*f.y);isFinite(I)&&(_.copy(d).multiplyScalar(g.y).addScaledVector(a,-f.y).multiplyScalar(I),m.copy(a).multiplyScalar(f.x).addScaledVector(d,-g.x).multiplyScalar(I),l[D].add(_),l[w].add(_),l[M].add(_),c[D].add(m),c[w].add(m),c[M].add(m))}let x=this.groups;x.length===0&&(x=[{start:0,count:e.count}]);for(let D=0,w=x.length;D<w;++D){const M=x[D],I=M.start,B=M.count;for(let N=I,V=I+B;N<V;N+=3)p(e.getX(N+0),e.getX(N+1),e.getX(N+2))}const b=new A,v=new A,P=new A,C=new A;function T(D){P.fromBufferAttribute(s,D),C.copy(P);const w=l[D];b.copy(w),b.sub(P.multiplyScalar(P.dot(w))).normalize(),v.crossVectors(C,w);const I=v.dot(c[D])<0?-1:1;o.setXYZW(D,b.x,b.y,b.z,I)}for(let D=0,w=x.length;D<w;++D){const M=x[D],I=M.start,B=M.count;for(let N=I,V=I+B;N<V;N+=3)T(e.getX(N+0)),T(e.getX(N+1)),T(e.getX(N+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new cn(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let h=0,f=n.count;h<f;h++)n.setXYZ(h,0,0,0);const s=new A,r=new A,o=new A,l=new A,c=new A,u=new A,d=new A,a=new A;if(e)for(let h=0,f=e.count;h<f;h+=3){const g=e.getX(h+0),_=e.getX(h+1),m=e.getX(h+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),d.subVectors(o,r),a.subVectors(s,r),d.cross(a),l.fromBufferAttribute(n,g),c.fromBufferAttribute(n,_),u.fromBufferAttribute(n,m),l.add(d),c.add(d),u.add(d),n.setXYZ(g,l.x,l.y,l.z),n.setXYZ(_,c.x,c.y,c.z),n.setXYZ(m,u.x,u.y,u.z)}else for(let h=0,f=t.count;h<f;h+=3)s.fromBufferAttribute(t,h+0),r.fromBufferAttribute(t,h+1),o.fromBufferAttribute(t,h+2),d.subVectors(o,r),a.subVectors(s,r),d.cross(a),n.setXYZ(h+0,d.x,d.y,d.z),n.setXYZ(h+1,d.x,d.y,d.z),n.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)It.fromBufferAttribute(e,t),It.normalize(),e.setXYZ(t,It.x,It.y,It.z)}toNonIndexed(){function e(l,c){const u=l.array,d=l.itemSize,a=l.normalized,h=new u.constructor(c.length*d);let f=0,g=0;for(let _=0,m=c.length;_<m;_++){l.isInterleavedBufferAttribute?f=c[_]*l.data.stride+l.offset:f=c[_]*d;for(let p=0;p<d;p++)h[g++]=u[f++]}return new cn(h,d,a)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Ut,n=this.index.array,s=this.attributes;for(const l in s){const c=s[l],u=e(c,n);t.setAttribute(l,u)}const r=this.morphAttributes;for(const l in r){const c=[],u=r[l];for(let d=0,a=u.length;d<a;d++){const h=u[d],f=e(h,n);c.push(f)}t.morphAttributes[l]=c}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let l=0,c=o.length;l<c;l++){const u=o[l];t.addGroup(u.start,u.count,u.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const u in c)c[u]!==void 0&&(e[u]=c[u]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const c in n){const u=n[c];e.data.attributes[c]=u.toJSON(e.data)}const s={};let r=!1;for(const c in this.morphAttributes){const u=this.morphAttributes[c],d=[];for(let a=0,h=u.length;a<h;a++){const f=u[a];d.push(f.toJSON(e.data))}d.length>0&&(s[c]=d,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const l=this.boundingSphere;return l!==null&&(e.data.boundingSphere=l.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const u in s){const d=s[u];this.setAttribute(u,d.clone(t))}const r=e.morphAttributes;for(const u in r){const d=[],a=r[u];for(let h=0,f=a.length;h<f;h++)d.push(a[h].clone(t));this.morphAttributes[u]=d}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let u=0,d=o.length;u<d;u++){const a=o[u];this.addGroup(a.start,a.count,a.materialIndex)}const l=e.boundingBox;l!==null&&(this.boundingBox=l.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const em=new We,Bi=new Po,jo=new ys,tm=new A,Ko=new A,Zo=new A,Jo=new A,Bc=new A,Qo=new A,nm=new A,ea=new A;class at extends gt{constructor(e=new Ut,t=new dt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const l=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[l]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const l=this.morphTargetInfluences;if(r&&l){Qo.set(0,0,0);for(let c=0,u=r.length;c<u;c++){const d=l[c],a=r[c];d!==0&&(Bc.fromBufferAttribute(a,e),o?Qo.addScaledVector(Bc,d):Qo.addScaledVector(Bc.sub(t),d))}t.add(Qo)}return t}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),jo.copy(n.boundingSphere),jo.applyMatrix4(r),Bi.copy(e.ray).recast(e.near),!(jo.containsPoint(Bi.origin)===!1&&(Bi.intersectSphere(jo,tm)===null||Bi.origin.distanceToSquared(tm)>(e.far-e.near)**2))&&(em.copy(r).invert(),Bi.copy(e.ray).applyMatrix4(em),!(n.boundingBox!==null&&Bi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Bi)))}_computeIntersections(e,t,n){let s;const r=this.geometry,o=this.material,l=r.index,c=r.attributes.position,u=r.attributes.uv,d=r.attributes.uv1,a=r.attributes.normal,h=r.groups,f=r.drawRange;if(l!==null)if(Array.isArray(o))for(let g=0,_=h.length;g<_;g++){const m=h[g],p=o[m.materialIndex],x=Math.max(m.start,f.start),b=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let v=x,P=b;v<P;v+=3){const C=l.getX(v),T=l.getX(v+1),D=l.getX(v+2);s=ta(this,p,e,n,u,d,a,C,T,D),s&&(s.faceIndex=Math.floor(v/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const x=l.getX(m),b=l.getX(m+1),v=l.getX(m+2);s=ta(this,o,e,n,u,d,a,x,b,v),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(c!==void 0)if(Array.isArray(o))for(let g=0,_=h.length;g<_;g++){const m=h[g],p=o[m.materialIndex],x=Math.max(m.start,f.start),b=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let v=x,P=b;v<P;v+=3){const C=v,T=v+1,D=v+2;s=ta(this,p,e,n,u,d,a,C,T,D),s&&(s.faceIndex=Math.floor(v/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(c.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const x=m,b=m+1,v=m+2;s=ta(this,o,e,n,u,d,a,x,b,v),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function Q1(i,e,t,n,s,r,o,l){let c;if(e.side===Wt?c=n.intersectTriangle(o,r,s,!0,l):c=n.intersectTriangle(s,r,o,e.side===Ri,l),c===null)return null;ea.copy(l),ea.applyMatrix4(i.matrixWorld);const u=t.ray.origin.distanceTo(ea);return u<t.near||u>t.far?null:{distance:u,point:ea.clone(),object:i}}function ta(i,e,t,n,s,r,o,l,c,u){i.getVertexPosition(l,Ko),i.getVertexPosition(c,Zo),i.getVertexPosition(u,Jo);const d=Q1(i,e,t,n,Ko,Zo,Jo,nm);if(d){const a=new A;Cn.getBarycoord(nm,Ko,Zo,Jo,a),s&&(d.uv=Cn.getInterpolatedAttribute(s,l,c,u,a,new xe)),r&&(d.uv1=Cn.getInterpolatedAttribute(r,l,c,u,a,new xe)),o&&(d.normal=Cn.getInterpolatedAttribute(o,l,c,u,a,new A),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const h={a:l,b:c,c:u,normal:new A,materialIndex:0};Cn.getNormal(Ko,Zo,Jo,h.normal),d.face=h,d.barycoord=a}return d}class Bt extends Ut{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};const l=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const c=[],u=[],d=[],a=[];let h=0,f=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new ot(u,3)),this.setAttribute("normal",new ot(d,3)),this.setAttribute("uv",new ot(a,2));function g(_,m,p,x,b,v,P,C,T,D,w){const M=v/T,I=P/D,B=v/2,N=P/2,V=C/2,Y=T+1,$=D+1;let Q=0,G=0;const ce=new A;for(let fe=0;fe<$;fe++){const Re=fe*I-N;for(let Ve=0;Ve<Y;Ve++){const ht=Ve*M-B;ce[_]=ht*x,ce[m]=Re*b,ce[p]=V,u.push(ce.x,ce.y,ce.z),ce[_]=0,ce[m]=0,ce[p]=C>0?1:-1,d.push(ce.x,ce.y,ce.z),a.push(Ve/T),a.push(1-fe/D),Q+=1}}for(let fe=0;fe<D;fe++)for(let Re=0;Re<T;Re++){const Ve=h+Re+Y*fe,ht=h+Re+Y*(fe+1),K=h+(Re+1)+Y*(fe+1),re=h+(Re+1)+Y*fe;c.push(Ve,ht,re),c.push(ht,K,re),G+=6}l.addGroup(f,G,w),f+=G,h+=Q}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Bt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function mr(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function Vt(i){const e={};for(let t=0;t<i.length;t++){const n=mr(i[t]);for(const s in n)e[s]=n[s]}return e}function eb(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function G_(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Ke.workingColorSpace}const tb={clone:mr,merge:Vt};var nb=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ib=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Ii extends Xn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=nb,this.fragmentShader=ib,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=mr(e.uniforms),this.uniformsGroups=eb(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class W_ extends gt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new We,this.projectionMatrix=new We,this.projectionMatrixInverse=new We,this.coordinateSystem=ai}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const gi=new A,im=new xe,sm=new xe;class gn extends W_{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Ku*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(ml*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Ku*2*Math.atan(Math.tan(ml*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){gi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(gi.x,gi.y).multiplyScalar(-e/gi.z),gi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(gi.x,gi.y).multiplyScalar(-e/gi.z)}getViewSize(e,t){return this.getViewBounds(e,im,sm),t.subVectors(sm,im)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(ml*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,u=o.fullHeight;r+=o.offsetX*s/c,t-=o.offsetY*n/u,s*=o.width/c,n*=o.height/u}const l=this.filmOffset;l!==0&&(r+=e*l/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Ds=-90,Us=1;class sb extends gt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new gn(Ds,Us,e,t);s.layers=this.layers,this.add(s);const r=new gn(Ds,Us,e,t);r.layers=this.layers,this.add(r);const o=new gn(Ds,Us,e,t);o.layers=this.layers,this.add(o);const l=new gn(Ds,Us,e,t);l.layers=this.layers,this.add(l);const c=new gn(Ds,Us,e,t);c.layers=this.layers,this.add(c);const u=new gn(Ds,Us,e,t);u.layers=this.layers,this.add(u)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,l,c]=t;for(const u of t)this.remove(u);if(e===ai)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),l.up.set(0,1,0),l.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===Cl)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),l.up.set(0,-1,0),l.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const u of t)this.add(u),u.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,l,c,u,d]=this.children,a=e.getRenderTarget(),h=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,l),e.setRenderTarget(n,3,s),e.render(t,c),e.setRenderTarget(n,4,s),e.render(t,u),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),e.render(t,d),e.setRenderTarget(a,h,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class X_ extends kt{constructor(e=[],t=dr,n,s,r,o,l,c,u,d){super(e,t,n,s,r,o,l,c,u,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class rb extends cs{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new X_(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Bt(5,5,5),r=new Ii({name:"CubemapFromEquirect",uniforms:mr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Wt,blending:Ei});r.uniforms.tEquirect.value=t;const o=new at(s,r),l=t.minFilter;return t.minFilter===ns&&(t.minFilter=Bn),new sb(1,10,this).update(e,o),t.minFilter=l,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}}let Hn=class extends gt{constructor(){super(),this.isGroup=!0,this.type="Group"}};const ob={type:"move"};class zc{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Hn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Hn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new A,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new A),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Hn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new A,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new A),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null;const l=this._targetRay,c=this._grip,u=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(u&&e.hand){o=!0;for(const _ of e.hand.values()){const m=t.getJointPose(_,n),p=this._getHandJoint(u,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const d=u.joints["index-finger-tip"],a=u.joints["thumb-tip"],h=d.position.distanceTo(a.position),f=.02,g=.005;u.inputState.pinching&&h>f+g?(u.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!u.inputState.pinching&&h<=f-g&&(u.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));l!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,this.dispatchEvent(ob)))}return l!==null&&(l.visible=s!==null),c!==null&&(c.visible=r!==null),u!==null&&(u.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Hn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class $_ extends gt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ln,this.environmentIntensity=1,this.environmentRotation=new Ln,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class ab extends kt{constructor(e=null,t=1,n=1,s,r,o,l,c,u=ln,d=ln,a,h){super(null,o,l,c,u,d,s,r,a,h),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class rm extends cn{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Os=new We,om=new We,na=[],am=new Un,lb=new We,Ur=new at,Or=new ys;class Zt extends at{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new rm(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,lb)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Un),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Os),am.copy(e.boundingBox).applyMatrix4(Os),this.boundingBox.union(am)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new ys),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Os),Or.copy(e.boundingSphere).applyMatrix4(Os),this.boundingSphere.union(Or)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=e*r+1;for(let l=0;l<n.length;l++)n[l]=s[o+l]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(Ur.geometry=this.geometry,Ur.material=this.material,Ur.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Or.copy(this.boundingSphere),Or.applyMatrix4(n),e.ray.intersectsSphere(Or)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Os),om.multiplyMatrices(n,Os),Ur.matrixWorld=om,Ur.raycast(e,na);for(let o=0,l=na.length;o<l;o++){const c=na[o];c.instanceId=r,c.object=this,t.push(c)}na.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new rm(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new ab(new Float32Array(s*this.count),s,this.count,Od,zn));const r=this.morphTexture.source.data.data;let o=0;for(let u=0;u<n.length;u++)o+=n[u];const l=this.geometry.morphTargetsRelative?1:1-o,c=s*e;r[c]=l,r.set(n,c+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Hc=new A,cb=new A,hb=new Be;class ri{constructor(e=new A(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Hc.subVectors(n,t).cross(cb.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Hc),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||hb.getNormalMatrix(e),s=this.coplanarPoint(Hc).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const zi=new ys,ia=new A;class Vd{constructor(e=new ri,t=new ri,n=new ri,s=new ri,r=new ri,o=new ri){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){const l=this.planes;return l[0].copy(e),l[1].copy(t),l[2].copy(n),l[3].copy(s),l[4].copy(r),l[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ai){const n=this.planes,s=e.elements,r=s[0],o=s[1],l=s[2],c=s[3],u=s[4],d=s[5],a=s[6],h=s[7],f=s[8],g=s[9],_=s[10],m=s[11],p=s[12],x=s[13],b=s[14],v=s[15];if(n[0].setComponents(c-r,h-u,m-f,v-p).normalize(),n[1].setComponents(c+r,h+u,m+f,v+p).normalize(),n[2].setComponents(c+o,h+d,m+g,v+x).normalize(),n[3].setComponents(c-o,h-d,m-g,v-x).normalize(),n[4].setComponents(c-l,h-a,m-_,v-b).normalize(),t===ai)n[5].setComponents(c+l,h+a,m+_,v+b).normalize();else if(t===Cl)n[5].setComponents(l,a,_,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),zi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),zi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(zi)}intersectsSprite(e){return zi.center.set(0,0,0),zi.radius=.7071067811865476,zi.applyMatrix4(e.matrixWorld),this.intersectsSphere(zi)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(ia.x=s.normal.x>0?e.max.x:e.min.x,ia.y=s.normal.y>0?e.max.y:e.min.y,ia.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(ia)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Kr extends Xn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new se(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Pl=new A,Il=new A,lm=new We,Fr=new Po,sa=new ys,Vc=new A,cm=new A;class Y_ extends gt{constructor(e=new Ut,t=new Kr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)Pl.fromBufferAttribute(t,s-1),Il.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Pl.distanceTo(Il);e.setAttribute("lineDistance",new ot(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),sa.copy(n.boundingSphere),sa.applyMatrix4(s),sa.radius+=r,e.ray.intersectsSphere(sa)===!1)return;lm.copy(s).invert(),Fr.copy(e.ray).applyMatrix4(lm);const l=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=l*l,u=this.isLineSegments?2:1,d=n.index,h=n.attributes.position;if(d!==null){const f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=u){const p=d.getX(_),x=d.getX(_+1),b=ra(this,e,Fr,c,p,x,_);b&&t.push(b)}if(this.isLineLoop){const _=d.getX(g-1),m=d.getX(f),p=ra(this,e,Fr,c,_,m,g-1);p&&t.push(p)}}else{const f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=u){const p=ra(this,e,Fr,c,_,_+1,_);p&&t.push(p)}if(this.isLineLoop){const _=ra(this,e,Fr,c,g-1,f,g-1);_&&t.push(_)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const l=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[l]=r}}}}}function ra(i,e,t,n,s,r,o){const l=i.geometry.attributes.position;if(Pl.fromBufferAttribute(l,s),Il.fromBufferAttribute(l,r),t.distanceSqToSegment(Pl,Il,Vc,cm)>n)return;Vc.applyMatrix4(i.matrixWorld);const u=e.ray.origin.distanceTo(Vc);if(!(u<e.near||u>e.far))return{distance:u,point:cm.clone().applyMatrix4(i.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:i}}const hm=new A,um=new A;class dm extends Y_{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)hm.fromBufferAttribute(t,s),um.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+hm.distanceTo(um);e.setAttribute("lineDistance",new ot(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class $r extends Xn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new se(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const fm=new We,Zu=new Po,oa=new ys,aa=new A;class Gc extends gt{constructor(e=new Ut,t=new $r){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),oa.copy(n.boundingSphere),oa.applyMatrix4(s),oa.radius+=r,e.ray.intersectsSphere(oa)===!1)return;fm.copy(s).invert(),Zu.copy(e.ray).applyMatrix4(fm);const l=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=l*l,u=n.index,a=n.attributes.position;if(u!==null){const h=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let g=h,_=f;g<_;g++){const m=u.getX(g);aa.fromBufferAttribute(a,m),pm(aa,m,c,s,e,t,this)}}else{const h=Math.max(0,o.start),f=Math.min(a.count,o.start+o.count);for(let g=h,_=f;g<_;g++)aa.fromBufferAttribute(a,g),pm(aa,g,c,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const l=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[l]=r}}}}}function pm(i,e,t,n,s,r,o){const l=Zu.distanceSqToPoint(i);if(l<t){const c=new A;Zu.closestPointToPoint(i,c),c.applyMatrix4(n);const u=s.ray.origin.distanceTo(c);if(u<s.near||u>s.far)return;r.push({distance:u,distanceToRay:Math.sqrt(l),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class Ju extends kt{constructor(e,t,n,s,r,o,l,c,u){super(e,t,n,s,r,o,l,c,u),this.isCanvasTexture=!0,this.needsUpdate=!0}}class q_ extends kt{constructor(e,t,n=ls,s,r,o,l=ln,c=ln,u,d=ho,a=1){if(d!==ho&&d!==uo)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const h={width:e,height:t,depth:a};super(h,s,r,o,l,c,d,n,u),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new zd(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class oc extends Ut{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const r=[],o=[],l=[],c=[],u=new A,d=new xe;o.push(0,0,0),l.push(0,0,1),c.push(.5,.5);for(let a=0,h=3;a<=t;a++,h+=3){const f=n+a/t*s;u.x=e*Math.cos(f),u.y=e*Math.sin(f),o.push(u.x,u.y,u.z),l.push(0,0,1),d.x=(o[h]/e+1)/2,d.y=(o[h+1]/e+1)/2,c.push(d.x,d.y)}for(let a=1;a<=t;a++)r.push(a,a+1,0);this.setIndex(r),this.setAttribute("position",new ot(o,3)),this.setAttribute("normal",new ot(l,3)),this.setAttribute("uv",new ot(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new oc(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Io extends Ut{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,l=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:l,thetaLength:c};const u=this;s=Math.floor(s),r=Math.floor(r);const d=[],a=[],h=[],f=[];let g=0;const _=[],m=n/2;let p=0;x(),o===!1&&(e>0&&b(!0),t>0&&b(!1)),this.setIndex(d),this.setAttribute("position",new ot(a,3)),this.setAttribute("normal",new ot(h,3)),this.setAttribute("uv",new ot(f,2));function x(){const v=new A,P=new A;let C=0;const T=(t-e)/n;for(let D=0;D<=r;D++){const w=[],M=D/r,I=M*(t-e)+e;for(let B=0;B<=s;B++){const N=B/s,V=N*c+l,Y=Math.sin(V),$=Math.cos(V);P.x=I*Y,P.y=-M*n+m,P.z=I*$,a.push(P.x,P.y,P.z),v.set(Y,T,$).normalize(),h.push(v.x,v.y,v.z),f.push(N,1-M),w.push(g++)}_.push(w)}for(let D=0;D<s;D++)for(let w=0;w<r;w++){const M=_[w][D],I=_[w+1][D],B=_[w+1][D+1],N=_[w][D+1];(e>0||w!==0)&&(d.push(M,I,N),C+=3),(t>0||w!==r-1)&&(d.push(I,B,N),C+=3)}u.addGroup(p,C,0),p+=C}function b(v){const P=g,C=new xe,T=new A;let D=0;const w=v===!0?e:t,M=v===!0?1:-1;for(let B=1;B<=s;B++)a.push(0,m*M,0),h.push(0,M,0),f.push(.5,.5),g++;const I=g;for(let B=0;B<=s;B++){const V=B/s*c+l,Y=Math.cos(V),$=Math.sin(V);T.x=w*$,T.y=m*M,T.z=w*Y,a.push(T.x,T.y,T.z),h.push(0,M,0),C.x=Y*.5+.5,C.y=$*.5*M+.5,f.push(C.x,C.y),g++}for(let B=0;B<s;B++){const N=P+B,V=I+B;v===!0?d.push(V,V+1,N):d.push(V+1,V,N),D+=3}u.addGroup(p,D,v===!0?1:2),p+=D}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Io(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Gd extends Io{constructor(e=1,t=1,n=32,s=1,r=!1,o=0,l=Math.PI*2){super(0,e,t,n,s,r,o,l),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:l}}static fromJSON(e){return new Gd(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Lo extends Ut{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,o=t/2,l=Math.floor(n),c=Math.floor(s),u=l+1,d=c+1,a=e/l,h=t/c,f=[],g=[],_=[],m=[];for(let p=0;p<d;p++){const x=p*h-o;for(let b=0;b<u;b++){const v=b*a-r;g.push(v,-x,0),_.push(0,0,1),m.push(b/l),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let x=0;x<l;x++){const b=x+u*p,v=x+u*(p+1),P=x+1+u*(p+1),C=x+1+u*p;f.push(b,v,C),f.push(v,P,C)}this.setIndex(f),this.setAttribute("position",new ot(g,3)),this.setAttribute("normal",new ot(_,3)),this.setAttribute("uv",new ot(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Lo(e.width,e.height,e.widthSegments,e.heightSegments)}}class Do extends Ut{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,l=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:l},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const c=Math.min(o+l,Math.PI);let u=0;const d=[],a=new A,h=new A,f=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){const x=[],b=p/n;let v=0;p===0&&o===0?v=.5/t:p===n&&c===Math.PI&&(v=-.5/t);for(let P=0;P<=t;P++){const C=P/t;a.x=-e*Math.cos(s+C*r)*Math.sin(o+b*l),a.y=e*Math.cos(o+b*l),a.z=e*Math.sin(s+C*r)*Math.sin(o+b*l),g.push(a.x,a.y,a.z),h.copy(a).normalize(),_.push(h.x,h.y,h.z),m.push(C+v,1-b),x.push(u++)}d.push(x)}for(let p=0;p<n;p++)for(let x=0;x<t;x++){const b=d[p][x+1],v=d[p][x],P=d[p+1][x],C=d[p+1][x+1];(p!==0||o>0)&&f.push(b,v,C),(p!==n-1||c<Math.PI)&&f.push(v,P,C)}this.setIndex(f),this.setAttribute("position",new ot(g,3)),this.setAttribute("normal",new ot(_,3)),this.setAttribute("uv",new ot(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Do(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class ub extends Xn{constructor(e){super(),this.isMeshPhongMaterial=!0,this.type="MeshPhongMaterial",this.color=new se(16777215),this.specular=new se(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new se(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Bd,this.normalScale=new xe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ln,this.combine=sc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class gr extends Xn{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new se(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new se(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Bd,this.normalScale=new xe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ln,this.combine=sc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class db extends Xn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=b1,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class fb extends Xn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const mm={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class pb{constructor(e,t,n){const s=this;let r=!1,o=0,l=0,c;const u=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(d){l++,r===!1&&s.onStart!==void 0&&s.onStart(d,o,l),r=!0},this.itemEnd=function(d){o++,s.onProgress!==void 0&&s.onProgress(d,o,l),o===l&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(d){s.onError!==void 0&&s.onError(d)},this.resolveURL=function(d){return c?c(d):d},this.setURLModifier=function(d){return c=d,this},this.addHandler=function(d,a){return u.push(d,a),this},this.removeHandler=function(d){const a=u.indexOf(d);return a!==-1&&u.splice(a,2),this},this.getHandler=function(d){for(let a=0,h=u.length;a<h;a+=2){const f=u[a],g=u[a+1];if(f.global&&(f.lastIndex=0),f.test(d))return g}return null}}}const mb=new pb;class Wd{constructor(e){this.manager=e!==void 0?e:mb,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}Wd.DEFAULT_MATERIAL_NAME="__DEFAULT";const Qn={};class gb extends Error{constructor(e,t){super(e),this.response=t}}class _b extends Wd{constructor(e){super(e),this.mimeType="",this.responseType=""}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=mm.get(e);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(Qn[e]!==void 0){Qn[e].push({onLoad:t,onProgress:n,onError:s});return}Qn[e]=[],Qn[e].push({onLoad:t,onProgress:n,onError:s});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),l=this.mimeType,c=this.responseType;fetch(o).then(u=>{if(u.status===200||u.status===0){if(u.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||u.body===void 0||u.body.getReader===void 0)return u;const d=Qn[e],a=u.body.getReader(),h=u.headers.get("X-File-Size")||u.headers.get("Content-Length"),f=h?parseInt(h):0,g=f!==0;let _=0;const m=new ReadableStream({start(p){x();function x(){a.read().then(({done:b,value:v})=>{if(b)p.close();else{_+=v.byteLength;const P=new ProgressEvent("progress",{lengthComputable:g,loaded:_,total:f});for(let C=0,T=d.length;C<T;C++){const D=d[C];D.onProgress&&D.onProgress(P)}p.enqueue(v),x()}},b=>{p.error(b)})}}});return new Response(m)}else throw new gb(`fetch for "${u.url}" responded with ${u.status}: ${u.statusText}`,u)}).then(u=>{switch(c){case"arraybuffer":return u.arrayBuffer();case"blob":return u.blob();case"document":return u.text().then(d=>new DOMParser().parseFromString(d,l));case"json":return u.json();default:if(l==="")return u.text();{const a=/charset="?([^;"\s]*)"?/i.exec(l),h=a&&a[1]?a[1].toLowerCase():void 0,f=new TextDecoder(h);return u.arrayBuffer().then(g=>f.decode(g))}}}).then(u=>{mm.add(e,u);const d=Qn[e];delete Qn[e];for(let a=0,h=d.length;a<h;a++){const f=d[a];f.onLoad&&f.onLoad(u)}}).catch(u=>{const d=Qn[e];if(d===void 0)throw this.manager.itemError(e),u;delete Qn[e];for(let a=0,h=d.length;a<h;a++){const f=d[a];f.onError&&f.onError(u)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}}class j_ extends gt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new se(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}const Wc=new We,gm=new A,_m=new A;class xb{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new xe(512,512),this.mapType=Wn,this.map=null,this.mapPass=null,this.matrix=new We,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Vd,this._frameExtents=new xe(1,1),this._viewportCount=1,this._viewports=[new Mt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;gm.setFromMatrixPosition(e.matrixWorld),t.position.copy(gm),_m.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(_m),t.updateMatrixWorld(),Wc.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Wc),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Wc)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class K_ extends W_{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,o=n+e,l=s+t,c=s-t;if(this.view!==null&&this.view.enabled){const u=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=u*this.view.offsetX,o=r+u*this.view.width,l-=d*this.view.offsetY,c=l-d*this.view.height}this.projectionMatrix.makeOrthographic(r,o,l,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class yb extends xb{constructor(){super(new K_(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class vb extends j_{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(gt.DEFAULT_UP),this.updateMatrix(),this.target=new gt,this.shadow=new yb}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class bb extends j_{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}class Mb extends gn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const xm=new We;class wb{constructor(e,t,n=0,s=1/0){this.ray=new Po(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Hd,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return xm.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(xm),this}intersectObject(e,t=!0,n=[]){return Qu(e,this,n,t),n.sort(ym),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)Qu(e[s],this,n,t);return n.sort(ym),n}}function ym(i,e){return i.distance-e.distance}function Qu(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let o=0,l=r.length;o<l;o++)Qu(r[o],e,t,!0)}}class Ll{constructor(e=1,t=0,n=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Ge(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(Ge(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const vm=new A;let la,Xc;class Sb extends gt{constructor(e=new A(0,0,1),t=new A(0,0,0),n=1,s=16776960,r=n*.2,o=r*.2){super(),this.type="ArrowHelper",la===void 0&&(la=new Ut,la.setAttribute("position",new ot([0,0,0,0,1,0],3)),Xc=new Gd(.5,1,5,1),Xc.translate(0,-.5,0)),this.position.copy(t),this.line=new Y_(la,new Kr({color:s,toneMapped:!1})),this.line.matrixAutoUpdate=!1,this.add(this.line),this.cone=new at(Xc,new dt({color:s,toneMapped:!1})),this.cone.matrixAutoUpdate=!1,this.add(this.cone),this.setDirection(e),this.setLength(n,r,o)}setDirection(e){if(e.y>.99999)this.quaternion.set(0,0,0,1);else if(e.y<-.99999)this.quaternion.set(1,0,0,0);else{vm.set(e.z,0,-e.x).normalize();const t=Math.acos(e.y);this.quaternion.setFromAxisAngle(vm,t)}}setLength(e,t=e*.2,n=t*.2){this.line.scale.set(1,Math.max(1e-4,e-t),1),this.line.updateMatrix(),this.cone.scale.set(n,t,n),this.cone.position.y=e,this.cone.updateMatrix()}setColor(e){this.line.material.color.set(e),this.cone.material.color.set(e)}copy(e){return super.copy(e,!1),this.line.copy(e.line),this.cone.copy(e.cone),this}dispose(){this.line.geometry.dispose(),this.line.material.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()}}class Eb extends xs{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){console.warn("THREE.Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function bm(i,e,t,n){const s=Ab(n);switch(t){case D_:return i*e;case Od:return i*e/s.components*s.byteLength;case Fd:return i*e/s.components*s.byteLength;case O_:return i*e*2/s.components*s.byteLength;case Nd:return i*e*2/s.components*s.byteLength;case U_:return i*e*3/s.components*s.byteLength;case Rn:return i*e*4/s.components*s.byteLength;case kd:return i*e*4/s.components*s.byteLength;case hl:case ul:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case dl:case fl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Eu:case Tu:return Math.max(i,16)*Math.max(e,8)/4;case Su:case Au:return Math.max(i,8)*Math.max(e,8)/2;case Cu:case Ru:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Pu:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Iu:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Lu:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Du:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Uu:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Ou:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Fu:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Nu:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case ku:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Bu:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case zu:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Hu:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Vu:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Gu:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Wu:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case pl:case Xu:case $u:return Math.ceil(i/4)*Math.ceil(e/4)*16;case F_:case Yu:return Math.ceil(i/4)*Math.ceil(e/4)*8;case qu:case ju:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Ab(i){switch(i){case Wn:case P_:return{byteLength:1,components:1};case lo:case I_:case Co:return{byteLength:2,components:1};case Dd:case Ud:return{byteLength:2,components:4};case ls:case Ld:case zn:return{byteLength:4,components:1};case L_:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Id}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Id);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Z_(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function Tb(i){const e=new WeakMap;function t(l,c){const u=l.array,d=l.usage,a=u.byteLength,h=i.createBuffer();i.bindBuffer(c,h),i.bufferData(c,u,d),l.onUploadCallback();let f;if(u instanceof Float32Array)f=i.FLOAT;else if(u instanceof Uint16Array)l.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(u instanceof Int16Array)f=i.SHORT;else if(u instanceof Uint32Array)f=i.UNSIGNED_INT;else if(u instanceof Int32Array)f=i.INT;else if(u instanceof Int8Array)f=i.BYTE;else if(u instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:h,type:f,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:a}}function n(l,c,u){const d=c.array,a=c.updateRanges;if(i.bindBuffer(u,l),a.length===0)i.bufferSubData(u,0,d);else{a.sort((f,g)=>f.start-g.start);let h=0;for(let f=1;f<a.length;f++){const g=a[h],_=a[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++h,a[h]=_)}a.length=h+1;for(let f=0,g=a.length;f<g;f++){const _=a[f];i.bufferSubData(u,_.start*d.BYTES_PER_ELEMENT,d,_.start,_.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(l){return l.isInterleavedBufferAttribute&&(l=l.data),e.get(l)}function r(l){l.isInterleavedBufferAttribute&&(l=l.data);const c=e.get(l);c&&(i.deleteBuffer(c.buffer),e.delete(l))}function o(l,c){if(l.isInterleavedBufferAttribute&&(l=l.data),l.isGLBufferAttribute){const d=e.get(l);(!d||d.version<l.version)&&e.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}const u=e.get(l);if(u===void 0)e.set(l,t(l,c));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(u.buffer,l,c),u.version=l.version}}return{get:s,remove:r,update:o}}var Cb=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Rb=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Pb=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ib=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Lb=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Db=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ub=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Ob=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Fb=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Nb=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,kb=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Bb=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,zb=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Hb=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Vb=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Gb=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Wb=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Xb=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,$b=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Yb=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,qb=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,jb=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Kb=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Zb=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Jb=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Qb=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,eM=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,tM=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,nM=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,iM=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,sM="gl_FragColor = linearToOutputTexel( gl_FragColor );",rM=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,oM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,aM=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,lM=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,cM=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,hM=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,uM=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,dM=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fM=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,pM=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,mM=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,gM=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,_M=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,xM=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,yM=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,vM=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,bM=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,MM=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,wM=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,SM=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,EM=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,AM=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,TM=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,CM=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,RM=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,PM=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,IM=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,LM=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,DM=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,UM=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,OM=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,FM=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,NM=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,kM=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,BM=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,zM=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,HM=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,VM=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,GM=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,WM=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,XM=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,$M=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,YM=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,qM=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,jM=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,KM=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,ZM=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,JM=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,QM=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ew=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,tw=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,nw=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,iw=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,sw=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,rw=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,ow=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,aw=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,lw=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,cw=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,hw=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,uw=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,dw=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,fw=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,pw=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,mw=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,gw=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,_w=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,xw=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,yw=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,vw=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,bw=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Mw=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,ww=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Sw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ew=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Aw=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Tw=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Cw=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Rw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Pw=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Iw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Lw=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Dw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Uw=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Ow=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Fw=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Nw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,kw=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bw=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,zw=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Hw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Vw=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gw=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ww=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xw=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,$w=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yw=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,qw=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,jw=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Kw=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zw=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Jw=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qw=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,eS=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tS=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,nS=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,iS=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,sS=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,rS=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,oS=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,He={alphahash_fragment:Cb,alphahash_pars_fragment:Rb,alphamap_fragment:Pb,alphamap_pars_fragment:Ib,alphatest_fragment:Lb,alphatest_pars_fragment:Db,aomap_fragment:Ub,aomap_pars_fragment:Ob,batching_pars_vertex:Fb,batching_vertex:Nb,begin_vertex:kb,beginnormal_vertex:Bb,bsdfs:zb,iridescence_fragment:Hb,bumpmap_pars_fragment:Vb,clipping_planes_fragment:Gb,clipping_planes_pars_fragment:Wb,clipping_planes_pars_vertex:Xb,clipping_planes_vertex:$b,color_fragment:Yb,color_pars_fragment:qb,color_pars_vertex:jb,color_vertex:Kb,common:Zb,cube_uv_reflection_fragment:Jb,defaultnormal_vertex:Qb,displacementmap_pars_vertex:eM,displacementmap_vertex:tM,emissivemap_fragment:nM,emissivemap_pars_fragment:iM,colorspace_fragment:sM,colorspace_pars_fragment:rM,envmap_fragment:oM,envmap_common_pars_fragment:aM,envmap_pars_fragment:lM,envmap_pars_vertex:cM,envmap_physical_pars_fragment:vM,envmap_vertex:hM,fog_vertex:uM,fog_pars_vertex:dM,fog_fragment:fM,fog_pars_fragment:pM,gradientmap_pars_fragment:mM,lightmap_pars_fragment:gM,lights_lambert_fragment:_M,lights_lambert_pars_fragment:xM,lights_pars_begin:yM,lights_toon_fragment:bM,lights_toon_pars_fragment:MM,lights_phong_fragment:wM,lights_phong_pars_fragment:SM,lights_physical_fragment:EM,lights_physical_pars_fragment:AM,lights_fragment_begin:TM,lights_fragment_maps:CM,lights_fragment_end:RM,logdepthbuf_fragment:PM,logdepthbuf_pars_fragment:IM,logdepthbuf_pars_vertex:LM,logdepthbuf_vertex:DM,map_fragment:UM,map_pars_fragment:OM,map_particle_fragment:FM,map_particle_pars_fragment:NM,metalnessmap_fragment:kM,metalnessmap_pars_fragment:BM,morphinstance_vertex:zM,morphcolor_vertex:HM,morphnormal_vertex:VM,morphtarget_pars_vertex:GM,morphtarget_vertex:WM,normal_fragment_begin:XM,normal_fragment_maps:$M,normal_pars_fragment:YM,normal_pars_vertex:qM,normal_vertex:jM,normalmap_pars_fragment:KM,clearcoat_normal_fragment_begin:ZM,clearcoat_normal_fragment_maps:JM,clearcoat_pars_fragment:QM,iridescence_pars_fragment:ew,opaque_fragment:tw,packing:nw,premultiplied_alpha_fragment:iw,project_vertex:sw,dithering_fragment:rw,dithering_pars_fragment:ow,roughnessmap_fragment:aw,roughnessmap_pars_fragment:lw,shadowmap_pars_fragment:cw,shadowmap_pars_vertex:hw,shadowmap_vertex:uw,shadowmask_pars_fragment:dw,skinbase_vertex:fw,skinning_pars_vertex:pw,skinning_vertex:mw,skinnormal_vertex:gw,specularmap_fragment:_w,specularmap_pars_fragment:xw,tonemapping_fragment:yw,tonemapping_pars_fragment:vw,transmission_fragment:bw,transmission_pars_fragment:Mw,uv_pars_fragment:ww,uv_pars_vertex:Sw,uv_vertex:Ew,worldpos_vertex:Aw,background_vert:Tw,background_frag:Cw,backgroundCube_vert:Rw,backgroundCube_frag:Pw,cube_vert:Iw,cube_frag:Lw,depth_vert:Dw,depth_frag:Uw,distanceRGBA_vert:Ow,distanceRGBA_frag:Fw,equirect_vert:Nw,equirect_frag:kw,linedashed_vert:Bw,linedashed_frag:zw,meshbasic_vert:Hw,meshbasic_frag:Vw,meshlambert_vert:Gw,meshlambert_frag:Ww,meshmatcap_vert:Xw,meshmatcap_frag:$w,meshnormal_vert:Yw,meshnormal_frag:qw,meshphong_vert:jw,meshphong_frag:Kw,meshphysical_vert:Zw,meshphysical_frag:Jw,meshtoon_vert:Qw,meshtoon_frag:eS,points_vert:tS,points_frag:nS,shadow_vert:iS,shadow_frag:sS,sprite_vert:rS,sprite_frag:oS},ae={common:{diffuse:{value:new se(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Be},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Be}},envmap:{envMap:{value:null},envMapRotation:{value:new Be},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Be}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Be}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Be},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Be},normalScale:{value:new xe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Be},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Be}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Be}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Be}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new se(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new se(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0},uvTransform:{value:new Be}},sprite:{diffuse:{value:new se(16777215)},opacity:{value:1},center:{value:new xe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Be},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0}}},Nn={basic:{uniforms:Vt([ae.common,ae.specularmap,ae.envmap,ae.aomap,ae.lightmap,ae.fog]),vertexShader:He.meshbasic_vert,fragmentShader:He.meshbasic_frag},lambert:{uniforms:Vt([ae.common,ae.specularmap,ae.envmap,ae.aomap,ae.lightmap,ae.emissivemap,ae.bumpmap,ae.normalmap,ae.displacementmap,ae.fog,ae.lights,{emissive:{value:new se(0)}}]),vertexShader:He.meshlambert_vert,fragmentShader:He.meshlambert_frag},phong:{uniforms:Vt([ae.common,ae.specularmap,ae.envmap,ae.aomap,ae.lightmap,ae.emissivemap,ae.bumpmap,ae.normalmap,ae.displacementmap,ae.fog,ae.lights,{emissive:{value:new se(0)},specular:{value:new se(1118481)},shininess:{value:30}}]),vertexShader:He.meshphong_vert,fragmentShader:He.meshphong_frag},standard:{uniforms:Vt([ae.common,ae.envmap,ae.aomap,ae.lightmap,ae.emissivemap,ae.bumpmap,ae.normalmap,ae.displacementmap,ae.roughnessmap,ae.metalnessmap,ae.fog,ae.lights,{emissive:{value:new se(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:He.meshphysical_vert,fragmentShader:He.meshphysical_frag},toon:{uniforms:Vt([ae.common,ae.aomap,ae.lightmap,ae.emissivemap,ae.bumpmap,ae.normalmap,ae.displacementmap,ae.gradientmap,ae.fog,ae.lights,{emissive:{value:new se(0)}}]),vertexShader:He.meshtoon_vert,fragmentShader:He.meshtoon_frag},matcap:{uniforms:Vt([ae.common,ae.bumpmap,ae.normalmap,ae.displacementmap,ae.fog,{matcap:{value:null}}]),vertexShader:He.meshmatcap_vert,fragmentShader:He.meshmatcap_frag},points:{uniforms:Vt([ae.points,ae.fog]),vertexShader:He.points_vert,fragmentShader:He.points_frag},dashed:{uniforms:Vt([ae.common,ae.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:He.linedashed_vert,fragmentShader:He.linedashed_frag},depth:{uniforms:Vt([ae.common,ae.displacementmap]),vertexShader:He.depth_vert,fragmentShader:He.depth_frag},normal:{uniforms:Vt([ae.common,ae.bumpmap,ae.normalmap,ae.displacementmap,{opacity:{value:1}}]),vertexShader:He.meshnormal_vert,fragmentShader:He.meshnormal_frag},sprite:{uniforms:Vt([ae.sprite,ae.fog]),vertexShader:He.sprite_vert,fragmentShader:He.sprite_frag},background:{uniforms:{uvTransform:{value:new Be},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:He.background_vert,fragmentShader:He.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Be}},vertexShader:He.backgroundCube_vert,fragmentShader:He.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:He.cube_vert,fragmentShader:He.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:He.equirect_vert,fragmentShader:He.equirect_frag},distanceRGBA:{uniforms:Vt([ae.common,ae.displacementmap,{referencePosition:{value:new A},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:He.distanceRGBA_vert,fragmentShader:He.distanceRGBA_frag},shadow:{uniforms:Vt([ae.lights,ae.fog,{color:{value:new se(0)},opacity:{value:1}}]),vertexShader:He.shadow_vert,fragmentShader:He.shadow_frag}};Nn.physical={uniforms:Vt([Nn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Be},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Be},clearcoatNormalScale:{value:new xe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Be},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Be},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Be},sheen:{value:0},sheenColor:{value:new se(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Be},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Be},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Be},transmissionSamplerSize:{value:new xe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Be},attenuationDistance:{value:0},attenuationColor:{value:new se(0)},specularColor:{value:new se(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Be},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Be},anisotropyVector:{value:new xe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Be}}]),vertexShader:He.meshphysical_vert,fragmentShader:He.meshphysical_frag};const ca={r:0,b:0,g:0},Hi=new Ln,aS=new We;function lS(i,e,t,n,s,r,o){const l=new se(0);let c=r===!0?0:1,u,d,a=null,h=0,f=null;function g(b){let v=b.isScene===!0?b.background:null;return v&&v.isTexture&&(v=(b.backgroundBlurriness>0?t:e).get(v)),v}function _(b){let v=!1;const P=g(b);P===null?p(l,c):P&&P.isColor&&(p(P,1),v=!0);const C=i.xr.getEnvironmentBlendMode();C==="additive"?n.buffers.color.setClear(0,0,0,1,o):C==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(b,v){const P=g(v);P&&(P.isCubeTexture||P.mapping===rc)?(d===void 0&&(d=new at(new Bt(1,1,1),new Ii({name:"BackgroundCubeMaterial",uniforms:mr(Nn.backgroundCube.uniforms),vertexShader:Nn.backgroundCube.vertexShader,fragmentShader:Nn.backgroundCube.fragmentShader,side:Wt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(C,T,D){this.matrixWorld.copyPosition(D.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(d)),Hi.copy(v.backgroundRotation),Hi.x*=-1,Hi.y*=-1,Hi.z*=-1,P.isCubeTexture&&P.isRenderTargetTexture===!1&&(Hi.y*=-1,Hi.z*=-1),d.material.uniforms.envMap.value=P,d.material.uniforms.flipEnvMap.value=P.isCubeTexture&&P.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(aS.makeRotationFromEuler(Hi)),d.material.toneMapped=Ke.getTransfer(P.colorSpace)!==lt,(a!==P||h!==P.version||f!==i.toneMapping)&&(d.material.needsUpdate=!0,a=P,h=P.version,f=i.toneMapping),d.layers.enableAll(),b.unshift(d,d.geometry,d.material,0,0,null)):P&&P.isTexture&&(u===void 0&&(u=new at(new Lo(2,2),new Ii({name:"BackgroundMaterial",uniforms:mr(Nn.background.uniforms),vertexShader:Nn.background.vertexShader,fragmentShader:Nn.background.fragmentShader,side:Ri,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(u)),u.material.uniforms.t2D.value=P,u.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,u.material.toneMapped=Ke.getTransfer(P.colorSpace)!==lt,P.matrixAutoUpdate===!0&&P.updateMatrix(),u.material.uniforms.uvTransform.value.copy(P.matrix),(a!==P||h!==P.version||f!==i.toneMapping)&&(u.material.needsUpdate=!0,a=P,h=P.version,f=i.toneMapping),u.layers.enableAll(),b.unshift(u,u.geometry,u.material,0,0,null))}function p(b,v){b.getRGB(ca,G_(i)),n.buffers.color.setClear(ca.r,ca.g,ca.b,v,o)}function x(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0)}return{getClearColor:function(){return l},setClearColor:function(b,v=1){l.set(b),c=v,p(l,c)},getClearAlpha:function(){return c},setClearAlpha:function(b){c=b,p(l,c)},render:_,addToRenderList:m,dispose:x}}function cS(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=h(null);let r=s,o=!1;function l(M,I,B,N,V){let Y=!1;const $=a(N,B,I);r!==$&&(r=$,u(r.object)),Y=f(M,N,B,V),Y&&g(M,N,B,V),V!==null&&e.update(V,i.ELEMENT_ARRAY_BUFFER),(Y||o)&&(o=!1,v(M,I,B,N),V!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(V).buffer))}function c(){return i.createVertexArray()}function u(M){return i.bindVertexArray(M)}function d(M){return i.deleteVertexArray(M)}function a(M,I,B){const N=B.wireframe===!0;let V=n[M.id];V===void 0&&(V={},n[M.id]=V);let Y=V[I.id];Y===void 0&&(Y={},V[I.id]=Y);let $=Y[N];return $===void 0&&($=h(c()),Y[N]=$),$}function h(M){const I=[],B=[],N=[];for(let V=0;V<t;V++)I[V]=0,B[V]=0,N[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:B,attributeDivisors:N,object:M,attributes:{},index:null}}function f(M,I,B,N){const V=r.attributes,Y=I.attributes;let $=0;const Q=B.getAttributes();for(const G in Q)if(Q[G].location>=0){const fe=V[G];let Re=Y[G];if(Re===void 0&&(G==="instanceMatrix"&&M.instanceMatrix&&(Re=M.instanceMatrix),G==="instanceColor"&&M.instanceColor&&(Re=M.instanceColor)),fe===void 0||fe.attribute!==Re||Re&&fe.data!==Re.data)return!0;$++}return r.attributesNum!==$||r.index!==N}function g(M,I,B,N){const V={},Y=I.attributes;let $=0;const Q=B.getAttributes();for(const G in Q)if(Q[G].location>=0){let fe=Y[G];fe===void 0&&(G==="instanceMatrix"&&M.instanceMatrix&&(fe=M.instanceMatrix),G==="instanceColor"&&M.instanceColor&&(fe=M.instanceColor));const Re={};Re.attribute=fe,fe&&fe.data&&(Re.data=fe.data),V[G]=Re,$++}r.attributes=V,r.attributesNum=$,r.index=N}function _(){const M=r.newAttributes;for(let I=0,B=M.length;I<B;I++)M[I]=0}function m(M){p(M,0)}function p(M,I){const B=r.newAttributes,N=r.enabledAttributes,V=r.attributeDivisors;B[M]=1,N[M]===0&&(i.enableVertexAttribArray(M),N[M]=1),V[M]!==I&&(i.vertexAttribDivisor(M,I),V[M]=I)}function x(){const M=r.newAttributes,I=r.enabledAttributes;for(let B=0,N=I.length;B<N;B++)I[B]!==M[B]&&(i.disableVertexAttribArray(B),I[B]=0)}function b(M,I,B,N,V,Y,$){$===!0?i.vertexAttribIPointer(M,I,B,V,Y):i.vertexAttribPointer(M,I,B,N,V,Y)}function v(M,I,B,N){_();const V=N.attributes,Y=B.getAttributes(),$=I.defaultAttributeValues;for(const Q in Y){const G=Y[Q];if(G.location>=0){let ce=V[Q];if(ce===void 0&&(Q==="instanceMatrix"&&M.instanceMatrix&&(ce=M.instanceMatrix),Q==="instanceColor"&&M.instanceColor&&(ce=M.instanceColor)),ce!==void 0){const fe=ce.normalized,Re=ce.itemSize,Ve=e.get(ce);if(Ve===void 0)continue;const ht=Ve.buffer,K=Ve.type,re=Ve.bytesPerElement,Ee=K===i.INT||K===i.UNSIGNED_INT||ce.gpuType===Ld;if(ce.isInterleavedBufferAttribute){const de=ce.data,Ae=de.stride,Je=ce.offset;if(de.isInstancedInterleavedBuffer){for(let Ue=0;Ue<G.locationSize;Ue++)p(G.location+Ue,de.meshPerAttribute);M.isInstancedMesh!==!0&&N._maxInstanceCount===void 0&&(N._maxInstanceCount=de.meshPerAttribute*de.count)}else for(let Ue=0;Ue<G.locationSize;Ue++)m(G.location+Ue);i.bindBuffer(i.ARRAY_BUFFER,ht);for(let Ue=0;Ue<G.locationSize;Ue++)b(G.location+Ue,Re/G.locationSize,K,fe,Ae*re,(Je+Re/G.locationSize*Ue)*re,Ee)}else{if(ce.isInstancedBufferAttribute){for(let de=0;de<G.locationSize;de++)p(G.location+de,ce.meshPerAttribute);M.isInstancedMesh!==!0&&N._maxInstanceCount===void 0&&(N._maxInstanceCount=ce.meshPerAttribute*ce.count)}else for(let de=0;de<G.locationSize;de++)m(G.location+de);i.bindBuffer(i.ARRAY_BUFFER,ht);for(let de=0;de<G.locationSize;de++)b(G.location+de,Re/G.locationSize,K,fe,Re*re,Re/G.locationSize*de*re,Ee)}}else if($!==void 0){const fe=$[Q];if(fe!==void 0)switch(fe.length){case 2:i.vertexAttrib2fv(G.location,fe);break;case 3:i.vertexAttrib3fv(G.location,fe);break;case 4:i.vertexAttrib4fv(G.location,fe);break;default:i.vertexAttrib1fv(G.location,fe)}}}}x()}function P(){D();for(const M in n){const I=n[M];for(const B in I){const N=I[B];for(const V in N)d(N[V].object),delete N[V];delete I[B]}delete n[M]}}function C(M){if(n[M.id]===void 0)return;const I=n[M.id];for(const B in I){const N=I[B];for(const V in N)d(N[V].object),delete N[V];delete I[B]}delete n[M.id]}function T(M){for(const I in n){const B=n[I];if(B[M.id]===void 0)continue;const N=B[M.id];for(const V in N)d(N[V].object),delete N[V];delete B[M.id]}}function D(){w(),o=!0,r!==s&&(r=s,u(r.object))}function w(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:l,reset:D,resetDefaultState:w,dispose:P,releaseStatesOfGeometry:C,releaseStatesOfProgram:T,initAttributes:_,enableAttribute:m,disableUnusedAttributes:x}}function hS(i,e,t){let n;function s(u){n=u}function r(u,d){i.drawArrays(n,u,d),t.update(d,n,1)}function o(u,d,a){a!==0&&(i.drawArraysInstanced(n,u,d,a),t.update(d,n,a))}function l(u,d,a){if(a===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,u,0,d,0,a);let f=0;for(let g=0;g<a;g++)f+=d[g];t.update(f,n,1)}function c(u,d,a,h){if(a===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<u.length;g++)o(u[g],d[g],h[g]);else{f.multiDrawArraysInstancedWEBGL(n,u,0,d,0,h,0,a);let g=0;for(let _=0;_<a;_++)g+=d[_]*h[_];t.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=l,this.renderMultiDrawInstances=c}function uS(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const T=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==Rn&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function l(T){const D=T===Co&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(T!==Wn&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==zn&&!D)}function c(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=t.precision!==void 0?t.precision:"highp";const d=c(u);d!==u&&(console.warn("THREE.WebGLRenderer:",u,"not supported, using",d,"instead."),u=d);const a=t.logarithmicDepthBuffer===!0,h=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),x=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),b=i.getParameter(i.MAX_VARYING_VECTORS),v=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),P=g>0,C=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:l,precision:u,logarithmicDepthBuffer:a,reverseDepthBuffer:h,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:x,maxVaryings:b,maxFragmentUniforms:v,vertexTextures:P,maxSamples:C}}function dS(i){const e=this;let t=null,n=0,s=!1,r=!1;const o=new ri,l=new Be,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(a,h){const f=a.length!==0||h||n!==0||s;return s=h,n=a.length,f},this.beginShadows=function(){r=!0,d(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(a,h){t=d(a,h,0)},this.setState=function(a,h,f){const g=a.clippingPlanes,_=a.clipIntersection,m=a.clipShadows,p=i.get(a);if(!s||g===null||g.length===0||r&&!m)r?d(null):u();else{const x=r?0:n,b=x*4;let v=p.clippingState||null;c.value=v,v=d(g,h,b,f);for(let P=0;P!==b;++P)v[P]=t[P];p.clippingState=v,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=x}};function u(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function d(a,h,f,g){const _=a!==null?a.length:0;let m=null;if(_!==0){if(m=c.value,g!==!0||m===null){const p=f+_*4,x=h.matrixWorldInverse;l.getNormalMatrix(x),(m===null||m.length<p)&&(m=new Float32Array(p));for(let b=0,v=f;b!==_;++b,v+=4)o.copy(a[b]).applyMatrix4(x,l),o.normal.toArray(m,v),m[v+3]=o.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function fS(i){let e=new WeakMap;function t(o,l){return l===vu?o.mapping=dr:l===bu&&(o.mapping=fr),o}function n(o){if(o&&o.isTexture){const l=o.mapping;if(l===vu||l===bu)if(e.has(o)){const c=e.get(o).texture;return t(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const u=new rb(c.height);return u.fromEquirectangularTexture(i,o),e.set(o,u),o.addEventListener("dispose",s),t(u.texture,o.mapping)}else return null}}return o}function s(o){const l=o.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}const Ys=4,Mm=[.125,.215,.35,.446,.526,.582],ji=20,$c=new K_,wm=new se;let Yc=null,qc=0,jc=0,Kc=!1;const Wi=(1+Math.sqrt(5))/2,Fs=1/Wi,Sm=[new A(-Wi,Fs,0),new A(Wi,Fs,0),new A(-Fs,0,Wi),new A(Fs,0,Wi),new A(0,Wi,-Fs),new A(0,Wi,Fs),new A(-1,1,-1),new A(1,1,-1),new A(-1,1,1),new A(1,1,1)],pS=new A;class Em{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100,r={}){const{size:o=256,position:l=pS}=r;Yc=this._renderer.getRenderTarget(),qc=this._renderer.getActiveCubeFace(),jc=this._renderer.getActiveMipmapLevel(),Kc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(e,n,s,c,l),t>0&&this._blur(c,0,0,t),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Cm(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Tm(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Yc,qc,jc),this._renderer.xr.enabled=Kc,e.scissorTest=!1,ha(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===dr||e.mapping===fr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Yc=this._renderer.getRenderTarget(),qc=this._renderer.getActiveCubeFace(),jc=this._renderer.getActiveMipmapLevel(),Kc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Bn,minFilter:Bn,generateMipmaps:!1,type:Co,format:Rn,colorSpace:pr,depthBuffer:!1},s=Am(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Am(e,t,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=mS(r)),this._blurMaterial=gS(r,e,t)}return s}_compileMaterial(e){const t=new at(this._lodPlanes[0],e);this._renderer.compile(t,$c)}_sceneToCubeUV(e,t,n,s,r){const c=new gn(90,1,t,n),u=[1,-1,1,1,1,1],d=[1,1,1,-1,-1,-1],a=this._renderer,h=a.autoClear,f=a.toneMapping;a.getClearColor(wm),a.toneMapping=Ai,a.autoClear=!1;const g=new dt({name:"PMREM.Background",side:Wt,depthWrite:!1,depthTest:!1}),_=new at(new Bt,g);let m=!1;const p=e.background;p?p.isColor&&(g.color.copy(p),e.background=null,m=!0):(g.color.copy(wm),m=!0);for(let x=0;x<6;x++){const b=x%3;b===0?(c.up.set(0,u[x],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+d[x],r.y,r.z)):b===1?(c.up.set(0,0,u[x]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+d[x],r.z)):(c.up.set(0,u[x],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+d[x]));const v=this._cubeSize;ha(s,b*v,x>2?v:0,v,v),a.setRenderTarget(s),m&&a.render(_,c),a.render(e,c)}_.geometry.dispose(),_.material.dispose(),a.toneMapping=f,a.autoClear=h,e.background=p}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===dr||e.mapping===fr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Cm()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Tm());const r=s?this._cubemapMaterial:this._equirectMaterial,o=new at(this._lodPlanes[0],r),l=r.uniforms;l.envMap.value=e;const c=this._cubeSize;ha(t,0,0,3*c,2*c),n.setRenderTarget(t),n.render(o,$c)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),l=Sm[(s-r-1)%Sm.length];this._blur(e,r-1,r,o,l)}t.autoClear=n}_blur(e,t,n,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,l){const c=this._renderer,u=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,a=new at(this._lodPlanes[s],u),h=u.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*ji-1),_=r/g,m=isFinite(r)?1+Math.floor(d*_):ji;m>ji&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${ji}`);const p=[];let x=0;for(let T=0;T<ji;++T){const D=T/_,w=Math.exp(-D*D/2);p.push(w),T===0?x+=w:T<m&&(x+=2*w)}for(let T=0;T<p.length;T++)p[T]=p[T]/x;h.envMap.value=e.texture,h.samples.value=m,h.weights.value=p,h.latitudinal.value=o==="latitudinal",l&&(h.poleAxis.value=l);const{_lodMax:b}=this;h.dTheta.value=g,h.mipInt.value=b-n;const v=this._sizeLods[s],P=3*v*(s>b-Ys?s-b+Ys:0),C=4*(this._cubeSize-v);ha(t,P,C,3*v,2*v),c.setRenderTarget(t),c.render(a,$c)}}function mS(i){const e=[],t=[],n=[];let s=i;const r=i-Ys+1+Mm.length;for(let o=0;o<r;o++){const l=Math.pow(2,s);t.push(l);let c=1/l;o>i-Ys?c=Mm[o-i+Ys-1]:o===0&&(c=0),n.push(c);const u=1/(l-2),d=-u,a=1+u,h=[d,d,a,d,a,a,d,d,a,a,d,a],f=6,g=6,_=3,m=2,p=1,x=new Float32Array(_*g*f),b=new Float32Array(m*g*f),v=new Float32Array(p*g*f);for(let C=0;C<f;C++){const T=C%3*2/3-1,D=C>2?0:-1,w=[T,D,0,T+2/3,D,0,T+2/3,D+1,0,T,D,0,T+2/3,D+1,0,T,D+1,0];x.set(w,_*g*C),b.set(h,m*g*C);const M=[C,C,C,C,C,C];v.set(M,p*g*C)}const P=new Ut;P.setAttribute("position",new cn(x,_)),P.setAttribute("uv",new cn(b,m)),P.setAttribute("faceIndex",new cn(v,p)),e.push(P),s>Ys&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function Am(i,e,t){const n=new cs(i,e,t);return n.texture.mapping=rc,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ha(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function gS(i,e,t){const n=new Float32Array(ji),s=new A(0,1,0);return new Ii({name:"SphericalGaussianBlur",defines:{n:ji,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Xd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ei,depthTest:!1,depthWrite:!1})}function Tm(){return new Ii({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Xd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ei,depthTest:!1,depthWrite:!1})}function Cm(){return new Ii({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Xd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ei,depthTest:!1,depthWrite:!1})}function Xd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function _S(i){let e=new WeakMap,t=null;function n(l){if(l&&l.isTexture){const c=l.mapping,u=c===vu||c===bu,d=c===dr||c===fr;if(u||d){let a=e.get(l);const h=a!==void 0?a.texture.pmremVersion:0;if(l.isRenderTargetTexture&&l.pmremVersion!==h)return t===null&&(t=new Em(i)),a=u?t.fromEquirectangular(l,a):t.fromCubemap(l,a),a.texture.pmremVersion=l.pmremVersion,e.set(l,a),a.texture;if(a!==void 0)return a.texture;{const f=l.image;return u&&f&&f.height>0||d&&f&&s(f)?(t===null&&(t=new Em(i)),a=u?t.fromEquirectangular(l):t.fromCubemap(l),a.texture.pmremVersion=l.pmremVersion,e.set(l,a),l.addEventListener("dispose",r),a.texture):null}}}return l}function s(l){let c=0;const u=6;for(let d=0;d<u;d++)l[d]!==void 0&&c++;return c===u}function r(l){const c=l.target;c.removeEventListener("dispose",r);const u=e.get(c);u!==void 0&&(e.delete(c),u.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function xS(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&nr("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function yS(i,e,t,n){const s={},r=new WeakMap;function o(a){const h=a.target;h.index!==null&&e.remove(h.index);for(const g in h.attributes)e.remove(h.attributes[g]);h.removeEventListener("dispose",o),delete s[h.id];const f=r.get(h);f&&(e.remove(f),r.delete(h)),n.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function l(a,h){return s[h.id]===!0||(h.addEventListener("dispose",o),s[h.id]=!0,t.memory.geometries++),h}function c(a){const h=a.attributes;for(const f in h)e.update(h[f],i.ARRAY_BUFFER)}function u(a){const h=[],f=a.index,g=a.attributes.position;let _=0;if(f!==null){const x=f.array;_=f.version;for(let b=0,v=x.length;b<v;b+=3){const P=x[b+0],C=x[b+1],T=x[b+2];h.push(P,C,C,T,T,P)}}else if(g!==void 0){const x=g.array;_=g.version;for(let b=0,v=x.length/3-1;b<v;b+=3){const P=b+0,C=b+1,T=b+2;h.push(P,C,C,T,T,P)}}else return;const m=new(k_(h)?V_:H_)(h,1);m.version=_;const p=r.get(a);p&&e.remove(p),r.set(a,m)}function d(a){const h=r.get(a);if(h){const f=a.index;f!==null&&h.version<f.version&&u(a)}else u(a);return r.get(a)}return{get:l,update:c,getWireframeAttribute:d}}function vS(i,e,t){let n;function s(h){n=h}let r,o;function l(h){r=h.type,o=h.bytesPerElement}function c(h,f){i.drawElements(n,f,r,h*o),t.update(f,n,1)}function u(h,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,h*o,g),t.update(f,n,g))}function d(h,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,h,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];t.update(m,n,1)}function a(h,f,g,_){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<h.length;p++)u(h[p]/o,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,h,0,_,0,g);let p=0;for(let x=0;x<g;x++)p+=f[x]*_[x];t.update(p,n,1)}}this.setMode=s,this.setIndex=l,this.render=c,this.renderInstances=u,this.renderMultiDraw=d,this.renderMultiDrawInstances=a}function bS(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,l){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=l*(r/3);break;case i.LINES:t.lines+=l*(r/2);break;case i.LINE_STRIP:t.lines+=l*(r-1);break;case i.LINE_LOOP:t.lines+=l*r;break;case i.POINTS:t.points+=l*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function MS(i,e,t){const n=new WeakMap,s=new Mt;function r(o,l,c){const u=o.morphTargetInfluences,d=l.morphAttributes.position||l.morphAttributes.normal||l.morphAttributes.color,a=d!==void 0?d.length:0;let h=n.get(l);if(h===void 0||h.count!==a){let M=function(){D.dispose(),n.delete(l),l.removeEventListener("dispose",M)};var f=M;h!==void 0&&h.texture.dispose();const g=l.morphAttributes.position!==void 0,_=l.morphAttributes.normal!==void 0,m=l.morphAttributes.color!==void 0,p=l.morphAttributes.position||[],x=l.morphAttributes.normal||[],b=l.morphAttributes.color||[];let v=0;g===!0&&(v=1),_===!0&&(v=2),m===!0&&(v=3);let P=l.attributes.position.count*v,C=1;P>e.maxTextureSize&&(C=Math.ceil(P/e.maxTextureSize),P=e.maxTextureSize);const T=new Float32Array(P*C*4*a),D=new B_(T,P,C,a);D.type=zn,D.needsUpdate=!0;const w=v*4;for(let I=0;I<a;I++){const B=p[I],N=x[I],V=b[I],Y=P*C*4*I;for(let $=0;$<B.count;$++){const Q=$*w;g===!0&&(s.fromBufferAttribute(B,$),T[Y+Q+0]=s.x,T[Y+Q+1]=s.y,T[Y+Q+2]=s.z,T[Y+Q+3]=0),_===!0&&(s.fromBufferAttribute(N,$),T[Y+Q+4]=s.x,T[Y+Q+5]=s.y,T[Y+Q+6]=s.z,T[Y+Q+7]=0),m===!0&&(s.fromBufferAttribute(V,$),T[Y+Q+8]=s.x,T[Y+Q+9]=s.y,T[Y+Q+10]=s.z,T[Y+Q+11]=V.itemSize===4?s.w:1)}}h={count:a,texture:D,size:new xe(P,C)},n.set(l,h),l.addEventListener("dispose",M)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let g=0;for(let m=0;m<u.length;m++)g+=u[m];const _=l.morphTargetsRelative?1:1-g;c.getUniforms().setValue(i,"morphTargetBaseInfluence",_),c.getUniforms().setValue(i,"morphTargetInfluences",u)}c.getUniforms().setValue(i,"morphTargetsTexture",h.texture,t),c.getUniforms().setValue(i,"morphTargetsTextureSize",h.size)}return{update:r}}function wS(i,e,t,n){let s=new WeakMap;function r(c){const u=n.render.frame,d=c.geometry,a=e.get(c,d);if(s.get(a)!==u&&(e.update(a),s.set(a,u)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),s.get(c)!==u&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,u))),c.isSkinnedMesh){const h=c.skeleton;s.get(h)!==u&&(h.update(),s.set(h,u))}return a}function o(){s=new WeakMap}function l(c){const u=c.target;u.removeEventListener("dispose",l),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:r,dispose:o}}const J_=new kt,Rm=new q_(1,1),Q_=new B_,ex=new V1,tx=new X_,Pm=[],Im=[],Lm=new Float32Array(16),Dm=new Float32Array(9),Um=new Float32Array(4);function Sr(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=Pm[s];if(r===void 0&&(r=new Float32Array(s),Pm[s]=r),e!==0){n.toArray(r,0);for(let o=1,l=0;o!==e;++o)l+=t,i[o].toArray(r,l)}return r}function Rt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Pt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ac(i,e){let t=Im[e];t===void 0&&(t=new Int32Array(e),Im[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function SS(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function ES(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2fv(this.addr,e),Pt(t,e)}}function AS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Rt(t,e))return;i.uniform3fv(this.addr,e),Pt(t,e)}}function TS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4fv(this.addr,e),Pt(t,e)}}function CS(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;Um.set(n),i.uniformMatrix2fv(this.addr,!1,Um),Pt(t,n)}}function RS(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;Dm.set(n),i.uniformMatrix3fv(this.addr,!1,Dm),Pt(t,n)}}function PS(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;Lm.set(n),i.uniformMatrix4fv(this.addr,!1,Lm),Pt(t,n)}}function IS(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function LS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2iv(this.addr,e),Pt(t,e)}}function DS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Rt(t,e))return;i.uniform3iv(this.addr,e),Pt(t,e)}}function US(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4iv(this.addr,e),Pt(t,e)}}function OS(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function FS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2uiv(this.addr,e),Pt(t,e)}}function NS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Rt(t,e))return;i.uniform3uiv(this.addr,e),Pt(t,e)}}function kS(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4uiv(this.addr,e),Pt(t,e)}}function BS(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(Rm.compareFunction=N_,r=Rm):r=J_,t.setTexture2D(e||r,s)}function zS(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||ex,s)}function HS(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||tx,s)}function VS(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||Q_,s)}function GS(i){switch(i){case 5126:return SS;case 35664:return ES;case 35665:return AS;case 35666:return TS;case 35674:return CS;case 35675:return RS;case 35676:return PS;case 5124:case 35670:return IS;case 35667:case 35671:return LS;case 35668:case 35672:return DS;case 35669:case 35673:return US;case 5125:return OS;case 36294:return FS;case 36295:return NS;case 36296:return kS;case 35678:case 36198:case 36298:case 36306:case 35682:return BS;case 35679:case 36299:case 36307:return zS;case 35680:case 36300:case 36308:case 36293:return HS;case 36289:case 36303:case 36311:case 36292:return VS}}function WS(i,e){i.uniform1fv(this.addr,e)}function XS(i,e){const t=Sr(e,this.size,2);i.uniform2fv(this.addr,t)}function $S(i,e){const t=Sr(e,this.size,3);i.uniform3fv(this.addr,t)}function YS(i,e){const t=Sr(e,this.size,4);i.uniform4fv(this.addr,t)}function qS(i,e){const t=Sr(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function jS(i,e){const t=Sr(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function KS(i,e){const t=Sr(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function ZS(i,e){i.uniform1iv(this.addr,e)}function JS(i,e){i.uniform2iv(this.addr,e)}function QS(i,e){i.uniform3iv(this.addr,e)}function eE(i,e){i.uniform4iv(this.addr,e)}function tE(i,e){i.uniform1uiv(this.addr,e)}function nE(i,e){i.uniform2uiv(this.addr,e)}function iE(i,e){i.uniform3uiv(this.addr,e)}function sE(i,e){i.uniform4uiv(this.addr,e)}function rE(i,e,t){const n=this.cache,s=e.length,r=ac(t,s);Rt(n,r)||(i.uniform1iv(this.addr,r),Pt(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||J_,r[o])}function oE(i,e,t){const n=this.cache,s=e.length,r=ac(t,s);Rt(n,r)||(i.uniform1iv(this.addr,r),Pt(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||ex,r[o])}function aE(i,e,t){const n=this.cache,s=e.length,r=ac(t,s);Rt(n,r)||(i.uniform1iv(this.addr,r),Pt(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||tx,r[o])}function lE(i,e,t){const n=this.cache,s=e.length,r=ac(t,s);Rt(n,r)||(i.uniform1iv(this.addr,r),Pt(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||Q_,r[o])}function cE(i){switch(i){case 5126:return WS;case 35664:return XS;case 35665:return $S;case 35666:return YS;case 35674:return qS;case 35675:return jS;case 35676:return KS;case 5124:case 35670:return ZS;case 35667:case 35671:return JS;case 35668:case 35672:return QS;case 35669:case 35673:return eE;case 5125:return tE;case 36294:return nE;case 36295:return iE;case 36296:return sE;case 35678:case 36198:case 36298:case 36306:case 35682:return rE;case 35679:case 36299:case 36307:return oE;case 35680:case 36300:case 36308:case 36293:return aE;case 36289:case 36303:case 36311:case 36292:return lE}}class hE{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=GS(t.type)}}class uE{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=cE(t.type)}}class dE{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const l=s[r];l.setValue(e,t[l.id],n)}}}const Zc=/(\w+)(\])?(\[|\.)?/g;function Om(i,e){i.seq.push(e),i.map[e.id]=e}function fE(i,e,t){const n=i.name,s=n.length;for(Zc.lastIndex=0;;){const r=Zc.exec(n),o=Zc.lastIndex;let l=r[1];const c=r[2]==="]",u=r[3];if(c&&(l=l|0),u===void 0||u==="["&&o+2===s){Om(t,u===void 0?new hE(l,i,e):new uE(l,i,e));break}else{let a=t.map[l];a===void 0&&(a=new dE(l),Om(t,a)),t=a}}}class gl{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);fE(r,o,this)}}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){const l=t[r],c=n[l.id];c.needsUpdate!==!1&&l.setValue(e,c.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in t&&n.push(o)}return n}}function Fm(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const pE=37297;let mE=0;function gE(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){const l=o+1;n.push(`${l===e?">":" "} ${l}: ${t[o]}`)}return n.join(`
`)}const Nm=new Be;function _E(i){Ke._getMatrix(Nm,Ke.workingColorSpace,i);const e=`mat3( ${Nm.elements.map(t=>t.toFixed(4))} )`;switch(Ke.getTransfer(i)){case Tl:return[e,"LinearTransferOETF"];case lt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function km(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const o=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+gE(i.getShaderSource(e),o)}else return s}function xE(i,e){const t=_E(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function yE(i,e){let t;switch(e){case f1:t="Linear";break;case p1:t="Reinhard";break;case m1:t="Cineon";break;case g1:t="ACESFilmic";break;case x1:t="AgX";break;case y1:t="Neutral";break;case _1:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ua=new A;function vE(){Ke.getLuminanceCoefficients(ua);const i=ua.x.toFixed(4),e=ua.y.toFixed(4),t=ua.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function bE(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Yr).join(`
`)}function ME(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function wE(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),o=r.name;let l=1;r.type===i.FLOAT_MAT2&&(l=2),r.type===i.FLOAT_MAT3&&(l=3),r.type===i.FLOAT_MAT4&&(l=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:l}}return t}function Yr(i){return i!==""}function Bm(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function zm(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const SE=/^[ \t]*#include +<([\w\d./]+)>/gm;function ed(i){return i.replace(SE,AE)}const EE=new Map;function AE(i,e){let t=He[e];if(t===void 0){const n=EE.get(e);if(n!==void 0)t=He[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return ed(t)}const TE=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Hm(i){return i.replace(TE,CE)}function CE(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Vm(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function RE(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===C_?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===$v?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===ii&&(e="SHADOWMAP_TYPE_VSM"),e}function PE(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case dr:case fr:e="ENVMAP_TYPE_CUBE";break;case rc:e="ENVMAP_TYPE_CUBE_UV";break}return e}function IE(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case fr:e="ENVMAP_MODE_REFRACTION";break}return e}function LE(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case sc:e="ENVMAP_BLENDING_MULTIPLY";break;case u1:e="ENVMAP_BLENDING_MIX";break;case d1:e="ENVMAP_BLENDING_ADD";break}return e}function DE(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function UE(i,e,t,n){const s=i.getContext(),r=t.defines;let o=t.vertexShader,l=t.fragmentShader;const c=RE(t),u=PE(t),d=IE(t),a=LE(t),h=DE(t),f=bE(t),g=ME(r),_=s.createProgram();let m,p,x=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Yr).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Yr).join(`
`),p.length>0&&(p+=`
`)):(m=[Vm(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Yr).join(`
`),p=[Vm(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.envMap?"#define "+d:"",t.envMap?"#define "+a:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ai?"#define TONE_MAPPING":"",t.toneMapping!==Ai?He.tonemapping_pars_fragment:"",t.toneMapping!==Ai?yE("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",He.colorspace_pars_fragment,xE("linearToOutputTexel",t.outputColorSpace),vE(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Yr).join(`
`)),o=ed(o),o=Bm(o,t),o=zm(o,t),l=ed(l),l=Bm(l,t),l=zm(l,t),o=Hm(o),l=Hm(l),t.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===Hp?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Hp?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const b=x+m+o,v=x+p+l,P=Fm(s,s.VERTEX_SHADER,b),C=Fm(s,s.FRAGMENT_SHADER,v);s.attachShader(_,P),s.attachShader(_,C),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function T(I){if(i.debug.checkShaderErrors){const B=s.getProgramInfoLog(_).trim(),N=s.getShaderInfoLog(P).trim(),V=s.getShaderInfoLog(C).trim();let Y=!0,$=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(Y=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,P,C);else{const Q=km(s,P,"vertex"),G=km(s,C,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+I.name+`
Material Type: `+I.type+`

Program Info Log: `+B+`
`+Q+`
`+G)}else B!==""?console.warn("THREE.WebGLProgram: Program Info Log:",B):(N===""||V==="")&&($=!1);$&&(I.diagnostics={runnable:Y,programLog:B,vertexShader:{log:N,prefix:m},fragmentShader:{log:V,prefix:p}})}s.deleteShader(P),s.deleteShader(C),D=new gl(s,_),w=wE(s,_)}let D;this.getUniforms=function(){return D===void 0&&T(this),D};let w;this.getAttributes=function(){return w===void 0&&T(this),w};let M=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=s.getProgramParameter(_,pE)),M},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=mE++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=P,this.fragmentShader=C,this}let OE=0;class FE{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new NE(e),t.set(e,n)),n}}class NE{constructor(e){this.id=OE++,this.code=e,this.usedTimes=0}}function kE(i,e,t,n,s,r,o){const l=new Hd,c=new FE,u=new Set,d=[],a=s.logarithmicDepthBuffer,h=s.vertexTextures;let f=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(w){return u.add(w),w===0?"uv":`uv${w}`}function m(w,M,I,B,N){const V=B.fog,Y=N.geometry,$=w.isMeshStandardMaterial?B.environment:null,Q=(w.isMeshStandardMaterial?t:e).get(w.envMap||$),G=Q&&Q.mapping===rc?Q.image.height:null,ce=g[w.type];w.precision!==null&&(f=s.getMaxPrecision(w.precision),f!==w.precision&&console.warn("THREE.WebGLProgram.getParameters:",w.precision,"not supported, using",f,"instead."));const fe=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,Re=fe!==void 0?fe.length:0;let Ve=0;Y.morphAttributes.position!==void 0&&(Ve=1),Y.morphAttributes.normal!==void 0&&(Ve=2),Y.morphAttributes.color!==void 0&&(Ve=3);let ht,K,re,Ee;if(ce){const st=Nn[ce];ht=st.vertexShader,K=st.fragmentShader}else ht=w.vertexShader,K=w.fragmentShader,c.update(w),re=c.getVertexShaderID(w),Ee=c.getFragmentShaderID(w);const de=i.getRenderTarget(),Ae=i.state.buffers.depth.getReversed(),Je=N.isInstancedMesh===!0,Ue=N.isBatchedMesh===!0,_t=!!w.map,xt=!!w.matcap,Qe=!!Q,L=!!w.aoMap,zt=!!w.lightMap,et=!!w.bumpMap,ut=!!w.normalMap,Me=!!w.displacementMap,qe=!!w.emissiveMap,Pe=!!w.metalnessMap,ze=!!w.roughnessMap,Tt=w.anisotropy>0,R=w.clearcoat>0,y=w.dispersion>0,k=w.iridescence>0,q=w.sheen>0,J=w.transmission>0,X=Tt&&!!w.anisotropyMap,we=R&&!!w.clearcoatMap,le=R&&!!w.clearcoatNormalMap,be=R&&!!w.clearcoatRoughnessMap,Se=k&&!!w.iridescenceMap,ee=k&&!!w.iridescenceThicknessMap,pe=q&&!!w.sheenColorMap,De=q&&!!w.sheenRoughnessMap,Le=!!w.specularMap,oe=!!w.specularColorMap,Ne=!!w.specularIntensityMap,U=J&&!!w.transmissionMap,he=J&&!!w.thicknessMap,te=!!w.gradientMap,ge=!!w.alphaMap,ne=w.alphaTest>0,Z=!!w.alphaHash,ye=!!w.extensions;let ke=Ai;w.toneMapped&&(de===null||de.isXRRenderTarget===!0)&&(ke=i.toneMapping);const ft={shaderID:ce,shaderType:w.type,shaderName:w.name,vertexShader:ht,fragmentShader:K,defines:w.defines,customVertexShaderID:re,customFragmentShaderID:Ee,isRawShaderMaterial:w.isRawShaderMaterial===!0,glslVersion:w.glslVersion,precision:f,batching:Ue,batchingColor:Ue&&N._colorsTexture!==null,instancing:Je,instancingColor:Je&&N.instanceColor!==null,instancingMorph:Je&&N.morphTexture!==null,supportsVertexTextures:h,outputColorSpace:de===null?i.outputColorSpace:de.isXRRenderTarget===!0?de.texture.colorSpace:pr,alphaToCoverage:!!w.alphaToCoverage,map:_t,matcap:xt,envMap:Qe,envMapMode:Qe&&Q.mapping,envMapCubeUVHeight:G,aoMap:L,lightMap:zt,bumpMap:et,normalMap:ut,displacementMap:h&&Me,emissiveMap:qe,normalMapObjectSpace:ut&&w.normalMapType===w1,normalMapTangentSpace:ut&&w.normalMapType===Bd,metalnessMap:Pe,roughnessMap:ze,anisotropy:Tt,anisotropyMap:X,clearcoat:R,clearcoatMap:we,clearcoatNormalMap:le,clearcoatRoughnessMap:be,dispersion:y,iridescence:k,iridescenceMap:Se,iridescenceThicknessMap:ee,sheen:q,sheenColorMap:pe,sheenRoughnessMap:De,specularMap:Le,specularColorMap:oe,specularIntensityMap:Ne,transmission:J,transmissionMap:U,thicknessMap:he,gradientMap:te,opaque:w.transparent===!1&&w.blending===tr&&w.alphaToCoverage===!1,alphaMap:ge,alphaTest:ne,alphaHash:Z,combine:w.combine,mapUv:_t&&_(w.map.channel),aoMapUv:L&&_(w.aoMap.channel),lightMapUv:zt&&_(w.lightMap.channel),bumpMapUv:et&&_(w.bumpMap.channel),normalMapUv:ut&&_(w.normalMap.channel),displacementMapUv:Me&&_(w.displacementMap.channel),emissiveMapUv:qe&&_(w.emissiveMap.channel),metalnessMapUv:Pe&&_(w.metalnessMap.channel),roughnessMapUv:ze&&_(w.roughnessMap.channel),anisotropyMapUv:X&&_(w.anisotropyMap.channel),clearcoatMapUv:we&&_(w.clearcoatMap.channel),clearcoatNormalMapUv:le&&_(w.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:be&&_(w.clearcoatRoughnessMap.channel),iridescenceMapUv:Se&&_(w.iridescenceMap.channel),iridescenceThicknessMapUv:ee&&_(w.iridescenceThicknessMap.channel),sheenColorMapUv:pe&&_(w.sheenColorMap.channel),sheenRoughnessMapUv:De&&_(w.sheenRoughnessMap.channel),specularMapUv:Le&&_(w.specularMap.channel),specularColorMapUv:oe&&_(w.specularColorMap.channel),specularIntensityMapUv:Ne&&_(w.specularIntensityMap.channel),transmissionMapUv:U&&_(w.transmissionMap.channel),thicknessMapUv:he&&_(w.thicknessMap.channel),alphaMapUv:ge&&_(w.alphaMap.channel),vertexTangents:!!Y.attributes.tangent&&(ut||Tt),vertexColors:w.vertexColors,vertexAlphas:w.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!Y.attributes.uv&&(_t||ge),fog:!!V,useFog:w.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:w.flatShading===!0,sizeAttenuation:w.sizeAttenuation===!0,logarithmicDepthBuffer:a,reverseDepthBuffer:Ae,skinning:N.isSkinnedMesh===!0,morphTargets:Y.morphAttributes.position!==void 0,morphNormals:Y.morphAttributes.normal!==void 0,morphColors:Y.morphAttributes.color!==void 0,morphTargetsCount:Re,morphTextureStride:Ve,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:w.dithering,shadowMapEnabled:i.shadowMap.enabled&&I.length>0,shadowMapType:i.shadowMap.type,toneMapping:ke,decodeVideoTexture:_t&&w.map.isVideoTexture===!0&&Ke.getTransfer(w.map.colorSpace)===lt,decodeVideoTextureEmissive:qe&&w.emissiveMap.isVideoTexture===!0&&Ke.getTransfer(w.emissiveMap.colorSpace)===lt,premultipliedAlpha:w.premultipliedAlpha,doubleSided:w.side===kn,flipSided:w.side===Wt,useDepthPacking:w.depthPacking>=0,depthPacking:w.depthPacking||0,index0AttributeName:w.index0AttributeName,extensionClipCullDistance:ye&&w.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ye&&w.extensions.multiDraw===!0||Ue)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:w.customProgramCacheKey()};return ft.vertexUv1s=u.has(1),ft.vertexUv2s=u.has(2),ft.vertexUv3s=u.has(3),u.clear(),ft}function p(w){const M=[];if(w.shaderID?M.push(w.shaderID):(M.push(w.customVertexShaderID),M.push(w.customFragmentShaderID)),w.defines!==void 0)for(const I in w.defines)M.push(I),M.push(w.defines[I]);return w.isRawShaderMaterial===!1&&(x(M,w),b(M,w),M.push(i.outputColorSpace)),M.push(w.customProgramCacheKey),M.join()}function x(w,M){w.push(M.precision),w.push(M.outputColorSpace),w.push(M.envMapMode),w.push(M.envMapCubeUVHeight),w.push(M.mapUv),w.push(M.alphaMapUv),w.push(M.lightMapUv),w.push(M.aoMapUv),w.push(M.bumpMapUv),w.push(M.normalMapUv),w.push(M.displacementMapUv),w.push(M.emissiveMapUv),w.push(M.metalnessMapUv),w.push(M.roughnessMapUv),w.push(M.anisotropyMapUv),w.push(M.clearcoatMapUv),w.push(M.clearcoatNormalMapUv),w.push(M.clearcoatRoughnessMapUv),w.push(M.iridescenceMapUv),w.push(M.iridescenceThicknessMapUv),w.push(M.sheenColorMapUv),w.push(M.sheenRoughnessMapUv),w.push(M.specularMapUv),w.push(M.specularColorMapUv),w.push(M.specularIntensityMapUv),w.push(M.transmissionMapUv),w.push(M.thicknessMapUv),w.push(M.combine),w.push(M.fogExp2),w.push(M.sizeAttenuation),w.push(M.morphTargetsCount),w.push(M.morphAttributeCount),w.push(M.numDirLights),w.push(M.numPointLights),w.push(M.numSpotLights),w.push(M.numSpotLightMaps),w.push(M.numHemiLights),w.push(M.numRectAreaLights),w.push(M.numDirLightShadows),w.push(M.numPointLightShadows),w.push(M.numSpotLightShadows),w.push(M.numSpotLightShadowsWithMaps),w.push(M.numLightProbes),w.push(M.shadowMapType),w.push(M.toneMapping),w.push(M.numClippingPlanes),w.push(M.numClipIntersection),w.push(M.depthPacking)}function b(w,M){l.disableAll(),M.supportsVertexTextures&&l.enable(0),M.instancing&&l.enable(1),M.instancingColor&&l.enable(2),M.instancingMorph&&l.enable(3),M.matcap&&l.enable(4),M.envMap&&l.enable(5),M.normalMapObjectSpace&&l.enable(6),M.normalMapTangentSpace&&l.enable(7),M.clearcoat&&l.enable(8),M.iridescence&&l.enable(9),M.alphaTest&&l.enable(10),M.vertexColors&&l.enable(11),M.vertexAlphas&&l.enable(12),M.vertexUv1s&&l.enable(13),M.vertexUv2s&&l.enable(14),M.vertexUv3s&&l.enable(15),M.vertexTangents&&l.enable(16),M.anisotropy&&l.enable(17),M.alphaHash&&l.enable(18),M.batching&&l.enable(19),M.dispersion&&l.enable(20),M.batchingColor&&l.enable(21),w.push(l.mask),l.disableAll(),M.fog&&l.enable(0),M.useFog&&l.enable(1),M.flatShading&&l.enable(2),M.logarithmicDepthBuffer&&l.enable(3),M.reverseDepthBuffer&&l.enable(4),M.skinning&&l.enable(5),M.morphTargets&&l.enable(6),M.morphNormals&&l.enable(7),M.morphColors&&l.enable(8),M.premultipliedAlpha&&l.enable(9),M.shadowMapEnabled&&l.enable(10),M.doubleSided&&l.enable(11),M.flipSided&&l.enable(12),M.useDepthPacking&&l.enable(13),M.dithering&&l.enable(14),M.transmission&&l.enable(15),M.sheen&&l.enable(16),M.opaque&&l.enable(17),M.pointsUvs&&l.enable(18),M.decodeVideoTexture&&l.enable(19),M.decodeVideoTextureEmissive&&l.enable(20),M.alphaToCoverage&&l.enable(21),w.push(l.mask)}function v(w){const M=g[w.type];let I;if(M){const B=Nn[M];I=tb.clone(B.uniforms)}else I=w.uniforms;return I}function P(w,M){let I;for(let B=0,N=d.length;B<N;B++){const V=d[B];if(V.cacheKey===M){I=V,++I.usedTimes;break}}return I===void 0&&(I=new UE(i,M,w,r),d.push(I)),I}function C(w){if(--w.usedTimes===0){const M=d.indexOf(w);d[M]=d[d.length-1],d.pop(),w.destroy()}}function T(w){c.remove(w)}function D(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:P,releaseProgram:C,releaseShaderCache:T,programs:d,dispose:D}}function BE(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let l=i.get(o);return l===void 0&&(l={},i.set(o,l)),l}function n(o){i.delete(o)}function s(o,l,c){i.get(o)[l]=c}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function zE(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Gm(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Wm(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(a,h,f,g,_,m){let p=i[e];return p===void 0?(p={id:a.id,object:a,geometry:h,material:f,groupOrder:g,renderOrder:a.renderOrder,z:_,group:m},i[e]=p):(p.id=a.id,p.object=a,p.geometry=h,p.material=f,p.groupOrder=g,p.renderOrder=a.renderOrder,p.z=_,p.group=m),e++,p}function l(a,h,f,g,_,m){const p=o(a,h,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):t.push(p)}function c(a,h,f,g,_,m){const p=o(a,h,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):t.unshift(p)}function u(a,h){t.length>1&&t.sort(a||zE),n.length>1&&n.sort(h||Gm),s.length>1&&s.sort(h||Gm)}function d(){for(let a=e,h=i.length;a<h;a++){const f=i[a];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:l,unshift:c,finish:d,sort:u}}function HE(){let i=new WeakMap;function e(n,s){const r=i.get(n);let o;return r===void 0?(o=new Wm,i.set(n,[o])):s>=r.length?(o=new Wm,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function VE(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new A,color:new se};break;case"SpotLight":t={position:new A,direction:new A,color:new se,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new A,color:new se,distance:0,decay:0};break;case"HemisphereLight":t={direction:new A,skyColor:new se,groundColor:new se};break;case"RectAreaLight":t={color:new se,position:new A,halfWidth:new A,halfHeight:new A};break}return i[e.id]=t,t}}}function GE(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new xe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new xe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new xe,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let WE=0;function XE(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function $E(i){const e=new VE,t=GE(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)n.probe.push(new A);const s=new A,r=new We,o=new We;function l(u){let d=0,a=0,h=0;for(let w=0;w<9;w++)n.probe[w].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,x=0,b=0,v=0,P=0,C=0,T=0;u.sort(XE);for(let w=0,M=u.length;w<M;w++){const I=u[w],B=I.color,N=I.intensity,V=I.distance,Y=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)d+=B.r*N,a+=B.g*N,h+=B.b*N;else if(I.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(I.sh.coefficients[$],N);T++}else if(I.isDirectionalLight){const $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),I.castShadow){const Q=I.shadow,G=t.get(I);G.shadowIntensity=Q.intensity,G.shadowBias=Q.bias,G.shadowNormalBias=Q.normalBias,G.shadowRadius=Q.radius,G.shadowMapSize=Q.mapSize,n.directionalShadow[f]=G,n.directionalShadowMap[f]=Y,n.directionalShadowMatrix[f]=I.shadow.matrix,x++}n.directional[f]=$,f++}else if(I.isSpotLight){const $=e.get(I);$.position.setFromMatrixPosition(I.matrixWorld),$.color.copy(B).multiplyScalar(N),$.distance=V,$.coneCos=Math.cos(I.angle),$.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),$.decay=I.decay,n.spot[_]=$;const Q=I.shadow;if(I.map&&(n.spotLightMap[P]=I.map,P++,Q.updateMatrices(I),I.castShadow&&C++),n.spotLightMatrix[_]=Q.matrix,I.castShadow){const G=t.get(I);G.shadowIntensity=Q.intensity,G.shadowBias=Q.bias,G.shadowNormalBias=Q.normalBias,G.shadowRadius=Q.radius,G.shadowMapSize=Q.mapSize,n.spotShadow[_]=G,n.spotShadowMap[_]=Y,v++}_++}else if(I.isRectAreaLight){const $=e.get(I);$.color.copy(B).multiplyScalar(N),$.halfWidth.set(I.width*.5,0,0),$.halfHeight.set(0,I.height*.5,0),n.rectArea[m]=$,m++}else if(I.isPointLight){const $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),$.distance=I.distance,$.decay=I.decay,I.castShadow){const Q=I.shadow,G=t.get(I);G.shadowIntensity=Q.intensity,G.shadowBias=Q.bias,G.shadowNormalBias=Q.normalBias,G.shadowRadius=Q.radius,G.shadowMapSize=Q.mapSize,G.shadowCameraNear=Q.camera.near,G.shadowCameraFar=Q.camera.far,n.pointShadow[g]=G,n.pointShadowMap[g]=Y,n.pointShadowMatrix[g]=I.shadow.matrix,b++}n.point[g]=$,g++}else if(I.isHemisphereLight){const $=e.get(I);$.skyColor.copy(I.color).multiplyScalar(N),$.groundColor.copy(I.groundColor).multiplyScalar(N),n.hemi[p]=$,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ae.LTC_FLOAT_1,n.rectAreaLTC2=ae.LTC_FLOAT_2):(n.rectAreaLTC1=ae.LTC_HALF_1,n.rectAreaLTC2=ae.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=a,n.ambient[2]=h;const D=n.hash;(D.directionalLength!==f||D.pointLength!==g||D.spotLength!==_||D.rectAreaLength!==m||D.hemiLength!==p||D.numDirectionalShadows!==x||D.numPointShadows!==b||D.numSpotShadows!==v||D.numSpotMaps!==P||D.numLightProbes!==T)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=x,n.directionalShadowMap.length=x,n.pointShadow.length=b,n.pointShadowMap.length=b,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=x,n.pointShadowMatrix.length=b,n.spotLightMatrix.length=v+P-C,n.spotLightMap.length=P,n.numSpotLightShadowsWithMaps=C,n.numLightProbes=T,D.directionalLength=f,D.pointLength=g,D.spotLength=_,D.rectAreaLength=m,D.hemiLength=p,D.numDirectionalShadows=x,D.numPointShadows=b,D.numSpotShadows=v,D.numSpotMaps=P,D.numLightProbes=T,n.version=WE++)}function c(u,d){let a=0,h=0,f=0,g=0,_=0;const m=d.matrixWorldInverse;for(let p=0,x=u.length;p<x;p++){const b=u[p];if(b.isDirectionalLight){const v=n.directional[a];v.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(m),a++}else if(b.isSpotLight){const v=n.spot[f];v.position.setFromMatrixPosition(b.matrixWorld),v.position.applyMatrix4(m),v.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(m),f++}else if(b.isRectAreaLight){const v=n.rectArea[g];v.position.setFromMatrixPosition(b.matrixWorld),v.position.applyMatrix4(m),o.identity(),r.copy(b.matrixWorld),r.premultiply(m),o.extractRotation(r),v.halfWidth.set(b.width*.5,0,0),v.halfHeight.set(0,b.height*.5,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),g++}else if(b.isPointLight){const v=n.point[h];v.position.setFromMatrixPosition(b.matrixWorld),v.position.applyMatrix4(m),h++}else if(b.isHemisphereLight){const v=n.hemi[_];v.direction.setFromMatrixPosition(b.matrixWorld),v.direction.transformDirection(m),_++}}}return{setup:l,setupView:c,state:n}}function Xm(i){const e=new $E(i),t=[],n=[];function s(d){u.camera=d,t.length=0,n.length=0}function r(d){t.push(d)}function o(d){n.push(d)}function l(){e.setup(t)}function c(d){e.setupView(t,d)}const u={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:u,setupLights:l,setupLightsView:c,pushLight:r,pushShadow:o}}function YE(i){let e=new WeakMap;function t(s,r=0){const o=e.get(s);let l;return o===void 0?(l=new Xm(i),e.set(s,[l])):r>=o.length?(l=new Xm(i),o.push(l)):l=o[r],l}function n(){e=new WeakMap}return{get:t,dispose:n}}const qE=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,jE=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function KE(i,e,t){let n=new Vd;const s=new xe,r=new xe,o=new Mt,l=new db({depthPacking:M1}),c=new fb,u={},d=t.maxTextureSize,a={[Ri]:Wt,[Wt]:Ri,[kn]:kn},h=new Ii({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new xe},radius:{value:4}},vertexShader:qE,fragmentShader:jE}),f=h.clone();f.defines.HORIZONTAL_PASS=1;const g=new Ut;g.setAttribute("position",new cn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new at(g,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=C_;let p=this.type;this.render=function(C,T,D){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||C.length===0)return;const w=i.getRenderTarget(),M=i.getActiveCubeFace(),I=i.getActiveMipmapLevel(),B=i.state;B.setBlending(Ei),B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);const N=p!==ii&&this.type===ii,V=p===ii&&this.type!==ii;for(let Y=0,$=C.length;Y<$;Y++){const Q=C[Y],G=Q.shadow;if(G===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(G.autoUpdate===!1&&G.needsUpdate===!1)continue;s.copy(G.mapSize);const ce=G.getFrameExtents();if(s.multiply(ce),r.copy(G.mapSize),(s.x>d||s.y>d)&&(s.x>d&&(r.x=Math.floor(d/ce.x),s.x=r.x*ce.x,G.mapSize.x=r.x),s.y>d&&(r.y=Math.floor(d/ce.y),s.y=r.y*ce.y,G.mapSize.y=r.y)),G.map===null||N===!0||V===!0){const Re=this.type!==ii?{minFilter:ln,magFilter:ln}:{};G.map!==null&&G.map.dispose(),G.map=new cs(s.x,s.y,Re),G.map.texture.name=Q.name+".shadowMap",G.camera.updateProjectionMatrix()}i.setRenderTarget(G.map),i.clear();const fe=G.getViewportCount();for(let Re=0;Re<fe;Re++){const Ve=G.getViewport(Re);o.set(r.x*Ve.x,r.y*Ve.y,r.x*Ve.z,r.y*Ve.w),B.viewport(o),G.updateMatrices(Q,Re),n=G.getFrustum(),v(T,D,G.camera,Q,this.type)}G.isPointLightShadow!==!0&&this.type===ii&&x(G,D),G.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(w,M,I)};function x(C,T){const D=e.update(_);h.defines.VSM_SAMPLES!==C.blurSamples&&(h.defines.VSM_SAMPLES=C.blurSamples,f.defines.VSM_SAMPLES=C.blurSamples,h.needsUpdate=!0,f.needsUpdate=!0),C.mapPass===null&&(C.mapPass=new cs(s.x,s.y)),h.uniforms.shadow_pass.value=C.map.texture,h.uniforms.resolution.value=C.mapSize,h.uniforms.radius.value=C.radius,i.setRenderTarget(C.mapPass),i.clear(),i.renderBufferDirect(T,null,D,h,_,null),f.uniforms.shadow_pass.value=C.mapPass.texture,f.uniforms.resolution.value=C.mapSize,f.uniforms.radius.value=C.radius,i.setRenderTarget(C.map),i.clear(),i.renderBufferDirect(T,null,D,f,_,null)}function b(C,T,D,w){let M=null;const I=D.isPointLight===!0?C.customDistanceMaterial:C.customDepthMaterial;if(I!==void 0)M=I;else if(M=D.isPointLight===!0?c:l,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){const B=M.uuid,N=T.uuid;let V=u[B];V===void 0&&(V={},u[B]=V);let Y=V[N];Y===void 0&&(Y=M.clone(),V[N]=Y,T.addEventListener("dispose",P)),M=Y}if(M.visible=T.visible,M.wireframe=T.wireframe,w===ii?M.side=T.shadowSide!==null?T.shadowSide:T.side:M.side=T.shadowSide!==null?T.shadowSide:a[T.side],M.alphaMap=T.alphaMap,M.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,M.map=T.map,M.clipShadows=T.clipShadows,M.clippingPlanes=T.clippingPlanes,M.clipIntersection=T.clipIntersection,M.displacementMap=T.displacementMap,M.displacementScale=T.displacementScale,M.displacementBias=T.displacementBias,M.wireframeLinewidth=T.wireframeLinewidth,M.linewidth=T.linewidth,D.isPointLight===!0&&M.isMeshDistanceMaterial===!0){const B=i.properties.get(M);B.light=D}return M}function v(C,T,D,w,M){if(C.visible===!1)return;if(C.layers.test(T.layers)&&(C.isMesh||C.isLine||C.isPoints)&&(C.castShadow||C.receiveShadow&&M===ii)&&(!C.frustumCulled||n.intersectsObject(C))){C.modelViewMatrix.multiplyMatrices(D.matrixWorldInverse,C.matrixWorld);const N=e.update(C),V=C.material;if(Array.isArray(V)){const Y=N.groups;for(let $=0,Q=Y.length;$<Q;$++){const G=Y[$],ce=V[G.materialIndex];if(ce&&ce.visible){const fe=b(C,ce,w,M);C.onBeforeShadow(i,C,T,D,N,fe,G),i.renderBufferDirect(D,null,N,fe,C,G),C.onAfterShadow(i,C,T,D,N,fe,G)}}}else if(V.visible){const Y=b(C,V,w,M);C.onBeforeShadow(i,C,T,D,N,Y,null),i.renderBufferDirect(D,null,N,Y,C,null),C.onAfterShadow(i,C,T,D,N,Y,null)}}const B=C.children;for(let N=0,V=B.length;N<V;N++)v(B[N],T,D,w,M)}function P(C){C.target.removeEventListener("dispose",P);for(const D in u){const w=u[D],M=C.target.uuid;M in w&&(w[M].dispose(),delete w[M])}}}const ZE={[fu]:pu,[mu]:xu,[gu]:yu,[ur]:_u,[pu]:fu,[xu]:mu,[yu]:gu,[_u]:ur};function JE(i,e){function t(){let U=!1;const he=new Mt;let te=null;const ge=new Mt(0,0,0,0);return{setMask:function(ne){te!==ne&&!U&&(i.colorMask(ne,ne,ne,ne),te=ne)},setLocked:function(ne){U=ne},setClear:function(ne,Z,ye,ke,ft){ft===!0&&(ne*=ke,Z*=ke,ye*=ke),he.set(ne,Z,ye,ke),ge.equals(he)===!1&&(i.clearColor(ne,Z,ye,ke),ge.copy(he))},reset:function(){U=!1,te=null,ge.set(-1,0,0,0)}}}function n(){let U=!1,he=!1,te=null,ge=null,ne=null;return{setReversed:function(Z){if(he!==Z){const ye=e.get("EXT_clip_control");Z?ye.clipControlEXT(ye.LOWER_LEFT_EXT,ye.ZERO_TO_ONE_EXT):ye.clipControlEXT(ye.LOWER_LEFT_EXT,ye.NEGATIVE_ONE_TO_ONE_EXT),he=Z;const ke=ne;ne=null,this.setClear(ke)}},getReversed:function(){return he},setTest:function(Z){Z?de(i.DEPTH_TEST):Ae(i.DEPTH_TEST)},setMask:function(Z){te!==Z&&!U&&(i.depthMask(Z),te=Z)},setFunc:function(Z){if(he&&(Z=ZE[Z]),ge!==Z){switch(Z){case fu:i.depthFunc(i.NEVER);break;case pu:i.depthFunc(i.ALWAYS);break;case mu:i.depthFunc(i.LESS);break;case ur:i.depthFunc(i.LEQUAL);break;case gu:i.depthFunc(i.EQUAL);break;case _u:i.depthFunc(i.GEQUAL);break;case xu:i.depthFunc(i.GREATER);break;case yu:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ge=Z}},setLocked:function(Z){U=Z},setClear:function(Z){ne!==Z&&(he&&(Z=1-Z),i.clearDepth(Z),ne=Z)},reset:function(){U=!1,te=null,ge=null,ne=null,he=!1}}}function s(){let U=!1,he=null,te=null,ge=null,ne=null,Z=null,ye=null,ke=null,ft=null;return{setTest:function(st){U||(st?de(i.STENCIL_TEST):Ae(i.STENCIL_TEST))},setMask:function(st){he!==st&&!U&&(i.stencilMask(st),he=st)},setFunc:function(st,vn,Yn){(te!==st||ge!==vn||ne!==Yn)&&(i.stencilFunc(st,vn,Yn),te=st,ge=vn,ne=Yn)},setOp:function(st,vn,Yn){(Z!==st||ye!==vn||ke!==Yn)&&(i.stencilOp(st,vn,Yn),Z=st,ye=vn,ke=Yn)},setLocked:function(st){U=st},setClear:function(st){ft!==st&&(i.clearStencil(st),ft=st)},reset:function(){U=!1,he=null,te=null,ge=null,ne=null,Z=null,ye=null,ke=null,ft=null}}}const r=new t,o=new n,l=new s,c=new WeakMap,u=new WeakMap;let d={},a={},h=new WeakMap,f=[],g=null,_=!1,m=null,p=null,x=null,b=null,v=null,P=null,C=null,T=new se(0,0,0),D=0,w=!1,M=null,I=null,B=null,N=null,V=null;const Y=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,Q=0;const G=i.getParameter(i.VERSION);G.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(G)[1]),$=Q>=1):G.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(G)[1]),$=Q>=2);let ce=null,fe={};const Re=i.getParameter(i.SCISSOR_BOX),Ve=i.getParameter(i.VIEWPORT),ht=new Mt().fromArray(Re),K=new Mt().fromArray(Ve);function re(U,he,te,ge){const ne=new Uint8Array(4),Z=i.createTexture();i.bindTexture(U,Z),i.texParameteri(U,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(U,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let ye=0;ye<te;ye++)U===i.TEXTURE_3D||U===i.TEXTURE_2D_ARRAY?i.texImage3D(he,0,i.RGBA,1,1,ge,0,i.RGBA,i.UNSIGNED_BYTE,ne):i.texImage2D(he+ye,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ne);return Z}const Ee={};Ee[i.TEXTURE_2D]=re(i.TEXTURE_2D,i.TEXTURE_2D,1),Ee[i.TEXTURE_CUBE_MAP]=re(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Ee[i.TEXTURE_2D_ARRAY]=re(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Ee[i.TEXTURE_3D]=re(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),l.setClear(0),de(i.DEPTH_TEST),o.setFunc(ur),et(!1),ut(Op),de(i.CULL_FACE),L(Ei);function de(U){d[U]!==!0&&(i.enable(U),d[U]=!0)}function Ae(U){d[U]!==!1&&(i.disable(U),d[U]=!1)}function Je(U,he){return a[U]!==he?(i.bindFramebuffer(U,he),a[U]=he,U===i.DRAW_FRAMEBUFFER&&(a[i.FRAMEBUFFER]=he),U===i.FRAMEBUFFER&&(a[i.DRAW_FRAMEBUFFER]=he),!0):!1}function Ue(U,he){let te=f,ge=!1;if(U){te=h.get(he),te===void 0&&(te=[],h.set(he,te));const ne=U.textures;if(te.length!==ne.length||te[0]!==i.COLOR_ATTACHMENT0){for(let Z=0,ye=ne.length;Z<ye;Z++)te[Z]=i.COLOR_ATTACHMENT0+Z;te.length=ne.length,ge=!0}}else te[0]!==i.BACK&&(te[0]=i.BACK,ge=!0);ge&&i.drawBuffers(te)}function _t(U){return g!==U?(i.useProgram(U),g=U,!0):!1}const xt={[qi]:i.FUNC_ADD,[qv]:i.FUNC_SUBTRACT,[jv]:i.FUNC_REVERSE_SUBTRACT};xt[Kv]=i.MIN,xt[Zv]=i.MAX;const Qe={[Jv]:i.ZERO,[Qv]:i.ONE,[e1]:i.SRC_COLOR,[uu]:i.SRC_ALPHA,[o1]:i.SRC_ALPHA_SATURATE,[s1]:i.DST_COLOR,[n1]:i.DST_ALPHA,[t1]:i.ONE_MINUS_SRC_COLOR,[du]:i.ONE_MINUS_SRC_ALPHA,[r1]:i.ONE_MINUS_DST_COLOR,[i1]:i.ONE_MINUS_DST_ALPHA,[a1]:i.CONSTANT_COLOR,[l1]:i.ONE_MINUS_CONSTANT_COLOR,[c1]:i.CONSTANT_ALPHA,[h1]:i.ONE_MINUS_CONSTANT_ALPHA};function L(U,he,te,ge,ne,Z,ye,ke,ft,st){if(U===Ei){_===!0&&(Ae(i.BLEND),_=!1);return}if(_===!1&&(de(i.BLEND),_=!0),U!==Yv){if(U!==m||st!==w){if((p!==qi||v!==qi)&&(i.blendEquation(i.FUNC_ADD),p=qi,v=qi),st)switch(U){case tr:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fp:i.blendFunc(i.ONE,i.ONE);break;case Np:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case kp:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case tr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fp:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Np:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case kp:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}x=null,b=null,P=null,C=null,T.set(0,0,0),D=0,m=U,w=st}return}ne=ne||he,Z=Z||te,ye=ye||ge,(he!==p||ne!==v)&&(i.blendEquationSeparate(xt[he],xt[ne]),p=he,v=ne),(te!==x||ge!==b||Z!==P||ye!==C)&&(i.blendFuncSeparate(Qe[te],Qe[ge],Qe[Z],Qe[ye]),x=te,b=ge,P=Z,C=ye),(ke.equals(T)===!1||ft!==D)&&(i.blendColor(ke.r,ke.g,ke.b,ft),T.copy(ke),D=ft),m=U,w=!1}function zt(U,he){U.side===kn?Ae(i.CULL_FACE):de(i.CULL_FACE);let te=U.side===Wt;he&&(te=!te),et(te),U.blending===tr&&U.transparent===!1?L(Ei):L(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),o.setFunc(U.depthFunc),o.setTest(U.depthTest),o.setMask(U.depthWrite),r.setMask(U.colorWrite);const ge=U.stencilWrite;l.setTest(ge),ge&&(l.setMask(U.stencilWriteMask),l.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),l.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),qe(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?de(i.SAMPLE_ALPHA_TO_COVERAGE):Ae(i.SAMPLE_ALPHA_TO_COVERAGE)}function et(U){M!==U&&(U?i.frontFace(i.CW):i.frontFace(i.CCW),M=U)}function ut(U){U!==Wv?(de(i.CULL_FACE),U!==I&&(U===Op?i.cullFace(i.BACK):U===Xv?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ae(i.CULL_FACE),I=U}function Me(U){U!==B&&($&&i.lineWidth(U),B=U)}function qe(U,he,te){U?(de(i.POLYGON_OFFSET_FILL),(N!==he||V!==te)&&(i.polygonOffset(he,te),N=he,V=te)):Ae(i.POLYGON_OFFSET_FILL)}function Pe(U){U?de(i.SCISSOR_TEST):Ae(i.SCISSOR_TEST)}function ze(U){U===void 0&&(U=i.TEXTURE0+Y-1),ce!==U&&(i.activeTexture(U),ce=U)}function Tt(U,he,te){te===void 0&&(ce===null?te=i.TEXTURE0+Y-1:te=ce);let ge=fe[te];ge===void 0&&(ge={type:void 0,texture:void 0},fe[te]=ge),(ge.type!==U||ge.texture!==he)&&(ce!==te&&(i.activeTexture(te),ce=te),i.bindTexture(U,he||Ee[U]),ge.type=U,ge.texture=he)}function R(){const U=fe[ce];U!==void 0&&U.type!==void 0&&(i.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function y(){try{i.compressedTexImage2D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function k(){try{i.compressedTexImage3D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function q(){try{i.texSubImage2D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function J(){try{i.texSubImage3D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function X(){try{i.compressedTexSubImage2D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function we(){try{i.compressedTexSubImage3D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function le(){try{i.texStorage2D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function be(){try{i.texStorage3D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Se(){try{i.texImage2D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ee(){try{i.texImage3D(...arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function pe(U){ht.equals(U)===!1&&(i.scissor(U.x,U.y,U.z,U.w),ht.copy(U))}function De(U){K.equals(U)===!1&&(i.viewport(U.x,U.y,U.z,U.w),K.copy(U))}function Le(U,he){let te=u.get(he);te===void 0&&(te=new WeakMap,u.set(he,te));let ge=te.get(U);ge===void 0&&(ge=i.getUniformBlockIndex(he,U.name),te.set(U,ge))}function oe(U,he){const ge=u.get(he).get(U);c.get(he)!==ge&&(i.uniformBlockBinding(he,ge,U.__bindingPointIndex),c.set(he,ge))}function Ne(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),d={},ce=null,fe={},a={},h=new WeakMap,f=[],g=null,_=!1,m=null,p=null,x=null,b=null,v=null,P=null,C=null,T=new se(0,0,0),D=0,w=!1,M=null,I=null,B=null,N=null,V=null,ht.set(0,0,i.canvas.width,i.canvas.height),K.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),l.reset()}return{buffers:{color:r,depth:o,stencil:l},enable:de,disable:Ae,bindFramebuffer:Je,drawBuffers:Ue,useProgram:_t,setBlending:L,setMaterial:zt,setFlipSided:et,setCullFace:ut,setLineWidth:Me,setPolygonOffset:qe,setScissorTest:Pe,activeTexture:ze,bindTexture:Tt,unbindTexture:R,compressedTexImage2D:y,compressedTexImage3D:k,texImage2D:Se,texImage3D:ee,updateUBOMapping:Le,uniformBlockBinding:oe,texStorage2D:le,texStorage3D:be,texSubImage2D:q,texSubImage3D:J,compressedTexSubImage2D:X,compressedTexSubImage3D:we,scissor:pe,viewport:De,reset:Ne}}function QE(i,e,t,n,s,r,o){const l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new xe,d=new WeakMap;let a;const h=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(R,y){return f?new OffscreenCanvas(R,y):Rl("canvas")}function _(R,y,k){let q=1;const J=Tt(R);if((J.width>k||J.height>k)&&(q=k/Math.max(J.width,J.height)),q<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const X=Math.floor(q*J.width),we=Math.floor(q*J.height);a===void 0&&(a=g(X,we));const le=y?g(X,we):a;return le.width=X,le.height=we,le.getContext("2d").drawImage(R,0,0,X,we),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+X+"x"+we+")."),le}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),R;return R}function m(R){return R.generateMipmaps}function p(R){i.generateMipmap(R)}function x(R){return R.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?i.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function b(R,y,k,q,J=!1){if(R!==null){if(i[R]!==void 0)return i[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let X=y;if(y===i.RED&&(k===i.FLOAT&&(X=i.R32F),k===i.HALF_FLOAT&&(X=i.R16F),k===i.UNSIGNED_BYTE&&(X=i.R8)),y===i.RED_INTEGER&&(k===i.UNSIGNED_BYTE&&(X=i.R8UI),k===i.UNSIGNED_SHORT&&(X=i.R16UI),k===i.UNSIGNED_INT&&(X=i.R32UI),k===i.BYTE&&(X=i.R8I),k===i.SHORT&&(X=i.R16I),k===i.INT&&(X=i.R32I)),y===i.RG&&(k===i.FLOAT&&(X=i.RG32F),k===i.HALF_FLOAT&&(X=i.RG16F),k===i.UNSIGNED_BYTE&&(X=i.RG8)),y===i.RG_INTEGER&&(k===i.UNSIGNED_BYTE&&(X=i.RG8UI),k===i.UNSIGNED_SHORT&&(X=i.RG16UI),k===i.UNSIGNED_INT&&(X=i.RG32UI),k===i.BYTE&&(X=i.RG8I),k===i.SHORT&&(X=i.RG16I),k===i.INT&&(X=i.RG32I)),y===i.RGB_INTEGER&&(k===i.UNSIGNED_BYTE&&(X=i.RGB8UI),k===i.UNSIGNED_SHORT&&(X=i.RGB16UI),k===i.UNSIGNED_INT&&(X=i.RGB32UI),k===i.BYTE&&(X=i.RGB8I),k===i.SHORT&&(X=i.RGB16I),k===i.INT&&(X=i.RGB32I)),y===i.RGBA_INTEGER&&(k===i.UNSIGNED_BYTE&&(X=i.RGBA8UI),k===i.UNSIGNED_SHORT&&(X=i.RGBA16UI),k===i.UNSIGNED_INT&&(X=i.RGBA32UI),k===i.BYTE&&(X=i.RGBA8I),k===i.SHORT&&(X=i.RGBA16I),k===i.INT&&(X=i.RGBA32I)),y===i.RGB&&k===i.UNSIGNED_INT_5_9_9_9_REV&&(X=i.RGB9_E5),y===i.RGBA){const we=J?Tl:Ke.getTransfer(q);k===i.FLOAT&&(X=i.RGBA32F),k===i.HALF_FLOAT&&(X=i.RGBA16F),k===i.UNSIGNED_BYTE&&(X=we===lt?i.SRGB8_ALPHA8:i.RGBA8),k===i.UNSIGNED_SHORT_4_4_4_4&&(X=i.RGBA4),k===i.UNSIGNED_SHORT_5_5_5_1&&(X=i.RGB5_A1)}return(X===i.R16F||X===i.R32F||X===i.RG16F||X===i.RG32F||X===i.RGBA16F||X===i.RGBA32F)&&e.get("EXT_color_buffer_float"),X}function v(R,y){let k;return R?y===null||y===ls||y===co?k=i.DEPTH24_STENCIL8:y===zn?k=i.DEPTH32F_STENCIL8:y===lo&&(k=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===ls||y===co?k=i.DEPTH_COMPONENT24:y===zn?k=i.DEPTH_COMPONENT32F:y===lo&&(k=i.DEPTH_COMPONENT16),k}function P(R,y){return m(R)===!0||R.isFramebufferTexture&&R.minFilter!==ln&&R.minFilter!==Bn?Math.log2(Math.max(y.width,y.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?y.mipmaps.length:1}function C(R){const y=R.target;y.removeEventListener("dispose",C),D(y),y.isVideoTexture&&d.delete(y)}function T(R){const y=R.target;y.removeEventListener("dispose",T),M(y)}function D(R){const y=n.get(R);if(y.__webglInit===void 0)return;const k=R.source,q=h.get(k);if(q){const J=q[y.__cacheKey];J.usedTimes--,J.usedTimes===0&&w(R),Object.keys(q).length===0&&h.delete(k)}n.remove(R)}function w(R){const y=n.get(R);i.deleteTexture(y.__webglTexture);const k=R.source,q=h.get(k);delete q[y.__cacheKey],o.memory.textures--}function M(R){const y=n.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),n.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(y.__webglFramebuffer[q]))for(let J=0;J<y.__webglFramebuffer[q].length;J++)i.deleteFramebuffer(y.__webglFramebuffer[q][J]);else i.deleteFramebuffer(y.__webglFramebuffer[q]);y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer[q])}else{if(Array.isArray(y.__webglFramebuffer))for(let q=0;q<y.__webglFramebuffer.length;q++)i.deleteFramebuffer(y.__webglFramebuffer[q]);else i.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&i.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&i.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let q=0;q<y.__webglColorRenderbuffer.length;q++)y.__webglColorRenderbuffer[q]&&i.deleteRenderbuffer(y.__webglColorRenderbuffer[q]);y.__webglDepthRenderbuffer&&i.deleteRenderbuffer(y.__webglDepthRenderbuffer)}const k=R.textures;for(let q=0,J=k.length;q<J;q++){const X=n.get(k[q]);X.__webglTexture&&(i.deleteTexture(X.__webglTexture),o.memory.textures--),n.remove(k[q])}n.remove(R)}let I=0;function B(){I=0}function N(){const R=I;return R>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+s.maxTextures),I+=1,R}function V(R){const y=[];return y.push(R.wrapS),y.push(R.wrapT),y.push(R.wrapR||0),y.push(R.magFilter),y.push(R.minFilter),y.push(R.anisotropy),y.push(R.internalFormat),y.push(R.format),y.push(R.type),y.push(R.generateMipmaps),y.push(R.premultiplyAlpha),y.push(R.flipY),y.push(R.unpackAlignment),y.push(R.colorSpace),y.join()}function Y(R,y){const k=n.get(R);if(R.isVideoTexture&&Pe(R),R.isRenderTargetTexture===!1&&R.version>0&&k.__version!==R.version){const q=R.image;if(q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Ee(k,R,y);return}}t.bindTexture(i.TEXTURE_2D,k.__webglTexture,i.TEXTURE0+y)}function $(R,y){const k=n.get(R);if(R.version>0&&k.__version!==R.version){Ee(k,R,y);return}t.bindTexture(i.TEXTURE_2D_ARRAY,k.__webglTexture,i.TEXTURE0+y)}function Q(R,y){const k=n.get(R);if(R.version>0&&k.__version!==R.version){Ee(k,R,y);return}t.bindTexture(i.TEXTURE_3D,k.__webglTexture,i.TEXTURE0+y)}function G(R,y){const k=n.get(R);if(R.version>0&&k.__version!==R.version){de(k,R,y);return}t.bindTexture(i.TEXTURE_CUBE_MAP,k.__webglTexture,i.TEXTURE0+y)}const ce={[Mu]:i.REPEAT,[ts]:i.CLAMP_TO_EDGE,[wu]:i.MIRRORED_REPEAT},fe={[ln]:i.NEAREST,[v1]:i.NEAREST_MIPMAP_NEAREST,[Bo]:i.NEAREST_MIPMAP_LINEAR,[Bn]:i.LINEAR,[xc]:i.LINEAR_MIPMAP_NEAREST,[ns]:i.LINEAR_MIPMAP_LINEAR},Re={[S1]:i.NEVER,[P1]:i.ALWAYS,[E1]:i.LESS,[N_]:i.LEQUAL,[A1]:i.EQUAL,[R1]:i.GEQUAL,[T1]:i.GREATER,[C1]:i.NOTEQUAL};function Ve(R,y){if(y.type===zn&&e.has("OES_texture_float_linear")===!1&&(y.magFilter===Bn||y.magFilter===xc||y.magFilter===Bo||y.magFilter===ns||y.minFilter===Bn||y.minFilter===xc||y.minFilter===Bo||y.minFilter===ns)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(R,i.TEXTURE_WRAP_S,ce[y.wrapS]),i.texParameteri(R,i.TEXTURE_WRAP_T,ce[y.wrapT]),(R===i.TEXTURE_3D||R===i.TEXTURE_2D_ARRAY)&&i.texParameteri(R,i.TEXTURE_WRAP_R,ce[y.wrapR]),i.texParameteri(R,i.TEXTURE_MAG_FILTER,fe[y.magFilter]),i.texParameteri(R,i.TEXTURE_MIN_FILTER,fe[y.minFilter]),y.compareFunction&&(i.texParameteri(R,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(R,i.TEXTURE_COMPARE_FUNC,Re[y.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===ln||y.minFilter!==Bo&&y.minFilter!==ns||y.type===zn&&e.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||n.get(y).__currentAnisotropy){const k=e.get("EXT_texture_filter_anisotropic");i.texParameterf(R,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,s.getMaxAnisotropy())),n.get(y).__currentAnisotropy=y.anisotropy}}}function ht(R,y){let k=!1;R.__webglInit===void 0&&(R.__webglInit=!0,y.addEventListener("dispose",C));const q=y.source;let J=h.get(q);J===void 0&&(J={},h.set(q,J));const X=V(y);if(X!==R.__cacheKey){J[X]===void 0&&(J[X]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,k=!0),J[X].usedTimes++;const we=J[R.__cacheKey];we!==void 0&&(J[R.__cacheKey].usedTimes--,we.usedTimes===0&&w(y)),R.__cacheKey=X,R.__webglTexture=J[X].texture}return k}function K(R,y,k){return Math.floor(Math.floor(R/k)/y)}function re(R,y,k,q){const X=R.updateRanges;if(X.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,y.width,y.height,k,q,y.data);else{X.sort((ee,pe)=>ee.start-pe.start);let we=0;for(let ee=1;ee<X.length;ee++){const pe=X[we],De=X[ee],Le=pe.start+pe.count,oe=K(De.start,y.width,4),Ne=K(pe.start,y.width,4);De.start<=Le+1&&oe===Ne&&K(De.start+De.count-1,y.width,4)===oe?pe.count=Math.max(pe.count,De.start+De.count-pe.start):(++we,X[we]=De)}X.length=we+1;const le=i.getParameter(i.UNPACK_ROW_LENGTH),be=i.getParameter(i.UNPACK_SKIP_PIXELS),Se=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,y.width);for(let ee=0,pe=X.length;ee<pe;ee++){const De=X[ee],Le=Math.floor(De.start/4),oe=Math.ceil(De.count/4),Ne=Le%y.width,U=Math.floor(Le/y.width),he=oe,te=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ne),i.pixelStorei(i.UNPACK_SKIP_ROWS,U),t.texSubImage2D(i.TEXTURE_2D,0,Ne,U,he,te,k,q,y.data)}R.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,le),i.pixelStorei(i.UNPACK_SKIP_PIXELS,be),i.pixelStorei(i.UNPACK_SKIP_ROWS,Se)}}function Ee(R,y,k){let q=i.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(q=i.TEXTURE_2D_ARRAY),y.isData3DTexture&&(q=i.TEXTURE_3D);const J=ht(R,y),X=y.source;t.bindTexture(q,R.__webglTexture,i.TEXTURE0+k);const we=n.get(X);if(X.version!==we.__version||J===!0){t.activeTexture(i.TEXTURE0+k);const le=Ke.getPrimaries(Ke.workingColorSpace),be=y.colorSpace===Mi?null:Ke.getPrimaries(y.colorSpace),Se=y.colorSpace===Mi||le===be?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Se);let ee=_(y.image,!1,s.maxTextureSize);ee=ze(y,ee);const pe=r.convert(y.format,y.colorSpace),De=r.convert(y.type);let Le=b(y.internalFormat,pe,De,y.colorSpace,y.isVideoTexture);Ve(q,y);let oe;const Ne=y.mipmaps,U=y.isVideoTexture!==!0,he=we.__version===void 0||J===!0,te=X.dataReady,ge=P(y,ee);if(y.isDepthTexture)Le=v(y.format===uo,y.type),he&&(U?t.texStorage2D(i.TEXTURE_2D,1,Le,ee.width,ee.height):t.texImage2D(i.TEXTURE_2D,0,Le,ee.width,ee.height,0,pe,De,null));else if(y.isDataTexture)if(Ne.length>0){U&&he&&t.texStorage2D(i.TEXTURE_2D,ge,Le,Ne[0].width,Ne[0].height);for(let ne=0,Z=Ne.length;ne<Z;ne++)oe=Ne[ne],U?te&&t.texSubImage2D(i.TEXTURE_2D,ne,0,0,oe.width,oe.height,pe,De,oe.data):t.texImage2D(i.TEXTURE_2D,ne,Le,oe.width,oe.height,0,pe,De,oe.data);y.generateMipmaps=!1}else U?(he&&t.texStorage2D(i.TEXTURE_2D,ge,Le,ee.width,ee.height),te&&re(y,ee,pe,De)):t.texImage2D(i.TEXTURE_2D,0,Le,ee.width,ee.height,0,pe,De,ee.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){U&&he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ge,Le,Ne[0].width,Ne[0].height,ee.depth);for(let ne=0,Z=Ne.length;ne<Z;ne++)if(oe=Ne[ne],y.format!==Rn)if(pe!==null)if(U){if(te)if(y.layerUpdates.size>0){const ye=bm(oe.width,oe.height,y.format,y.type);for(const ke of y.layerUpdates){const ft=oe.data.subarray(ke*ye/oe.data.BYTES_PER_ELEMENT,(ke+1)*ye/oe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ne,0,0,ke,oe.width,oe.height,1,pe,ft)}y.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ne,0,0,0,oe.width,oe.height,ee.depth,pe,oe.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ne,Le,oe.width,oe.height,ee.depth,0,oe.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else U?te&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ne,0,0,0,oe.width,oe.height,ee.depth,pe,De,oe.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ne,Le,oe.width,oe.height,ee.depth,0,pe,De,oe.data)}else{U&&he&&t.texStorage2D(i.TEXTURE_2D,ge,Le,Ne[0].width,Ne[0].height);for(let ne=0,Z=Ne.length;ne<Z;ne++)oe=Ne[ne],y.format!==Rn?pe!==null?U?te&&t.compressedTexSubImage2D(i.TEXTURE_2D,ne,0,0,oe.width,oe.height,pe,oe.data):t.compressedTexImage2D(i.TEXTURE_2D,ne,Le,oe.width,oe.height,0,oe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):U?te&&t.texSubImage2D(i.TEXTURE_2D,ne,0,0,oe.width,oe.height,pe,De,oe.data):t.texImage2D(i.TEXTURE_2D,ne,Le,oe.width,oe.height,0,pe,De,oe.data)}else if(y.isDataArrayTexture)if(U){if(he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ge,Le,ee.width,ee.height,ee.depth),te)if(y.layerUpdates.size>0){const ne=bm(ee.width,ee.height,y.format,y.type);for(const Z of y.layerUpdates){const ye=ee.data.subarray(Z*ne/ee.data.BYTES_PER_ELEMENT,(Z+1)*ne/ee.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Z,ee.width,ee.height,1,pe,De,ye)}y.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ee.width,ee.height,ee.depth,pe,De,ee.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Le,ee.width,ee.height,ee.depth,0,pe,De,ee.data);else if(y.isData3DTexture)U?(he&&t.texStorage3D(i.TEXTURE_3D,ge,Le,ee.width,ee.height,ee.depth),te&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ee.width,ee.height,ee.depth,pe,De,ee.data)):t.texImage3D(i.TEXTURE_3D,0,Le,ee.width,ee.height,ee.depth,0,pe,De,ee.data);else if(y.isFramebufferTexture){if(he)if(U)t.texStorage2D(i.TEXTURE_2D,ge,Le,ee.width,ee.height);else{let ne=ee.width,Z=ee.height;for(let ye=0;ye<ge;ye++)t.texImage2D(i.TEXTURE_2D,ye,Le,ne,Z,0,pe,De,null),ne>>=1,Z>>=1}}else if(Ne.length>0){if(U&&he){const ne=Tt(Ne[0]);t.texStorage2D(i.TEXTURE_2D,ge,Le,ne.width,ne.height)}for(let ne=0,Z=Ne.length;ne<Z;ne++)oe=Ne[ne],U?te&&t.texSubImage2D(i.TEXTURE_2D,ne,0,0,pe,De,oe):t.texImage2D(i.TEXTURE_2D,ne,Le,pe,De,oe);y.generateMipmaps=!1}else if(U){if(he){const ne=Tt(ee);t.texStorage2D(i.TEXTURE_2D,ge,Le,ne.width,ne.height)}te&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,pe,De,ee)}else t.texImage2D(i.TEXTURE_2D,0,Le,pe,De,ee);m(y)&&p(q),we.__version=X.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function de(R,y,k){if(y.image.length!==6)return;const q=ht(R,y),J=y.source;t.bindTexture(i.TEXTURE_CUBE_MAP,R.__webglTexture,i.TEXTURE0+k);const X=n.get(J);if(J.version!==X.__version||q===!0){t.activeTexture(i.TEXTURE0+k);const we=Ke.getPrimaries(Ke.workingColorSpace),le=y.colorSpace===Mi?null:Ke.getPrimaries(y.colorSpace),be=y.colorSpace===Mi||we===le?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,y.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,y.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,be);const Se=y.isCompressedTexture||y.image[0].isCompressedTexture,ee=y.image[0]&&y.image[0].isDataTexture,pe=[];for(let Z=0;Z<6;Z++)!Se&&!ee?pe[Z]=_(y.image[Z],!0,s.maxCubemapSize):pe[Z]=ee?y.image[Z].image:y.image[Z],pe[Z]=ze(y,pe[Z]);const De=pe[0],Le=r.convert(y.format,y.colorSpace),oe=r.convert(y.type),Ne=b(y.internalFormat,Le,oe,y.colorSpace),U=y.isVideoTexture!==!0,he=X.__version===void 0||q===!0,te=J.dataReady;let ge=P(y,De);Ve(i.TEXTURE_CUBE_MAP,y);let ne;if(Se){U&&he&&t.texStorage2D(i.TEXTURE_CUBE_MAP,ge,Ne,De.width,De.height);for(let Z=0;Z<6;Z++){ne=pe[Z].mipmaps;for(let ye=0;ye<ne.length;ye++){const ke=ne[ye];y.format!==Rn?Le!==null?U?te&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye,0,0,ke.width,ke.height,Le,ke.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye,Ne,ke.width,ke.height,0,ke.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):U?te&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye,0,0,ke.width,ke.height,Le,oe,ke.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye,Ne,ke.width,ke.height,0,Le,oe,ke.data)}}}else{if(ne=y.mipmaps,U&&he){ne.length>0&&ge++;const Z=Tt(pe[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,ge,Ne,Z.width,Z.height)}for(let Z=0;Z<6;Z++)if(ee){U?te&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,pe[Z].width,pe[Z].height,Le,oe,pe[Z].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ne,pe[Z].width,pe[Z].height,0,Le,oe,pe[Z].data);for(let ye=0;ye<ne.length;ye++){const ft=ne[ye].image[Z].image;U?te&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye+1,0,0,ft.width,ft.height,Le,oe,ft.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye+1,Ne,ft.width,ft.height,0,Le,oe,ft.data)}}else{U?te&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,Le,oe,pe[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ne,Le,oe,pe[Z]);for(let ye=0;ye<ne.length;ye++){const ke=ne[ye];U?te&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye+1,0,0,Le,oe,ke.image[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ye+1,Ne,Le,oe,ke.image[Z])}}}m(y)&&p(i.TEXTURE_CUBE_MAP),X.__version=J.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function Ae(R,y,k,q,J,X){const we=r.convert(k.format,k.colorSpace),le=r.convert(k.type),be=b(k.internalFormat,we,le,k.colorSpace),Se=n.get(y),ee=n.get(k);if(ee.__renderTarget=y,!Se.__hasExternalTextures){const pe=Math.max(1,y.width>>X),De=Math.max(1,y.height>>X);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?t.texImage3D(J,X,be,pe,De,y.depth,0,we,le,null):t.texImage2D(J,X,be,pe,De,0,we,le,null)}t.bindFramebuffer(i.FRAMEBUFFER,R),qe(y)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,q,J,ee.__webglTexture,0,Me(y)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,q,J,ee.__webglTexture,X),t.bindFramebuffer(i.FRAMEBUFFER,null)}function Je(R,y,k){if(i.bindRenderbuffer(i.RENDERBUFFER,R),y.depthBuffer){const q=y.depthTexture,J=q&&q.isDepthTexture?q.type:null,X=v(y.stencilBuffer,J),we=y.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,le=Me(y);qe(y)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,le,X,y.width,y.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,le,X,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,X,y.width,y.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,we,i.RENDERBUFFER,R)}else{const q=y.textures;for(let J=0;J<q.length;J++){const X=q[J],we=r.convert(X.format,X.colorSpace),le=r.convert(X.type),be=b(X.internalFormat,we,le,X.colorSpace),Se=Me(y);k&&qe(y)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Se,be,y.width,y.height):qe(y)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Se,be,y.width,y.height):i.renderbufferStorage(i.RENDERBUFFER,be,y.width,y.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ue(R,y){if(y&&y.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,R),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const q=n.get(y.depthTexture);q.__renderTarget=y,(!q.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),Y(y.depthTexture,0);const J=q.__webglTexture,X=Me(y);if(y.depthTexture.format===ho)qe(y)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0);else if(y.depthTexture.format===uo)qe(y)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0);else throw new Error("Unknown depthTexture format")}function _t(R){const y=n.get(R),k=R.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==R.depthTexture){const q=R.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),q){const J=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,q.removeEventListener("dispose",J)};q.addEventListener("dispose",J),y.__depthDisposeCallback=J}y.__boundDepthTexture=q}if(R.depthTexture&&!y.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");const q=R.texture.mipmaps;q&&q.length>0?Ue(y.__webglFramebuffer[0],R):Ue(y.__webglFramebuffer,R)}else if(k){y.__webglDepthbuffer=[];for(let q=0;q<6;q++)if(t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer[q]),y.__webglDepthbuffer[q]===void 0)y.__webglDepthbuffer[q]=i.createRenderbuffer(),Je(y.__webglDepthbuffer[q],R,!1);else{const J=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,X=y.__webglDepthbuffer[q];i.bindRenderbuffer(i.RENDERBUFFER,X),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,X)}}else{const q=R.texture.mipmaps;if(q&&q.length>0?t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=i.createRenderbuffer(),Je(y.__webglDepthbuffer,R,!1);else{const J=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,X=y.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,X),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,X)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function xt(R,y,k){const q=n.get(R);y!==void 0&&Ae(q.__webglFramebuffer,R,R.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),k!==void 0&&_t(R)}function Qe(R){const y=R.texture,k=n.get(R),q=n.get(y);R.addEventListener("dispose",T);const J=R.textures,X=R.isWebGLCubeRenderTarget===!0,we=J.length>1;if(we||(q.__webglTexture===void 0&&(q.__webglTexture=i.createTexture()),q.__version=y.version,o.memory.textures++),X){k.__webglFramebuffer=[];for(let le=0;le<6;le++)if(y.mipmaps&&y.mipmaps.length>0){k.__webglFramebuffer[le]=[];for(let be=0;be<y.mipmaps.length;be++)k.__webglFramebuffer[le][be]=i.createFramebuffer()}else k.__webglFramebuffer[le]=i.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){k.__webglFramebuffer=[];for(let le=0;le<y.mipmaps.length;le++)k.__webglFramebuffer[le]=i.createFramebuffer()}else k.__webglFramebuffer=i.createFramebuffer();if(we)for(let le=0,be=J.length;le<be;le++){const Se=n.get(J[le]);Se.__webglTexture===void 0&&(Se.__webglTexture=i.createTexture(),o.memory.textures++)}if(R.samples>0&&qe(R)===!1){k.__webglMultisampledFramebuffer=i.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let le=0;le<J.length;le++){const be=J[le];k.__webglColorRenderbuffer[le]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,k.__webglColorRenderbuffer[le]);const Se=r.convert(be.format,be.colorSpace),ee=r.convert(be.type),pe=b(be.internalFormat,Se,ee,be.colorSpace,R.isXRRenderTarget===!0),De=Me(R);i.renderbufferStorageMultisample(i.RENDERBUFFER,De,pe,R.width,R.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.RENDERBUFFER,k.__webglColorRenderbuffer[le])}i.bindRenderbuffer(i.RENDERBUFFER,null),R.depthBuffer&&(k.__webglDepthRenderbuffer=i.createRenderbuffer(),Je(k.__webglDepthRenderbuffer,R,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(X){t.bindTexture(i.TEXTURE_CUBE_MAP,q.__webglTexture),Ve(i.TEXTURE_CUBE_MAP,y);for(let le=0;le<6;le++)if(y.mipmaps&&y.mipmaps.length>0)for(let be=0;be<y.mipmaps.length;be++)Ae(k.__webglFramebuffer[le][be],R,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,be);else Ae(k.__webglFramebuffer[le],R,y,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,0);m(y)&&p(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(we){for(let le=0,be=J.length;le<be;le++){const Se=J[le],ee=n.get(Se);t.bindTexture(i.TEXTURE_2D,ee.__webglTexture),Ve(i.TEXTURE_2D,Se),Ae(k.__webglFramebuffer,R,Se,i.COLOR_ATTACHMENT0+le,i.TEXTURE_2D,0),m(Se)&&p(i.TEXTURE_2D)}t.unbindTexture()}else{let le=i.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(le=R.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(le,q.__webglTexture),Ve(le,y),y.mipmaps&&y.mipmaps.length>0)for(let be=0;be<y.mipmaps.length;be++)Ae(k.__webglFramebuffer[be],R,y,i.COLOR_ATTACHMENT0,le,be);else Ae(k.__webglFramebuffer,R,y,i.COLOR_ATTACHMENT0,le,0);m(y)&&p(le),t.unbindTexture()}R.depthBuffer&&_t(R)}function L(R){const y=R.textures;for(let k=0,q=y.length;k<q;k++){const J=y[k];if(m(J)){const X=x(R),we=n.get(J).__webglTexture;t.bindTexture(X,we),p(X),t.unbindTexture()}}}const zt=[],et=[];function ut(R){if(R.samples>0){if(qe(R)===!1){const y=R.textures,k=R.width,q=R.height;let J=i.COLOR_BUFFER_BIT;const X=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,we=n.get(R),le=y.length>1;if(le)for(let Se=0;Se<y.length;Se++)t.bindFramebuffer(i.FRAMEBUFFER,we.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,we.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,we.__webglMultisampledFramebuffer);const be=R.texture.mipmaps;be&&be.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,we.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,we.__webglFramebuffer);for(let Se=0;Se<y.length;Se++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),le){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,we.__webglColorRenderbuffer[Se]);const ee=n.get(y[Se]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,ee,0)}i.blitFramebuffer(0,0,k,q,0,0,k,q,J,i.NEAREST),c===!0&&(zt.length=0,et.length=0,zt.push(i.COLOR_ATTACHMENT0+Se),R.depthBuffer&&R.resolveDepthBuffer===!1&&(zt.push(X),et.push(X),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,et)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,zt))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),le)for(let Se=0;Se<y.length;Se++){t.bindFramebuffer(i.FRAMEBUFFER,we.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,we.__webglColorRenderbuffer[Se]);const ee=n.get(y[Se]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,we.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,ee,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,we.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&c){const y=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[y])}}}function Me(R){return Math.min(s.maxSamples,R.samples)}function qe(R){const y=n.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function Pe(R){const y=o.render.frame;d.get(R)!==y&&(d.set(R,y),R.update())}function ze(R,y){const k=R.colorSpace,q=R.format,J=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||k!==pr&&k!==Mi&&(Ke.getTransfer(k)===lt?(q!==Rn||J!==Wn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",k)),y}function Tt(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(u.width=R.naturalWidth||R.width,u.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(u.width=R.displayWidth,u.height=R.displayHeight):(u.width=R.width,u.height=R.height),u}this.allocateTextureUnit=N,this.resetTextureUnits=B,this.setTexture2D=Y,this.setTexture2DArray=$,this.setTexture3D=Q,this.setTextureCube=G,this.rebindTextures=xt,this.setupRenderTarget=Qe,this.updateRenderTargetMipmap=L,this.updateMultisampleRenderTarget=ut,this.setupDepthRenderbuffer=_t,this.setupFrameBufferTexture=Ae,this.useMultisampledRTT=qe}function eA(i,e){function t(n,s=Mi){let r;const o=Ke.getTransfer(s);if(n===Wn)return i.UNSIGNED_BYTE;if(n===Dd)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Ud)return i.UNSIGNED_SHORT_5_5_5_1;if(n===L_)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===P_)return i.BYTE;if(n===I_)return i.SHORT;if(n===lo)return i.UNSIGNED_SHORT;if(n===Ld)return i.INT;if(n===ls)return i.UNSIGNED_INT;if(n===zn)return i.FLOAT;if(n===Co)return i.HALF_FLOAT;if(n===D_)return i.ALPHA;if(n===U_)return i.RGB;if(n===Rn)return i.RGBA;if(n===ho)return i.DEPTH_COMPONENT;if(n===uo)return i.DEPTH_STENCIL;if(n===Od)return i.RED;if(n===Fd)return i.RED_INTEGER;if(n===O_)return i.RG;if(n===Nd)return i.RG_INTEGER;if(n===kd)return i.RGBA_INTEGER;if(n===hl||n===ul||n===dl||n===fl)if(o===lt)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===hl)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ul)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===dl)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===fl)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===hl)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ul)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===dl)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===fl)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Su||n===Eu||n===Au||n===Tu)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Su)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Eu)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Au)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Tu)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Cu||n===Ru||n===Pu)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Cu||n===Ru)return o===lt?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Pu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Iu||n===Lu||n===Du||n===Uu||n===Ou||n===Fu||n===Nu||n===ku||n===Bu||n===zu||n===Hu||n===Vu||n===Gu||n===Wu)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Iu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Lu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Du)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Uu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Ou)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Fu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Nu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===ku)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Bu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===zu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Hu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Vu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Gu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Wu)return o===lt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===pl||n===Xu||n===$u)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===pl)return o===lt?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Xu)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===$u)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===F_||n===Yu||n===qu||n===ju)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===pl)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Yu)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===qu)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===ju)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===co?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const tA=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,nA=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class iA{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const s=new kt,r=e.properties.get(s);r.__webglTexture=t.texture,(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Ii({vertexShader:tA,fragmentShader:nA,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new at(new Lo(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class sA extends xs{constructor(e,t){super();const n=this;let s=null,r=1,o=null,l="local-floor",c=1,u=null,d=null,a=null,h=null,f=null,g=null;const _=new iA,m=t.getContextAttributes();let p=null,x=null;const b=[],v=[],P=new xe;let C=null;const T=new gn;T.viewport=new Mt;const D=new gn;D.viewport=new Mt;const w=[T,D],M=new Mb;let I=null,B=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let re=b[K];return re===void 0&&(re=new zc,b[K]=re),re.getTargetRaySpace()},this.getControllerGrip=function(K){let re=b[K];return re===void 0&&(re=new zc,b[K]=re),re.getGripSpace()},this.getHand=function(K){let re=b[K];return re===void 0&&(re=new zc,b[K]=re),re.getHandSpace()};function N(K){const re=v.indexOf(K.inputSource);if(re===-1)return;const Ee=b[re];Ee!==void 0&&(Ee.update(K.inputSource,K.frame,u||o),Ee.dispatchEvent({type:K.type,data:K.inputSource}))}function V(){s.removeEventListener("select",N),s.removeEventListener("selectstart",N),s.removeEventListener("selectend",N),s.removeEventListener("squeeze",N),s.removeEventListener("squeezestart",N),s.removeEventListener("squeezeend",N),s.removeEventListener("end",V),s.removeEventListener("inputsourceschange",Y);for(let K=0;K<b.length;K++){const re=v[K];re!==null&&(v[K]=null,b[K].disconnect(re))}I=null,B=null,_.reset(),e.setRenderTarget(p),f=null,h=null,a=null,s=null,x=null,ht.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(P.width,P.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){r=K,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){l=K,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return u||o},this.setReferenceSpace=function(K){u=K},this.getBaseLayer=function(){return h!==null?h:f},this.getBinding=function(){return a},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(K){if(s=K,s!==null){if(p=e.getRenderTarget(),s.addEventListener("select",N),s.addEventListener("selectstart",N),s.addEventListener("selectend",N),s.addEventListener("squeeze",N),s.addEventListener("squeezestart",N),s.addEventListener("squeezeend",N),s.addEventListener("end",V),s.addEventListener("inputsourceschange",Y),m.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(P),typeof XRWebGLBinding<"u"&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ee=null,de=null,Ae=null;m.depth&&(Ae=m.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Ee=m.stencil?uo:ho,de=m.stencil?co:ls);const Je={colorFormat:t.RGBA8,depthFormat:Ae,scaleFactor:r};a=new XRWebGLBinding(s,t),h=a.createProjectionLayer(Je),s.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),x=new cs(h.textureWidth,h.textureHeight,{format:Rn,type:Wn,depthTexture:new q_(h.textureWidth,h.textureHeight,de,void 0,void 0,void 0,void 0,void 0,void 0,Ee),stencilBuffer:m.stencil,colorSpace:e.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}else{const Ee={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,Ee),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),x=new cs(f.framebufferWidth,f.framebufferHeight,{format:Rn,type:Wn,colorSpace:e.outputColorSpace,stencilBuffer:m.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}x.isXRRenderTarget=!0,this.setFoveation(c),u=null,o=await s.requestReferenceSpace(l),ht.setContext(s),ht.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function Y(K){for(let re=0;re<K.removed.length;re++){const Ee=K.removed[re],de=v.indexOf(Ee);de>=0&&(v[de]=null,b[de].disconnect(Ee))}for(let re=0;re<K.added.length;re++){const Ee=K.added[re];let de=v.indexOf(Ee);if(de===-1){for(let Je=0;Je<b.length;Je++)if(Je>=v.length){v.push(Ee),de=Je;break}else if(v[Je]===null){v[Je]=Ee,de=Je;break}if(de===-1)break}const Ae=b[de];Ae&&Ae.connect(Ee)}}const $=new A,Q=new A;function G(K,re,Ee){$.setFromMatrixPosition(re.matrixWorld),Q.setFromMatrixPosition(Ee.matrixWorld);const de=$.distanceTo(Q),Ae=re.projectionMatrix.elements,Je=Ee.projectionMatrix.elements,Ue=Ae[14]/(Ae[10]-1),_t=Ae[14]/(Ae[10]+1),xt=(Ae[9]+1)/Ae[5],Qe=(Ae[9]-1)/Ae[5],L=(Ae[8]-1)/Ae[0],zt=(Je[8]+1)/Je[0],et=Ue*L,ut=Ue*zt,Me=de/(-L+zt),qe=Me*-L;if(re.matrixWorld.decompose(K.position,K.quaternion,K.scale),K.translateX(qe),K.translateZ(Me),K.matrixWorld.compose(K.position,K.quaternion,K.scale),K.matrixWorldInverse.copy(K.matrixWorld).invert(),Ae[10]===-1)K.projectionMatrix.copy(re.projectionMatrix),K.projectionMatrixInverse.copy(re.projectionMatrixInverse);else{const Pe=Ue+Me,ze=_t+Me,Tt=et-qe,R=ut+(de-qe),y=xt*_t/ze*Pe,k=Qe*_t/ze*Pe;K.projectionMatrix.makePerspective(Tt,R,y,k,Pe,ze),K.projectionMatrixInverse.copy(K.projectionMatrix).invert()}}function ce(K,re){re===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(re.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(s===null)return;let re=K.near,Ee=K.far;_.texture!==null&&(_.depthNear>0&&(re=_.depthNear),_.depthFar>0&&(Ee=_.depthFar)),M.near=D.near=T.near=re,M.far=D.far=T.far=Ee,(I!==M.near||B!==M.far)&&(s.updateRenderState({depthNear:M.near,depthFar:M.far}),I=M.near,B=M.far),T.layers.mask=K.layers.mask|2,D.layers.mask=K.layers.mask|4,M.layers.mask=T.layers.mask|D.layers.mask;const de=K.parent,Ae=M.cameras;ce(M,de);for(let Je=0;Je<Ae.length;Je++)ce(Ae[Je],de);Ae.length===2?G(M,T,D):M.projectionMatrix.copy(T.projectionMatrix),fe(K,M,de)};function fe(K,re,Ee){Ee===null?K.matrix.copy(re.matrixWorld):(K.matrix.copy(Ee.matrixWorld),K.matrix.invert(),K.matrix.multiply(re.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(re.projectionMatrix),K.projectionMatrixInverse.copy(re.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=Ku*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(h===null&&f===null))return c},this.setFoveation=function(K){c=K,h!==null&&(h.fixedFoveation=K),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=K)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)};let Re=null;function Ve(K,re){if(d=re.getViewerPose(u||o),g=re,d!==null){const Ee=d.views;f!==null&&(e.setRenderTargetFramebuffer(x,f.framebuffer),e.setRenderTarget(x));let de=!1;Ee.length!==M.cameras.length&&(M.cameras.length=0,de=!0);for(let Ue=0;Ue<Ee.length;Ue++){const _t=Ee[Ue];let xt=null;if(f!==null)xt=f.getViewport(_t);else{const L=a.getViewSubImage(h,_t);xt=L.viewport,Ue===0&&(e.setRenderTargetTextures(x,L.colorTexture,L.depthStencilTexture),e.setRenderTarget(x))}let Qe=w[Ue];Qe===void 0&&(Qe=new gn,Qe.layers.enable(Ue),Qe.viewport=new Mt,w[Ue]=Qe),Qe.matrix.fromArray(_t.transform.matrix),Qe.matrix.decompose(Qe.position,Qe.quaternion,Qe.scale),Qe.projectionMatrix.fromArray(_t.projectionMatrix),Qe.projectionMatrixInverse.copy(Qe.projectionMatrix).invert(),Qe.viewport.set(xt.x,xt.y,xt.width,xt.height),Ue===0&&(M.matrix.copy(Qe.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),de===!0&&M.cameras.push(Qe)}const Ae=s.enabledFeatures;if(Ae&&Ae.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&a){const Ue=a.getDepthInformation(Ee[0]);Ue&&Ue.isValid&&Ue.texture&&_.init(e,Ue,s.renderState)}}for(let Ee=0;Ee<b.length;Ee++){const de=v[Ee],Ae=b[Ee];de!==null&&Ae!==void 0&&Ae.update(de,re,u||o)}Re&&Re(K,re),re.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:re}),g=null}const ht=new Z_;ht.setAnimationLoop(Ve),this.setAnimationLoop=function(K){Re=K},this.dispose=function(){}}}const Vi=new Ln,rA=new We;function oA(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,G_(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,x,b,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),a(m,p)):p.isMeshPhongMaterial?(r(m,p),d(m,p)):p.isMeshStandardMaterial?(r(m,p),h(m,p),p.isMeshPhysicalMaterial&&f(m,p,v)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&l(m,p)):p.isPointsMaterial?c(m,p,x,b):p.isSpriteMaterial?u(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Wt&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Wt&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const x=e.get(p),b=x.envMap,v=x.envMapRotation;b&&(m.envMap.value=b,Vi.copy(v),Vi.x*=-1,Vi.y*=-1,Vi.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(Vi.y*=-1,Vi.z*=-1),m.envMapRotation.value.setFromMatrix4(rA.makeRotationFromEuler(Vi)),m.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function l(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,x,b){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*x,m.scale.value=b*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function u(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function d(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function a(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function h(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,x){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Wt&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const x=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function aA(i,e,t,n){let s={},r={},o=[];const l=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(x,b){const v=b.program;n.uniformBlockBinding(x,v)}function u(x,b){let v=s[x.id];v===void 0&&(g(x),v=d(x),s[x.id]=v,x.addEventListener("dispose",m));const P=b.program;n.updateUBOMapping(x,P);const C=e.render.frame;r[x.id]!==C&&(h(x),r[x.id]=C)}function d(x){const b=a();x.__bindingPointIndex=b;const v=i.createBuffer(),P=x.__size,C=x.usage;return i.bindBuffer(i.UNIFORM_BUFFER,v),i.bufferData(i.UNIFORM_BUFFER,P,C),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,b,v),v}function a(){for(let x=0;x<l;x++)if(o.indexOf(x)===-1)return o.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(x){const b=s[x.id],v=x.uniforms,P=x.__cache;i.bindBuffer(i.UNIFORM_BUFFER,b);for(let C=0,T=v.length;C<T;C++){const D=Array.isArray(v[C])?v[C]:[v[C]];for(let w=0,M=D.length;w<M;w++){const I=D[w];if(f(I,C,w,P)===!0){const B=I.__offset,N=Array.isArray(I.value)?I.value:[I.value];let V=0;for(let Y=0;Y<N.length;Y++){const $=N[Y],Q=_($);typeof $=="number"||typeof $=="boolean"?(I.__data[0]=$,i.bufferSubData(i.UNIFORM_BUFFER,B+V,I.__data)):$.isMatrix3?(I.__data[0]=$.elements[0],I.__data[1]=$.elements[1],I.__data[2]=$.elements[2],I.__data[3]=0,I.__data[4]=$.elements[3],I.__data[5]=$.elements[4],I.__data[6]=$.elements[5],I.__data[7]=0,I.__data[8]=$.elements[6],I.__data[9]=$.elements[7],I.__data[10]=$.elements[8],I.__data[11]=0):($.toArray(I.__data,V),V+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,B,I.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(x,b,v,P){const C=x.value,T=b+"_"+v;if(P[T]===void 0)return typeof C=="number"||typeof C=="boolean"?P[T]=C:P[T]=C.clone(),!0;{const D=P[T];if(typeof C=="number"||typeof C=="boolean"){if(D!==C)return P[T]=C,!0}else if(D.equals(C)===!1)return D.copy(C),!0}return!1}function g(x){const b=x.uniforms;let v=0;const P=16;for(let T=0,D=b.length;T<D;T++){const w=Array.isArray(b[T])?b[T]:[b[T]];for(let M=0,I=w.length;M<I;M++){const B=w[M],N=Array.isArray(B.value)?B.value:[B.value];for(let V=0,Y=N.length;V<Y;V++){const $=N[V],Q=_($),G=v%P,ce=G%Q.boundary,fe=G+ce;v+=ce,fe!==0&&P-fe<Q.storage&&(v+=P-fe),B.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),B.__offset=v,v+=Q.storage}}}const C=v%P;return C>0&&(v+=P-C),x.__size=v,x.__cache={},this}function _(x){const b={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(b.boundary=4,b.storage=4):x.isVector2?(b.boundary=8,b.storage=8):x.isVector3||x.isColor?(b.boundary=16,b.storage=12):x.isVector4?(b.boundary=16,b.storage=16):x.isMatrix3?(b.boundary=48,b.storage=48):x.isMatrix4?(b.boundary=64,b.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),b}function m(x){const b=x.target;b.removeEventListener("dispose",m);const v=o.indexOf(b.__bindingPointIndex);o.splice(v,1),i.deleteBuffer(s[b.id]),delete s[b.id],delete r[b.id]}function p(){for(const x in s)i.deleteBuffer(s[x]);o=[],s={},r={}}return{bind:c,update:u,dispose:p}}class nx{constructor(e={}){const{canvas:t=D1(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:l=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:u=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:a=!1,reverseDepthBuffer:h=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const x=[],b=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ai,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const v=this;let P=!1;this._outputColorSpace=on;let C=0,T=0,D=null,w=-1,M=null;const I=new Mt,B=new Mt;let N=null;const V=new se(0);let Y=0,$=t.width,Q=t.height,G=1,ce=null,fe=null;const Re=new Mt(0,0,$,Q),Ve=new Mt(0,0,$,Q);let ht=!1;const K=new Vd;let re=!1,Ee=!1;const de=new We,Ae=new We,Je=new A,Ue=new Mt,_t={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let xt=!1;function Qe(){return D===null?G:1}let L=n;function zt(S,O){return t.getContext(S,O)}try{const S={alpha:!0,depth:s,stencil:r,antialias:l,premultipliedAlpha:c,preserveDrawingBuffer:u,powerPreference:d,failIfMajorPerformanceCaveat:a};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Id}`),t.addEventListener("webglcontextlost",ge,!1),t.addEventListener("webglcontextrestored",ne,!1),t.addEventListener("webglcontextcreationerror",Z,!1),L===null){const O="webgl2";if(L=zt(O,S),L===null)throw zt(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(S){throw console.error("THREE.WebGLRenderer: "+S.message),S}let et,ut,Me,qe,Pe,ze,Tt,R,y,k,q,J,X,we,le,be,Se,ee,pe,De,Le,oe,Ne,U;function he(){et=new xS(L),et.init(),oe=new eA(L,et),ut=new uS(L,et,e,oe),Me=new JE(L,et),ut.reverseDepthBuffer&&h&&Me.buffers.depth.setReversed(!0),qe=new bS(L),Pe=new BE,ze=new QE(L,et,Me,Pe,ut,oe,qe),Tt=new fS(v),R=new _S(v),y=new Tb(L),Ne=new cS(L,y),k=new yS(L,y,qe,Ne),q=new wS(L,k,y,qe),pe=new MS(L,ut,ze),be=new dS(Pe),J=new kE(v,Tt,R,et,ut,Ne,be),X=new oA(v,Pe),we=new HE,le=new YE(et),ee=new lS(v,Tt,R,Me,q,f,c),Se=new KE(v,q,ut),U=new aA(L,qe,ut,Me),De=new hS(L,et,qe),Le=new vS(L,et,qe),qe.programs=J.programs,v.capabilities=ut,v.extensions=et,v.properties=Pe,v.renderLists=we,v.shadowMap=Se,v.state=Me,v.info=qe}he();const te=new sA(v,L);this.xr=te,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const S=et.get("WEBGL_lose_context");S&&S.loseContext()},this.forceContextRestore=function(){const S=et.get("WEBGL_lose_context");S&&S.restoreContext()},this.getPixelRatio=function(){return G},this.setPixelRatio=function(S){S!==void 0&&(G=S,this.setSize($,Q,!1))},this.getSize=function(S){return S.set($,Q)},this.setSize=function(S,O,z=!0){if(te.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}$=S,Q=O,t.width=Math.floor(S*G),t.height=Math.floor(O*G),z===!0&&(t.style.width=S+"px",t.style.height=O+"px"),this.setViewport(0,0,S,O)},this.getDrawingBufferSize=function(S){return S.set($*G,Q*G).floor()},this.setDrawingBufferSize=function(S,O,z){$=S,Q=O,G=z,t.width=Math.floor(S*z),t.height=Math.floor(O*z),this.setViewport(0,0,S,O)},this.getCurrentViewport=function(S){return S.copy(I)},this.getViewport=function(S){return S.copy(Re)},this.setViewport=function(S,O,z,H){S.isVector4?Re.set(S.x,S.y,S.z,S.w):Re.set(S,O,z,H),Me.viewport(I.copy(Re).multiplyScalar(G).round())},this.getScissor=function(S){return S.copy(Ve)},this.setScissor=function(S,O,z,H){S.isVector4?Ve.set(S.x,S.y,S.z,S.w):Ve.set(S,O,z,H),Me.scissor(B.copy(Ve).multiplyScalar(G).round())},this.getScissorTest=function(){return ht},this.setScissorTest=function(S){Me.setScissorTest(ht=S)},this.setOpaqueSort=function(S){ce=S},this.setTransparentSort=function(S){fe=S},this.getClearColor=function(S){return S.copy(ee.getClearColor())},this.setClearColor=function(){ee.setClearColor(...arguments)},this.getClearAlpha=function(){return ee.getClearAlpha()},this.setClearAlpha=function(){ee.setClearAlpha(...arguments)},this.clear=function(S=!0,O=!0,z=!0){let H=0;if(S){let F=!1;if(D!==null){const ie=D.texture.format;F=ie===kd||ie===Nd||ie===Fd}if(F){const ie=D.texture.type,ue=ie===Wn||ie===ls||ie===lo||ie===co||ie===Dd||ie===Ud,ve=ee.getClearColor(),me=ee.getClearAlpha(),Oe=ve.r,Fe=ve.g,Te=ve.b;ue?(g[0]=Oe,g[1]=Fe,g[2]=Te,g[3]=me,L.clearBufferuiv(L.COLOR,0,g)):(_[0]=Oe,_[1]=Fe,_[2]=Te,_[3]=me,L.clearBufferiv(L.COLOR,0,_))}else H|=L.COLOR_BUFFER_BIT}O&&(H|=L.DEPTH_BUFFER_BIT),z&&(H|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ge,!1),t.removeEventListener("webglcontextrestored",ne,!1),t.removeEventListener("webglcontextcreationerror",Z,!1),ee.dispose(),we.dispose(),le.dispose(),Pe.dispose(),Tt.dispose(),R.dispose(),q.dispose(),Ne.dispose(),U.dispose(),J.dispose(),te.dispose(),te.removeEventListener("sessionstart",Mp),te.removeEventListener("sessionend",wp),Oi.stop()};function ge(S){S.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),P=!0}function ne(){console.log("THREE.WebGLRenderer: Context Restored."),P=!1;const S=qe.autoReset,O=Se.enabled,z=Se.autoUpdate,H=Se.needsUpdate,F=Se.type;he(),qe.autoReset=S,Se.enabled=O,Se.autoUpdate=z,Se.needsUpdate=H,Se.type=F}function Z(S){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",S.statusMessage)}function ye(S){const O=S.target;O.removeEventListener("dispose",ye),ke(O)}function ke(S){ft(S),Pe.remove(S)}function ft(S){const O=Pe.get(S).programs;O!==void 0&&(O.forEach(function(z){J.releaseProgram(z)}),S.isShaderMaterial&&J.releaseShaderCache(S))}this.renderBufferDirect=function(S,O,z,H,F,ie){O===null&&(O=_t);const ue=F.isMesh&&F.matrixWorld.determinant()<0,ve=uv(S,O,z,H,F);Me.setMaterial(H,ue);let me=z.index,Oe=1;if(H.wireframe===!0){if(me=k.getWireframeAttribute(z),me===void 0)return;Oe=2}const Fe=z.drawRange,Te=z.attributes.position;let Xe=Fe.start*Oe,rt=(Fe.start+Fe.count)*Oe;ie!==null&&(Xe=Math.max(Xe,ie.start*Oe),rt=Math.min(rt,(ie.start+ie.count)*Oe)),me!==null?(Xe=Math.max(Xe,0),rt=Math.min(rt,me.count)):Te!=null&&(Xe=Math.max(Xe,0),rt=Math.min(rt,Te.count));const yt=rt-Xe;if(yt<0||yt===1/0)return;Ne.setup(F,H,ve,z,me);let bt,je=De;if(me!==null&&(bt=y.get(me),je=Le,je.setIndex(bt)),F.isMesh)H.wireframe===!0?(Me.setLineWidth(H.wireframeLinewidth*Qe()),je.setMode(L.LINES)):je.setMode(L.TRIANGLES);else if(F.isLine){let Ie=H.linewidth;Ie===void 0&&(Ie=1),Me.setLineWidth(Ie*Qe()),F.isLineSegments?je.setMode(L.LINES):F.isLineLoop?je.setMode(L.LINE_LOOP):je.setMode(L.LINE_STRIP)}else F.isPoints?je.setMode(L.POINTS):F.isSprite&&je.setMode(L.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)nr("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),je.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(et.get("WEBGL_multi_draw"))je.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{const Ie=F._multiDrawStarts,Lt=F._multiDrawCounts,nt=F._multiDrawCount,bn=me?y.get(me).bytesPerElement:1,bs=Pe.get(H).currentProgram.getUniforms();for(let en=0;en<nt;en++)bs.setValue(L,"_gl_DrawID",en),je.render(Ie[en]/bn,Lt[en])}else if(F.isInstancedMesh)je.renderInstances(Xe,yt,F.count);else if(z.isInstancedBufferGeometry){const Ie=z._maxInstanceCount!==void 0?z._maxInstanceCount:1/0,Lt=Math.min(z.instanceCount,Ie);je.renderInstances(Xe,yt,Lt)}else je.render(Xe,yt)};function st(S,O,z){S.transparent===!0&&S.side===kn&&S.forceSinglePass===!1?(S.side=Wt,S.needsUpdate=!0,ko(S,O,z),S.side=Ri,S.needsUpdate=!0,ko(S,O,z),S.side=kn):ko(S,O,z)}this.compile=function(S,O,z=null){z===null&&(z=S),p=le.get(z),p.init(O),b.push(p),z.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),S!==z&&S.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();const H=new Set;return S.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;const ie=F.material;if(ie)if(Array.isArray(ie))for(let ue=0;ue<ie.length;ue++){const ve=ie[ue];st(ve,z,F),H.add(ve)}else st(ie,z,F),H.add(ie)}),p=b.pop(),H},this.compileAsync=function(S,O,z=null){const H=this.compile(S,O,z);return new Promise(F=>{function ie(){if(H.forEach(function(ue){Pe.get(ue).currentProgram.isReady()&&H.delete(ue)}),H.size===0){F(S);return}setTimeout(ie,10)}et.get("KHR_parallel_shader_compile")!==null?ie():setTimeout(ie,10)})};let vn=null;function Yn(S){vn&&vn(S)}function Mp(){Oi.stop()}function wp(){Oi.start()}const Oi=new Z_;Oi.setAnimationLoop(Yn),typeof self<"u"&&Oi.setContext(self),this.setAnimationLoop=function(S){vn=S,te.setAnimationLoop(S),S===null?Oi.stop():Oi.start()},te.addEventListener("sessionstart",Mp),te.addEventListener("sessionend",wp),this.render=function(S,O){if(O!==void 0&&O.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(P===!0)return;if(S.matrixWorldAutoUpdate===!0&&S.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),te.enabled===!0&&te.isPresenting===!0&&(te.cameraAutoUpdate===!0&&te.updateCamera(O),O=te.getCamera()),S.isScene===!0&&S.onBeforeRender(v,S,O,D),p=le.get(S,b.length),p.init(O),b.push(p),Ae.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),K.setFromProjectionMatrix(Ae),Ee=this.localClippingEnabled,re=be.init(this.clippingPlanes,Ee),m=we.get(S,x.length),m.init(),x.push(m),te.enabled===!0&&te.isPresenting===!0){const ie=v.xr.getDepthSensingMesh();ie!==null&&mc(ie,O,-1/0,v.sortObjects)}mc(S,O,0,v.sortObjects),m.finish(),v.sortObjects===!0&&m.sort(ce,fe),xt=te.enabled===!1||te.isPresenting===!1||te.hasDepthSensing()===!1,xt&&ee.addToRenderList(m,S),this.info.render.frame++,re===!0&&be.beginShadows();const z=p.state.shadowsArray;Se.render(z,S,O),re===!0&&be.endShadows(),this.info.autoReset===!0&&this.info.reset();const H=m.opaque,F=m.transmissive;if(p.setupLights(),O.isArrayCamera){const ie=O.cameras;if(F.length>0)for(let ue=0,ve=ie.length;ue<ve;ue++){const me=ie[ue];Ep(H,F,S,me)}xt&&ee.render(S);for(let ue=0,ve=ie.length;ue<ve;ue++){const me=ie[ue];Sp(m,S,me,me.viewport)}}else F.length>0&&Ep(H,F,S,O),xt&&ee.render(S),Sp(m,S,O);D!==null&&T===0&&(ze.updateMultisampleRenderTarget(D),ze.updateRenderTargetMipmap(D)),S.isScene===!0&&S.onAfterRender(v,S,O),Ne.resetDefaultState(),w=-1,M=null,b.pop(),b.length>0?(p=b[b.length-1],re===!0&&be.setGlobalState(v.clippingPlanes,p.state.camera)):p=null,x.pop(),x.length>0?m=x[x.length-1]:m=null};function mc(S,O,z,H){if(S.visible===!1)return;if(S.layers.test(O.layers)){if(S.isGroup)z=S.renderOrder;else if(S.isLOD)S.autoUpdate===!0&&S.update(O);else if(S.isLight)p.pushLight(S),S.castShadow&&p.pushShadow(S);else if(S.isSprite){if(!S.frustumCulled||K.intersectsSprite(S)){H&&Ue.setFromMatrixPosition(S.matrixWorld).applyMatrix4(Ae);const ue=q.update(S),ve=S.material;ve.visible&&m.push(S,ue,ve,z,Ue.z,null)}}else if((S.isMesh||S.isLine||S.isPoints)&&(!S.frustumCulled||K.intersectsObject(S))){const ue=q.update(S),ve=S.material;if(H&&(S.boundingSphere!==void 0?(S.boundingSphere===null&&S.computeBoundingSphere(),Ue.copy(S.boundingSphere.center)):(ue.boundingSphere===null&&ue.computeBoundingSphere(),Ue.copy(ue.boundingSphere.center)),Ue.applyMatrix4(S.matrixWorld).applyMatrix4(Ae)),Array.isArray(ve)){const me=ue.groups;for(let Oe=0,Fe=me.length;Oe<Fe;Oe++){const Te=me[Oe],Xe=ve[Te.materialIndex];Xe&&Xe.visible&&m.push(S,ue,Xe,z,Ue.z,Te)}}else ve.visible&&m.push(S,ue,ve,z,Ue.z,null)}}const ie=S.children;for(let ue=0,ve=ie.length;ue<ve;ue++)mc(ie[ue],O,z,H)}function Sp(S,O,z,H){const F=S.opaque,ie=S.transmissive,ue=S.transparent;p.setupLightsView(z),re===!0&&be.setGlobalState(v.clippingPlanes,z),H&&Me.viewport(I.copy(H)),F.length>0&&No(F,O,z),ie.length>0&&No(ie,O,z),ue.length>0&&No(ue,O,z),Me.buffers.depth.setTest(!0),Me.buffers.depth.setMask(!0),Me.buffers.color.setMask(!0),Me.setPolygonOffset(!1)}function Ep(S,O,z,H){if((z.isScene===!0?z.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[H.id]===void 0&&(p.state.transmissionRenderTarget[H.id]=new cs(1,1,{generateMipmaps:!0,type:et.has("EXT_color_buffer_half_float")||et.has("EXT_color_buffer_float")?Co:Wn,minFilter:ns,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ke.workingColorSpace}));const ie=p.state.transmissionRenderTarget[H.id],ue=H.viewport||I;ie.setSize(ue.z*v.transmissionResolutionScale,ue.w*v.transmissionResolutionScale);const ve=v.getRenderTarget();v.setRenderTarget(ie),v.getClearColor(V),Y=v.getClearAlpha(),Y<1&&v.setClearColor(16777215,.5),v.clear(),xt&&ee.render(z);const me=v.toneMapping;v.toneMapping=Ai;const Oe=H.viewport;if(H.viewport!==void 0&&(H.viewport=void 0),p.setupLightsView(H),re===!0&&be.setGlobalState(v.clippingPlanes,H),No(S,z,H),ze.updateMultisampleRenderTarget(ie),ze.updateRenderTargetMipmap(ie),et.has("WEBGL_multisampled_render_to_texture")===!1){let Fe=!1;for(let Te=0,Xe=O.length;Te<Xe;Te++){const rt=O[Te],yt=rt.object,bt=rt.geometry,je=rt.material,Ie=rt.group;if(je.side===kn&&yt.layers.test(H.layers)){const Lt=je.side;je.side=Wt,je.needsUpdate=!0,Ap(yt,z,H,bt,je,Ie),je.side=Lt,je.needsUpdate=!0,Fe=!0}}Fe===!0&&(ze.updateMultisampleRenderTarget(ie),ze.updateRenderTargetMipmap(ie))}v.setRenderTarget(ve),v.setClearColor(V,Y),Oe!==void 0&&(H.viewport=Oe),v.toneMapping=me}function No(S,O,z){const H=O.isScene===!0?O.overrideMaterial:null;for(let F=0,ie=S.length;F<ie;F++){const ue=S[F],ve=ue.object,me=ue.geometry,Oe=ue.group;let Fe=ue.material;Fe.allowOverride===!0&&H!==null&&(Fe=H),ve.layers.test(z.layers)&&Ap(ve,O,z,me,Fe,Oe)}}function Ap(S,O,z,H,F,ie){S.onBeforeRender(v,O,z,H,F,ie),S.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,S.matrixWorld),S.normalMatrix.getNormalMatrix(S.modelViewMatrix),F.onBeforeRender(v,O,z,H,S,ie),F.transparent===!0&&F.side===kn&&F.forceSinglePass===!1?(F.side=Wt,F.needsUpdate=!0,v.renderBufferDirect(z,O,H,F,S,ie),F.side=Ri,F.needsUpdate=!0,v.renderBufferDirect(z,O,H,F,S,ie),F.side=kn):v.renderBufferDirect(z,O,H,F,S,ie),S.onAfterRender(v,O,z,H,F,ie)}function ko(S,O,z){O.isScene!==!0&&(O=_t);const H=Pe.get(S),F=p.state.lights,ie=p.state.shadowsArray,ue=F.state.version,ve=J.getParameters(S,F.state,ie,O,z),me=J.getProgramCacheKey(ve);let Oe=H.programs;H.environment=S.isMeshStandardMaterial?O.environment:null,H.fog=O.fog,H.envMap=(S.isMeshStandardMaterial?R:Tt).get(S.envMap||H.environment),H.envMapRotation=H.environment!==null&&S.envMap===null?O.environmentRotation:S.envMapRotation,Oe===void 0&&(S.addEventListener("dispose",ye),Oe=new Map,H.programs=Oe);let Fe=Oe.get(me);if(Fe!==void 0){if(H.currentProgram===Fe&&H.lightsStateVersion===ue)return Cp(S,ve),Fe}else ve.uniforms=J.getUniforms(S),S.onBeforeCompile(ve,v),Fe=J.acquireProgram(ve,me),Oe.set(me,Fe),H.uniforms=ve.uniforms;const Te=H.uniforms;return(!S.isShaderMaterial&&!S.isRawShaderMaterial||S.clipping===!0)&&(Te.clippingPlanes=be.uniform),Cp(S,ve),H.needsLights=fv(S),H.lightsStateVersion=ue,H.needsLights&&(Te.ambientLightColor.value=F.state.ambient,Te.lightProbe.value=F.state.probe,Te.directionalLights.value=F.state.directional,Te.directionalLightShadows.value=F.state.directionalShadow,Te.spotLights.value=F.state.spot,Te.spotLightShadows.value=F.state.spotShadow,Te.rectAreaLights.value=F.state.rectArea,Te.ltc_1.value=F.state.rectAreaLTC1,Te.ltc_2.value=F.state.rectAreaLTC2,Te.pointLights.value=F.state.point,Te.pointLightShadows.value=F.state.pointShadow,Te.hemisphereLights.value=F.state.hemi,Te.directionalShadowMap.value=F.state.directionalShadowMap,Te.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Te.spotShadowMap.value=F.state.spotShadowMap,Te.spotLightMatrix.value=F.state.spotLightMatrix,Te.spotLightMap.value=F.state.spotLightMap,Te.pointShadowMap.value=F.state.pointShadowMap,Te.pointShadowMatrix.value=F.state.pointShadowMatrix),H.currentProgram=Fe,H.uniformsList=null,Fe}function Tp(S){if(S.uniformsList===null){const O=S.currentProgram.getUniforms();S.uniformsList=gl.seqWithValue(O.seq,S.uniforms)}return S.uniformsList}function Cp(S,O){const z=Pe.get(S);z.outputColorSpace=O.outputColorSpace,z.batching=O.batching,z.batchingColor=O.batchingColor,z.instancing=O.instancing,z.instancingColor=O.instancingColor,z.instancingMorph=O.instancingMorph,z.skinning=O.skinning,z.morphTargets=O.morphTargets,z.morphNormals=O.morphNormals,z.morphColors=O.morphColors,z.morphTargetsCount=O.morphTargetsCount,z.numClippingPlanes=O.numClippingPlanes,z.numIntersection=O.numClipIntersection,z.vertexAlphas=O.vertexAlphas,z.vertexTangents=O.vertexTangents,z.toneMapping=O.toneMapping}function uv(S,O,z,H,F){O.isScene!==!0&&(O=_t),ze.resetTextureUnits();const ie=O.fog,ue=H.isMeshStandardMaterial?O.environment:null,ve=D===null?v.outputColorSpace:D.isXRRenderTarget===!0?D.texture.colorSpace:pr,me=(H.isMeshStandardMaterial?R:Tt).get(H.envMap||ue),Oe=H.vertexColors===!0&&!!z.attributes.color&&z.attributes.color.itemSize===4,Fe=!!z.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),Te=!!z.morphAttributes.position,Xe=!!z.morphAttributes.normal,rt=!!z.morphAttributes.color;let yt=Ai;H.toneMapped&&(D===null||D.isXRRenderTarget===!0)&&(yt=v.toneMapping);const bt=z.morphAttributes.position||z.morphAttributes.normal||z.morphAttributes.color,je=bt!==void 0?bt.length:0,Ie=Pe.get(H),Lt=p.state.lights;if(re===!0&&(Ee===!0||S!==M)){const Ht=S===M&&H.id===w;be.setState(H,S,Ht)}let nt=!1;H.version===Ie.__version?(Ie.needsLights&&Ie.lightsStateVersion!==Lt.state.version||Ie.outputColorSpace!==ve||F.isBatchedMesh&&Ie.batching===!1||!F.isBatchedMesh&&Ie.batching===!0||F.isBatchedMesh&&Ie.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Ie.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Ie.instancing===!1||!F.isInstancedMesh&&Ie.instancing===!0||F.isSkinnedMesh&&Ie.skinning===!1||!F.isSkinnedMesh&&Ie.skinning===!0||F.isInstancedMesh&&Ie.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Ie.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Ie.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Ie.instancingMorph===!1&&F.morphTexture!==null||Ie.envMap!==me||H.fog===!0&&Ie.fog!==ie||Ie.numClippingPlanes!==void 0&&(Ie.numClippingPlanes!==be.numPlanes||Ie.numIntersection!==be.numIntersection)||Ie.vertexAlphas!==Oe||Ie.vertexTangents!==Fe||Ie.morphTargets!==Te||Ie.morphNormals!==Xe||Ie.morphColors!==rt||Ie.toneMapping!==yt||Ie.morphTargetsCount!==je)&&(nt=!0):(nt=!0,Ie.__version=H.version);let bn=Ie.currentProgram;nt===!0&&(bn=ko(H,O,F));let bs=!1,en=!1,Tr=!1;const mt=bn.getUniforms(),un=Ie.uniforms;if(Me.useProgram(bn.program)&&(bs=!0,en=!0,Tr=!0),H.id!==w&&(w=H.id,en=!0),bs||M!==S){Me.buffers.depth.getReversed()?(de.copy(S.projectionMatrix),O1(de),F1(de),mt.setValue(L,"projectionMatrix",de)):mt.setValue(L,"projectionMatrix",S.projectionMatrix),mt.setValue(L,"viewMatrix",S.matrixWorldInverse);const Xt=mt.map.cameraPosition;Xt!==void 0&&Xt.setValue(L,Je.setFromMatrixPosition(S.matrixWorld)),ut.logarithmicDepthBuffer&&mt.setValue(L,"logDepthBufFC",2/(Math.log(S.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&mt.setValue(L,"isOrthographic",S.isOrthographicCamera===!0),M!==S&&(M=S,en=!0,Tr=!0)}if(F.isSkinnedMesh){mt.setOptional(L,F,"bindMatrix"),mt.setOptional(L,F,"bindMatrixInverse");const Ht=F.skeleton;Ht&&(Ht.boneTexture===null&&Ht.computeBoneTexture(),mt.setValue(L,"boneTexture",Ht.boneTexture,ze))}F.isBatchedMesh&&(mt.setOptional(L,F,"batchingTexture"),mt.setValue(L,"batchingTexture",F._matricesTexture,ze),mt.setOptional(L,F,"batchingIdTexture"),mt.setValue(L,"batchingIdTexture",F._indirectTexture,ze),mt.setOptional(L,F,"batchingColorTexture"),F._colorsTexture!==null&&mt.setValue(L,"batchingColorTexture",F._colorsTexture,ze));const dn=z.morphAttributes;if((dn.position!==void 0||dn.normal!==void 0||dn.color!==void 0)&&pe.update(F,z,bn),(en||Ie.receiveShadow!==F.receiveShadow)&&(Ie.receiveShadow=F.receiveShadow,mt.setValue(L,"receiveShadow",F.receiveShadow)),H.isMeshGouraudMaterial&&H.envMap!==null&&(un.envMap.value=me,un.flipEnvMap.value=me.isCubeTexture&&me.isRenderTargetTexture===!1?-1:1),H.isMeshStandardMaterial&&H.envMap===null&&O.environment!==null&&(un.envMapIntensity.value=O.environmentIntensity),en&&(mt.setValue(L,"toneMappingExposure",v.toneMappingExposure),Ie.needsLights&&dv(un,Tr),ie&&H.fog===!0&&X.refreshFogUniforms(un,ie),X.refreshMaterialUniforms(un,H,G,Q,p.state.transmissionRenderTarget[S.id]),gl.upload(L,Tp(Ie),un,ze)),H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(gl.upload(L,Tp(Ie),un,ze),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&mt.setValue(L,"center",F.center),mt.setValue(L,"modelViewMatrix",F.modelViewMatrix),mt.setValue(L,"normalMatrix",F.normalMatrix),mt.setValue(L,"modelMatrix",F.matrixWorld),H.isShaderMaterial||H.isRawShaderMaterial){const Ht=H.uniformsGroups;for(let Xt=0,gc=Ht.length;Xt<gc;Xt++){const Fi=Ht[Xt];U.update(Fi,bn),U.bind(Fi,bn)}}return bn}function dv(S,O){S.ambientLightColor.needsUpdate=O,S.lightProbe.needsUpdate=O,S.directionalLights.needsUpdate=O,S.directionalLightShadows.needsUpdate=O,S.pointLights.needsUpdate=O,S.pointLightShadows.needsUpdate=O,S.spotLights.needsUpdate=O,S.spotLightShadows.needsUpdate=O,S.rectAreaLights.needsUpdate=O,S.hemisphereLights.needsUpdate=O}function fv(S){return S.isMeshLambertMaterial||S.isMeshToonMaterial||S.isMeshPhongMaterial||S.isMeshStandardMaterial||S.isShadowMaterial||S.isShaderMaterial&&S.lights===!0}this.getActiveCubeFace=function(){return C},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return D},this.setRenderTargetTextures=function(S,O,z){const H=Pe.get(S);H.__autoAllocateDepthBuffer=S.resolveDepthBuffer===!1,H.__autoAllocateDepthBuffer===!1&&(H.__useRenderToTexture=!1),Pe.get(S.texture).__webglTexture=O,Pe.get(S.depthTexture).__webglTexture=H.__autoAllocateDepthBuffer?void 0:z,H.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(S,O){const z=Pe.get(S);z.__webglFramebuffer=O,z.__useDefaultFramebuffer=O===void 0};const pv=L.createFramebuffer();this.setRenderTarget=function(S,O=0,z=0){D=S,C=O,T=z;let H=!0,F=null,ie=!1,ue=!1;if(S){const me=Pe.get(S);if(me.__useDefaultFramebuffer!==void 0)Me.bindFramebuffer(L.FRAMEBUFFER,null),H=!1;else if(me.__webglFramebuffer===void 0)ze.setupRenderTarget(S);else if(me.__hasExternalTextures)ze.rebindTextures(S,Pe.get(S.texture).__webglTexture,Pe.get(S.depthTexture).__webglTexture);else if(S.depthBuffer){const Te=S.depthTexture;if(me.__boundDepthTexture!==Te){if(Te!==null&&Pe.has(Te)&&(S.width!==Te.image.width||S.height!==Te.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");ze.setupDepthRenderbuffer(S)}}const Oe=S.texture;(Oe.isData3DTexture||Oe.isDataArrayTexture||Oe.isCompressedArrayTexture)&&(ue=!0);const Fe=Pe.get(S).__webglFramebuffer;S.isWebGLCubeRenderTarget?(Array.isArray(Fe[O])?F=Fe[O][z]:F=Fe[O],ie=!0):S.samples>0&&ze.useMultisampledRTT(S)===!1?F=Pe.get(S).__webglMultisampledFramebuffer:Array.isArray(Fe)?F=Fe[z]:F=Fe,I.copy(S.viewport),B.copy(S.scissor),N=S.scissorTest}else I.copy(Re).multiplyScalar(G).floor(),B.copy(Ve).multiplyScalar(G).floor(),N=ht;if(z!==0&&(F=pv),Me.bindFramebuffer(L.FRAMEBUFFER,F)&&H&&Me.drawBuffers(S,F),Me.viewport(I),Me.scissor(B),Me.setScissorTest(N),ie){const me=Pe.get(S.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+O,me.__webglTexture,z)}else if(ue){const me=Pe.get(S.texture),Oe=O;L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,me.__webglTexture,z,Oe)}else if(S!==null&&z!==0){const me=Pe.get(S.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,me.__webglTexture,z)}w=-1},this.readRenderTargetPixels=function(S,O,z,H,F,ie,ue,ve=0){if(!(S&&S.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let me=Pe.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&ue!==void 0&&(me=me[ue]),me){Me.bindFramebuffer(L.FRAMEBUFFER,me);try{const Oe=S.textures[ve],Fe=Oe.format,Te=Oe.type;if(!ut.textureFormatReadable(Fe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ut.textureTypeReadable(Te)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=S.width-H&&z>=0&&z<=S.height-F&&(S.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+ve),L.readPixels(O,z,H,F,oe.convert(Fe),oe.convert(Te),ie))}finally{const Oe=D!==null?Pe.get(D).__webglFramebuffer:null;Me.bindFramebuffer(L.FRAMEBUFFER,Oe)}}},this.readRenderTargetPixelsAsync=async function(S,O,z,H,F,ie,ue,ve=0){if(!(S&&S.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let me=Pe.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&ue!==void 0&&(me=me[ue]),me)if(O>=0&&O<=S.width-H&&z>=0&&z<=S.height-F){Me.bindFramebuffer(L.FRAMEBUFFER,me);const Oe=S.textures[ve],Fe=Oe.format,Te=Oe.type;if(!ut.textureFormatReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ut.textureTypeReadable(Te))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Xe=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,Xe),L.bufferData(L.PIXEL_PACK_BUFFER,ie.byteLength,L.STREAM_READ),S.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+ve),L.readPixels(O,z,H,F,oe.convert(Fe),oe.convert(Te),0);const rt=D!==null?Pe.get(D).__webglFramebuffer:null;Me.bindFramebuffer(L.FRAMEBUFFER,rt);const yt=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await U1(L,yt,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,Xe),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,ie),L.deleteBuffer(Xe),L.deleteSync(yt),ie}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(S,O=null,z=0){const H=Math.pow(2,-z),F=Math.floor(S.image.width*H),ie=Math.floor(S.image.height*H),ue=O!==null?O.x:0,ve=O!==null?O.y:0;ze.setTexture2D(S,0),L.copyTexSubImage2D(L.TEXTURE_2D,z,0,0,ue,ve,F,ie),Me.unbindTexture()};const mv=L.createFramebuffer(),gv=L.createFramebuffer();this.copyTextureToTexture=function(S,O,z=null,H=null,F=0,ie=null){ie===null&&(F!==0?(nr("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),ie=F,F=0):ie=0);let ue,ve,me,Oe,Fe,Te,Xe,rt,yt;const bt=S.isCompressedTexture?S.mipmaps[ie]:S.image;if(z!==null)ue=z.max.x-z.min.x,ve=z.max.y-z.min.y,me=z.isBox3?z.max.z-z.min.z:1,Oe=z.min.x,Fe=z.min.y,Te=z.isBox3?z.min.z:0;else{const dn=Math.pow(2,-F);ue=Math.floor(bt.width*dn),ve=Math.floor(bt.height*dn),S.isDataArrayTexture?me=bt.depth:S.isData3DTexture?me=Math.floor(bt.depth*dn):me=1,Oe=0,Fe=0,Te=0}H!==null?(Xe=H.x,rt=H.y,yt=H.z):(Xe=0,rt=0,yt=0);const je=oe.convert(O.format),Ie=oe.convert(O.type);let Lt;O.isData3DTexture?(ze.setTexture3D(O,0),Lt=L.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(ze.setTexture2DArray(O,0),Lt=L.TEXTURE_2D_ARRAY):(ze.setTexture2D(O,0),Lt=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,O.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,O.unpackAlignment);const nt=L.getParameter(L.UNPACK_ROW_LENGTH),bn=L.getParameter(L.UNPACK_IMAGE_HEIGHT),bs=L.getParameter(L.UNPACK_SKIP_PIXELS),en=L.getParameter(L.UNPACK_SKIP_ROWS),Tr=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,bt.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,bt.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Oe),L.pixelStorei(L.UNPACK_SKIP_ROWS,Fe),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Te);const mt=S.isDataArrayTexture||S.isData3DTexture,un=O.isDataArrayTexture||O.isData3DTexture;if(S.isDepthTexture){const dn=Pe.get(S),Ht=Pe.get(O),Xt=Pe.get(dn.__renderTarget),gc=Pe.get(Ht.__renderTarget);Me.bindFramebuffer(L.READ_FRAMEBUFFER,Xt.__webglFramebuffer),Me.bindFramebuffer(L.DRAW_FRAMEBUFFER,gc.__webglFramebuffer);for(let Fi=0;Fi<me;Fi++)mt&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Pe.get(S).__webglTexture,F,Te+Fi),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Pe.get(O).__webglTexture,ie,yt+Fi)),L.blitFramebuffer(Oe,Fe,ue,ve,Xe,rt,ue,ve,L.DEPTH_BUFFER_BIT,L.NEAREST);Me.bindFramebuffer(L.READ_FRAMEBUFFER,null),Me.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(F!==0||S.isRenderTargetTexture||Pe.has(S)){const dn=Pe.get(S),Ht=Pe.get(O);Me.bindFramebuffer(L.READ_FRAMEBUFFER,mv),Me.bindFramebuffer(L.DRAW_FRAMEBUFFER,gv);for(let Xt=0;Xt<me;Xt++)mt?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,dn.__webglTexture,F,Te+Xt):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,dn.__webglTexture,F),un?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ht.__webglTexture,ie,yt+Xt):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,Ht.__webglTexture,ie),F!==0?L.blitFramebuffer(Oe,Fe,ue,ve,Xe,rt,ue,ve,L.COLOR_BUFFER_BIT,L.NEAREST):un?L.copyTexSubImage3D(Lt,ie,Xe,rt,yt+Xt,Oe,Fe,ue,ve):L.copyTexSubImage2D(Lt,ie,Xe,rt,Oe,Fe,ue,ve);Me.bindFramebuffer(L.READ_FRAMEBUFFER,null),Me.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else un?S.isDataTexture||S.isData3DTexture?L.texSubImage3D(Lt,ie,Xe,rt,yt,ue,ve,me,je,Ie,bt.data):O.isCompressedArrayTexture?L.compressedTexSubImage3D(Lt,ie,Xe,rt,yt,ue,ve,me,je,bt.data):L.texSubImage3D(Lt,ie,Xe,rt,yt,ue,ve,me,je,Ie,bt):S.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,ie,Xe,rt,ue,ve,je,Ie,bt.data):S.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,ie,Xe,rt,bt.width,bt.height,je,bt.data):L.texSubImage2D(L.TEXTURE_2D,ie,Xe,rt,ue,ve,je,Ie,bt);L.pixelStorei(L.UNPACK_ROW_LENGTH,nt),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,bn),L.pixelStorei(L.UNPACK_SKIP_PIXELS,bs),L.pixelStorei(L.UNPACK_SKIP_ROWS,en),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Tr),ie===0&&O.generateMipmaps&&L.generateMipmap(Lt),Me.unbindTexture()},this.copyTextureToTexture3D=function(S,O,z=null,H=null,F=0){return nr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(S,O,z,H,F)},this.initRenderTarget=function(S){Pe.get(S).__webglFramebuffer===void 0&&ze.setupRenderTarget(S)},this.initTexture=function(S){S.isCubeTexture?ze.setTextureCube(S,0):S.isData3DTexture?ze.setTexture3D(S,0):S.isDataArrayTexture||S.isCompressedArrayTexture?ze.setTexture2DArray(S,0):ze.setTexture2D(S,0),Me.unbindTexture()},this.resetState=function(){C=0,T=0,D=null,Me.reset(),Ne.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Ke._getDrawingBufferColorSpace(e),t.unpackColorSpace=Ke._getUnpackColorSpace()}}class lA{constructor(e,t){E(this,"meshes",[]);this.n=t;let n;for(n in e){const s=new Zt(e[n],new dt({color:16777215}),t);this.meshes.push(s)}}setColorsForInstance(e,t){this.partNames.forEach((n,s)=>{this.meshes[s].setColorAt(e,t[n])})}setMatrixAt(e,t){for(const n of this.meshes)n.setMatrixAt(e,t)}queueUpdate(){for(const e of this.meshes)e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0),e.frustumCulled=!1}get count(){return this.meshes[0].count}set count(e){for(const t of this.meshes)t.count=e}}const vs=["top","sides"];class ix extends lA{constructor(){super(...arguments);E(this,"partNames",vs)}}function cA(i){const{n:e,radius:t,angle:n}=i;return{top:new oc(t,e).rotateX(-Math.PI/2).rotateY(n-Math.PI/2).translate(0,.5,0),sides:new Io(t,t,1,e,1,!0).rotateY(n)}}const ro=class ro{constructor(e,t,n){this.index=e,this.group=t,this.subgroup=n}get posArrays(){const[e,t]=this.group.subgroupsByFlatIndex[this.index];if(!(e.mesh instanceof ix))throw new Error(`invalid subgroup. mesh has type ${e.mesh.constructor.name}`);return e.mesh.meshes.map(n=>n.instanceMatrix.array)}get offset(){const[e,t]=this.group.subgroupsByFlatIndex[this.index];if(e!==this.subgroup)throw new Error("subgroup changed");return t*16+12}get y(){return this.posArrays[0][this.offset+1]}get position(){const e=this.posArrays[0];let{offset:t}=this;return ro.positionDummy.set(e[t++],e[t++],e[t++]),ro.positionDummy}set position(e){for(const t of this.posArrays){let{offset:n}=this;t[n++]=e.x,t[n++]=e.y,t[n++]=e.z}}};E(ro,"positionDummy",new A);let td=ro;const hA=new se(11193599),Jc=new se,uA=dA();function dA(){return vs.reduce((i,e)=>(i[e]=new se,i),{})}class fA{constructor(e){this.css=e}getBackgroundColor(){return Jc.copy(hA),$m(Jc,this.css.background),Jc}getTileColors(e){const t=uA;for(const n of vs)t[n].copy(e.generatedTile.color);for(const[n,s]of Rd(this.css)){const r=gA(n),{key:o}=r;if(o!=="background"){let l=!0;"atCondition"in r&&(l=rx(r.atCondition,e)),l&&$m(t[o],s,e)}}return t}}const pA=["value","red","green","blue","hue","saturation","lightness"];function mA(i){return pA.includes(i)}function $m(i,e,t){if(e)for(const[n,s]of Object.entries(e)){const{key:r,atCondition:o}=_A(n);rx(o,t)&&xA[r](i,s)}}function gA(i){const[e,t]=i.split("@"),n=sx(t);if(e==="background"){if(n)throw new Error("@ condition not allowed for background");return{key:e}}if(e==="top"||e==="sides")return n?{key:e,atCondition:n}:{key:e};throw new Error(`unrecognized selector ${i}`)}function _A(i){const[e,t]=i.split("@");if(!mA(e))throw new Error(`Unrecognized CSS key: ${e}`);const n=sx(t);return n?{key:e,atCondition:n}:{key:e}}function sx(i){if(i==="land"||i==="sea")return i;if(typeof i=="string")throw new Error(`unreconized @ condition "${i}"`)}function rx(i,e){return!i||!e?!0:e[i]??!1}const xA={red:eh("r"),green:eh("g"),blue:eh("b"),hue:Qc("h"),saturation:Qc("s"),lightness:Qc("l"),value:(i,e)=>{const t=$d(e);typeof t=="number"&&i.addScalar(t);const n=Yd(e);typeof n=="number"&&i.multiplyScalar(n),typeof e=="number"&&i.setRGB(e,e,e),i.set(e)}},Dt={h:0,s:0,l:0};function Qc(i){return(e,t)=>{e.getHSL(Dt);const n=$d(t);if(typeof n=="number")return i==="h"?Dt[i]=(Dt[i]+n+1)%1:Dt[i]=Dt[i]+n,e.setHSL(Dt.h,Dt.s,Dt.l);const s=Yd(t);if(typeof s=="number")return Dt[i]=(Dt[i]*s+1)%1,e.setHSL(Dt.h,Dt.s,Dt.l);if(typeof t=="number")return Dt[i]=t,e.setHSL(Dt.h,Dt.s,Dt.l);throw new Error("channel value must be offset, value, or percentage")}}function eh(i){return(e,t)=>{const n=$d(t);if(typeof n=="number")return e[i]+=n,e;const s=Yd(t);if(typeof s=="number")return e[i]*=s,e;if(typeof t=="number")return e[i]=t,e;throw new Error("channel value must be offset, value, or percentage")}}function $d(i){return typeof i=="string"&&(i.startsWith("-")||i.startsWith("+"))?parseFloat(i):typeof i=="number"&&i<0?i:null}function Yd(i){return typeof i=="string"&&i.endsWith("%")?parseFloat(i.slice(0,-1))/100:null}function yA(){const i=vA();return{background:{hue:i},top:{hue:i},sides:{hue:i,lightness:"50%"}}}function vA(){const i=.3+Math.random()*.3;return Math.random()>.5?`-${i.toFixed(3)}`:`+${i.toFixed(3)}`}const hs={default:{},"black-and-white":{background:{value:"#fff"},top:{value:"#fff"},sides:{value:"#000"},"top@land":{saturation:0}},tron:{background:{value:"#000"},"top@land":{saturation:0},"sides@land":{saturation:0,lightness:"-0.2"},"top@sea":{value:"#000"},"sides@sea":{value:"#6ee2ff"}},pastel:{background:{value:"#ddd"},"top@land":{saturation:.2,lightness:"+.2"},"sides@land":{saturation:.2,lightness:"+.1"},"top@sea":{saturation:.5,lightness:.6},"sides@sea":{saturation:.5,lightness:.5}},"???":yA(),custom:{}};function da(i){return new fA(hs[i])}const ox={label:"Graphics",children:{pixelScale:{value:4*(typeof window<"u"?window.devicePixelRatio:1),min:2,max:16,step:1},visibleRadius:{value:15,min:10,max:60,step:1},extendBottom:{value:-132,min:-256,max:256,step:1},style:{value:"default",options:Object.keys(hs)},copyStyle:{label:"Copy Style",action:i=>navigator.clipboard.writeText(JSON.stringify(i.style.css,null,2)),hasNoEffect:!0},pasteStyle:{label:"Paste Style",action:async()=>{const i=await navigator.clipboard.readText();hs.custom=JSON.parse(i),ox.children.style.value="custom"}}}},Ff=class Ff extends tt{constructor(){super(...arguments);E(this,"tree",ox)}};tt.register("gfx",()=>new Ff);let Ym=Ff;const Jt=tt.create("gfx"),bA={label:"Michael2-3B Terrain Config",children:{seedScaleOffset:{children:{xzLogScale:{value:-.6,min:-1,max:1,step:.01,resetOnChange:"full"},yScale:{value:1,min:.1,max:10,step:.01,resetOnChange:"full"},seed:{value:0,min:0,max:1e4,step:1,resetOnChange:"full"},offsetX:{value:0,min:-1e3,max:1e3,step:1,resetOnChange:"full"},offsetZ:{value:0,min:-1e3,max:1e3,step:1,resetOnChange:"full"}}},noiseMapValues:{children:{persistence:{value:.5,min:0,max:1,step:.01,resetOnChange:"full"},amplitude:{value:1,min:0,max:10,step:.1,resetOnChange:"full"},octaves:{value:5,min:1,max:8,step:1,resetOnChange:"full"},wavelength:{value:133,min:1,max:256,step:1,resetOnChange:"full"}}},terrainCustomization:{children:{exponent:{value:5,min:1,max:10,step:.05,resetOnChange:"full"},peaks:{value:.2,min:0,max:.25,step:.01,resetOnChange:"full"},waterLevel:{value:132,min:0,max:255,step:1,resetOnChange:"full"},beachSize:{value:12,min:0,max:255,step:1,resetOnChange:"full"}}},lighting:{children:{worldLight:{value:160,min:0,max:255,step:1},lightPosition:{value:225,min:0,max:360,step:1},lightHeight:{value:60,min:-90,max:90,step:1}}}}},Nf=class Nf extends tt{constructor(){super(...arguments);E(this,"tree",bA)}};tt.register("michael",()=>new Nf);let qm=Nf;const fo=tt.create("michael"),MA=5e-4,wA=.01,SA=.8,EA=0,AA=.002,TA=5e-4,CA=5e-4,RA=3e-4,PA=1e-4,IA=1e-4,LA=10,DA=2e-4,UA=4e-4,nd={tooltip:"settings for spheres and waves",children:{GRAVITY:{value:MA,min:1e-4,max:.005,step:1e-4},AIR_RESISTANCE:{value:wA,min:0,max:1,step:.001,tooltip:"fraction of sphere speed lost per step"},RESTITUTION:{value:SA,min:0,max:1,step:.01,tooltip:"fraction of sphere speed maintained in solid terrain bounce"},SPHERE_COHESION:{value:EA,isHidden:!0,min:0,max:.01,step:1e-4},SPHERE_STIFFNESS:{value:AA,isHidden:!0,min:0,max:.01,step:1e-4},SPHERE_DAMPING:{value:TA,isHidden:!0,min:0,max:.01,step:1e-5},WATER_FRICTION:{value:CA,min:0,max:1,step:1e-5,tooltip:"fraction of tile speed lost per step"},WATER_SPRING:{value:RA,min:0,max:.01,step:1e-5,tooltip:"springs pushing water tile towards neighboring tiles' heights"},WATER_CENTERING:{value:PA,min:0,max:.01,step:1e-5,tooltip:"spring pushing water tile towards sea level"},WATER_DAMPING:{value:IA,min:0,max:.01,step:1e-5,tooltip:"damping for water tile springs"},WAVE_AMPLITUDE:{value:LA,min:0,max:50,step:.1,tooltip:"multiplier for water tile height changes"},BUOYANT_FORCE:{value:DA,min:0,max:.001,step:1e-5,tooltip:"force of water tile pushing up on sphere"},PRESSURE_FORCE:{value:UA,min:0,max:.001,step:1e-5,tooltip:"force of sphere pushing down on water tile"}}};for(const i in nd.children)nd.children[i].resetOnChange="physics";const kf=class kf extends tt{constructor(){super(...arguments);E(this,"tree",nd)}};tt.register("physics",()=>new kf);let jm=kf;const us=tt.create("physics"),fa=new A;class Dl{constructor(e,t){E(this,"wmAngle",0);E(this,"wmSpeed",3e-4);E(this,"wmRadius",7);E(this,"wmTarget",new A);E(this,"wmForce",1e-5);E(this,"sphere");this.sphere=e,this.sphere.isGhost=!1,this.sphere.scalePressure=.2,this.updateWaveMaker({dt:0,seaBlock:t}),this.sphere.position=this.wmTarget}updateWaveMaker(e){const{dt:t,seaBlock:n}=e,{x:s,z:r}=n.terrain.centerXZ;this.wmAngle+=this.wmSpeed*t,this.wmTarget.set(s+this.wmRadius*Math.cos(this.wmAngle),this.sphere.position.y,r+this.wmRadius*Math.sin(this.wmAngle)),this.accelSphere(this.sphere,this.wmTarget,this.wmForce*t),n&&this.sphere.position.y<10&&(this.sphere.position=this.wmTarget)}accelSphere(e,t,n){fa.set(t.x-e.position.x,0,t.z-e.position.z).normalize(),fa.multiplyScalar(n),e.velocity.x+=fa.x,e.velocity.z+=fa.z}}function OA(i,e){const{grid:t}=j,n={current:j.getPiecesOnTile(e).map(({type:s})=>s),adjacentFloors:0};for(const{x:s,z:r}of t.tiling.getAdjacent(e.x,e.z)){const o=t.xzToIndex(e.x+s,e.z+r);o&&j.getPiecesOnTile(o).some(l=>l.type==="floor")&&n.adjacentFloors++}return FA[i](n)}const FA={floor:({current:i})=>i.length===0,button:({current:i})=>i.length===1&&i[0]==="floor",thruster:({current:i,adjacentFloors:e})=>i.length===0&&e===1},NA=new dt({color:"white",depthTest:!1,depthWrite:!1}),Li=new Zt(new Bt(1,1,1).scale(.1,.1,.1),NA,100);Li.renderOrder=999;Li.count=0;let ax=0;function Km(){Li.count=0,ax=j.currentPhase==="place-button"?.5:0;for(const i of j.hlTiles.clickable)kA(j.grid.tileIndices[i]);Li.instanceMatrix.needsUpdate=!0}function lx(){Li.count=0}const Zm=new We;function kA(i){const{x:e,z:t}=j.getPosOnTile(i);Zm.setPosition(e-.5,ax,t-.5);const n=Li.count++;Li.setMatrixAt(n,Zm)}class BA{constructor(){E(this,"clickable",new Set)}clear(){this.clickable.clear(),lx()}highlightThrusters(){this.clickable.clear();for(const e of j.thrusters){const t=j.raftPieces[e.pieceIndex];this.clickable.add(t.tile.i)}Km()}updateBuildableTiles(e){const{x:t,z:n}=j.centerTile,{grid:s}=j;this.clickable.clear();for(let r=-Za;r<=Za;r++)for(let o=-Za;o<=Za;o++){const l=s.xzToIndex(t+r,n+o);l&&OA(e,l)&&this.clickable.add(l.i)}Km()}}const cx=["floor","button","thruster"],hx=["cockpit",...cx],qd=["idle","edit-button","show-all-wires",...cx.map(i=>`place-${i}`)];function ux(i){const{raft:e,tile:t}=i;for(const{x:n,z:s}of e.grid.tiling.getAdjacent(t.x,t.z)){const r=e.grid.xzToIndex(t.x+n,t.z+s);if(!r)continue;if(e.getPiecesOnTile(r).some(({type:l})=>l==="floor")){if(n===-1)return"up";if(n===1)return"down";if(s===-1)return"right";if(s===1)return"left"}}return"down"}function zA(i,e){let t=0,n=0,s=0;for(const r of i)switch(r.direction){case"down":r.isFiring&&(t+=1,s+=r.dz);break;case"up":r.isFiring&&(t-=1,s-=r.dz);break;case"right":r.isFiring&&(n-=1,s+=r.dx);break;case"left":r.isFiring&&(n+=1,s-=r.dx);break}i.length!==0&&(e.applyForwardThrust(t*1e-4),e.applyRightThrust(n*1e-4),e.applyTorque(s*1e-5))}const Jm={type:"change"},jd={type:"start"},dx={type:"end"},pa=new Po,Qm=new ri,HA=Math.cos(70*L1.DEG2RAD),Ct=new A,Yt=2*Math.PI,ct={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},th=1e-6;class VA extends Eb{constructor(e,t=null){super(e,t),this.state=ct.NONE,this.target=new A,this.cursor=new A,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:er.ROTATE,MIDDLE:er.DOLLY,RIGHT:er.PAN},this.touches={ONE:$s.ROTATE,TWO:$s.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new A,this._lastQuaternion=new Pi,this._lastTargetPosition=new A,this._quat=new Pi().setFromUnitVectors(e.up,new A(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Ll,this._sphericalDelta=new Ll,this._scale=1,this._panOffset=new A,this._rotateStart=new xe,this._rotateEnd=new xe,this._rotateDelta=new xe,this._panStart=new xe,this._panEnd=new xe,this._panDelta=new xe,this._dollyStart=new xe,this._dollyEnd=new xe,this._dollyDelta=new xe,this._dollyDirection=new A,this._mouse=new xe,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=WA.bind(this),this._onPointerDown=GA.bind(this),this._onPointerUp=XA.bind(this),this._onContextMenu=JA.bind(this),this._onMouseWheel=qA.bind(this),this._onKeyDown=jA.bind(this),this._onTouchStart=KA.bind(this),this._onTouchMove=ZA.bind(this),this._onMouseDown=$A.bind(this),this._onMouseMove=YA.bind(this),this._interceptControlDown=QA.bind(this),this._interceptControlUp=eT.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Jm),this.update(),this.state=ct.NONE}update(e=null){const t=this.object.position;Ct.copy(t).sub(this.target),Ct.applyQuaternion(this._quat),this._spherical.setFromVector3(Ct),this.autoRotate&&this.state===ct.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(n)&&isFinite(s)&&(n<-Math.PI?n+=Yt:n>Math.PI&&(n-=Yt),s<-Math.PI?s+=Yt:s>Math.PI&&(s-=Yt),n<=s?this._spherical.theta=Math.max(n,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+s)/2?Math.max(n,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(Ct.setFromSpherical(this._spherical),Ct.applyQuaternion(this._quatInverse),t.copy(this.target).add(Ct),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const l=Ct.length();o=this._clampDistance(l*this._scale);const c=l-o;this.object.position.addScaledVector(this._dollyDirection,c),this.object.updateMatrixWorld(),r=!!c}else if(this.object.isOrthographicCamera){const l=new A(this._mouse.x,this._mouse.y,0);l.unproject(this.object);const c=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=c!==this.object.zoom;const u=new A(this._mouse.x,this._mouse.y,0);u.unproject(this.object),this.object.position.sub(u).add(l),this.object.updateMatrixWorld(),o=Ct.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(pa.origin.copy(this.object.position),pa.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(pa.direction))<HA?this.object.lookAt(this.target):(Qm.setFromNormalAndCoplanarPoint(this.object.up,this.target),pa.intersectPlane(Qm,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>th||8*(1-this._lastQuaternion.dot(this.object.quaternion))>th||this._lastTargetPosition.distanceToSquared(this.target)>th?(this.dispatchEvent(Jm),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?Yt/60*this.autoRotateSpeed*e:Yt/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){Ct.setFromMatrixColumn(t,0),Ct.multiplyScalar(-e),this._panOffset.add(Ct)}_panUp(e,t){this.screenSpacePanning===!0?Ct.setFromMatrixColumn(t,1):(Ct.setFromMatrixColumn(t,0),Ct.crossVectors(this.object.up,Ct)),Ct.multiplyScalar(e),this._panOffset.add(Ct)}_pan(e,t){const n=this.domElement;if(this.object.isPerspectiveCamera){const s=this.object.position;Ct.copy(s).sub(this.target);let r=Ct.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/n.clientHeight,this.object.matrix),this._panUp(2*t*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),s=e-n.left,r=t-n.top,o=n.width,l=n.height;this._mouse.x=s/o*2-1,this._mouse.y=-(r/l)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Yt*this._rotateDelta.x/t.clientHeight),this._rotateUp(Yt*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(Yt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-Yt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(Yt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-Yt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._rotateStart.set(n,s)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panStart.set(n,s)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(n*n+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const n=this._getSecondPointerPosition(e),s=.5*(e.pageX+n.x),r=.5*(e.pageY+n.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Yt*this._rotateDelta.x/t.clientHeight),this._rotateUp(Yt*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panEnd.set(n,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(n*n+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,l=(e.pageY+t.y)*.5;this._updateZoomParameters(o,l)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new xe,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function GA(i){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(i.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(i)&&(this._addPointer(i),i.pointerType==="touch"?this._onTouchStart(i):this._onMouseDown(i)))}function WA(i){this.enabled!==!1&&(i.pointerType==="touch"?this._onTouchMove(i):this._onMouseMove(i))}function XA(i){switch(this._removePointer(i),this._pointers.length){case 0:this.domElement.releasePointerCapture(i.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(dx),this.state=ct.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function $A(i){let e;switch(i.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case er.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(i),this.state=ct.DOLLY;break;case er.ROTATE:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=ct.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=ct.ROTATE}break;case er.PAN:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=ct.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=ct.PAN}break;default:this.state=ct.NONE}this.state!==ct.NONE&&this.dispatchEvent(jd)}function YA(i){switch(this.state){case ct.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(i);break;case ct.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(i);break;case ct.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(i);break}}function qA(i){this.enabled===!1||this.enableZoom===!1||this.state!==ct.NONE||(i.preventDefault(),this.dispatchEvent(jd),this._handleMouseWheel(this._customWheelEvent(i)),this.dispatchEvent(dx))}function jA(i){this.enabled!==!1&&this._handleKeyDown(i)}function KA(i){switch(this._trackPointer(i),this._pointers.length){case 1:switch(this.touches.ONE){case $s.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(i),this.state=ct.TOUCH_ROTATE;break;case $s.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(i),this.state=ct.TOUCH_PAN;break;default:this.state=ct.NONE}break;case 2:switch(this.touches.TWO){case $s.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(i),this.state=ct.TOUCH_DOLLY_PAN;break;case $s.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(i),this.state=ct.TOUCH_DOLLY_ROTATE;break;default:this.state=ct.NONE}break;default:this.state=ct.NONE}this.state!==ct.NONE&&this.dispatchEvent(jd)}function ZA(i){switch(this._trackPointer(i),this.state){case ct.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(i),this.update();break;case ct.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(i),this.update();break;case ct.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(i),this.update();break;case ct.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(i),this.update();break;default:this.state=ct.NONE}}function JA(i){this.enabled!==!1&&i.preventDefault()}function QA(i){i.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function eT(i){i.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function fx(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},o={},l=i[0].morphTargetsRelative,c=new Ut;let u=0;for(let d=0;d<i.length;++d){const a=i[d];let h=0;if(t!==(a.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const f in a.attributes){if(!n.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(a.attributes[f]),h++}if(h!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(l!==a.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const f in a.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;o[f]===void 0&&(o[f]=[]),o[f].push(a.morphAttributes[f])}if(e){let f;if(t)f=a.index.count;else if(a.attributes.position!==void 0)f=a.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;c.addGroup(u,f,d),u+=f}}if(t){let d=0;const a=[];for(let h=0;h<i.length;++h){const f=i[h].index;for(let g=0;g<f.count;++g)a.push(f.getX(g)+d);d+=i[h].attributes.position.count}c.setIndex(a)}for(const d in r){const a=eg(r[d]);if(!a)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;c.setAttribute(d,a)}for(const d in o){const a=o[d][0].length;if(a===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[d]=[];for(let h=0;h<a;++h){const f=[];for(let _=0;_<o[d].length;++_)f.push(o[d][_][h]);const g=eg(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;c.morphAttributes[d].push(g)}}return c}function eg(i){let e,t,n,s=-1,r=0;for(let u=0;u<i.length;++u){const d=i[u];if(e===void 0&&(e=d.array.constructor),e!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=d.itemSize),t!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=d.gpuType),s!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=d.count*t}const o=new e(r),l=new cn(o,t,n);let c=0;for(let u=0;u<i.length;++u){const d=i[u];if(d.isInterleavedBufferAttribute){const a=c/t;for(let h=0,f=d.count;h<f;h++)for(let g=0;g<t;g++){const _=d.getComponent(h,g);l.setComponent(h+a,g,_)}}else o.set(d.array,c);c+=d.count*t}return s!==void 0&&(l.gpuType=s),l}const tT=/^[og]\s*(.+)?/,nT=/^mtllib /,iT=/^usemtl /,sT=/^usemap /,tg=/\s+/,ng=new A,nh=new A,ig=new A,sg=new A,pn=new A,ma=new se;function rT(){const i={objects:[],object:{},vertices:[],normals:[],colors:[],uvs:[],materials:{},materialLibraries:[],startObject:function(e,t){if(this.object&&this.object.fromDeclaration===!1){this.object.name=e,this.object.fromDeclaration=t!==!1;return}const n=this.object&&typeof this.object.currentMaterial=="function"?this.object.currentMaterial():void 0;if(this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0),this.object={name:e||"",fromDeclaration:t!==!1,geometry:{vertices:[],normals:[],colors:[],uvs:[],hasUVIndices:!1},materials:[],smooth:!0,startMaterial:function(s,r){const o=this._finalize(!1);o&&(o.inherited||o.groupCount<=0)&&this.materials.splice(o.index,1);const l={index:this.materials.length,name:s||"",mtllib:Array.isArray(r)&&r.length>0?r[r.length-1]:"",smooth:o!==void 0?o.smooth:this.smooth,groupStart:o!==void 0?o.groupEnd:0,groupEnd:-1,groupCount:-1,inherited:!1,clone:function(c){const u={index:typeof c=="number"?c:this.index,name:this.name,mtllib:this.mtllib,smooth:this.smooth,groupStart:0,groupEnd:-1,groupCount:-1,inherited:!1};return u.clone=this.clone.bind(u),u}};return this.materials.push(l),l},currentMaterial:function(){if(this.materials.length>0)return this.materials[this.materials.length-1]},_finalize:function(s){const r=this.currentMaterial();if(r&&r.groupEnd===-1&&(r.groupEnd=this.geometry.vertices.length/3,r.groupCount=r.groupEnd-r.groupStart,r.inherited=!1),s&&this.materials.length>1)for(let o=this.materials.length-1;o>=0;o--)this.materials[o].groupCount<=0&&this.materials.splice(o,1);return s&&this.materials.length===0&&this.materials.push({name:"",smooth:this.smooth}),r}},n&&n.name&&typeof n.clone=="function"){const s=n.clone(0);s.inherited=!0,this.object.materials.push(s)}this.objects.push(this.object)},finalize:function(){this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0)},parseVertexIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseNormalIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseUVIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/2)*2},addVertex:function(e,t,n){const s=this.vertices,r=this.object.geometry.vertices;r.push(s[e+0],s[e+1],s[e+2]),r.push(s[t+0],s[t+1],s[t+2]),r.push(s[n+0],s[n+1],s[n+2])},addVertexPoint:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addVertexLine:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addNormal:function(e,t,n){const s=this.normals,r=this.object.geometry.normals;r.push(s[e+0],s[e+1],s[e+2]),r.push(s[t+0],s[t+1],s[t+2]),r.push(s[n+0],s[n+1],s[n+2])},addFaceNormal:function(e,t,n){const s=this.vertices,r=this.object.geometry.normals;ng.fromArray(s,e),nh.fromArray(s,t),ig.fromArray(s,n),pn.subVectors(ig,nh),sg.subVectors(ng,nh),pn.cross(sg),pn.normalize(),r.push(pn.x,pn.y,pn.z),r.push(pn.x,pn.y,pn.z),r.push(pn.x,pn.y,pn.z)},addColor:function(e,t,n){const s=this.colors,r=this.object.geometry.colors;s[e]!==void 0&&r.push(s[e+0],s[e+1],s[e+2]),s[t]!==void 0&&r.push(s[t+0],s[t+1],s[t+2]),s[n]!==void 0&&r.push(s[n+0],s[n+1],s[n+2])},addUV:function(e,t,n){const s=this.uvs,r=this.object.geometry.uvs;r.push(s[e+0],s[e+1]),r.push(s[t+0],s[t+1]),r.push(s[n+0],s[n+1])},addDefaultUV:function(){const e=this.object.geometry.uvs;e.push(0,0),e.push(0,0),e.push(0,0)},addUVLine:function(e){const t=this.uvs;this.object.geometry.uvs.push(t[e+0],t[e+1])},addFace:function(e,t,n,s,r,o,l,c,u){const d=this.vertices.length;let a=this.parseVertexIndex(e,d),h=this.parseVertexIndex(t,d),f=this.parseVertexIndex(n,d);if(this.addVertex(a,h,f),this.addColor(a,h,f),l!==void 0&&l!==""){const g=this.normals.length;a=this.parseNormalIndex(l,g),h=this.parseNormalIndex(c,g),f=this.parseNormalIndex(u,g),this.addNormal(a,h,f)}else this.addFaceNormal(a,h,f);if(s!==void 0&&s!==""){const g=this.uvs.length;a=this.parseUVIndex(s,g),h=this.parseUVIndex(r,g),f=this.parseUVIndex(o,g),this.addUV(a,h,f),this.object.geometry.hasUVIndices=!0}else this.addDefaultUV()},addPointGeometry:function(e){this.object.geometry.type="Points";const t=this.vertices.length;for(let n=0,s=e.length;n<s;n++){const r=this.parseVertexIndex(e[n],t);this.addVertexPoint(r),this.addColor(r)}},addLineGeometry:function(e,t){this.object.geometry.type="Line";const n=this.vertices.length,s=this.uvs.length;for(let r=0,o=e.length;r<o;r++)this.addVertexLine(this.parseVertexIndex(e[r],n));for(let r=0,o=t.length;r<o;r++)this.addUVLine(this.parseUVIndex(t[r],s))}};return i.startObject("",!1),i}class oT extends Wd{constructor(e){super(e),this.materials=null}load(e,t,n,s){const r=this,o=new _b(this.manager);o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(l){try{t(r.parse(l))}catch(c){s?s(c):console.error(c),r.manager.itemError(e)}},n,s)}setMaterials(e){return this.materials=e,this}parse(e){const t=new rT;e.indexOf(`\r
`)!==-1&&(e=e.replace(/\r\n/g,`
`)),e.indexOf(`\\
`)!==-1&&(e=e.replace(/\\\n/g,""));const n=e.split(`
`);let s=[];for(let l=0,c=n.length;l<c;l++){const u=n[l].trimStart();if(u.length===0)continue;const d=u.charAt(0);if(d!=="#")if(d==="v"){const a=u.split(tg);switch(a[0]){case"v":t.vertices.push(parseFloat(a[1]),parseFloat(a[2]),parseFloat(a[3])),a.length>=7?(ma.setRGB(parseFloat(a[4]),parseFloat(a[5]),parseFloat(a[6]),on),t.colors.push(ma.r,ma.g,ma.b)):t.colors.push(void 0,void 0,void 0);break;case"vn":t.normals.push(parseFloat(a[1]),parseFloat(a[2]),parseFloat(a[3]));break;case"vt":t.uvs.push(parseFloat(a[1]),parseFloat(a[2]));break}}else if(d==="f"){const h=u.slice(1).trim().split(tg),f=[];for(let _=0,m=h.length;_<m;_++){const p=h[_];if(p.length>0){const x=p.split("/");f.push(x)}}const g=f[0];for(let _=1,m=f.length-1;_<m;_++){const p=f[_],x=f[_+1];t.addFace(g[0],p[0],x[0],g[1],p[1],x[1],g[2],p[2],x[2])}}else if(d==="l"){const a=u.substring(1).trim().split(" ");let h=[];const f=[];if(u.indexOf("/")===-1)h=a;else for(let g=0,_=a.length;g<_;g++){const m=a[g].split("/");m[0]!==""&&h.push(m[0]),m[1]!==""&&f.push(m[1])}t.addLineGeometry(h,f)}else if(d==="p"){const h=u.slice(1).trim().split(" ");t.addPointGeometry(h)}else if((s=tT.exec(u))!==null){const a=(" "+s[0].slice(1).trim()).slice(1);t.startObject(a)}else if(iT.test(u))t.object.startMaterial(u.substring(7).trim(),t.materialLibraries);else if(nT.test(u))t.materialLibraries.push(u.substring(7).trim());else if(sT.test(u))console.warn('THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.');else if(d==="s"){if(s=u.split(" "),s.length>1){const h=s[1].trim().toLowerCase();t.object.smooth=h!=="0"&&h!=="off"}else t.object.smooth=!0;const a=t.object.currentMaterial();a&&(a.smooth=t.object.smooth)}else{if(u==="\0")continue;console.warn('THREE.OBJLoader: Unexpected line: "'+u+'"')}}t.finalize();const r=new Hn;if(r.materialLibraries=[].concat(t.materialLibraries),!(t.objects.length===1&&t.objects[0].geometry.vertices.length===0)===!0)for(let l=0,c=t.objects.length;l<c;l++){const u=t.objects[l],d=u.geometry,a=u.materials,h=d.type==="Line",f=d.type==="Points";let g=!1;if(d.vertices.length===0)continue;const _=new Ut;_.setAttribute("position",new ot(d.vertices,3)),d.normals.length>0&&_.setAttribute("normal",new ot(d.normals,3)),d.colors.length>0&&(g=!0,_.setAttribute("color",new ot(d.colors,3))),d.hasUVIndices===!0&&_.setAttribute("uv",new ot(d.uvs,2));const m=[];for(let x=0,b=a.length;x<b;x++){const v=a[x],P=v.name+"_"+v.smooth+"_"+g;let C=t.materials[P];if(this.materials!==null){if(C=this.materials.create(v.name),h&&C&&!(C instanceof Kr)){const T=new Kr;Xn.prototype.copy.call(T,C),T.color.copy(C.color),C=T}else if(f&&C&&!(C instanceof $r)){const T=new $r({size:10,sizeAttenuation:!1});Xn.prototype.copy.call(T,C),T.color.copy(C.color),T.map=C.map,C=T}}C===void 0&&(h?C=new Kr:f?C=new $r({size:1,sizeAttenuation:!1}):C=new ub,C.name=v.name,C.flatShading=!v.smooth,C.vertexColors=g,t.materials[P]=C),m.push(C)}let p;if(m.length>1){for(let x=0,b=a.length;x<b;x++){const v=a[x];_.addGroup(v.groupStart,v.groupCount,x)}h?p=new dm(_,m):f?p=new Gc(_,m):p=new at(_,m)}else h?p=new dm(_,m[0]):f?p=new Gc(_,m[0]):p=new at(_,m[0]);p.name=u.name,r.add(p)}else if(t.vertices.length>0){const l=new $r({size:1,sizeAttenuation:!1}),c=new Ut;c.setAttribute("position",new ot(t.vertices,3)),t.colors.length>0&&t.colors[0]!==void 0&&(c.setAttribute("color",new ot(t.colors,3)),l.vertexColors=!0);const u=new Gc(c,l);r.add(u)}return r}}const aT=new Un(new A(-.5,-.5,-.5),new A(.5,.5,.5));function lc(i){const{box:e=aT,thickness:t=.1}=i??{},n=lT(e),s=cT.map(([o,l])=>hT(n[o],n[l],t)),r=fx(s,!1);return r.deleteAttribute("normal"),r.deleteAttribute("uv"),r}function lT(i){const e=i.min,t=i.max;return[[e.x,e.y,e.z],[t.x,e.y,e.z],[t.x,t.y,e.z],[e.x,t.y,e.z],[e.x,e.y,t.z],[t.x,e.y,t.z],[t.x,t.y,t.z],[e.x,t.y,t.z]]}const cT=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]];function hT(i,e,t){const n=Math.abs(e[0]-i[0]),s=Math.abs(e[1]-i[1]),r=Math.abs(e[2]-i[2]),o=Math.max(n,s,r)+t,l=new Bt(n>0?o:t,s>0?o:t,r>0?o:t),c=(i[0]+e[0])/2,u=(i[1]+e[1])/2,d=(i[2]+e[2])/2;return l.translate(c,u,d),l}function uT(i){const t=new Bt(1,1,1),n=1,s=lc({box:new Un(new A(-n/2,-n/2,-n/2),new A(n/2,n/2,n/2)),thickness:.02}),r=new gr({color:"#b47a3d"}),o=new dt({color:0}),l=t.clone(),c=l.attributes.position.count,u=Array.from(l.attributes.position.array),d=s.attributes.position.array;for(let m=0;m<d.length;++m)u.push(d[m]);const a=Array.from(l.attributes.normal.array);if(s.attributes.normal){const m=s.attributes.normal.array;for(let p=0;p<m.length;++p)a.push(m[p])}else for(let m=0;m<d.length;m+=3)a.push(0,0,0);const h=Array.from(l.index.array),f=c;if(s.index){const m=s.index.array;for(let p=0;p<m.length;++p)h.push(m[p]+f)}else for(let m=0;m<d.length/3;++m)h.push(f+m);l.setAttribute("position",new ot(u,3)),l.setAttribute("normal",new ot(a,3)),l.setIndex(h),l.clearGroups(),l.addGroup(0,t.index.count,0);const g=t.index.count;let _=0;return s.index?_=s.index.array.length:_=d.length/3,l.addGroup(g,_,1),new Zt(l,[r,o],i)}const rg=new dt({color:0,side:Wt,depthTest:!1});function Kd(i,e){const{scale:t=1.05,dilate:n=-.1}=e||{};return i.traverse(s=>{if(s instanceof at){if(s.geometry=s.geometry.clone(),s.renderOrder=99,t<1)throw new Error("scale should not be less than one");if(t>1){const o=s.clone();o.isOutline=!0,o.material=rg,o.scale.multiplyScalar(t),i.add(o),o.renderOrder=98}const r=s.clone();r.isOutline=!0,r.material=rg,n>0?r.geometry=id(r.geometry.clone(),n):n<0&&(s.geometry=id(s.geometry.clone(),n)),i.add(r),r.renderOrder=98}}),i}function id(i,e=.1){const t=i.index?i.toNonIndexed():i.clone();t.attributes.normal||t.computeVertexNormals();const n=t.attributes.position,s=t.attributes.normal,r=n.array.slice();for(let o=0;o<n.count;o++)r[o*3+0]+=s.getX(o)*e,r[o*3+1]+=s.getY(o)*e,r[o*3+2]+=s.getZ(o)*e;return t.setAttribute("position",new cn(new Float32Array(r),3)),t.attributes.position.needsUpdate=!0,t.computeVertexNormals(),t}const dT=["raft/thruster.obj","kenney/chest.obj","chess/bishop.obj","chess/king.obj","chess/knight.obj","chess/pawn.obj","chess/queen.obj","chess/rook.obj"],fT=new oT,px=new Map;function Uo(i){return px.get(i)}async function pT(){await Promise.all(dT.map(async i=>{const e=`obj/${i}`,t=await fT.loadAsync(e);px.set(i,t)}))}function mT(i){const e=Uo("raft/thruster.obj").children[0].geometry;e.rotateY(Math.PI/2),e.rotateZ(-Math.PI/2);const t=.5;e.scale(t,t,t);const n=id(e.clone(),.05);if(!e.index){const _=e.attributes.position.count,m=[];for(let p=0;p<_;++p)m.push(p);e.setIndex(m)}const s=e.clone(),r=s.attributes.position.count,o=Array.from(s.attributes.position.array),l=n.attributes.position.array;for(let _=0;_<l.length;++_)o.push(l[_]);const c=Array.from(s.attributes.normal.array);if(n.attributes.normal){const _=n.attributes.normal.array;for(let m=0;m<_.length;++m)c.push(_[m])}else for(let _=0;_<l.length;_+=3)c.push(0,0,0);if(!s.index){const _=s.attributes.position.count,m=[];for(let p=0;p<_;++p)m.push(p);s.setIndex(m)}const u=s.index?Array.from(s.index.array):[],d=r;if(n.index){const _=n.index.array;for(let m=0;m<_.length;++m)u.push(_[m]+d)}else for(let _=0;_<l.length/3;++_)u.push(d+_);s.setAttribute("position",new ot(o,3)),s.setAttribute("normal",new ot(c,3)),s.setIndex(u),s.clearGroups(),s.addGroup(0,e.index.count,0);const a=e.index.count;let h=0;n.index?h=n.index.array.length:h=l.length/3,s.addGroup(a,h,1);const f=new dt({color:16777215,side:kn}),g=new dt({color:0,side:1});return new Zt(s,[f,g],i)}const gT=(i,e,t)=>new Bt(i,e,t),_T=i=>new gr(i);function xT(i){return new Zt(gT(.9,1,.9).translate(0,.05,0),_T({color:16777215}),i)}const ga=50,yT=(i,e,t)=>new Bt(i,e,t),vT=i=>new gr(i),bT={cockpit:()=>new Zt(yT(.1,.1,.1),vT({color:16777215}),ga),button:()=>xT(ga),floor:()=>uT(ga),thruster:()=>mT(ga)},Er={},MT=hx.map(i=>({pieceName:i,meshLoader:async()=>{const e=bT[i]();return e.scale.set(1,1,1),Er[i]=e,e}}));let wT;function ST(i,e,t){const n=Er[e];if(!n)throw new Error(`missing piece mesh for ${e}`);const s=n,r=s.count;return s.count++,s.visible=!0,{raft:i,instancedMesh:s,index:r,tile:t,type:e}}function ET(i,e){"instancedMesh"in i?AT(i,e):i.mesh.position.copy(e)}function AT(i,e){const{instancedMesh:t,index:n}=i,{x:s,y:r,z:o}=e;let l=new We;i.type==="thruster"&&(l=mx(ux(i))),l.setPosition(s,r,o),t.setMatrixAt(n,l),t.instanceMatrix.needsUpdate=!0,t.frustumCulled=!1}function mx(i){const e=new We;switch(i){case"up":e.makeRotationZ(Math.PI/2);break;case"down":e.makeRotationZ(-Math.PI/2);break;case"right":e.makeRotationX(-Math.PI/2);break;case"left":e.makeRotationX(Math.PI/2);break;default:e.makeRotationX(Math.PI/2).multiply(new We().makeRotationY(Math.PI/2));break}return e}const Ul={x:.5,y:.5},ci={left:Ul,right:Ul},gx=.1,TT=Math.pow(gx,2),og=.2,ag=.05,ds={display:{type:"joy-region",border:"16x16-btn-square",shouldClearBehind:!0},layoutKey:"leftJoy",hotkeys:[]},Zd={display:{type:"button",icon:"icons/16x16-pan.png",border:"16x16-btn-shiny"},layoutKey:"leftJoySlider",slideIn:"leftJoy",slideRadius:12,hotkeys:[],clickAction:lg,dragAction:lg,unclickAction:()=>{ds.display.needsUpdate=!0,ds.display.forcedState=void 0,ci.left=Ul}},fs={display:{type:"joy-region",border:"16x16-btn-square",shouldClearBehind:!0},layoutKey:"rightJoy",hotkeys:[]},Jd={display:{type:"button",icon:"icons/16x16-rotate.png",border:"16x16-btn-shiny"},layoutKey:"rightJoySlider",slideIn:"rightJoy",slideRadius:12,hotkeys:[],clickAction:i=>cg(i),dragAction:i=>cg(i),unclickAction:()=>{fs.display.needsUpdate=!0,fs.display.forcedState=void 0,ci.right=Ul}};function lg(i){const{sliderState:e}=i;e&&(ci.left=e,ds.display.needsUpdate=!0,ds.display.forcedState="pressed")}function cg(i){const{sliderState:e}=i;e&&(ci.right=e,fs.display.needsUpdate=!0,fs.display.forcedState="pressed")}function _x(){const{x:i,y:e}=ci.left,t=i-.5,n=e-.5;return t*t+n*n<TT?null:{x:t,y:n}}function cc(i){const{seaBlock:e,dt:t}=i,n=e.orbitControls,{x:s,y:r}=ci.right;let o=s-.5;Math.abs(o)>ag&&(o=Math.sign(o)*(Math.abs(o)-ag),n._rotateLeft(.005*o*t));let l=r-.5;Math.abs(l)>og&&(l=Math.sign(l)*(Math.abs(l)-og),n._rotateUp(.005*l*t)),i.seaBlock.orbitControls.update()}const xx=2e-4,CT=10*xx;function RT(i){const e=i.sphereGroup.members.slice(2,6),t=i.orbitControls.target;return new IT(e,t)}const Nr=new A,ih=new A,PT=new A(0,1,0),_a=new A,hg=new A,ug=new A,xa=new A,ya=new A,va=new A,ba=new A,sh=new A,Ma=new A,dg=new We;class IT{constructor(e,t){E(this,"springs",[]);if(this.spheres=e,e.length!==4)throw new Error("raft rig should have exactly 4 spheres");const s=4/2,r=14,o=[{x:t.x-s,y:r,z:t.z-s},{x:t.x+s,y:r,z:t.z-s},{x:t.x+s,y:r,z:t.z+s},{x:t.x-s,y:r,z:t.z+s}];for(let l=0;l<4;++l)Nr.copy(o[l]),this.spheres[l].position=Nr,this.spheres[l].velocity.set(0,0,0),this.spheres[l].isGhost=!1,this.spheres[l].isFish=!1,this.spheres[l].scalePressure=.1;for(let l=0;l<4;++l)for(let c=l+1;c<4;++c){const u=this.spheres[l],d=this.spheres[c],a=Nr.copy(u.position).distanceTo(d.position);this.springs.push({i:l,j:c,restLength:a,k:xx,damping:CT})}}applyForwardThrust(e){ya.copy(this.spheres[2].position).sub(this.spheres[0].position).normalize().multiplyScalar(e);for(const t of this.spheres)t.velocity.add(ya)}applyRightThrust(e){va.copy(this.spheres[3].position).sub(this.spheres[1].position).normalize().multiplyScalar(e);for(const t of this.spheres)t.velocity.add(va)}getCameraTarget(e){const t=e??Nr;return t.copy(this.spheres[0].position).lerp(this.spheres[2].position,.5),ih.copy(this.spheres[0].velocity).lerp(this.spheres[2].velocity,.5),t.addScaledVector(ih,100),t}applyTorque(e){_a.set(0,0,0);for(const t of this.spheres)_a.add(t.position);_a.multiplyScalar(1/this.spheres.length);for(const t of this.spheres)hg.copy(t.position).sub(_a),ug.crossVectors(PT,hg).normalize(),t.velocity.add(ug.multiplyScalar(e))}update(e){for(const t of this.springs){const n=this.spheres[t.i],s=this.spheres[t.j],r=Nr.copy(n.position).sub(s.position),o=r.length();if(o<1e-6)continue;const l=r.multiplyScalar(1/o),c=-t.k*(o-t.restLength),u=ih.copy(n.velocity).sub(s.velocity),d=-t.damping*u.dot(l),a=l.multiplyScalar((c+d)*.5*e);n.velocity.add(a),s.velocity.sub(a)}}alignMesh(e,t){xa.set(0,-4,0);for(const n of this.spheres)xa.add(n.position);xa.multiplyScalar(1/this.spheres.length),ya.copy(this.spheres[2].position).sub(this.spheres[0].position),va.copy(this.spheres[3].position).sub(this.spheres[1].position),ba.copy(ya).normalize(),Ma.copy(va).normalize(),sh.crossVectors(Ma,ba).normalize(),Ma.crossVectors(ba,sh).normalize(),dg.makeBasis(ba,sh,Ma),e.position.copy(xa),e.quaternion.setFromRotationMatrix(dg)}}const _n={upBtn:!1,downBtn:!1,leftBtn:!1,rightBtn:!1};function wa(i,e,t){return{display:{type:"button",icon:`icons/16x16-arrow-${e}.png`},layoutKey:i,hotkeys:t,clickAction:n=>{_n[i]=!0},unclickAction:n=>{_n[i]=!1}}}const yx=[wa("upBtn","up",["KeyW","ArrowUp","DPadUp"]),wa("downBtn","down",["KeyS","ArrowDown","DPadDown"]),wa("leftBtn","left",["KeyA","ArrowLeft","DPadLeft"]),wa("rightBtn","right",["KeyD","ArrowRight","DPadRight"])],po=[];function Di(i){const e=Qd();po.push({image:i,y0:e,y1:e+i.height})}function Qd(){return po.length===0?0:po.at(-1).y1}function LT(i){const{ctx:e,yFraction:t,viewHeight:n}=i,s=Qd();if(s===0)return;const r=Math.round((s-n)*t),o=r+n,l=DT(r,o);for(const c of l)e.drawImage(c.image,0,c.y0-r)}function DT(i,e){if(po.length===0)return[];const t=[];for(const n of po)n.y0>e||n.y1<i||t.push(n);return t}const Gt=class Gt{static getTorsoWithTexturedFace(e){const t=new Hn;t.add(e);const n=.8,s=new Lo(n,n),r=Gt.getFaceMaterial({eyesOpen:!0,mouthOpen:!1,fill:!1}),o=new at(s,r);return o.position.z=.5+.05,t.add(o),t}static getFaceMaterial(e){const t=this._getGfx(e).texture;return new dt({map:t,transparent:!0})}static drawFace(e,t,n){const s=this._getGfx(n).buffer,[r,o,l,c]=t,u=l/Gt._bufferWidth,d=c/Gt._bufferHeight,a=Math.min(u,d);e.save(),e.translate(r,o),e.scale(a,a),e.drawImage(s,0,0),e.restore()}static _getGfx(e){const t=Gt._hash(e),n=Gt._graphics;return Object.hasOwn(n,t)||(n[t]=new Gt()._buildFaceGfx(e)),n[t]}static _hash(e){const t=["shocked","eyesOpen","mouthOpen","fill"];let n="base";for(const s of t)e[s]&&(n=`${n}-${s}`);return e.rotations&&(n=`${n}-rot=${e.rotations}`),n}_buildFaceGfx(e){const r=Gt._bufferWidth,o=Gt._bufferHeight,l=document.createElement("canvas");l.width=r,l.height=o,Di(l);const c=l.getContext("2d"),{rotations:u=0}=e;if(u){const[a,h]=[r/2,o/2],f=Math.PI/2*u;c.translate(a,h),c.rotate(f),c.translate(-a,-h)}if(c.lineCap="round",c.lineWidth=Gt._lineWidth,e.fill){c.fillStyle="#ddd";const a="#666";c.fillRect(0,0,r,o),c.strokeStyle=a,c.strokeRect(0,0,r,o),c.fillStyle=a,c.strokeStyle=a}else c.fillStyle="black",c.strokeStyle="black";const{shocked:d}=e;return d?this._shockedFace(c,{x:0,y:0,w:r,h:o,ox:0,...e}):this._idleFace(c,{x:0,y:0,w:r,h:o,ox:0,...e}),{buffer:l,texture:new Ju(l)}}_shockedFace(e,t){const{x:n,y:s,w:r,h:o,ox:l}=t;e.beginPath(),e.arc(n+r/2+l,s+o/2,r/4,0,2*Math.PI),e.fill(),e.beginPath(),e.arc(n+r/4+l,s+o/5,r/10,0,2*Math.PI),e.fill(),e.beginPath(),e.arc(n+3*r/4+l,s+o/5,r/10,0,2*Math.PI),e.fill()}_idleFace(e,t){const{x:n,y:s,w:r,h:o,ox:l,mouthOpen:c,eyesOpen:u}=t;c?(e.beginPath(),e.arc(n+r/2+l,s+o/3,r/3,.1*Math.PI,.9*Math.PI),e.fill()):(e.beginPath(),e.arc(n+r/2+l,s,r/2,.3*Math.PI,.7*Math.PI),e.stroke()),u?(e.beginPath(),e.arc(n+r/4+l,s+o/5,r/10,0,2*Math.PI),e.fill(),e.beginPath(),e.arc(n+3*r/4+l,s+o/5,r/10,0,2*Math.PI),e.fill()):(e.beginPath(),e.arc(n+r/4+l,s+o/3,r/6,1.25*Math.PI,1.75*Math.PI),e.stroke(),e.beginPath(),e.arc(n+3*r/4+l,s+o/3,r/6,1.25*Math.PI,1.75*Math.PI),e.stroke())}};E(Gt,"_bufferWidth",100),E(Gt,"_bufferHeight",100),E(Gt,"_lineWidth",8),E(Gt,"_graphics",{});let sd=Gt;function ef(i,e,t){return(1-t)*i+t*e}class UT{static getTorsoWithEyeMeshes(e){const t=new Hn;t.add(e);const n=new dt({color:"black"}),s=lc({thickness:.05}),r=new at(s,n);t.add(r);const o=OT(),l=new at(o,n);return t.add(l),t}}function OT(){const i=[];i.push(new Bt(.15,.3,.1).translate(-.3/2,.2,.5)),i.push(new Bt(.15,.3,.1).translate(.3/2,.2,.5));const r=new Bt(.3,.1,.1).translate(0,-.1,.5),o=r.attributes.position;let l=-1/0;for(let u=0;u<o.count;++u){const d=o.getY(u);d>l&&(l=d)}for(let u=0;u<o.count;++u)if(Math.abs(o.getY(u)-l)<1e-6){const d=o.getX(u),a=.07*Math.sign(d);o.setX(u,d+a)}o.needsUpdate=!0,i.push(r);const c=fx(i,!1);return c.deleteAttribute("normal"),c.deleteAttribute("uv"),c}function rh(i,e,t,n,s){return{meshLoader:async()=>{const r=new at(new Bt(i,e,t),new dt({color:n}));return s!=null&&s.hasFaceTexture?sd.getTorsoWithTexturedFace(r):s!=null&&s.hasFaceMesh?UT.getTorsoWithEyeMeshes(r):r}}}function FT(i,e,t){return new A(i.x+(e.x-i.x)*t,i.y+(e.y-i.y)*t,i.z+(e.z-i.z)*t)}class vx{constructor(e=11.5){E(this,"leftFoot");E(this,"rightFoot");E(this,"torso");E(this,"torsoPos");E(this,"torsoAngle",0);E(this,"torsoVel");E(this,"torsoAvel",0);E(this,"moveX",0);E(this,"moveZ",0);E(this,"feet");E(this,"controlMode","default");E(this,"y0");E(this,"TORSO_Y");E(this,"FOOT_Y");E(this,"FOOT_DIST");E(this,"MAX_FOOT_DIST");E(this,"WALK_SPEED");E(this,"FOOT_SLIDE_SPEED");this.y0=e,this.TORSO_Y=e+.6,this.FOOT_Y=e+.05,this.FOOT_DIST=.3,this.MAX_FOOT_DIST=1,this.WALK_SPEED=.006,this.FOOT_SLIDE_SPEED=this.WALK_SPEED*.9,this.torsoPos=new A(0,this.TORSO_Y,0),this.torsoVel=new A(0,0,0),this.leftFoot=rh(.3,.1,.5,"black"),this.rightFoot=rh(.3,.1,.5,"black"),this.torso=rh(1,1,1,"#fff360",{hasFaceMesh:!0}),this.feet={left:{state:"anchored",pos:new A(-this.FOOT_DIST,this.FOOT_Y,0),angle:0},right:{state:"anchored",pos:new A(this.FOOT_DIST,this.FOOT_Y,0),angle:0}}}reset(){this.torsoPos=new A(0,this.TORSO_Y,0),this.torsoAngle=0,this.torsoVel=new A(0,0,0),this.torsoAvel=0,this.moveX=0,this.moveZ=0,this.feet.left={state:"anchored",pos:new A(-this.FOOT_DIST,this.FOOT_Y,0),angle:0},this.feet.right={state:"anchored",pos:new A(this.FOOT_DIST,this.FOOT_Y,0),angle:0}}update(e){if(e.seaBlock.isShowingSettingsMenu){On.set(0,0,0),this.moveX=0,this.moveZ=0;return}this.controlMode==="default"?(this._pollLeftHandInput(e,!0),this._updateDefaultControls(e)):(this._pollLeftHandInput(e,!1),this._updateRaftControls(e))}_updateRaftControls(e){const{dt:t}=e;this.torsoAngle=Math.PI/2,this.torsoPos.set(-this.moveZ/2,1.5,this.moveX/2),this._updateMeshesRaft(t)}_updateDefaultControls(e){const{dt:t}=e;this.moveX!==0||this.moveZ!==0?(this.torsoVel.set(this.moveX,0,this.moveZ).normalize().multiplyScalar(this.WALK_SPEED*t),this.torsoAngle=Math.atan2(this.moveX,this.moveZ)):this.torsoVel.set(0,0,0),this.torsoPos.add(this.torsoVel),this._updateWalkingFeet(t),this._updateMeshesDefault()}_pollLeftHandInput(e,t=!1){const{seaBlock:n}=e,{camera:s,orbitControls:r}=n;t?(ei.set(s.position.x-r.target.x,0,s.position.z-r.target.z),ei.lengthSq()>0?ei.normalize():ei.set(0,0,1)):ei.set(0,0,1),Sa.crossVectors(ei,NT);const o=_n.upBtn,l=_n.downBtn,c=_n.leftBtn,u=_n.rightBtn;On.set(0,0,0),o&&On.sub(ei),l&&On.add(ei),c&&On.add(Sa),u&&On.sub(Sa);const d=_x();if(d){const{x:a,y:h}=d;On.addScaledVector(Sa,-a*2*Math.SQRT2),On.addScaledVector(ei,h*2*Math.SQRT2)}this.moveX=On.x,this.moveZ=On.z}_restRelPos(e){const t=e==="left"?-1:1,n=this.torsoAngle+t*Math.PI/2;return new A(Math.sin(n)*this.FOOT_DIST,this.FOOT_Y-this.TORSO_Y,Math.cos(n)*this.FOOT_DIST)}_pickFootTarget(e){const t=this._restRelPos(e),n=new A(this.moveX,0,this.moveZ).normalize().multiplyScalar(this.MAX_FOOT_DIST*.7);return t.add(n)}_updateMeshesRaft(e){if(this.torso.mesh&&(this.torso.mesh.position.copy(this.torsoPos),this.torso.mesh.setRotationFromAxisAngle(Ns,this.torsoAngle)),this.leftFoot.mesh){const{mesh:s}=this.leftFoot;s.position.set(0,0,-.5),s.setRotationFromAxisAngle(Ns,0)}if(this.rightFoot.mesh){const{mesh:s}=this.rightFoot;s.position.set(0,0,.5),s.setRotationFromAxisAngle(Ns,0)}}_updateWalkingFeet(e){let t=Object.values(this.feet).some(n=>n.state==="sliding");for(const[n,s]of Object.entries(this.feet))if(s.state==="anchored"){const r=s.pos.clone().sub(this.torsoPos);if(r.length()>this.MAX_FOOT_DIST&&!t){t=!0;const l=s;l.state="sliding",l.startRel=r,l.startAngle=s.angle,l.endRel=this._pickFootTarget(n),l.endAngle=this.torsoAngle,l.t=0}}else if(s.state==="sliding"){const r=s,{startRel:o,startAngle:l,endRel:c,endAngle:u}=r,d=r.t+this.FOOT_SLIDE_SPEED*e;r.t=d,r.t>1?(r.state="anchored",r.pos=this.torsoPos.clone().add(c),r.angle=u):(r.pos=this.torsoPos.clone().add(FT(o,c,d)),r.angle=ef(l,u,d))}}_updateMeshesDefault(){if(this.leftFoot.mesh){const{mesh:e}=this.leftFoot,{pos:t,angle:n}=this.feet.left;e.position.copy(t),e.setRotationFromAxisAngle(Ns,n)}if(this.rightFoot.mesh){const{mesh:e}=this.rightFoot,{pos:t,angle:n}=this.feet.right;e.position.copy(t),e.setRotationFromAxisAngle(Ns,n)}this.torso.mesh&&(this.torso.mesh.position.copy(this.torsoPos),this.torso.mesh.setRotationFromAxisAngle(Ns,this.torsoAngle))}}const NT={x:0,y:1,z:0},ei=new A,Sa=new A,On=new A,Ns=new A(0,1,0);function bx(i,e){return new tf(i,e)._computedRects}class tf{constructor(e,t){E(this,"_computedRects",{});E(this,"isPortrait",!1);E(this,"isLandscape",!1);E(this,"parent");E(this,"_currentLayoutKey","");E(this,"_childrenToParse",{});e.w>e.h?this.isLandscape=!0:this.isPortrait=!0,this.parent=e;for(const[s,r]of Object.entries(t))this.parent=e,this._currentLayoutKey=s,this._computedRects[s]=this.floorRect(this.computeRect(r));const n=this._childrenToParse;for(;Object.keys(n).length>0;){const s=Object.keys(n)[0],r=n[s];delete n[s];const o=this._computedRects[s],{_computedRects:l}=new tf(o,r);for(const c in l)this._computedRects[`${s}.${c}`]=l[c]}}floorRect(e){const{x:t,y:n,w:s,h:r}=e;return{x:Math.floor(t),y:Math.floor(n),w:Math.floor(s),h:Math.floor(r)}}computeRect(e){let t={...this.parent};for(const[n,s]of Rd(e))if(n==="parent"){if(!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);this.parent=this._computedRects[s],t={...this.parent}}else if(n==="children")this._childrenToParse[this._currentLayoutKey]=s;else if(n.includes("@")){const[r,o]=n.split("@");if(o==="portrait")this.isPortrait&&(t=this.applyRule(t,r,s));else if(o==="landscape")this.isLandscape&&(t=this.applyRule(t,r,s));else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else t=this.applyRule(t,n,s);return{x:t.x,y:t.y,w:t.w,h:t.h}}applyRule(e,t,n){const{x:s,y:r,w:o,h:l}=e,{x:c,y:u,w:d,h:a}=this.parent,h=(g,_)=>{if(typeof _=="string"&&_.endsWith("%")){const m=parseFloat(_)/100;return["left","right","width","margin"].includes(g)?d*m:a*m}else{if(_==="auto")return g==="width"?c+d-s:g==="height"?u+a-r:["left","right"].includes(g)?(d-o)/2:(a-l)/2;if(typeof _=="number"&&_<0){if(g==="width")return d+_;if(g==="height")return a+_}}return Number(_)},f=t.split("-");if(f.length===2){const[g,_]=f;let m;if(g==="min")m=Math.max;else if(g==="max")m=Math.min;else throw new Error("only min- or max- prefixed allowed");if(_==="width")return{...e,w:m(o,h("width",n))};if(_==="height")return{...e,h:m(l,h("height",n))};throw new Error("only min/max-width or -height allowed")}switch(t){case"left":return{x:c+h("left",n),y:r,w:o,h:l};case"right":return{x:c+d-o-h("right",n),y:r,w:o,h:l};case"top":return{x:s,y:u+h("top",n),w:o,h:l};case"bottom":return{x:s,y:u+a-l-h("bottom",n),w:o,h:l};case"width":return{x:s,y:r,w:h("width",n),h:l};case"height":return{x:s,y:r,w:o,h:h("height",n)};case"margin":{const g=h("margin",n);return{x:s+g,y:r+g,w:o-2*g,h:l-2*g}}default:return e}}}const kT=0,rd=16,BT={width:rd,height:rd},fg=48,zT={width:fg,height:fg},HT={width:24,height:24},VT={width:0,height:0},yn={btnSize:rd,pad:kT,btn:BT,point:VT,joy:zT,joySlider:HT};function GT(i,e){const t={},n={x:0,y:0,w:1e3,h:1e3};for(const s of e){const r=bx(n,s);for(const{layoutKey:o}of i){const l=r[o];if(l){const{w:c,h:u}=l;if(o in t){if(t[o].w!==c||t[o].h!==u)throw new Error(`got multiple dims for element with layout key ${o}`)}else t[o]={w:c,h:u}}}}return t}const ss=["placeFloorBtn","placeButtonBtn","placeThrusterBtn","wiresBtn"],Ol={placeFloorBtn:{phase:"place-floor",icon:"icons/16x16-checkered.png",action:()=>{j.currentPhase==="place-floor"?j.startPhase("idle"):(qs("placeFloorBtn"),j.startPhase("place-floor"),j.hlTiles.updateBuildableTiles("floor"))}},placeButtonBtn:{phase:"place-button",icon:"icons/raft/16x16-raft-button.png",action:()=>{j.currentPhase==="place-button"?j.startPhase("idle"):(qs("placeButtonBtn"),j.startPhase("place-button"),j.hlTiles.updateBuildableTiles("button"))}},placeThrusterBtn:{phase:"place-thruster",icon:"icons/raft/16x16-thruster.png",action:()=>{j.currentPhase==="place-thruster"?j.startPhase("idle"):(qs("placeThrusterBtn"),j.startPhase("place-thruster"),j.hlTiles.updateBuildableTiles("thruster"))}},wiresBtn:{phase:"show-all-wires",icon:"icons/raft/16x16-wire.png",action:()=>{j.currentPhase==="show-all-wires"?j.startPhase("idle"):(qs("wiresBtn"),j.startPhase("show-all-wires"),j.hlTiles.clear())}}},Mx=ss.map(i=>({layoutKey:i,display:{type:"button",icon:Ol[i].icon},clickAction:Ol[i].action}));function qs(i){for(const[e,t]of ss.entries()){const{display:n}=Mx[e];n.forcedState=t===i?"pressed":void 0,n.needsUpdate=!0}}const WT={layoutKey:"prevToolBtn",hotkeys:["ButtonLB"],display:{type:"button",label:"<",gamepadPrompt:{name:"LB"}},clickAction:()=>{wx(-1)}},XT={layoutKey:"nextToolBtn",hotkeys:["ButtonRB"],display:{type:"button",label:">",gamepadPrompt:{name:"RB"}},clickAction:()=>{wx(1)}},$T={layoutKey:"raftSettingsBtn",hotkeys:["Escape","ButtonStart"],display:{type:"button",icon:"icons/16x16-config.png",isVisible:!0,gamepadPrompt:{name:"start",offset:[0,16]}},clickAction:({seaBlock:i})=>{i.toggleSettings(),i.refreshGui()}};function wx(i){let e;for(const[r,o]of Object.entries(Ol))o.phase===j.currentPhase&&(e=r);const t=ss.indexOf(e),n=ss.length,s=ss[(t+i+n)%n];Ol[s].action()}const YT={pieceDialogPanel:{parent:"toolbar",top:"100%",width:128,left:"auto"},pieceDeleteBtn:{parent:"pieceDialogPanel",width:40,right:0,top:"100%"}},qT={buildPhasePanel:{parent:"toolbar",top:"100%",width:128,left:"auto"},buildCancelBtn:{parent:"buildPhasePanel",width:32,left:0,top:"100%"}},{btn:jT}=yn,oh=16,Sx={toolbar:{height:16,width:ss.length*oh,left:"auto"},raftSettingsBtn:{...jT,right:0},...Object.fromEntries(ss.map((i,e)=>[i,{parent:"toolbar",width:oh,left:oh*e}])),prevToolBtn:{parent:"toolbar",width:32,height:16,right:"100%"},nextToolBtn:{parent:"toolbar",width:32,height:16,bottom:0,left:"100%"},...qT,...YT},{joy:KT,pad:ZT,joySlider:JT}=yn,Ex={...Sx,leftJoy:{...KT,bottom:ZT},leftJoySlider:{parent:"leftJoy",...JT,left:"auto",top:"auto"}},{joy:QT,pad:pg,joySlider:eC}=yn,Ax={...Ex,rightJoy:{...QT,bottom:pg,right:pg},rightJoySlider:{parent:"rightJoy",...eC,left:"auto",top:"auto"}},tC=new Do(.3,6,6).translate(0,-.7,0),nC=new dt({color:"orange"}),mo=new Zt(tC,nC,25);function iC(){mo.count=0;for(const i of j.thrusters)i.isFiring&&sC(i);mo.instanceMatrix.needsUpdate=!0}function sC(i){const{direction:e,dx:t,dz:n}=i,s=mo.count++,r=mx(e);r.setPosition(t,0,n),mo.setMatrixAt(s,r)}const rC=new se("#ffffff"),oC=new se("#7eb5e8"),aC=new se("#c4d4fa"),lC=new se("#868686");function cC(){for(const i of j.buttons)i.isPressed=!1,Tx(i)}function hC(i){for(const e of j.thrusters)e.isFiring=!1;for(const e of j.buttons){const{dx:t,dz:n}=e,s=e.isPressed;e.isPressed=Math.abs(i.x-t)<.6&&Math.abs(i.z-n)<.6,Tx(e),s!==e.isPressed&&Ye("chessClick")}dC(),iC()}function Tx(i){const e=Er.button,t=i.isPressed?rC:oC;e.setColorAt(i.imIndex,t),e.instanceColor.needsUpdate=!0,uC(i)}function uC(i){if(i.isPressed)for(const e of i.triggers)e.isFiring=!0}function dC(){const i=Er.thruster;for(const e of j.thrusters){const t=e.isFiring?aC:lC;i.setColorAt(e.imIndex,t)}i.instanceColor.needsUpdate=!0}const{btn:fC,btnSize:mg,pad:Ea}=yn,Aa={parent:"_wasdBtnRegion",...fC},Cx={_wasdBtnRegion:{width:3*mg+2*Ea,height:2*mg+Ea,bottom:Ea,left:Ea},upBtn:{...Aa,left:"auto"},downBtn:{...Aa,left:"auto",bottom:0},leftBtn:{...Aa,bottom:0},rightBtn:{...Aa,right:0,bottom:0}},Rx={...Sx,...Cx},ks=1.2,pC=new Un(new A(-ks/2,-ks/2,-ks/2),new A(ks/2,ks/2,ks/2)),Ki=new at(lc({box:pC,thickness:.05}),new dt({color:"white"})),mC={default:new dt({color:13421772}),buildable:new dt({color:"white"})};function od(i,e="default"){Ki.position.x=i.x,Ki.position.z=i.z,Ki.visible=!0,Ki.material=mC[e],Ki.frustumCulled=!1}const gC=new dt({color:"white",depthTest:!1,depthWrite:!1}),Ui=new Zt(new Bt(1,1,1),gC,100);Ui.renderOrder=999;Ui.count=0;function go(i){if(Ui.count=0,i)for(const e of i.triggers)_g(i,e);else for(const e of j.buttons)for(const t of e.triggers)_g(e,t);Ui.instanceMatrix.needsUpdate=!0}function Px(){Ui.count=0}const ah=new A,lh=new A,Ta=new A,ch=new A,Ca=new A,hh=new A,uh=new A,gg=new A,kr=new We;function _g(i,e){ah.set(i.dx,.5,i.dz),lh.set(e.dx,0,e.dz),Ta.addVectors(ah,lh).multiplyScalar(.5),ch.subVectors(lh,ah);const t=ch.length();if(t<1e-6)throw new Error("wire is too short");kr.identity(),Ca.copy(ch).normalize();let n;uh.set(0,0,1).angleTo(Ca)>=1e-6&&(hh.crossVectors(uh,Ca).normalize(),n=Math.acos(uh.dot(Ca)),hh.lengthSq()>=1e-6&&n!==void 0&&kr.makeRotationAxis(hh,n)),gg.set(.08,.08,t),kr.scale(gg),kr.setPosition(Ta.x,Ta.y,Ta.z);const s=Ui.count++;Ui.setMatrixAt(s,kr)}const Bs=1.2,_C=new Un(new A(-Bs/2,-Bs/2,-Bs/2),new A(Bs/2,Bs/2,Bs/2)),wi=new at(lc({box:_C}),new dt({color:"white"})),xC={default:new dt({color:13421772}),buildable:new dt({color:"white"})};function yC(i,e="default"){wi.position.x=i.x,wi.position.z=i.z,wi.visible=!0,wi.material=xC[e],wi.frustumCulled=!1}const nf=1,_r=50,Ix=5,vC=2,dh=25,bC=new A(dh,dh,dh),fh=45,MC=new A(fh,fh,fh),sf=new A(0,10,0);function wC(i,e){const t={},n=Object.keys(i);for(const[s,r]of n.entries()){const{layoutKey:o}=i[r],l=e[o];if(!l)continue;const c=new Set;for(let u=s+1;u<n.length;u++){const d=n[u],a=i[d],h=e[a.layoutKey];h&&SC(l,h)&&c.add(d)}t[r]=c}return t}function SC(i,e){return!(i.x+i.w<=e.x||e.x+e.w<=i.x||i.y+i.h<=e.y||e.y+e.h<=i.y)}const EC=["gamepad/playstation-L1.png","gamepad/playstation-R1.png","gamepad/playstation-X.png","gamepad/playstation-O.png","gamepad/xbox-A.png","gamepad/xbox-B.png","gamepad/xbox-start.png","gamepad/xbox-back.png","sm-banner-edge.png","tile-shapes/4_0.71_0.79.png","tile-shapes/8_0.77_0.39.png","tile-shapes/3_1.15_3.14.png","tile-shapes/3_1.15_0.00.png","tile-shapes/6_0.87_0.52.png","tile-shapes/4_0.43_0.79.png","borders/16x16-panel.png","borders/16x16-dark-panel.png","borders/16x16-btn-sm-default.png","borders/16x16-btn-sm-hovered.png","borders/16x16-btn-sm-pressed.png","borders/16x16-btn-square-hovered.png","borders/24x24-joy-slider-default.png","borders/16x16-btn-shiny-pressed.png","borders/16x16-btn-square-pressed.png","borders/16x16-btn-square-default.png","borders/16x16-btn-shiny-default.png","borders/24x24-joy-slider-pressed.png","borders/24x24-joy-slider-hovered.png","borders/16x16-btn-shiny-hovered.png","textures/kenney-colormap.png","icons/skip.png","icons/16x16-arrow-up.png","icons/16x16-config.png","icons/16x16-pan.png","icons/launch.png","icons/16x16-arrow-down.png","icons/16x16-arrow-right.png","icons/16x16-music.png","icons/chess/16x16-queen.png","icons/chess/16x16-rook.png","icons/chess/8x8-queen.png","icons/chess/8x8-pawn.png","icons/chess/16x16-pawn.png","icons/chess/16x16-king.png","icons/chess/8x8-knight.png","icons/chess/8x8-bishop.png","icons/chess/8x8-rook.png","icons/chess/8x8-king.png","icons/chess/16x16-knight.png","icons/chess/16x16-chest.png","icons/chess/16x16-bishop.png","icons/16x16-arrow-left.png","icons/raft/16x16-thruster.png","icons/raft/16x16-raft-button.png","icons/raft/16x16-wire.png","icons/16x16-x.png","icons/16x16-checkered.png","icons/16x16-rotate.png","icons/16x16-ellipsis.png"],Lx=new Map;function wt(i){return Lx.get(i)}let xg=!1;async function AC(i=""){if(xg)throw new Error("called loadAllImages multiple times");xg=!0,await Promise.all(EC.map(e=>new Promise((t,n)=>{const s=new Image;s.onload=()=>{Lx.set(e,s),Di(s),t()},s.onerror=n,s.src=`${i}images/${e}`})))}const Dx="https://raw.githubusercontent.com/hgcummings/pixel-fonts/refs/heads/master/data/seven-plus.json",Ux=7,Ox=`7x4 numbers, 7x5 upper case 
and variable-width lower case letters`,Fx=!1,Nx={0:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},1:{offset:0,pixels:[[0,0,1,0],[0,1,1,0],[1,0,1,0],[0,0,1,0],[0,0,1,0],[0,0,1,0],[1,1,1,1]]},2:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0],[1,1,1,1]]},3:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,1,1,0],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},4:{offset:0,pixels:[[0,0,1,0],[0,1,1,0],[1,0,1,0],[1,1,1,1],[0,0,1,0],[0,0,1,0],[0,0,1,0]]},5:{offset:0,pixels:[[1,1,1,1],[1,0,0,0],[1,0,0,0],[1,1,1,0],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},6:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},7:{offset:0,pixels:[[1,1,1,1],[0,0,0,1],[0,0,1,0],[0,0,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]]},8:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},9:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},A:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},B:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},C:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,1],[0,1,1,1,0]]},D:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},E:{offset:0,pixels:[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},F:{offset:0,pixels:[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},G:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},H:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},I:{offset:0,pixels:[[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[1,1,1,1,1]]},J:{offset:0,pixels:[[1,1,1,1,1],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[1,0,0,1,0],[0,1,1,0,0]]},K:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,1,0],[1,0,1,0,0],[1,1,0,0,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},L:{offset:0,pixels:[[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},M:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,1,0,1,1],[1,0,1,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},N:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,1,0,0,1],[1,0,1,0,1],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1]]},O:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},P:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},Q:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},R:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},S:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[0,1,1,1,0],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},T:{offset:0,pixels:[[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},U:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},V:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0]]},W:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},X:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,1,0,1,0],[1,0,0,0,1],[1,0,0,0,1]]},Y:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},Z:{offset:0,pixels:[[1,1,1,1,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},a:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},b:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0]]},c:{offset:2,pixels:[[0,1,1,1],[1,0,0,0],[1,0,0,0],[1,0,0,0],[0,1,1,1]]},d:{offset:0,pixels:[[0,0,0,1],[0,0,0,1],[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},e:{offset:2,pixels:[[0,1,1,0],[1,0,0,1],[1,1,1,1],[1,0,0,0],[0,1,1,1]]},f:{offset:0,pixels:[[0,0,1,1],[0,1,0,0],[1,1,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]]},g:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,1,1,0]]},h:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1]]},i:{offset:0,pixels:[[0,1,0],[0,0,0],[1,1,0],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},j:{offset:0,pixels:[[0,0,1],[0,0,0],[0,1,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[1,1,0]]},k:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,0,0,1],[1,0,1,0],[1,1,0,0],[1,0,1,0],[1,0,0,1]]},l:{offset:0,pixels:[[1,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},m:{offset:2,pixels:[[1,1,1,1,0],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1]]},n:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1]]},o:{offset:2,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},p:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0],[1,0,0,0],[1,0,0,0]]},q:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,0,0,1]]},r:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,0],[1,0,0,0],[1,0,0,0]]},s:{offset:2,pixels:[[0,1,1,1],[1,0,0,0],[0,1,1,0],[0,0,0,1],[1,1,1,0]]},t:{offset:0,pixels:[[0,1,0,0],[0,1,0,0],[1,1,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,0,1,1]]},u:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},v:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,1,0],[0,1,0,0]]},w:{offset:2,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},x:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[0,1,1,0],[1,0,0,1],[1,0,0,1]]},y:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,1,1,0]]},z:{offset:2,pixels:[[1,1,1,1],[0,0,0,1],[0,1,1,0],[1,0,0,0],[1,1,1,1]]}," ":{offset:0,pixels:[[0,0,0]]},"!":{offset:0,pixels:[[1],[1],[1],[1],[1],[0],[1]]},'"':{offset:0,pixels:[[1,0,1],[1,0,1]]},"#":{offset:0,pixels:[[0,1,0,1,0],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[0,1,0,1,0]]},$:{offset:0,pixels:[[0,0,1,0,0],[0,1,1,1,1],[1,0,1,0,0],[0,1,1,1,0],[0,0,1,0,1],[1,1,1,1,0],[0,0,1,0,0]]},"%":{offset:0,pixels:[[1,1,0,0,1],[1,1,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,1,1],[1,0,0,1,1]]},"&":{offset:0,pixels:[[0,1,1,0,0],[1,0,0,1,0],[1,0,1,0,0],[0,1,0,0,1],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},"'":{offset:0,pixels:[[1],[1]]},"(":{offset:0,pixels:[[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[0,1]]},")":{offset:0,pixels:[[1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[1,0]]},"*":{offset:1,pixels:[[1,0,1],[0,1,0],[1,0,1]]},"+":{offset:2,pixels:[[0,1,0],[1,1,1],[0,1,0]]},",":{offset:6,pixels:[[1],[1]]},"-":{offset:3,pixels:[[1,1,1]]},".":{offset:6,pixels:[[1]]},"/":{offset:0,pixels:[[0,0,1],[0,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,0],[1,0,0]]},":":{offset:4,pixels:[[1],[0],[1]]},";":{offset:4,pixels:[[1],[0],[1],[1]]},"<":{offset:1,pixels:[[0,0,1],[0,1,0],[1,0,0],[0,1,0],[0,0,1]]},"=":{offset:2,pixels:[[1,1,1],[0,0,0],[1,1,1]]},">":{offset:1,pixels:[[1,0,0],[0,1,0],[0,0,1],[0,1,0],[1,0,0]]},"?":{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,0,1,0],[0,1,0,0],[0,0,0,0],[0,1,0,0]]},"@":{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,1,1],[1,0,1,0,1],[1,0,1,1,1],[1,0,0,0,0],[0,1,1,1,0]]},"[":{offset:0,pixels:[[1,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1]]},"\\":{offset:0,pixels:[[1,0,0],[1,0,0],[0,1,0],[0,1,0],[0,1,0],[0,0,1],[0,0,1]]},"]":{offset:0,pixels:[[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,1]]},"^":{offset:0,pixels:[[0,1,0],[1,0,1]]},_:{offset:6,pixels:[[1,1,1,1,1]]},"`":{offset:0,pixels:[[1,0],[0,1]]},"{":{offset:0,pixels:[[0,0,1],[0,1,0],[0,1,0],[1,0,0],[0,1,0],[0,1,0],[0,0,1]]},"|":{offset:0,pixels:[[1],[1],[1],[1],[1],[1],[1]]},"}":{offset:0,pixels:[[1,0,0],[0,1,0],[0,1,0],[0,0,1],[0,1,0],[0,1,0],[1,0,0]]},"~":{offset:2,pixels:[[0,1,0,0,0],[1,0,1,0,1],[0,0,0,1,0]]},"":{offset:0,pixels:[[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]}},TC={source:Dx,lineHeight:Ux,description:Ox,isFixedWidth:Fx,glyphs:Nx},CC=Object.freeze(Object.defineProperty({__proto__:null,default:TC,description:Ox,glyphs:Nx,isFixedWidth:Fx,lineHeight:Ux,source:Dx},Symbol.toStringTag,{value:"Module"})),kx="3x5 uppercase letters only",Bx=5,zx=!0,Hx={"!":{offset:0,pixels:[[0,1,0],[0,1,0],[0,1,0],[0,0,0],[0,1,0]]},"/":{offset:0,pixels:[[0,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,0]]}," ":{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]},_:{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[1,1,1]]},A:{offset:0,pixels:[[0,1,0],[1,0,1],[1,1,1],[1,0,1],[1,0,1]]},B:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,1],[1,1,0]]},C:{offset:0,pixels:[[0,1,1],[1,0,0],[1,0,0],[1,0,0],[0,1,1]]},D:{offset:0,pixels:[[1,1,0],[1,0,1],[1,0,1],[1,0,1],[1,1,0]]},E:{offset:0,pixels:[[1,1,1],[1,0,0],[1,1,0],[1,0,0],[1,1,1]]},F:{offset:0,pixels:[[1,1,1],[1,0,0],[1,1,0],[1,0,0],[1,0,0]]},G:{offset:0,pixels:[[0,1,1],[1,0,0],[1,0,1],[1,0,1],[0,1,1]]},H:{offset:0,pixels:[[1,0,1],[1,0,1],[1,1,1],[1,0,1],[1,0,1]]},I:{offset:0,pixels:[[1,1,1],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},J:{offset:0,pixels:[[0,0,1],[0,0,1],[0,0,1],[1,0,1],[0,1,0]]},K:{offset:0,pixels:[[1,0,1],[1,1,0],[1,0,0],[1,1,0],[1,0,1]]},L:{offset:0,pixels:[[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,1,1]]},M:{offset:0,pixels:[[1,0,1],[1,1,1],[1,0,1],[1,0,1],[1,0,1]]},N:{offset:0,pixels:[[1,0,1],[1,1,1],[1,1,1],[1,0,1],[1,0,1]]},O:{offset:0,pixels:[[0,1,0],[1,0,1],[1,0,1],[1,0,1],[0,1,0]]},P:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,0],[1,0,0]]},Q:{offset:0,pixels:[[0,1,0],[1,0,1],[1,0,1],[1,1,1],[0,1,1]]},R:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,1],[1,0,1]]},S:{offset:0,pixels:[[0,1,1],[1,0,0],[0,1,0],[0,0,1],[1,1,0]]},T:{offset:0,pixels:[[1,1,1],[0,1,0],[0,1,0],[0,1,0],[0,1,0]]},U:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[1,0,1],[0,1,0]]},V:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[0,1,0],[0,1,0]]},W:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[1,1,1],[1,0,1]]},X:{offset:0,pixels:[[1,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,1]]},Y:{offset:0,pixels:[[1,0,1],[1,0,1],[0,1,0],[0,1,0],[0,1,0]]},Z:{offset:0,pixels:[[1,1,1],[0,0,1],[0,1,0],[1,0,0],[1,1,1]]}},RC={description:kx,lineHeight:Bx,isFixedWidth:zx,glyphs:Hx},PC=Object.freeze(Object.defineProperty({__proto__:null,default:RC,description:kx,glyphs:Hx,isFixedWidth:zx,lineHeight:Bx},Symbol.toStringTag,{value:"Module"})),_l=2;function ps(i,e){const{label:t,width:n,height:s,font:r="default",color:o="black",textAlign:l="center",offset:c=[0,0]}=e;let u=t;r==="mini"&&(u=u.toUpperCase());const d=u.split(`
`),h=Vx(r).lineHeight+_l,f=d.length,g=d.map(x=>IC(x,r)),_=Math.max(...g.map(x=>{var b;return((b=x[0])==null?void 0:b.length)||0}));let m=0,p=0;l==="center"?(m=Math.floor(n/2-_/2),p=Math.floor(s/2-f*h/2+_l/2)):l==="left"&&(p=Math.floor(s/2-f*h/2+_l/2)),m+=c[0],p+=c[1],i.fillStyle=o;for(let x=0;x<f;x++){const b=g[x];for(const[v,P]of b.entries())for(const[C,T]of P.entries())T===1&&i.fillRect(m+C,p+v+x*h,1,1)}}function Vx(i){return i==="default"?CC:PC}function IC(i,e="default"){const t=Vx(e),{glyphs:n,lineHeight:s}=t,r=s+_l,o=[];for(let c=0;c<r;c++)o[c]=[];let l=!0;for(const c of i){const u=n[c];if(!u)continue;if(!l)for(let a=0;a<r;a++)o[a].push(0);l=!1;const d=new Array(u.pixels[0].length).fill(0);for(let a=0;a<r;a++){const h=u.pixels[a-u.offset]||d;o[a].push(...h)}}return o}const Ce=8;function Gx(i,e,t,n){if(e.width===t&&e.height===n){i.drawImage(e,0,0);return}i.drawImage(e,0,0,Ce,Ce,0,0,Ce,Ce),i.drawImage(e,16-Ce,0,Ce,Ce,t-Ce,0,Ce,Ce),i.drawImage(e,0,16-Ce,Ce,Ce,0,n-Ce,Ce,Ce),i.drawImage(e,16-Ce,16-Ce,Ce,Ce,t-Ce,n-Ce,Ce,Ce),i.imageSmoothingEnabled=!1,i.drawImage(e,Ce,0,1,Ce,Ce,0,t-2*Ce,Ce),i.drawImage(e,Ce,16-Ce,1,Ce,Ce,n-Ce,t-2*Ce,Ce),i.drawImage(e,0,Ce,Ce,1,0,Ce,Ce,n-2*Ce),i.drawImage(e,16-Ce,Ce,Ce,1,t-Ce,Ce,Ce,n-2*Ce),i.drawImage(e,Ce,Ce,1,1,Ce,Ce,t-2*Ce,n-2*Ce)}const yg=["16x16-btn-shiny","16x16-btn-square","16x16-btn-sm"],vg=["16x16-panel","16x16-dark-panel"];function LC(i){const{w:e,h:t,type:n,border:s,font:r,textAlign:o}=i,l="icon"in i?i.icon:"null",c="label"in i?i.label:"null";return JSON.stringify([e,t,n,s,r,o,l,c])}const ph={},DC={border:"16x16-btn-shiny",font:"default",textAlign:"center"},UC={border:"16x16-panel"};function Wx(i){const t={...i.type==="button"?DC:UC,...i},n=LC(t);return Object.hasOwn(ph,n)||(ph[n]=FC(t)),ph[n]}const OC={button:Xx,label:VC,panel:HC,"ss-region":zC,"joy-region":BC,diagram:NC,"sprite-atlas":kC};function FC(i){const{type:e}=i,t=OC[e],n=t(i);if(e!=="sprite-atlas"){const s=new Set(Object.values(n));for(const r of s)Di(r)}return n}function NC(i){const{w:e,h:t}=i;return{default:new OffscreenCanvas(e,t)}}function kC(i){return{default:new OffscreenCanvas(500,500)}}function BC(i){const e=Xx(i);for(const t of Object.keys(e)){const n=e[t],s=n.getContext("2d");if(!s)continue;const r=s.getImageData(6,6,1,1).data,[o,l,c]=r,u=s.getImageData(0,0,n.width,n.height),d=u.data;for(let a=0;a<d.length;a+=4)d[a]===o&&d[a+1]===l&&d[a+2]===c&&(d[a+3]=0);s.putImageData(u,0,0)}return e}function zC(i){const{w:e,h:t}=i,n=new OffscreenCanvas(e,t),s=n.getContext("2d");return s.fillStyle="rgb(128,128,128)",s.fillRect(0,0,e,t),s.fillStyle="black",s.fillRect(0,t/2,e,1),s.fillRect(0,0,1,t),s.fillRect(e-1,0,1,t),{default:n}}function HC(i){let e;const{border:t}=i;if(!t||!vg.includes(t))throw new Error(`panel border must be one of ${JSON.stringify(vg)}`);const n=`borders/${t}.png`;if("label"in i)e=Fl(n,i);else if("icon"in i)e=$x(n,i);else{const s={...i,label:""};e=Fl(n,s)}return{default:e}}function VC(i){const{w:e,h:t}=i,n=new OffscreenCanvas(e,t),s=n.getContext("2d");if(!s)throw new Error("offscreen canvas ctx is null");if("label"in i)ps(s,{width:e,height:t,label:i.label,font:i.font,color:i.color,textAlign:i.textAlign});else if("icon"in i){const r=wt(i.icon),o=Math.floor((e-r.width)/2),l=Math.floor((t-r.height)/2);s.drawImage(r,o,l)}return{default:n,pressed:n,hovered:n}}function Xx(i){const e={};for(const t of sR){let n;const{border:s}=i;if(!s||!yg.includes(s))throw new Error(`button border must be one of ${JSON.stringify(yg)}`);const r=`borders/${s}-${t}.png`;if("label"in i)n=Fl(r,i);else if("icon"in i)n=$x(r,i);else{const o={...i,label:""};n=Fl(r,o)}e[t]=n}return e}function $x(i,e){const{w:t,h:n,icon:s}=e,r=new OffscreenCanvas(t,n),o=r.getContext("2d");if(!o)throw new Error("offscreen canvas ctx is null");const l=wt(i);Gx(o,l,t,n);const c=wt(s),u=Math.floor((t-c.width)/2),d=Math.floor((n-c.height)/2);return o.drawImage(c,u,d),r}function Fl(i,e){const{w:t,h:n}=e,s=new OffscreenCanvas(t,n),r=s.getContext("2d");if(!r)throw new Error("offscreen canvas ctx is null");const o=wt(i);return Gx(r,o,t,n),ps(r,{width:t,height:n,label:e.label,font:e.font,color:e.color,textAlign:e.textAlign}),s}function Pn(i){const e=[i.game.gui],{testGui:t}=i.config.flatConfig;return t==="sprite-atlas"?[it.create("sprite-atlas")]:(i.isShowingSettingsMenu&&e.unshift(it.create("settings-menu")),e)}function GC(i){for(const e of Pn(i.seaBlock))if(e.click(i))return!0;return!1}function WC(i){for(const e of Pn(i.seaBlock))e.unclick(i)}function XC(i){document.documentElement.style.cursor="default";for(const e of Pn(i.seaBlock))if(e.move(i))return!0;return!1}let js={};const Ra={};function xr(i){js={};const{w:e,h:t}=i.layeredViewport;i.layeredViewport.ctx.clearRect(0,0,e,t)}function $C(i){for(const e in i.elements)delete js[e]}function mh(i){if(!i.didLoadAssets)return;const{layeredViewport:e}=i,{ctx:t}=e;for(const n of[...Pn(i)].reverse()){const s=n.overrideLayoutRectangles,r=n.layoutRectangles,o=n.elementOcclusions;for(const l in n.elements){const c=n.elements[l],{display:u,layoutKey:d}=c;if("isVisible"in u&&!u.isVisible)continue;let a=s[d]||r[d];if(a&&u.forcedSliderState&&"slideIn"in c){const{slideIn:_}=c,{x:m,y:p}=u.forcedSliderState,{w:x,h:b}=a,v=s[_]||r[_];a={x:v.x+m*(v.w-x),y:v.y+p*(v.h-b),w:x,h:b},u.shouldSnapToPixel&&(a={...a,x:Math.round(a.x),y:Math.round(a.y)}),s[d]=a,u.forcedSliderState=void 0}if(c.gamepadNavBox?c.gguiNavRectangle=s[c.gamepadNavBox]||r[c.gamepadNavBox]:c.gguiNavRectangle=a,!a){c.rectangle=void 0;continue}let h=n.getElementState(l);const f=Wx({...u,w:a.w,h:a.h});h in f||(h="default"),u.needsUpdate&&(u.needsUpdate=!1,delete js[l]),u.forcedState&&(h=u.forcedState);const g=js[l];if(h!==g){h==="pressed"&&!Ra[l]?(Ye("click"),Ra[l]=!0):h!=="pressed"&&Ra[l]&&(Ye("unclick"),Ra[l]=!1),u.shouldClearBehind&&t.clearRect(a.x,a.y,a.w,a.h),u.type==="sprite-atlas"?n.drawAtlasView(t,a):(u.isVisible=!0,c.rectangle=a,t.drawImage(f[h],a.x,a.y)),js[l]=h;for(const _ of o[l])delete js[_]}}}}let oi=null;const gh=.5,an=new at(new Io(.5,0,1,5,1).scale(gh,gh,gh).translate(0,2,0),new dt({color:"white"}));an.visible=!1;function yr(){an.visible=!1,oi=null}function rf(i){oi=i}function bg(i,e){const{x:t,y:n}=Yx(i,e),s=i.config.flatConfig.pixelScale,r=50;return[t*s-r/2,n*s-r/2,r,r]}const Mg=new xe,YC=new A;function Yx(i,e){const{camera:t,layeredViewport:n}=i,s=YC.copy(e).project(t);return Mg.set((s.x+1)/2*n.w,(1-s.y)/2*n.h),Mg}const qC={A:{getAssetUrl:({isPlaystation:i})=>i?"gamepad/playstation-X.png":"gamepad/xbox-A.png"},B:{getAssetUrl:({isPlaystation:i})=>i?"gamepad/playstation-O.png":"gamepad/xbox-B.png"},LB:{getAssetUrl:()=>"gamepad/playstation-L1.png"},RB:{getAssetUrl:()=>"gamepad/playstation-R1.png"},start:{getAssetUrl:()=>"gamepad/xbox-start.png"},back:{getAssetUrl:()=>"gamepad/xbox-back.png"}};let Ws=null;function ms(i){Ws=i}function wg(i,e){let t=!1;return i.hasConnectedGamepad==="xbox"||(t=!0),qC[e].getAssetUrl({isPlaystation:t})}function jC(i){if(i.transition)return;const{w:e,h:t}=i.layeredViewport,n=i.layeredViewport.frontCtx;if(n.clearRect(0,0,e,t),!!i.isUsingGamepad){for(const s in Hl){const r=Hl[s],{rectangle:o,display:l}=r;if(l.isVisible!==!1&&o){const c=wg(i,s),u=wt(c),{offset:d=[0,0]}=l.gamepadPrompt??{};n.drawImage(u,0,0,u.width,u.height,d[0]+o.x+o.w/2-u.width/2,d[1]+o.y+o.h/2-u.height/2,u.width,u.height)}}if(Ws){const s=wg(i,"A"),r=wt(s);if("z"in Ws&&!i.isShowingSettingsMenu){const o=Yx(i,Ws);o.round(),n.drawImage(r,0,0,r.width,r.height,o.x,o.y,r.width,r.height)}else n.drawImage(r,0,0,r.width,r.height,Ws.x,Ws.y,r.width,r.height)}}}const KC=10;let Sg=0,Ti,Nl,At,kl=!1;const Pa={AxisLX:["left","right"],AxisLY:["up","down"],AxisRX:["left","right"],AxisRY:["up","down"],DPadDown:["down"],DPadUp:["up"],DPadLeft:["left"],DPadRight:["right"]},Eg=["ButtonA"],ZC={up:-Math.PI/2,down:Math.PI/2,left:Math.PI,right:0};function Ks(i,e,t,n){if(!i.isShowingSettingsMenu&&i.game.doesAllowGgui3DCursor()){if(Eg.includes(e)){if(oi&&oi.selectAction(e,t))return!0}else if(e in Pa&&t!==0){if(typeof n=="number")return oi&&(oi.navAction(n),Ye("smNav")),!0;{const o=Ag(Pa[e],t);return oi&&(oi.navAction(ZC[o]),Ye("smNav")),!0}}}else yr();if(!i.isShowingSettingsMenu&&!i.game.doesAllowGgui())return!1;const s=performance.now();if(s-Sg<KC)return!1;if(Sg=s,e in Pa&&t!==0){const o=Ag(Pa[e],t);if(At&&kl&&(o==="left"||o==="right")){const l=At.rectangle,c=At.gguiNavRectangle;let u=At.display.forcedSliderState||{x:(l.x-c.x)/(c.w-l.w||1),y:(l.y-c.y)/(c.h-l.h||1)};const[d,a]=qx[o];return u={x:Math.max(0,Math.min(1,u.x+.1*d)),y:0},At.display.forcedSliderState=u,At.display.needsUpdate=!0,At.dragAction&&At.dragAction({seaBlock:i,sliderState:u}),!0}return QC(i,_o,o),!0}else if(Eg.includes(e)){if(At&&At.clickAction&&t===1)return Nl=Ti,At.clickAction({seaBlock:i}),!0;if(At&&At.unclickAction&&t===0)return Nl=void 0,At.unclickAction({seaBlock:i}),!0}return!1}function Ag(i,e){return i[1]&&typeof e=="number"&&e>0?i[1]:i[0]}function JC(i){const{seaBlock:e}=i;if(!e.isUsingGamepad){Bl();return}Pn(e).forEach(t=>t.hovered=void 0),tR(e),Ti&&!(Ti in _o)?(Bl(),zl()):Ti||zl()}const qx={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};function QC(i,e,t){if(!At)return zl();if(!At.gguiNavRectangle)return zl(i,Ti);const{x:n,y:s,w:r,h:o}=At.gguiNavRectangle,[l,c]=qx[t],u=n+r/2+r/2*l,d=s+o/2+o/2*c,a=4,h=i.layeredViewport.w,f=i.layeredViewport.h;for(let _=0;_<_h.length;_++)_h[_].set((u+l*(_+1)*a)%h,(d+c*(_+1)*a)%f);const g=nR(e,_h);g&&jx(g,e[g])}const _h=Array.from({length:100},()=>new xe);function eR(){Bl()}function Bl(){At&&(At=void 0,Ti=void 0,Nl=void 0,kl=!1,ms(null))}function jx(i,e){if(Bl(),Ti=i,At=e,kl=!1,"slideIn"in e&&e.rectangle&&e.gguiNavRectangle){const{rectangle:t,gguiNavRectangle:n}=e;t.h===n.h&&(kl=!0)}if(e.rectangle){const{x:t,y:n,w:s,h:r}=e.rectangle,{offset:o=[0,0],isHidden:l}=e.display.gamepadPrompt??{};l||(Tg.set(o[0]+t+s/2-8,o[1]+n+r/2-8),ms(Tg))}Ye("smNav")}const Tg=new xe;function zl(i,e){for(const[t,n]of Object.entries(_o))if(t!==e){jx(t,n);return}}let _o={},Hl={};function tR(i){var t;_o={},Hl={};let e;i.isShowingSettingsMenu?e=[it.create("settings-menu")]:e=Pn(i);for(const n of e)for(const[s,r]of Object.entries(n.elements)){const{display:o}=r;o.type==="button"&&r.gamepadNavBox&&o.isVisible&&(_o[s]=r),o.isVisible&&((t=o.gamepadPrompt)!=null&&t.name)&&(Hl[o.gamepadPrompt.name]=r)}}function nR(i,e){for(const t of e)for(const[n,{gguiNavRectangle:s}]of Object.entries(i))if(iR(t,s))return n}function iR(i,e){if(!e)return!1;const{x:t,y:n,w:s,h:r}=e;return i.x>=t&&i.x<t+s&&i.y>=n&&i.y<n+r}const sR=["default","pressed","hovered"];let rR=0;class it{constructor(){E(this,"guiLayout");E(this,"layoutRectangles",{});E(this,"overrideLayoutRectangles",{});E(this,"elementOcclusions",{});E(this,"elements",{});E(this,"reversedIds");E(this,"held",{});E(this,"pickable",{});E(this,"panels",new Set);E(this,"stuckDown",new Set);E(this,"hidden",new Set);E(this,"hovered");E(this,"layoutFactory")}closeDialogs(e){}resetElementStates(e){$C(this),this.stuckDown.clear(),this.hovered=void 0,this.held={}}getElementState(e){return e===Nl?"pressed":e===Ti?"hovered":this.stuckDown.has(e)||e in this.held?"pressed":e===this.hovered?"hovered":"default"}init(e,t){this.layoutFactory=e;for(const n of t){const s=`_${rR++}`;this.elements[s]=n,"display"in n&&["panel"].includes(n.display.type)&&!n.clickAction&&!n.dragAction&&this.panels.add(s)}this.reversedIds=[...Object.keys(this.elements)].reverse();for(const n of this.reversedIds){const s=this.elements[n];s.layoutKey&&(this.pickable[n]=s.slideIn||s.layoutKey)}}refreshLayout(e){const{screenRectangle:t}=e.layeredViewport;this.guiLayout=this.layoutFactory(e),this.overrideLayoutRectangles={},this.layoutRectangles=bx(t,this.guiLayout),this.elementOcclusions=wC(this.elements,this.layoutRectangles)}pickElementAtPoint(...e){for(const t in this.pickable){const n=this.pickable[t],s=this.elements[t];if(s.display.isVisible===!1||s.isPickable===!1)continue;const r=this.overrideLayoutRectangles[n]||this.layoutRectangles[n];if(!r)continue;const{x:o,y:l,w:c,h:u}=r;for(const d of e)if(d.x>o&&d.x<o+c&&d.y>l&&d.y<l+u)return t}}move(e){const t=Object.entries(this.held).find(([n,s])=>s===e.inputId);if(t){const[n,s]=t,r=this.elements[n];let o;const{lvPos:l}=e;return"slideIn"in r&&(o=this._slide(r,l)),r.dragAction&&r.dragAction({seaBlock:e.seaBlock,inputEvent:e,sliderState:o}),!0}else if(e.event.type.startsWith("mouse")&&(this.hovered=this.pickElementAtPoint(e.lvPos),this.hovered))return["button","sprite-atlas"].includes(this.elements[this.hovered].display.type)&&(document.documentElement.style.cursor="pointer"),!0;return!1}click(e){const{seaBlock:t,lvPos:n,inputId:s}=e,{held:r}=this;for(const l in r)r[l]===s&&delete r[l];const o=this.pickElementAtPoint(n);return o?(this.panels.has(o)||this._click({seaBlock:t,inputEvent:e},o),!0):!1}unclick(e){const{seaBlock:t,inputId:n}=e;this._unclick(t,n)}_click(e,t){const n=this.elements[t],{isSticky:s}=n,{inputEvent:r,buttonCode:o}=e;if(r){this.held[t]=r.inputId;const{lvPos:l}=r;l&&"slideIn"in n&&(e.sliderState=this._slide(n,l))}else o&&(this.held[t]=o);s&&this.stuckDown.add(t),this.clickElem(n,e)}clickElem(e,t){const{clickAction:n}=e;n&&n(t)}_slide(e,t){const{layoutKey:n,slideIn:s,slideRadius:r}=e,o=this.layoutRectangles[n],l=this.layoutRectangles[s];if(!o||!l)return;const{w:c,h:u}=o;let d={x:t.x-c/2,y:t.y-u/2,w:c,h:u};if(typeof r=="number"){const f=e.slideRadius;if(Math.hypot(d.x-o.x,d.y-o.y)>f){const _=d.x-o.x,m=d.y-o.y,p=Math.atan2(m,_);d={...d,x:o.x+Math.cos(p)*f,y:o.y+Math.sin(p)*f}}}const a=oR(d,l);if(!a)return;this.overrideLayoutRectangles[n]=a,e.display.needsUpdate=!0;const h=a;return{x:(h.x-l.x)/(l.w-h.w),y:(h.y-l.y)/(l.h-h.h)}}_unclick(e,t){const{held:n}=this;for(const s in n){const r=this.elements[s];if("slideRadius"in r){const{layoutKey:o}=r,{overrideLayoutRectangles:l}=this;delete l[o]}if(n[s]===t){const{unclickAction:o}=this.elements[s];o&&o(e),delete n[s]}}}keydown(e,t){const{held:n}=this;for(const s in n)n[s]===t&&delete n[s];for(const s in this.elements){const r=this.elements[s],{display:o,hotkeys:l}=r;if(o.isVisible&&r.rectangle&&(l!=null&&l.includes(t)))return this._click({seaBlock:e,buttonCode:t},s),!0}return!1}keyup(e,t){this._unclick(e,t)}static register(e,t){if(e in this._registry)throw new Error(`Game already registered: '${e}'`);this._registry[e]=t}static preload(e,t){const{factory:n,layoutFactory:s,elements:r,allLayouts:o}=this._registry[e],l=n();this._preloaded[e]=l,l.init(s,r);const c=o||[s(t)],u=GT(r,c);return Promise.all(Object.entries(l.elements).map(async([d,a])=>{const{w:h,h:f}=u[a.layoutKey];a.display.imageset=Wx({...a.display,w:h,h:f})}))}static create(e){if(e in this._preloaded)return this._preloaded[e];throw new Error(`gui '${e}' was not preloaded`)}}E(it,"_registry",{}),E(it,"_preloaded",{});function oR(i,e){let{x:t,y:n}=i;const{w:s,h:r}=i;if(!(s>e.w||r>e.h))return t<e.x?t=e.x:t+s>e.x+e.w&&(t=e.x+e.w-s),n<e.y?n=e.y:n+r>e.y+e.h&&(n=e.y+e.h-r),{x:t,y:n,w:s,h:r}}const gs=3,xo=vs.length,aR=_r*_r,hc=aR*gs*xo,Kx=new Float32Array(hc),uc=new Float32Array(hc),sr=new Float32Array(hc);function Zx(i,e,t=!1){xl(Kx,i,e),t&&(xl(uc,i,e),xl(sr,i,e))}function lR(i,e){xl(uc,i,e)}function cR(i){const e=i.i*xo*gs,t=(i.i+1)*xo*gs;for(let n=e;n<t;n++)uc[n]=Kx[n]}function xl(i,e,t){const n=e.i*xo*gs;for(const[s,r]of vs.entries()){let o=n+s*gs;const{r:l,g:c,b:u}=t[r];i[o++]=l,i[o++]=c,i[o++]=u}}function hR(i){const e=hc;for(let t=0;t<e;t++){const n=sr[t],s=uc[t];sr[t]=n+(s-n)*i}}const Cg=vs.reduce((i,e)=>(i[e]=new se,i),{});function Jx(i){const e=i.i*xo*gs;return vs.forEach((t,n)=>{const s=e+n*gs,r=sr[s],o=sr[s+1],l=sr[s+2];Cg[t].setRGB(r,o,l)}),Cg}const uR=300,xh=300;let Rg=10,Pg=10;const Qx=20,Ia={},Br={},dc={update:i=>{Rg=Math.pow(Jt.flatConfig.visibleRadius,2),Pg=-Jt.flatConfig.extendBottom/Qx},steps:[({group:i,tileIndex:e,current:t})=>{const{i:n}=e,s=i.tilePositions[n],r=s.x-i.centerXZ.x,o=s.z-i.centerXZ.z;return r*r+o*o<Rg?(Ia[n]||(Ia[n]=performance.now(),Br[n]=0),t):Br[n]?performance.now()-Br[n]<xh?t:null:(Br[n]=performance.now(),Ia[n]=0,t)},({group:i,tileIndex:e,style:t,current:n})=>{const{x:s,z:r,i:o}=e;let l=i.generatedTiles[o];if(!l){l=i.generateTile(e);const{gTile:c}=l,u=t.getTileColors({x:s,z:r,generatedTile:c,land:!c.isWater,sea:c.isWater});Zx(e,u,!0)}return n.isWater=l.gTile.isWater,n},({group:i,tileIndex:e,current:t})=>{const{i:n}=e,s=i.generatedTiles[n];if(!s)return null;const{gTile:r}=s;return r.isWater?t.height=Lg(r.height,i.sim.getWavePos(n)):t.height=Lg(r.height,0),t},({current:i,tileIndex:e})=>{let t=1;const{i:n}=e,s=Ia[n],r=Br[n];if(r){const l=xh-(performance.now()-r);t=Ig(l,xh)}else if(s){const l=performance.now()-s;t=Ig(l,uR)}const o=-Math.min(i.height-Pg,t);return i.height+=o,i}]};function Ig(i,e){if(i>e)return 0;const t=Math.min(i/e,1);return 1-(1-Math.pow(1-t,4))}function Lg(i,e){return i*Qx/255+1+e}class St{constructor(){E(this,"gui");E(this,"elements",[]);E(this,"meshes",[]);E(this,"pickableMeshes",[])}getTerrainRenderPipeline(e){return dc}resetCamera(e){}getCamOffset(e){const{w:t,h:n}=e.layeredViewport;return n>t?MC:bC}getCamTargetOffset(){return sf}doesAllowOrbitControls(e){return!0}doesAllowGgui(){return!1}doesAllowGgui3DCursor(){return!1}doesAllow3DRender(){return!0}update(e){}static register(e,t){if(e in this._registry)throw new Error(`Game already registered: '${e}'`);this._registry[e]=t}static preload(e){const{factory:t,guiName:n,elements:s=[]}=this._registry[e],r=t();return this._preloaded[e]=r,r.elements=s,r.gui=it.create(n),Promise.all(s.map(async o=>{const l=await o.meshLoader();o.mesh=l,r.meshes.push(l),(o.clickAction||o.isPickable)&&(dR(l,o),r.pickableMeshes.push(l))}))}static create(e,t){var s;const n=this._preloaded[e];if(!n)throw new Error(`game '${e}' was not preloaded`);return n.reset(t),(s=n.gui)==null||s.refreshLayout(t),n}}E(St,"_registry",{}),E(St,"_preloaded",{});function dR(i,e){i.gameElement=e,i.traverse(t=>{t.gameElement=e})}function fR(i){i.gameElement=void 0,i.traverse(e=>{e.gameElement=void 0})}function vr(i,e){const t=i instanceof gt?i:i.mesh;t&&t.traverse(n=>{if(n instanceof at){if(n.isOutline)return;n.material=e}})}function pR(i,e,t){const{w:n,h:s}=t;let r=-7;n<s&&(r*=2);const o=e.fov*(Math.PI/180),c=2*Math.abs(r)*Math.tan(o/2)/t.h;i.position.copy(e.position),i.quaternion.copy(e.quaternion),i.translateZ(r),i.scale.set(c,c,c)}function mR(i,e,t,n){const s=n.x+n.w/2-(t.x+t.w/2),r=t.y+t.h/2-(n.y+n.h/2);i.position.set(s,r,0),i.scale.set(100,100,100)}class ad{constructor(e){this.seed=e}next(){return this.seed=(this.seed*9301+49297)%233280,this.seed/233280}}function hi(i){return i[Math.floor(Math.random()*i.length)]}function gR(i){const e=[...i];for(let t=e.length-1;t>0;t--){const n=Math.floor(Math.random()*(t+1));[e[t],e[n]]=[e[n],e[t]]}return e}function of(i){return $e.isLaunching?$e.create(hi(["zoom"]),i):$e.isFirstUncover?$e.create(hi(["ss"]),i):$e.create(hi(["flat","ss"]),i)}const Ji=class Ji{constructor(){E(this,"doesAllowMidTransitionReset",!0);E(this,"totalDuration",1500);E(this,"elapsed",0);E(this,"didFinishCover",!1);E(this,"didFinishUncover",!1);E(this,"layeredViewport");E(this,"terrain")}getExtraPipelineStep(){return null}cleanupHide(){const{frontCtx:e,w:t,h:n}=this.layeredViewport;e.fillStyle="black",e.fillRect(0,0,t,n)}cleanupShow(){const{frontCtx:e,w:t,h:n}=this.layeredViewport;e.clearRect(0,0,t,n)}update(e){const t=this.elapsed/this.totalDuration;this.elapsed+=e;const n=this.elapsed/this.totalDuration;if(!this.didFinishCover&&n>=.5){this.elapsed=this.totalDuration/2,this.cleanupHide(),this.didFinishCover=!0;return}if(n>=1){this.cleanupShow(),this.didFinishUncover=!0,Ji.isFirstUncover&&(Ji.isFirstUncover=!1);return}if(n<=.5){const s=Math.max(0,t*2),r=Math.min(1,n*2);this._hide(s,r)}else{const s=Math.max(0,t*2-1),r=Math.min(1,n*2-1);this._show(s,r)}}static register(e,t){if(e in this._registry)throw new Error(`Transition already registered: '${e}'`);this._registry[e]=t}static create(e,t,n){const s=this._registry[e],r=s(),{layeredViewport:o,terrain:l}=t;if(r.layeredViewport=o,r.terrain=l,t.config.flatConfig.transitionMode==="skip"&&(r.totalDuration=0),n){const{colors:c,tiling:u}=n,d=r,a=c.map(h=>new se(h).toArray());d.hideColors=a,u&&(d.tiling=u)}return r.reset(t),r}};E(Ji,"isLaunching",!0),E(Ji,"isFirstUncover",!1),E(Ji,"_registry",{});let $e=Ji;const Dg=new A,yh=new A,_i=new Ll,La=new Ll;function _R(i,e,t,n){Dg.copy(t),yh.subVectors(i.position,e),_i.setFromVector3(yh),La.setFromVector3(Dg);const s=Math.min(1,.005*n);_i.radius+=(La.radius-_i.radius)*s,_i.theta+=(La.theta-_i.theta)*s,_i.phi+=(La.phi-_i.phi)*s,i.position.copy(yh.setFromSpherical(_i).add(e))}const xR=400,bi=class bi extends $e{constructor(){super(...arguments);E(this,"totalDuration",800);E(this,"doesAllowMidTransitionReset",!1);E(this,"fractionDone",0);E(this,"context")}static snapshotTerrain(t){const n={},{terrain:s}=t,{grid:r,gfxHelper:o}=s;for(const l of r.tileIndices)n[l.i]=o.getLiveHeight(l);bi.snapshot=n}getExtraPipelineStep(){return({current:t,tileIndex:n})=>{const s=bi.snapshot[n.i]||t.height,r=Math.min(1,this.fractionDone+.5);return t.height=yR(s,t.height,r),t}}reset(t){this.context=t,this.fractionDone=0}cleanupHide(){this.cleanupShow()}lerpCamera(t){const{camera:n,orbitControls:s}=this.context,{target:r}=s;_R(n,r,bi.desiredCameraOffset,t*xR)}_hide(t,n){this.lerpCamera(n-t),this.fractionDone=n/2}_show(t,n){this.lerpCamera(n-t),this.fractionDone=n/2+.5}};$e.register("seamless",()=>new bi),E(bi,"desiredCameraOffset",new A(10,10,10)),E(bi,"snapshot",{});let Vl=bi;function yR(i,e,t){return i*(1-t)+e*t}const ey=["player-choice","player-anim","pawn-anim","enemy-anim","place-pawn","reached-chest","reward-choice","game-over"],In=["pawn","rook","knight","bishop","queen","king"],vR=[[0,0,0,255],[255,0,0,255],[0,255,0,255],[0,0,255,255]],An=30,Gl=Array.from({length:12},(i,e)=>e+1);function ty(i){return`${i.n}_${i.radius.toFixed(2)}_${i.angle.toFixed(2)}.png`}const ny=new Map,iy=10,sy=[];let vh=0;function Ug(i,e){return i.shapes.map((t,n)=>bR(t,e[n%2]))}function bR(i,e){const t=sy[vh];vh=(vh+1)%iy;const n=wR(i),s=t.getContext("2d");s.clearRect(0,0,n.width,n.height);const[r,o,l]=e;return s.globalCompositeOperation="copy",s.globalAlpha=1,Da(s,n,0),s.globalCompositeOperation="lighten",s.globalAlpha=r,Da(s,n,1),s.globalAlpha=o,Da(s,n,2),s.globalAlpha=l,Da(s,n,3),t}let Og=!1;async function MR(i,e=""){if(Og)throw new Error("preloadPixeltiles called multiple times");Og=!0;const t=[];for(const n of i){const s=ty(n),r=`${e}images/tile-shapes/${s}`;t.push(new Promise((o,l)=>{const c=new Image;c.onload=()=>{const u=c.width,d=c.height,a=document.createElement("canvas");a.width=u,a.height=d*4;const h=a.getContext("2d");for(let g=0;g<4;++g){h.drawImage(c,0,d*g);const _=h.getImageData(0,d*g,u,d),m=_.data;for(let p=0;p<m.length;p+=4)if(m[p+3]>0){const[x,b,v,P]=vR[g];m[p]=x,m[p+1]=b,m[p+2]=v,m[p+3]=P}h.putImageData(_,0,d*g)}const f=new Image;f.onload=()=>{ny.set(s,f),Di(f),o()},f.onerror=l,f.src=a.toDataURL()},c.onerror=l,c.src=r}))}await Promise.all(t);for(let n=0;n<iy;n++){const s=new OffscreenCanvas(Gl.length*An,An);Di(s),sy.push(s)}}function wR(i){const e=ty(i);return ny.get(e)}function SR(i,e){const{ctx:t,x:n,y:s,scale:r}=i,o=Gl[Math.max(0,Math.floor(r*Gl.length)-2)];ER(t,e,o,0,n,s)}function Da(i,e,t){const n=Gl.length*An,s=An;i.drawImage(e,0,t*An,n,s,0,0,n,s)}function ER(i,e,t,n,s,r){i.drawImage(e,t*An,n*An,An,An,s,r,An,An)}class Dn{constructor(){E(this,"config",fo);E(this,"prng",new ad(0));E(this,"xzScale",1)}refreshConfig(){this.config.refreshConfig(),this.xzScale=Math.pow(10,this.config.flatConfig.xzLogScale),this.prng=new ad(this.config.flatConfig.seed)}static register(e,t){if(e in this._registry)throw new Error(`TerrainGenerator already registered: '${e}'`);this._registry[e]=t}static create(e){const t=this._registry[e],n=t();return n.refreshConfig(),n}}E(Dn,"_registry",{});const Gi=new A,Ua=new A,Oa=new A;function AR(i,e){const t=i.ray;Gi.set(1/t.direction.x,1/t.direction.y,1/t.direction.z);let n=1/0,s;for(const r of e.grid.tileIndices){const o=e.members[r.i],l=e.tilePositions[r.i],c=o.height||1,u=.5;Ua.set(l.x-u,0,l.z-u),Oa.set(l.x+u,c,l.z+u);const d=(Ua.x-t.origin.x)*Gi.x,a=(Oa.x-t.origin.x)*Gi.x,h=(Ua.y-t.origin.y)*Gi.y,f=(Oa.y-t.origin.y)*Gi.y,g=(Ua.z-t.origin.z)*Gi.z,_=(Oa.z-t.origin.z)*Gi.z,m=Math.max(Math.max(Math.min(d,a),Math.min(h,f)),Math.min(g,_)),p=Math.min(Math.min(Math.max(d,a),Math.max(h,f)),Math.max(g,_));p<0||m>p||m>=0&&m<n&&(n=m,s=r)}return s}let sn,ti,zs,rs=!1,xi;const TR=[{on:["mouseleave"],action:(i,e)=>{}},{on:["mousemove","touchmove"],action:(i,e)=>{if(e.mousePosForTestSupport=i.screenPos,xi){const{defaultMat:o}=xi;o&&vr(xi,o),xi=void 0}const t=e.orbitControls,n=i.inputId===(sn==null?void 0:sn.inputId),s=i.inputId===(ti==null?void 0:ti.inputId);n&&(sn=i);let r=!1;if(!n&&!s&&(r=XC(i),!r&&i.pickedMesh&&!rs&&(xi=i.pickedMesh.gameElement,xi))){const{hoverMat:o,clickAction:l}=xi;o&&vr(xi,o),l&&(r=!0,document.documentElement.style.cursor="pointer")}if(!n&&!r&&sn&&(!ti||s))if(ti=i,typeof zs!="number")zs=i.screenPos.distanceTo(sn.screenPos);else{const o=i.screenPos.distanceTo(sn.screenPos),l=o-zs;zs=o;const c=.01*l;t._dollyOut(1+c)}if(n&&!r){const o=new MouseEvent("mousedown",{bubbles:!0,cancelable:!0,view:window,detail:1,screenX:i.screenPos.x,screenY:i.screenPos.y,clientX:i.screenPos.x,clientY:i.screenPos.y,button:0,buttons:1});t.enabled&&t._onMouseMove(o)}}},{on:["mousedown","touchstart"],action:(i,e)=>{if(e.transition)return;let t=GC(i);if(!t&&i.pickedMesh){const n=i.pickedMesh.gameElement;if(n){const{clickAction:s}=n;s&&(s({seaBlock:e,inputEvent:i}),t=!0)}}if(!t&&typeof sn>"u"){sn=i;const n=e.orbitControls,s=new MouseEvent("mousedown",{bubbles:!0,cancelable:!0,view:window,detail:1,screenX:i.screenPos.x,screenY:i.screenPos.y,clientX:i.screenPos.x,clientY:i.screenPos.y,button:0,buttons:1});n._onMouseDown(s)}}},{on:["mouseup","touchend","touchcancel"],action:(i,e)=>{if(i.inputId===(sn==null?void 0:sn.inputId)){const t=e.orbitControls;t.state=-1,zs=void 0,sn=void 0}i.inputId===(ti==null?void 0:ti.inputId)&&(zs=void 0,ti=void 0),WC(i)}}];function CR(i){const{layeredViewport:e}=i,{frontCanvas:t}=e;for(const{on:s,action:r}of TR)for(const o of s)t.addEventListener(o,l=>{DR(i,l,r)});const n=i.orbitControls;t.addEventListener("wheel",s=>{n._onMouseWheel(s)})}const bh=new xe,Mh=new xe,RR=new A(0,-1,0),PR=new ri(RR,sf.y);function IR(i){PR.constant=i}const Fa=new wb,LR=new A;function DR(i,e,t){if(rs&&e.type.startsWith("mouse"))return;const{terrain:n,layeredViewport:s,game:r,camera:o}=i,l=UR(e);for(const c of l){const u=c.screenPos;Mh.x=u.x/window.innerWidth*2-1,Mh.y=-(u.y/window.innerHeight)*2+1,Fa.setFromCamera(Mh,o);let d,a,h;const f=Fa.intersectObjects(r.pickableMeshes);f.length>0&&(d=f[0],a=f[0].object),h=AR(Fa,n),bh.x=u.x*s.pixelRatio,bh.y=u.y*s.pixelRatio,!rs&&e.type.startsWith("touch")&&(rs=!0),i.isUsingGamepad=!1,yr(),t({seaBlock:i,event:e,screenPos:u,lvPos:bh,raycaster:Fa,intersection:LR,rawPick:d,pickedMesh:a,pickedTile:h,inputId:c.touchId},i)}}function UR(i){const e=[];if("changedTouches"in i&&i.changedTouches.length>0)for(const t of i.changedTouches)typeof t.clientX=="number"&&typeof t.clientY=="number"?e.push({screenPos:new xe(t.clientX,t.clientY),touchId:t.identifier}):e.push({screenPos:new xe(t.pageX,t.pageY),touchId:t.identifier});else"clientX"in i&&"clientY"in i&&e.push({screenPos:new xe(i.clientX,i.clientY),touchId:"mouse"});return e}const ry={NAMES:["splash-screen","start-menu","start-sequence","free-cam","sphere-test","tile-inspector","chess","walking-cube","raft"]},OR={NAMES:["Michael2-3B","space-quest","all-ocean","flora-test","flat","chess"]},af={NAMES:["triangle","square","hex","octagon"]},FR={NAMES:["splash-screen","start-menu","free-cam","start-sequence","tile-inspector","chess","raft","empty","settings-menu","sprite-atlas"]},NR={children:{generator:{value:"Michael2-3B",options:OR.NAMES,resetOnChange:"full"},tiling:{value:"square",options:af.NAMES,resetOnChange:"full"},game:{value:"start-menu",options:ry.NAMES},freeCamLayout:{label:"Input Layout",value:"auto",options:["auto","desktop","landscape","portrait"]},testGui:{value:"none",options:["none","sprite-atlas"]},transitionMode:{label:"Transitions",value:"enabled",options:["enabled","skip"]}}},Bf=class Bf extends tt{constructor(){super(...arguments);E(this,"tree",NR)}};tt.register("top",()=>new Bf);let Fg=Bf;const yl=tt.create("top"),kR={children:{firstLink:{label:"Check me out on Github",action:()=>{window.open("https://github.com/tessmero/sea-block","_blank")},hasNoEffect:!0},...yl.tree.children,gfx:Jt.tree,physics:us.tree,freeCamGame:as.tree,michael:fo.tree,sounds:Ci.tree}},zf=class zf extends tt{constructor(){super(...arguments);E(this,"tree",kR)}};tt.register("sea-block",()=>new zf);let Ng=zf;const BR=tt.create("sea-block");function zR(i){const e=new $_;e.add(new bb(16777215,1));const t=new vb(16777215,1);if(t.position.set(5,10,5),e.add(t),i.terrain.subgroups.forEach(n=>n.addToScene(e)),i.floraGroup&&i.floraGroup.subgroups.forEach(n=>n.addToScene(e)),i.sphereGroup&&i.sphereGroup.subgroups.forEach(n=>n.addToScene(e)),i.game){const n=i.game;n.meshes.length>0&&e.add(...n.meshes)}return e.add(an),{threeScene:e,update:n=>{},add:(...n)=>e.add(...n),setBackground:n=>e.background=n}}class oy{}class HR extends oy{constructor(e){super(),this.terrain=e}step(e){if(this.terrain)for(const t of e)t.position.y>-1e3&&VR(t,this.terrain,us.flatConfig);for(let t=0;t<e.length;t++){const n=e[t];if(!(!n||n.isGhost))for(let s=t+1;s<e.length;s++){const r=e[s];!r||r.isGhost||GR(n,r,us.flatConfig)}}}}const wh=new A,Sh=new A;function VR(i,e,t){const{GRAVITY:n,AIR_RESISTANCE:s}=t;if(i.isGhost||(i.velocity.y-=n),i.isGhost?i.velocity.multiplyScalar(1-s*5):i.velocity.multiplyScalar(1-s),wh.copy(i.velocity).multiplyScalar(Ix),Sh.copy(i.position).add(wh),i.isGhost){const{x:r,z:o}=e.grid.positionToCoord(i.position.x,i.position.z),l=e.grid.xzToIndex(r,o);if(l){const c=e.members[l.i].height;Sh.y=c}i.velocity.y=0}else XR(i,e,Sh,t);i.position=i.position.add(wh)}function GR(i,e,t){const{SPHERE_COHESION:n,SPHERE_STIFFNESS:s,SPHERE_DAMPING:r}=t,o=e.position.x-i.position.x,l=e.position.y-i.position.y,c=e.position.z-i.position.z,u=o*o+l*l+c*c;if(u===0)return;const d=2*nf;if(u<d*d){const a=d*(1-n),h=Math.sqrt(u),f=a-h,g=s*f,_=o/h,m=l/h,p=c/h,x=e.velocity.x-i.velocity.x,b=e.velocity.y-i.velocity.y,v=e.velocity.z-i.velocity.z,P=x*_+b*m+v*p,C=-r*P,T=g+C;i.velocity.x-=_*T,i.velocity.y-=m*T,i.velocity.z-=p*T,e.velocity.x+=_*T,e.velocity.y+=m*T,e.velocity.z+=p*T}}const WR=(()=>{const i=vC,e=[];let t=0,n=0,s=0,r=-1;const o=i*2+1,l=o*o;for(let c=0;c<l;c++)Math.abs(t)<=i&&Math.abs(n)<=i&&e.push({dx:t,dz:n}),(t===n||t<0&&t===-n||t>0&&t===1-n)&&([s,r]=[-r,s]),t+=s,n+=r;return e})();function XR(i,e,t,n){const{BUOYANT_FORCE:s,PRESSURE_FORCE:r,RESTITUTION:o}=n,l=e.grid,{x:c,z:u}=l.positionToCoord(t.x,t.z);for(const{dx:d,dz:a}of WR){const h=c+d,f=u+a,g=l.xzToIndex(h,f);if(!g)continue;const _=e.members[g.i],m=$R(_,t);if(m){if(_.isWater)i.velocity.y+=s,e.sim.accelTile(g,r*i.scalePressure);else if(!i.isFish){i.position=m.adjustedPosition;const p=i.velocity.x*m.normal.x+i.velocity.y*m.normal.y+i.velocity.z*m.normal.z,x=-(1+o)*p*m.normal.x,b=-(1+o)*p*m.normal.y,v=-(1+o)*p*m.normal.z;i.velocity.x+=x,i.velocity.y+=b,i.velocity.z+=v}}}}const ni=new A;function $R(i,e){const{x:t,z:n}=i.position,s=i.height,r=s/2,o=2,l=t-o,c=t+o,u=r-s/2,d=r+s/2,a=n-o,h=n+o,f=nf,g=Math.max(l,Math.min(e.x,c)),_=Math.max(u,Math.min(e.y,d)),m=Math.max(a,Math.min(e.z,h)),p=e.x-g,x=e.y-_,b=e.z-m,v=p*p+x*x+b*b;if(v>f*f)return null;const P=i.normal,C=Math.sqrt(v),T=C>0;if(T){const D=f-C;ni.set(e.x+P.x*D,e.y+P.y*D,e.z+P.z*D)}else{const D=[Math.abs(e.x-l),Math.abs(e.x-c),Math.abs(e.y-u),Math.abs(e.y-d),Math.abs(e.z-a),Math.abs(e.z-h)],w=Math.min(...D),M=D.indexOf(w);ni.copy(e),M===0?ni.x=l-f:M===1?ni.x=c+f:M===2?ni.y=u-f:M===3?ni.y=d+f:M===4?ni.z=a-f:M===5&&(ni.z=h+f)}return{normal:P,adjustedPosition:ni,isCenterOutside:T}}class YR{constructor(e,t){E(this,"n");E(this,"mesh");E(this,"memberIds",[]);E(this,"_counter",0);this.offset=t,this.n=e.n,e.geometry instanceof Ut?this.mesh=new Zt(e.geometry,new gr({color:16777215,flatShading:!0}),this.n):this.mesh=new ix(e.geometry,this.n)}addToScene(e){this.mesh instanceof Zt?e.add(this.mesh):e.add(...this.mesh.meshes)}setInstanceColor(e,t){if(this.mesh instanceof Zt)this.mesh.setColorAt(e,t);else throw new Error("subgroups with tile mesh should use setColorsForTile")}resetCount(){this._counter=0}reachedCountLimit(){return this._counter>=this.n}setMemberMatrix(e,t){const n=this._counter++;return this.mesh.setMatrixAt(n,t),this.memberIds[n]=e,n}finalizeCount(){this.mesh.count=this._counter}}class lf{constructor(e){E(this,"n");E(this,"sim");E(this,"subgroupsByFlatIndex");E(this,"members",[]);E(this,"subgroups",[]);this.sim=e.sim,this.n=0;for(const t of e.subgroups)this.subgroups.push(new YR(t,this.n)),this.n+=t.n;this.subgroupsByFlatIndex=[],e.subgroupsByFlatIndex.forEach(({subgroupIndex:t,indexInSubgroup:n})=>{this.subgroups[t].memberIds.push(this.subgroupsByFlatIndex.length),this.subgroupsByFlatIndex.push([this.subgroups[t],n])})}setInstanceColor(e,t){const[n,s]=this.subgroupsByFlatIndex[e];n.setInstanceColor(s,t)}setMemberMatrix(e,t){const[n,s]=this.subgroupsByFlatIndex[e];n.mesh.setMatrixAt(s,t)}build(){return us.refreshConfig(),this.members=this.buildMembers(),this._needsUpdate(),this}update(e,t,n){for(let s=0;s<n;s++)this.sim.step(this.members);this.updateMeshes(e,t),this._needsUpdate()}_needsUpdate(){this.subgroups.forEach(({mesh:e})=>{e instanceof Zt?(e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0),e.frustumCulled=!1):e.queueUpdate()})}}const oo=class oo{constructor(e,t,n){E(this,"posArray");E(this,"offset");if(this.index=e,this.indexInSubgroup=n,t.mesh instanceof Zt)this.posArray=t.mesh.instanceMatrix.array;else throw new Error("should use TileMeshIm for subgroup with TileMesh");this.offset=n*16+12}get y(){return this.posArray[this.offset+1]}get position(){const{posArray:e}=this;let{offset:t}=this;return oo.positionDummy.set(e[t++],e[t++],e[t++]),oo.positionDummy}set position(e){const{posArray:t}=this;let{offset:n}=this;t[n++]=e.x,t[n++]=e.y,t[n++]=e.z}};E(oo,"positionDummy",new A);let ld=oo;class qR extends ld{constructor(){super(...arguments);E(this,"velocity",new A(0,0,0));E(this,"isGhost",!0);E(this,"isVisible",!1);E(this,"isFish",!1);E(this,"scalePressure",1)}}class jR extends lf{constructor(t,n){super({sim:new HR(n),subgroups:[{n:t,geometry:new Do(nf,16,16)}],subgroupsByFlatIndex:Array.from({length:t},(s,r)=>r).map(s=>({subgroupIndex:0,indexInSubgroup:s}))});E(this,"terrain",null);this.n=t}buildMembers(){const t=[],n=Array.from({length:this.n},(r,o)=>new A(0,o*10,0)),s=Array.from({length:this.n},(r,o)=>new se().setHSL(o/10,.8,.5));for(let r=0;r<n.length;r++){const o=new qR(r,this.subgroups[0],r);o.position=n[r],t.push(o),this.setInstanceColor(r,s[r])}return t}updateMeshes(){for(let t=0;t<this.n;t++){const n=this.members[t];n?(Hs.position.set(n.position.x,n.position.y,n.position.z),n.isVisible?Hs.scale.set(1,1,1):Hs.scale.set(0,0,0)):Hs.position.set(0,-9999,0),Hs.updateMatrix(),this.setMemberMatrix(t,Hs.matrix)}}}const Hs=new gt;class ay extends oy{constructor(t){super();E(this,"n");E(this,"springs");this.grid=t,this.springs=KR(t),this.n=t.n}}function KR(i){return i.springsForTileSim||(i.springsForTileSim=ZR(i)),i.springsForTileSim}function ZR(i){const e=1/Math.SQRT2,{width:t,depth:n}=i,s=[];for(const{x:r,z:o,i:l}of i.tileIndices){const c=[...i.tiling.getAdjacent(r,o).map(({x:u,z:d})=>[u,d,1]),...i.tiling.getDiagonal(r,o).map(({x:u,z:d})=>[u,d,e])];for(const[u,d,a]of c){const h=(r+u+t)%t,f=(o+d+n)%n,g=i.xzToIndex(h,f);if(!g)throw new Error(`initial grid is missing tile (${h},${f})`);const _=g.i;l<_&&s.push({indexA:l,indexB:_,weight:a})}}return s}class JR extends ay{constructor(t){super(t);E(this,"pos");E(this,"vel");this.pos=new Float32Array(this.n),this.vel=new Float32Array(this.n)}step(t){const{WATER_FRICTION:n,WATER_CENTERING:s,WATER_DAMPING:r,WATER_SPRING:o}=us.flatConfig,l=1-n;for(const{indexA:c,indexB:u,weight:d}of this.springs){if(!t[c].isWater||!t[u].isWater)continue;const a=this.pos[u]-this.pos[c],h=this.vel[u]-this.vel[c],f=a*d*o,g=h*r,_=f+g;this.vel[c]+=_,this.vel[u]-=_}for(let c=0;c<this.n;c++){let u=this.pos[c],d=this.vel[c];const a=-u*s;d=d+a,u=u+d,d=d*l,this.pos[c]=u,this.vel[c]=d}}getWavePos(t){return this.pos[t]*us.flatConfig.WAVE_AMPLITUDE}hitTile(t,n,s){this.vel[s]+=-.002}accelTile(t,n){this.vel[t.i]-=n}resetTile(t){this.pos[t]=Math.max(-0,Math.min(0,this.pos[t]));const s=.001;Math.max(-s,Math.min(s,this.vel[t]))}}function vl(i,e){const{x:t,z:n}=i,s=Math.abs((t+n)%2),r=e&&kg[e]?kg[e][s]:bl[s];return{top:r.top,sides:r.sides}}const bl=[{top:new se("#E1E2EF"),sides:new se("#C1C2CF")},{top:new se("#D1BB9E"),sides:new se("#A79277")}],kg={hold:[{top:new se("#B3CFFF"),sides:new se("#7FA7E0")},{top:new se("#8aabe3"),sides:new se("#4f6584")}],hover:[{top:new se("#B3CFFF"),sides:new se("#7FA7E0")},{top:new se("#8aabe3"),sides:new se("#4f6584")}],allowedMove:[{top:new se("#81E28F"),sides:new se("#71C27F")},{top:new se("#41BB6E"),sides:new se("#379247")}],enemyMove:[{top:new se("#FF8A8A"),sides:new se("#E05A5A")},{top:new se("#D14A4A"),sides:new se("#A72A2A")}]},ly=["rook"],cy=1,Ze={hasSwitchedPiece:!1,hasPlacedPawn:!1,collectedPawns:cy,collected:[...ly],completedLevels:[]};function Bg(i){const e=QR(i);return e[Math.floor(Math.random()*e.length)]}function QR(i){const e=[];for(const t in $n)$n[t].isValid(i)&&e.push(t);return e}const $n={"dual-vector-foil":{title:"Downgrade",description:`
      Reduce to 2D
      prevents exploration
    `,icon:"icons/16x16-arrow-down.png",isValid:()=>!Ze.collected.includes("dual-vector-foil")&&Ze.collected.includes("king")},pawn:{title:"+1 Pawn",description:`

    `,icon:"icons/chess/16x16-pawn.png",isValid:()=>!0,collectAction:()=>{Ze.collectedPawns++,cf()}},rook:{title:"Unlock Rook",description:`
    
    `,icon:"icons/chess/16x16-rook.png",isValid:()=>!Ze.collected.includes("rook")},bishop:{title:"Unlock Bishop",description:`
    
    `,icon:"icons/chess/16x16-bishop.png",isValid:()=>!Ze.collected.includes("bishop")},knight:{title:"Unlock Knight",description:`
    
    `,icon:"icons/chess/16x16-knight.png",isValid:()=>!Ze.collected.includes("knight")&&Ze.collected.includes("bishop")},queen:{title:"Unlock Queen",description:`
    
    `,icon:"icons/chess/16x16-queen.png",isValid:()=>!Ze.collected.includes("queen")&&Ze.collected.includes("knight")},king:{title:"Unlock King",description:`
    
    `,icon:"icons/chess/16x16-king.png",isValid:()=>!Ze.collected.includes("king")&&Ze.collected.includes("queen")}},Zr={layoutKey:"flatViewport",isPickable:!1,display:{type:"diagram",label:"chess-flat-viewport",isVisible:!1,shouldClearBehind:!0}},eP={layoutKey:"pawnHint",display:{type:"label",label:"Place Pawn",shouldClearBehind:!0,isVisible:!1}},hy={layoutKey:"topLeftDisplay",display:{type:"diagram",label:"chess-goal-a",shouldClearBehind:!0}},uy={layoutKey:"topLeftDisplay",display:{type:"diagram",label:"chess-goal-b",shouldClearBehind:!0,isVisible:!1}},tP={layoutKey:"topRightBtn",hotkeys:["Escape","ButtonStart"],display:{type:"button",icon:"icons/16x16-config.png",gamepadPrompt:{name:"start",offset:[-16,0]}},clickAction:({seaBlock:i})=>{W.currentPhase==="game-over"&&(Ye("click"),vf()),i.toggleSettings(),i.refreshGui()}};function dy(i){var l;for(const c of zg)c.display.isVisible=!1;const e=In.indexOf(i);zg[e].display.isVisible=!0;const t=(l=iP.display.imageset)==null?void 0:l.default;if(!t)return;const n=wt(`icons/chess/16x16-${i}.png`),s=t.getContext("2d"),{width:r,height:o}=t;s.clearRect(0,0,r,o),s.drawImage(n,(r-n.width)/2,(o-n.height)/2),Ml(i)}const nP="rook",zg=In.map(i=>({layoutKey:"currentPieceLabel",isPickable:!1,display:{type:"label",label:i.toUpperCase(),font:"default",textAlign:"left",isVisible:i===nP}})),iP={display:{}},Xi={layoutKey:"pawnBtn",display:{type:"button",gamepadPrompt:{name:"B",offset:[-20,0]}},hotkeys:["ButtonB"],clickAction:()=>{Ye("click"),W.startPlacePawn()}},fy={layoutKey:"pawnBtn",isPickable:!1,display:{type:"diagram",label:"pawn-button-label"}},$i={layoutKey:"cancelPawnBtn",display:{type:"button",label:"CANCEL",gamepadPrompt:{name:"B",offset:[-30,0]}},hotkeys:["ButtonB"],clickAction:()=>{Ye("click"),W.cancelPlacePawn()}},py=[hy.display,uy.display],zr=Zr.display,sP=[hy,uy,tP,eP,Xi,fy,$i,Zr],rP=new se(0),oP=new se(11193599);function cf(){var u;const i=fy,e=(u=i.display.imageset)==null?void 0:u.default;if(!e)throw new Error(`chess pawn button label with layout key ${i.layoutKey} has no buffer`);const{width:t,height:n}=e,s=e.getContext("2d");s.clearRect(0,0,t,n),ps(s,{width:t,height:n,label:`${Ze.collectedPawns}`,offset:[-10,0]});const r=wt("icons/chess/8x8-pawn.png"),o=r.width,l=(e.width-o)/2,c=(e.height-o)/2;s.drawImage(r,l+10,c,o,o)}function Hg(i,e){var u;const t=(u=i.display.imageset)==null?void 0:u.default;if(!t)throw new Error(`chess reward diagram element with layout key ${i.layoutKey} has no buffer`);const{icon:n}=$n[e],s=wt(n),r=t.getContext("2d");r.clearRect(0,0,t.width,t.height);const o=s.width,l=(t.width-o)/2,c=(t.height-o)/2;r.drawImage(s,l,c,o,o)}function Ml(i){var t;let e=0;for(const n of py){const s=(t=n==null?void 0:n.imageset)==null?void 0:t.default;if(!s)throw new Error("chess goal diagram element has no buffer");aP(s,i,e-1),n.needsUpdate=!0,e++}}function aP(i,e,t=0){const{width:n,height:s}=i,r=i.getContext("2d");r.clearRect(0,0,i.width,i.height);const o=wt(`icons/chess/16x16-${e}.png`),l=wt("icons/16x16-arrow-right.png"),c=wt("icons/chess/16x16-chest.png"),u=16,d=-6,a=u*3+d*2,h=(n-a)/2,f=(s-u)/2;r.drawImage(o,h,f,u,u),r.drawImage(l,h+t+u+d,f,u,u),r.drawImage(c,h+2*(u+d),f,u,u)}const Eh=5,vt=16;function lP(i){var t;const e=(t=zr==null?void 0:zr.imageset)==null?void 0:t.default;if(!e)throw new Error("flat viewport diagram element has no buffer");zr.isVisible=!0,zr.needsUpdate=!0,cP(e,i)}function cP(i,e){const t=i.getContext("2d"),{centerTile:n,goalTile:s,player:r,pawns:o,enemies:l}=e;t.clearRect(0,0,i.width,i.height);const c=Math.floor(Eh/2),u=Math.floor(Eh/2),d=Eh*vt,a=(i.width-d)/2,h=(i.height-d)/2,f=e.getPosOnTile(n,new A);for(let T=-2;T<=2;T++)for(let D=-2;D<=2;D++){const w=e.context.terrain.grid.xzToIndex(n.x+D,n.z+T);if(!w)continue;const M=e.getPosOnTile(w),I=a+(c+(M.x-f.x))*vt,B=h+(u+(M.z-f.z))*vt;Vg(t,I,B,e.context.terrain.grid.tiling,w),gy(w)&&Vg(t,I,B+1,e.context.terrain.grid.tiling,w)}const g=Uh(r),_=a+(c+(g.x-f.x))*vt,m=h+(u+(g.z-f.z))*vt,p=wt(`icons/chess/16x16-${r.type}.png`);t.drawImage(p,_,m,vt,vt);const x=wt("icons/chess/16x16-pawn.png");for(const T of o){const D=Uh(T),w=a+(c+(D.x-f.x))*vt,M=h+(u+(D.z-f.z))*vt;t.drawImage(x,w,M,vt,vt)}for(const T of l){const D=Uh(T),w=a+(c+(D.x-f.x))*vt,M=h+(u+(D.z-f.z))*vt,I=my[T.type];I&&t.drawImage(I,w,M,vt,vt)}const b=e.context.terrain.grid.indexToPosition(s),v=a+(c+(b.x-f.x))*vt,P=h+(u+(b.z-f.z))*vt,C=wt("icons/chess/16x16-chest.png");t.drawImage(C,v,P,vt,vt)}function Vg(i,e,t,n,s){const r=Jx(s);i.fillStyle=r.top.getStyle(),i.fillRect(e,t,vt,vt),i.strokeStyle=r.sides.getStyle(),i.lineWidth=1,i.strokeRect(e+.5,t+.5,vt-1,vt-1)}const my={},hP=[200,0,0,255];async function uP(){const i=[];for(const e of In){const t=wt(`icons/chess/16x16-${e}.png`),n=t.width,s=t.height;i.push(new Promise((r,o)=>{const l=document.createElement("canvas");l.width=n,l.height=s;const c=l.getContext("2d");c.drawImage(t,0,0);const u=c.getImageData(0,0,n,s),d=u.data;for(let h=0;h<d.length;h+=4)if(d[h+3]>0){const[f,g,_,m]=hP;d[h]=f,d[h+1]=g,d[h+2]=_,d[h+3]=m}c.putImageData(u,0,0);const a=new window.Image;a.onload=()=>{my[e]=a,Di(a),r()},a.onerror=o,a.src=l.toDataURL()}))}}function dP(i){if("lvPos"in i&&Ze.collected.includes("dual-vector-foil")){const e=Oo(i);e&&Jr(e,i.inputId)}}function fP(i){if("lvPos"in i&&Ze.collected.includes("dual-vector-foil")){const e=Oo(i);e&&Qr(e,i.inputId)}}function pP(i){if(W.currentPhase!=="game-over"){if(Ze.collected.includes("dual-vector-foil")){const e=Oo(i);Ah(e,i)}else if(W.currentPhase!=="reward-choice"){const e=df(i);Ah(e?e.tile:i.pickedTile,i)}}}function mP(i){if(i.seaBlock.toggleSettings(!1),W.currentPhase==="game-over")return!1;if(Ze.collected.includes("dual-vector-foil")){const e=Oo(i);if(e)return Jr(e,i.inputId),!0}else if(W.currentPhase!=="reward-choice"){const e=df(i);if(e)return Jr(e.tile,i.inputId),!0;const{pickedTile:t}=i,n=t;return!n||!W.hlTiles.allowedMoves.has(n.i)?!1:(Jr(n,i.inputId),!0)}return!1}function gP(i){if(Ze.collected.includes("dual-vector-foil")){const e=Oo(i);e&&Qr(e,i.inputId)}else if(W.currentPhase!=="reward-choice"){const e=df(i);e?Qr(e.tile,i.inputId):i.pickedTile?Qr(i.pickedTile,i.inputId):Ye("chessCancel")}}const hn={},hf=500;function gy(i){const{i:e}=i;for(const t of Object.values(hn))if(t&&t.tile.i===e)return!0}function uf(){for(const i in hn)delete hn[i]}function _P(){const i=performance.now();for(const e in hn){const t=hn[e];i-(t==null?void 0:t.time)>hf&&(Ye("chessCancel"),delete hn[e])}}function Ah(i,e){const{inputId:t}=e;if(t in hn){const{time:n,tile:s}=hn[t],r=performance.now()-n;if((i==null?void 0:i.i)!==s.i||r>hf){Ye("chessCancel"),delete hn[t];return}}return(!i||!W.hlTiles.allowedMoves.has(i.i))&&(i=void 0),rs||(W.hlTiles.hovered=i),i&&(document.documentElement.style.cursor="pointer"),!1}function Jr(i,e){Ye("chessClick"),hn[e]={time:performance.now(),tile:i}}function Qr(i,e){if(e in hn){const{tile:t,time:n}=hn[e];if(delete hn[e],t.i!==i.i){Ye("chessCancel");return}if(performance.now()-n>hf){Ye("chessCancel");return}xP(t)}}function xP(i){if(W.hlTiles.allowedMoves.has(i.i)){if(W.currentPhase==="player-choice")W.movePlayerToTile(i);else if(W.currentPhase==="place-pawn"){if(Ze.hasPlacedPawn=!0,!wr.pawn)throw new Error("missing pawn mesh");const t=gd("pawn",i,!1);W.pawns.push(t),Si(t,W.getPosOnTile(i)),W.cancelPlacePawn(),Ze.collectedPawns--,cf()}}else Ye("chessCancel")}function yP(i){const e=it.create("chess"),t="flatViewport",n=e.overrideLayoutRectangles[t]||e.layoutRectangles[t];if(!n)return;const s=16,r=3+i.x-W.centerTile.x,o=3+i.z-W.centerTile.z,l=n.x+r*s,c=n.y+o*s;return{x:l,y:c,w:s,h:s}}function Oo(i){const{lvPos:e}=i,{gui:t}=i.seaBlock.game;if(e){const n="flatViewport",s=t.overrideLayoutRectangles[n]||t.layoutRectangles[n];if(s){const{x:r,y:o,w:l,h:c}=s;if(e.x>=r&&e.x<r+l&&e.y>=o&&e.y<o+c){const u=(e.x-r)/16,d=(e.y-o)/16;return W.context.terrain.grid.xzToIndex(Math.floor(W.centerTile.x+u-3),Math.floor(W.centerTile.z+d-3))}}}}function df(i){const{pickedMesh:e}=i;if(e){const t=e.gameElement;if(t===jl)return{tile:W.goalTile};if(t===W.playerElement)return{tile:W.player.tile};if(t&&"pieceType"in t){const n=t.pieceType,{instanceId:s}=i.rawPick;if(typeof s=="number")return W.identifyPiece(n,s)}}}let Na;const ff={setChess:i=>{Na=i},update:i=>{},steps:[...dc.steps,({group:i,tileIndex:e,current:t})=>{const{x:n,z:s,i:r}=e;if(!Na.boardTiles.includes(r))return cR(e),t;const o=Math.abs((n+s)%2);let l=i.generatedTiles[r];return l||(Mo.queueHltUpdate(),l={gTile:{color:bl[o].top,isWater:!1,isFlora:!1,height:10+o}},i.generatedTiles[r]=l),Zx(e,bl[o]),{targetColors:bl[o],isWater:!1,isFlora:!1,height:12+.1*o,isVisible:!0,yOffset:0}},({current:i,tileIndex:e})=>{const{allowedMoves:t}=Na.hlTiles,{i:n}=e;return t.has(n)&&(i.isWater?Mo.queueHltUpdate():i.targetColors=vl(e,"allowedMove")),i},({current:i,tileIndex:e})=>{const{hovered:t}=Na.hlTiles;return t&&t.i===e.i&&(i.targetColors=vl(e,"hover")),i},({current:i,tileIndex:e})=>(gy(e)&&(i.targetColors=vl(e,"hold"),i.height-=.1),i)]},Vs=new gt;class vP{constructor(e){E(this,"amplitude",20);this.group=e}updateTileMeshes(e,t){const{group:n}=this;hR(Math.min(1,.008*t));const s=e.game.getTerrainRenderPipeline,{style:r}=e;dc.update(t),ff.update(t);for(const o of n.subgroups)o.resetCount();for(const o of n.grid.tileIndices){const l=s(o),c=this.getFullStepsToRun(l,e);this._updateRenderInstance(c,r,o)}for(const o of n.subgroups)o.finalizeCount()}getFullStepsToRun(e,t){var r;const n=[...e.steps],s=(r=t.transition)==null?void 0:r.getExtraPipelineStep();return s&&n.push(s),n}_updateRenderInstance(e,t,n){const{group:s}=this,{x:r,z:o,i:l}=n;if(typeof r>"u")throw new Error(`grid has no xz for memberIndex ${l}`);const c=s.grid.tiling.getShapeIndex(r,o);if(c<0||c>=s.subgroups.length)throw new Error(`grid has invalide shapeIndex ${c} at xz ${r}, ${o}`);const u=s.subgroups[c];if(u.reachedCountLimit())return!1;if(s.subgroupsByFlatIndex[l][0]!==u)throw new Error("subgroup changed");let d={height:0,yOffset:0};for(const b of e){const v=b({group:this.group,current:d,tileIndex:n,style:t});if(!v)return!0;d=v}const{height:a,yOffset:h,targetColors:f}=d;f&&lR(n,f);const g=s.generatedTiles[l];if(!g)return!0;s.members[l].height=a;const _=-Jt.flatConfig.extendBottom/this.amplitude,m=s.tilePositions[l];Vs.position.set(m.x,Math.max(_,a/2+_/2)+h,m.z),Vs.scale.set(1,Math.max(0,a-_),1),g.liveHeight=Vs.position.y+Vs.scale.y/2,Vs.updateMatrix();const p=u.setMemberMatrix(l,Vs.matrix);return s.subgroupsByFlatIndex[l]=[u,p],u.mesh.setColorsForInstance(p,Jx(n)),!0}getNewRenderHeight(e,t){return e.isWater?(this.group.sim.resetTile(t),this.getAnimatedRenderHeight(e.height,this.group.sim.getWavePos(t))):this.getAnimatedRenderHeight(e.height,0)}_dampedAnim(e,t){if(e>t)return 0;const n=Math.min(e/t,1);return 1-(1-Math.pow(1-n,4))}getLiveHeight(e){var t;return(t=this.group.generatedTiles[e.i])==null?void 0:t.liveHeight}getAnimatedRenderHeight(e,t){return e*this.amplitude/255+1+t}}const ka=new gt,Gg=new A;class bP extends lf{constructor(t,n){const s=t.tiling.shapes.map(o=>cA(o)).map(o=>({n:0,geometry:o})),r=[];for(const{x:o,z:l}of t.tileIndices){const c=t.tiling.getShapeIndex(o,l);r.push({subgroupIndex:c,indexInSubgroup:s[c].n}),s[c].n++}super({sim:new JR(t),subgroups:s,subgroupsByFlatIndex:r});E(this,"tilePositions",[]);E(this,"generatedTiles",[]);E(this,"gfxHelper");E(this,"_offsetX",0);E(this,"_offsetZ",0);E(this,"centerXZ",{x:0,z:0});this.grid=t,this.seaBlock=n,this.gfxHelper=new vP(this),Jt.refreshConfig()}get generator(){return this.seaBlock.generator}updateMeshes(t,n){this.gfxHelper.updateTileMeshes(t,n)}buildTileMember(t){const{i:n,x:s,z:r}=t,o=wP,l=[],{width:c,depth:u}=this.grid;for(const{x:a,z:h}of o){const f=(s+a+c)%c,g=(r+h+u)%u,_=this.grid.xzToIndex(f,g).i;l.push(_)}return new MP(this,n,l)}generateTile(t){const{i:n,x:s,z:r}=t,o={gTile:this.generator.getTile(s,r)};return this.generatedTiles[n]=o,n<this.members.length&&(this.members[n].isWater=o.gTile.isWater,this.members[n].isFlora=o.gTile.isFlora),o}build(){return super.build(),this.resetColors(),this}buildMembers(){const t=[];for(const n of this.grid.tileIndices){const{i:s}=n,{x:r,z:o}=this.grid.indexToPosition(n),l=1;ka.position.set(r,l/2,o),this.tilePositions[s]={x:r,z:o},ka.scale.set(1,l,1),ka.updateMatrix(),this.setMemberMatrix(s,ka.matrix),t.push(this.buildTileMember(n))}return t}panToCenter(t,n){this.centerXZ={x:t,z:n};const{x:s,z:r}=this.grid.positionToCoord(t,n),o=this.grid.width,l=this.grid.depth,c=s-Math.floor(o/2),u=r-Math.floor(l/2);let d=c-this._offsetX,a=u-this._offsetZ;for(;Math.abs(d)>0;){const h=Math.sign(d);this.pan(h,0),d-=h}for(;Math.abs(a)>0;){const h=Math.sign(a);this.pan(0,h),a-=h}}pan(t,n){const s=this.grid.width,r=this.grid.depth,o=this._offsetX,l=this._offsetZ;if(t!==0){const c=o+(t>0?0:s-1),u=o+(t>0?s:-1);for(let d=l;d<l+r;d++){const a=this.grid.xzToIndex(c,d);a&&(this.grid.updateMapping(a,u,d),this.generatedTiles[a.i]=null,this.tilePositions[a.i]=this.grid.indexToPosition(a))}}else if(n!==0){const c=l+(n>0?0:r-1),u=l+(n>0?r:-1);for(let d=o;d<o+s;d++){const a=this.grid.xzToIndex(d,c);a&&(this.grid.updateMapping(a,d,u),this.generatedTiles[a.i]=null,this.tilePositions[a.i]=this.grid.indexToPosition(a))}}this._offsetX+=t,this._offsetZ+=n}resetColors(){this.generatedTiles.fill(null)}}class MP extends td{constructor(t,n,s){super(n,t,t.subgroupsByFlatIndex[n][0]);E(this,"wavePos",0);E(this,"height",0);E(this,"isWater",!1);E(this,"isFlora",!1);E(this,"isVisible",!1);this.normalNeighborIds=s}get normal(){const t=this.normalNeighborIds.map(n=>this.group.members[n].height);return SP(t)}}const wP=[{x:1,z:0},{x:-1,z:0},{x:0,z:1},{x:0,z:-1}];function SP(i){const[e,t,n,s]=i,r=(t-e)*.5,o=(s-n)*.5;return Gg.set(r,2,o).normalize(),Gg}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class Vn{constructor(e,t,n,s,r="div"){this.parent=e,this.object=t,this.property=n,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(r),this.domElement.classList.add("controller"),this.domElement.classList.add(s),this.$name=document.createElement("div"),this.$name.classList.add("name"),Vn.nextNameID=Vn.nextNameID||0,this.$name.id=`lil-gui-name-${++Vn.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",o=>o.stopPropagation()),this.domElement.addEventListener("keyup",o=>o.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(n)}name(e){return this._name=e,this.$name.textContent=e,this}onChange(e){return this._onChange=e,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(e){return this._onFinishChange=e,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(e=!0){return this.disable(!e)}disable(e=!0){return e===this._disabled?this:(this._disabled=e,this.domElement.classList.toggle("disabled",e),this.$disable.toggleAttribute("disabled",e),this)}show(e=!0){return this._hidden=!e,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(e){const t=this.parent.add(this.object,this.property,e);return t.name(this._name),this.destroy(),t}min(e){return this}max(e){return this}step(e){return this}decimals(e){return this}listen(e=!0){return this._listening=e,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const e=this.save();e!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=e}getValue(){return this.object[this.property]}setValue(e){return this.getValue()!==e&&(this.object[this.property]=e,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(e){return this.setValue(e),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class EP extends Vn{constructor(e,t,n){super(e,t,n,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function cd(i){let e,t;return(e=i.match(/(#|0x)?([a-f0-9]{6})/i))?t=e[2]:(e=i.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?t=parseInt(e[1]).toString(16).padStart(2,0)+parseInt(e[2]).toString(16).padStart(2,0)+parseInt(e[3]).toString(16).padStart(2,0):(e=i.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(t=e[1]+e[1]+e[2]+e[2]+e[3]+e[3]),t?"#"+t:!1}const AP={isPrimitive:!0,match:i=>typeof i=="string",fromHexString:cd,toHexString:cd},yo={isPrimitive:!0,match:i=>typeof i=="number",fromHexString:i=>parseInt(i.substring(1),16),toHexString:i=>"#"+i.toString(16).padStart(6,0)},TP={isPrimitive:!1,match:i=>Array.isArray(i),fromHexString(i,e,t=1){const n=yo.fromHexString(i);e[0]=(n>>16&255)/255*t,e[1]=(n>>8&255)/255*t,e[2]=(n&255)/255*t},toHexString([i,e,t],n=1){n=255/n;const s=i*n<<16^e*n<<8^t*n<<0;return yo.toHexString(s)}},CP={isPrimitive:!1,match:i=>Object(i)===i,fromHexString(i,e,t=1){const n=yo.fromHexString(i);e.r=(n>>16&255)/255*t,e.g=(n>>8&255)/255*t,e.b=(n&255)/255*t},toHexString({r:i,g:e,b:t},n=1){n=255/n;const s=i*n<<16^e*n<<8^t*n<<0;return yo.toHexString(s)}},RP=[AP,yo,TP,CP];function PP(i){return RP.find(e=>e.match(i))}class IP extends Vn{constructor(e,t,n,s){super(e,t,n,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=PP(this.initialValue),this._rgbScale=s,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const r=cd(this.$text.value);r&&this._setValueFromHexString(r)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(e){if(this._format.isPrimitive){const t=this._format.fromHexString(e);this.setValue(t)}else this._format.fromHexString(e,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(e){return this._setValueFromHexString(e),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class Th extends Vn{constructor(e,t,n){super(e,t,n,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",s=>{s.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class LP extends Vn{constructor(e,t,n,s,r,o){super(e,t,n,"number"),this._initInput(),this.min(s),this.max(r);const l=o!==void 0;this.step(l?o:this._getImplicitStep(),l),this.updateDisplay()}decimals(e){return this._decimals=e,this.updateDisplay(),this}min(e){return this._min=e,this._onUpdateMinMax(),this}max(e){return this._max=e,this._onUpdateMinMax(),this}step(e,t=!0){return this._step=e,this._stepExplicit=t,this}updateDisplay(){const e=this.getValue();if(this._hasSlider){let t=(e-this._min)/(this._max-this._min);t=Math.max(0,Math.min(t,1)),this.$fill.style.width=t*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?e:e.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const t=()=>{let x=parseFloat(this.$input.value);isNaN(x)||(this._stepExplicit&&(x=this._snap(x)),this.setValue(this._clamp(x)))},n=x=>{const b=parseFloat(this.$input.value);isNaN(b)||(this._snapClampSetValue(b+x),this.$input.value=this.getValue())},s=x=>{x.key==="Enter"&&this.$input.blur(),x.code==="ArrowUp"&&(x.preventDefault(),n(this._step*this._arrowKeyMultiplier(x))),x.code==="ArrowDown"&&(x.preventDefault(),n(this._step*this._arrowKeyMultiplier(x)*-1))},r=x=>{this._inputFocused&&(x.preventDefault(),n(this._step*this._normalizeMouseWheel(x)))};let o=!1,l,c,u,d,a;const h=5,f=x=>{l=x.clientX,c=u=x.clientY,o=!0,d=this.getValue(),a=0,window.addEventListener("mousemove",g),window.addEventListener("mouseup",_)},g=x=>{if(o){const b=x.clientX-l,v=x.clientY-c;Math.abs(v)>h?(x.preventDefault(),this.$input.blur(),o=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(b)>h&&_()}if(!o){const b=x.clientY-u;a-=b*this._step*this._arrowKeyMultiplier(x),d+a>this._max?a=this._max-d:d+a<this._min&&(a=this._min-d),this._snapClampSetValue(d+a)}u=x.clientY},_=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",_)},m=()=>{this._inputFocused=!0},p=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",t),this.$input.addEventListener("keydown",s),this.$input.addEventListener("wheel",r,{passive:!1}),this.$input.addEventListener("mousedown",f),this.$input.addEventListener("focus",m),this.$input.addEventListener("blur",p)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const e=(p,x,b,v,P)=>(p-x)/(b-x)*(P-v)+v,t=p=>{const x=this.$slider.getBoundingClientRect();let b=e(p,x.left,x.right,this._min,this._max);this._snapClampSetValue(b)},n=p=>{this._setDraggingStyle(!0),t(p.clientX),window.addEventListener("mousemove",s),window.addEventListener("mouseup",r)},s=p=>{t(p.clientX)},r=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",s),window.removeEventListener("mouseup",r)};let o=!1,l,c;const u=p=>{p.preventDefault(),this._setDraggingStyle(!0),t(p.touches[0].clientX),o=!1},d=p=>{p.touches.length>1||(this._hasScrollBar?(l=p.touches[0].clientX,c=p.touches[0].clientY,o=!0):u(p),window.addEventListener("touchmove",a,{passive:!1}),window.addEventListener("touchend",h))},a=p=>{if(o){const x=p.touches[0].clientX-l,b=p.touches[0].clientY-c;Math.abs(x)>Math.abs(b)?u(p):(window.removeEventListener("touchmove",a),window.removeEventListener("touchend",h))}else p.preventDefault(),t(p.touches[0].clientX)},h=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",a),window.removeEventListener("touchend",h)},f=this._callOnFinishChange.bind(this),g=400;let _;const m=p=>{if(Math.abs(p.deltaX)<Math.abs(p.deltaY)&&this._hasScrollBar)return;p.preventDefault();const b=this._normalizeMouseWheel(p)*this._step;this._snapClampSetValue(this.getValue()+b),this.$input.value=this.getValue(),clearTimeout(_),_=setTimeout(f,g)};this.$slider.addEventListener("mousedown",n),this.$slider.addEventListener("touchstart",d,{passive:!1}),this.$slider.addEventListener("wheel",m,{passive:!1})}_setDraggingStyle(e,t="horizontal"){this.$slider&&this.$slider.classList.toggle("active",e),document.body.classList.toggle("lil-gui-dragging",e),document.body.classList.toggle(`lil-gui-${t}`,e)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(e){let{deltaX:t,deltaY:n}=e;return Math.floor(e.deltaY)!==e.deltaY&&e.wheelDelta&&(t=0,n=-e.wheelDelta/120,n*=this._stepExplicit?1:10),t+-n}_arrowKeyMultiplier(e){let t=this._stepExplicit?1:10;return e.shiftKey?t*=10:e.altKey&&(t/=10),t}_snap(e){let t=0;return this._hasMin?t=this._min:this._hasMax&&(t=this._max),e-=t,e=Math.round(e/this._step)*this._step,e+=t,e=parseFloat(e.toPrecision(15)),e}_clamp(e){return e<this._min&&(e=this._min),e>this._max&&(e=this._max),e}_snapClampSetValue(e){this.setValue(this._clamp(this._snap(e)))}get _hasScrollBar(){const e=this.parent.root.$children;return e.scrollHeight>e.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class DP extends Vn{constructor(e,t,n,s){super(e,t,n,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(s)}options(e){return this._values=Array.isArray(e)?e:Object.values(e),this._names=Array.isArray(e)?e:Object.keys(e),this.$select.replaceChildren(),this._names.forEach(t=>{const n=document.createElement("option");n.textContent=t,this.$select.appendChild(n)}),this.updateDisplay(),this}updateDisplay(){const e=this.getValue(),t=this._values.indexOf(e);return this.$select.selectedIndex=t,this.$display.textContent=t===-1?e:this._names[t],this}}class UP extends Vn{constructor(e,t,n){super(e,t,n,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",s=>{s.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var OP=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function FP(i){const e=document.createElement("style");e.innerHTML=i;const t=document.querySelector("head link[rel=stylesheet], head style");t?document.head.insertBefore(e,t):document.head.appendChild(e)}let Wg=!1;class pf{constructor({parent:e,autoPlace:t=e===void 0,container:n,width:s,title:r="Controls",closeFolders:o=!1,injectStyles:l=!0,touchStyles:c=!0}={}){if(this.parent=e,this.root=e?e.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(r),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),c&&this.domElement.classList.add("allow-touch-styles"),!Wg&&l&&(FP(OP),Wg=!0),n?n.appendChild(this.domElement):t&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),s&&this.domElement.style.setProperty("--width",s+"px"),this._closeFolders=o}add(e,t,n,s,r){if(Object(n)===n)return new DP(this,e,t,n);const o=e[t];switch(typeof o){case"number":return new LP(this,e,t,n,s,r);case"boolean":return new EP(this,e,t);case"string":return new UP(this,e,t);case"function":return new Th(this,e,t)}console.error(`gui.add failed
	property:`,t,`
	object:`,e,`
	value:`,o)}addColor(e,t,n=1){return new IP(this,e,t,n)}addFolder(e){const t=new pf({parent:this,title:e});return this.root._closeFolders&&t.close(),t}load(e,t=!0){return e.controllers&&this.controllers.forEach(n=>{n instanceof Th||n._name in e.controllers&&n.load(e.controllers[n._name])}),t&&e.folders&&this.folders.forEach(n=>{n._title in e.folders&&n.load(e.folders[n._title])}),this}save(e=!0){const t={controllers:{},folders:{}};return this.controllers.forEach(n=>{if(!(n instanceof Th)){if(n._name in t.controllers)throw new Error(`Cannot save GUI with duplicate property "${n._name}"`);t.controllers[n._name]=n.save()}}),e&&this.folders.forEach(n=>{if(n._title in t.folders)throw new Error(`Cannot save GUI with duplicate folder "${n._title}"`);t.folders[n._title]=n.save()}),t}open(e=!0){return this._setClosed(!e),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(e){this._closed!==e&&(this._closed=e,this._callOnOpenClose(this))}show(e=!0){return this._hidden=!e,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(e=!0){return this._setClosed(!e),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const t=this.$children.clientHeight;this.$children.style.height=t+"px",this.domElement.classList.add("transition");const n=r=>{r.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",n))};this.$children.addEventListener("transitionend",n);const s=e?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!e),requestAnimationFrame(()=>{this.$children.style.height=s+"px"})}),this}title(e){return this._title=e,this.$title.textContent=e,this}reset(e=!0){return(e?this.controllersRecursive():this.controllers).forEach(n=>n.reset()),this}onChange(e){return this._onChange=e,this}_callOnChange(e){this.parent&&this.parent._callOnChange(e),this._onChange!==void 0&&this._onChange.call(this,{object:e.object,property:e.property,value:e.getValue(),controller:e})}onFinishChange(e){return this._onFinishChange=e,this}_callOnFinishChange(e){this.parent&&this.parent._callOnFinishChange(e),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:e.object,property:e.property,value:e.getValue(),controller:e})}onOpenClose(e){return this._onOpenClose=e,this}_callOnOpenClose(e){this.parent&&this.parent._callOnOpenClose(e),this._onOpenClose!==void 0&&this._onOpenClose.call(this,e)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(e=>e.destroy())}controllersRecursive(){let e=Array.from(this.controllers);return this.folders.forEach(t=>{e=e.concat(t.controllersRecursive())}),e}foldersRecursive(){let e=Array.from(this.folders);return this.folders.forEach(t=>{e=e.concat(t.foldersRecursive())}),e}}let hd={},En;function NP(i){En&&!En._closed?(En.destroy(),En=void 0):_y(i)}function _y(i){const e=i.config.tree;hd={},En&&En.destroy(),En=new pf({closeFolders:!0,container:document.getElementById("controls-container")}),xy(En,e,i),En.onOpenClose(()=>{En._closed&&setTimeout(()=>{En.destroy(),i.game.gui.resetElementStates(i)},200)})}function xy(i,e,t){const n=e.children;for(const s in n){const r=n[s];if(!("isHidden"in r&&r.isHidden))if("action"in r){const o=r,l=r.label??Ba(s),c={[l]:async()=>{await o.action(t),o.hasNoEffect||t.onCtrlChange(o)}};i.add(c,l)}else if("options"in r&&Array.isArray(r.options)){const o=r,l={};for(const u of o.options)typeof u=="string"&&(l[u]=u);const c=i.add(o,"value",l).name(o.label??Ba(s)).listen();c.onChange(u=>{o.value=u,t.onCtrlChange(o)}),Ch(c,o.tooltip),hd[s]=c}else if("value"in r&&typeof r.value=="number"){const o=r,l=i.add(o,"value",o.min,o.max).name(o.label??Ba(s));o.step&&l.step(o.step),l.onChange(c=>{typeof c=="number"&&(o.value=c,t.onCtrlChange(o))}),Ch(l,o.tooltip),hd[s]=l}else{const o=i.addFolder(r.label??Ba(s));Ch(o,r.tooltip),xy(o,r,t)}}}function Ch(i,e){if(typeof e!="string"||e.trim()==="")return;i.domElement.setAttribute("title",e)}function Ba(i){return/^[A-Z0-9_]+$/.test(i)?i.toLowerCase().split("_").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ").trim():i.replace(/([A-Z])/g," $1").replace(/^./,e=>e.toUpperCase()).trim()}const yy=Math.sqrt(3),kP=.5*(yy-1),Hr=(3-yy)/6,Xg=i=>Math.floor(i)|0,$g=new Float64Array([1,1,-1,1,1,-1,-1,-1,1,0,-1,0,1,0,-1,0,0,1,0,-1,0,1,0,-1]);function mf(i=Math.random){const e=BP(i),t=new Float64Array(e).map(s=>$g[s%12*2]),n=new Float64Array(e).map(s=>$g[s%12*2+1]);return function(r,o){let l=0,c=0,u=0;const d=(r+o)*kP,a=Xg(r+d),h=Xg(o+d),f=(a+h)*Hr,g=a-f,_=h-f,m=r-g,p=o-_;let x,b;m>p?(x=1,b=0):(x=0,b=1);const v=m-x+Hr,P=p-b+Hr,C=m-1+2*Hr,T=p-1+2*Hr,D=a&255,w=h&255;let M=.5-m*m-p*p;if(M>=0){const N=D+e[w],V=t[N],Y=n[N];M*=M,l=M*M*(V*m+Y*p)}let I=.5-v*v-P*P;if(I>=0){const N=D+x+e[w+b],V=t[N],Y=n[N];I*=I,c=I*I*(V*v+Y*P)}let B=.5-C*C-T*T;if(B>=0){const N=D+1+e[w+1],V=t[N],Y=n[N];B*=B,u=B*B*(V*C+Y*T)}return 70*(l+c+u)}}function BP(i){const t=new Uint8Array(512);for(let n=0;n<512/2;n++)t[n]=n;for(let n=0;n<512/2-1;n++){const s=n+~~(i()*(256-n)),r=t[n];t[n]=t[s],t[s]=r}for(let n=256;n<512;n++)t[n]=t[n-256];return t}const Yg=mf();let qg=0;class zP extends ay{constructor(t){super(t);E(this,"pos");E(this,"vel");this.pos=new Float32Array(this.n*2),this.vel=new Float32Array(this.n*2)}step(t){const{FLORA_FRICTION:n,FLORA_CENTERING:s,FLORA_DAMPING:r,FLORA_SPRING:o,FLORA_TEMPERATURE:l}=T_.flatConfig,c=1-n,u=1e-4*Yg(.001*qg++,0),d=1e-4*Yg(1e5+.001*qg++,0);for(const{indexA:a,indexB:h,weight:f}of this.springs){if(!t[a].isFlora||!t[h].isFlora)continue;const g=this.pos[h*2]-this.pos[a*2],_=this.pos[h*2+1]-this.pos[a*2+1],m=this.vel[h*2]-this.vel[a*2],p=this.vel[h*2+1]-this.vel[a*2+1],x=g*f*o,b=_*f*o,v=m*r,P=p*r,C=x+v+u+l*(Math.random()-.5),T=b+P+d+l*(Math.random()-.5);this.vel[a*2]+=C,this.vel[a*2+1]+=T,this.vel[h*2]-=C,this.vel[h*2+1]-=T}for(let a=0;a<this.n;a++){let h=this.pos[a*2],f=this.pos[a*2+1],g=this.vel[a*2],_=this.vel[a*2+1];const m=-h*s,p=-f*s;g+=m,_+=p,h+=g,f+=_,g*=c,_*=c,this.pos[a*2]=h,this.pos[a*2+1]=f,this.vel[a*2]=g,this.vel[a*2+1]=_}}}class HP{constructor(e){this.group=e}updateFloraMeshes(e){var n;const{group:t}=this;for(const s of t.subgroups)s.resetCount();za.subVectors(e.camera.position,e.orbitControls.target);for(const s of t.grid.tileIndices){if(!t.members[s.i].isFlora)continue;const o=(n=t.terrain.generatedTiles[s.i])==null?void 0:n.liveHeight;typeof o=="number"&&this._updateRenderInstance(s,o)}for(const s of t.subgroups)s.finalizeCount()}_updateRenderInstance(e,t){const{FLORA_AMPLITUDE:n,FLORA_LIMIT:s}=T_.flatConfig,{group:r}=this,{i:o}=e,l=r.subgroups[0];if(l.reachedCountLimit())return!1;const c=r.terrain.tilePositions[o];let u=n*this.group.sim.pos[o*2],d=n*this.group.sim.pos[o*2+1];const h=(u*u+d*d)/s;h>1&&(u/=h,d/=h),qr.position.set(c.x+u,t+.25,c.z+d),qr.lookAt(c.x+za.x,t+za.y,c.z+za.z),qr.updateMatrix();const f=l.setMemberMatrix(o,qr.matrix);return r.subgroupsByFlatIndex[o]=[l,f],!0}}const qr=new gt;qr.scale.set(1,1,1);const za=new A;class VP extends lf{constructor(t){const n=t.grid.n;super({sim:new zP(t.grid),subgroups:[{n,geometry:new oc(.5,4).rotateZ(Math.PI/4)}],subgroupsByFlatIndex:Array.from({length:n},(o,l)=>l).map(o=>({subgroupIndex:0,indexInSubgroup:o}))});E(this,"gfxHelper");E(this,"grid");this.terrain=t;const s=this.subgroups[0].mesh,r=new se(5635959);for(let o=0;o<n;o++)s.setColorAt(o,r);this.grid=t.grid,this.gfxHelper=new HP(this)}buildMembers(){return this.terrain.members}updateMeshes(t){this.gfxHelper.updateFloraMeshes(t)}}class Qt{constructor(){}static register(e,t){if(e in this._registry)throw new Error(`TerrainGenerator already registered: '${e}'`);this._registry[e]=t}static create(e){const t=this._registry[e];if(!t)throw new Error(`tiling '${e}' not registered`);return t()}static getAllShapes(){const e=[];for(const t in this._registry){const n=this.create(t);e.push(...n.shapes)}return e}}E(Qt,"_registry",{});class GP{constructor(e,t){E(this,"n");E(this,"tileIndices");E(this,"xzIndexMap");this.width=e,this.depth=t,this.n=e*t;let n=0;const s=[];this.xzIndexMap=new Map;for(let r=0;r<this.width;r++){const o=new Map;this.xzIndexMap.set(r,o);for(let l=0;l<this.depth;l++){const c={i:n++,x:r,z:l};o.set(l,c),s.push(c)}}this.tileIndices=s}xzToIndex(e,t){if(e%1!==0||t%1!==0)throw new Error(`invalid tile x/z index (${e},${t}). must be integers.`);const n=this.xzIndexMap.get(e);if(n)return n.get(t)}updateMapping(e,t,n){if(t%1!==0||n%1!==0)throw new Error(`invalid tile x/z index (${t},${n}). must be integers.`);const s=this.xzIndexMap,r=e.x,o=e.z;if(!s.has(r))throw new Error("old mapping not valid");const l=s.get(r);l.delete(o),l.size===0&&s.delete(r),e.x=t,e.z=n,s.has(t)||s.set(t,new Map),s.get(t).set(n,e)}}class Wl extends GP{constructor(t,n,s){super(t,n);E(this,"_midX",this.width/2);E(this,"_midZ",this.depth/2);E(this,"springsForTileSim");this.tiling=s}positionToCoord(t,n){const{x:s,z:r}=this.tiling.positionToIndex(t+this._midX,n+this._midZ);return{x:s,z:r}}indexToPosition(t){const{x:n,z:s}=this.tiling.indexToPosition(t.x,t.z);return{x:-this._midX+n,z:-this._midZ+s}}}const Ha=[[-1,-1],[1,-1],[1,1],[-1,1]],Rh=[[0,-1],[0,1],[-1,0],[1,0]],vy={knight:{range:"short",deltas:[[1,2],[-1,2],[-1,-2],[1,-2],[2,1],[-2,1],[-2,-1],[2,-1]]},rook:{range:"long",deltas:[...Rh]},bishop:{range:"long",deltas:[...Ha]},king:{range:"short",deltas:[...Rh,...Ha]},queen:{range:"long",deltas:[...Rh,...Ha]},pawn:{range:"short",deltas:[...Ha,[0,1],[0,-1],[0,2],[0,-2]]}};function by(i){const{tile:e,type:t,terrain:n}=i,{range:s,deltas:r}=vy[t],o=[],l=s==="long"?8:1;for(const[c,u]of r)for(let d=1;d<=l;d++){const a=e.x+c*d,h=e.z+u*d,f=n.grid.xzToIndex(a,h);if(f){if(gf(f,i))o.push(f);else break;if(!WP(f,i))break}}return o}function gf(i,e){const{chess:t,terrain:n}=e,{i:s}=i;return t&&t.boardTiles.includes(s)?!0:!n.members[s].isWater}function WP(i,e){const{chess:t,terrain:n}=e,{i:s}=i;return t&&(t.getPieceOnTile(i)||t.goalTile.i===s)?!1:t&&t.boardTiles.includes(s)?!0:!n.members[s].isWater}function XP(i,e){const{piece:t,rectangle:n}=e,s=5,r=10,o=wt(`icons/chess/8x8-${t}.png`),l=(x,b)=>100*x+b,c=[],{range:u,deltas:d}=vy[t];for(const[x,b]of d)c.push(l(x,b)),u==="long"&&c.push(l(2*x,2*b));const a=s*r,h=n.x+(n.w-a)/2,f=n.y+(n.h-a)/2;for(let x=0;x<s;x++)for(let b=0;b<s;b++){const v=h+b*r,P=f+x*r;let C;c.includes(l(b-2,x-2))&&(C="allowedMove");const T=vl({x:b,z:x},C);i.fillStyle=T.top.getStyle(),i.fillRect(v,P,r,r),i.strokeStyle=T.sides.getStyle(),i.lineWidth=1,i.strokeRect(v+.5,P+.5,r-1,r-1)}const g=s/2,_=s/2,m=h+g*r,p=f+_*r;i.drawImage(o,m-o.width/2,p-o.height/2)}const $P=10,Xl=[{detectColor:[113,194,127],fillColor:[255,255,255],currentIndex:-1e3},{detectColor:[55,146,71],fillColor:[255,255,255],currentIndex:-1e3},{detectColor:[113,194,127],currentIndex:-2e3},{detectColor:[55,146,71],currentIndex:-2e3}],YP=Xl.map(i=>i.currentIndex);let wl,$l,My;function qP(i){wl=i;const{width:e,height:t}=wl;$l=wl.getContext("2d"),My=$l.getImageData(0,0,e,t);for(let n=0;n<Xl.length;n++)Xl[n].currentIndex=YP[n]}function jP(i){const{width:e}=wl,t=My.data,n=Math.floor(i*$P);for(let s=0;s<n;s++)for(const r of Xl){const o=r.currentIndex,l=o*4;if(l>0&&l+2<t.length){const[c,u,d]=[t[l],t[l+1],t[l+2]],[a,h,f]=r.detectColor;if(c===a&&u===h&&d===f){const g=o%e,_=Math.floor(o/e),[m,p,x]=r.fillColor||r.detectColor;$l.fillStyle=`rgb(${m},${p},${x})`,$l.fillRect(g,_,1,1)}}r.currentIndex=o+1}}const wy={layoutKey:"rewardHelpPanel",display:{type:"panel",isVisible:!1}},Sy={layoutKey:"rewardHelpCloseBtn",display:{type:"button",icon:"icons/16x16-x.png",isVisible:!1},clickAction:()=>fc()},vo={layoutKey:"rewardHelpDiagram",display:{type:"diagram",label:"help-diagram",isVisible:!1}},Ey=[];async function KP(){for(const i of Object.keys($n)){const{icon:e,title:t,description:n}=$n[i],s=document.createElement("canvas");s.width=64,s.height=64;const r=s.getContext("2d");r.clearRect(0,0,s.width,s.height),r.drawImage(wt(e),4,4),ps(r,{label:t,width:s.width,height:16,font:"default",textAlign:"center",offset:[0,0]}),In.includes(i)?XP(r,{piece:i,rectangle:{x:0,y:0,w:s.width,h:s.height}}):ps(r,{label:n,width:s.width,height:s.height,font:"mini",textAlign:"left",offset:[0,0]}),Di(s),Ey.push(s)}}const ZP=[wy,vo,Sy];let Ay;function fc(i){Ay=i;const e=typeof i=="string";for(const{display:n}of[wy,Sy])n.isVisible=e,n.needsUpdate=!0;vo.display.isVisible=typeof i=="string",vo.display.needsUpdate=!0;const t=JP(i);QP(t),W.context.layeredViewport.handleResize(W.context)}function JP(i){if(!i)return;const{leftReward:e,rightReward:t}=W;return i==="left"?e:t}function QP(i){var o;const e=(o=vo.display.imageset)==null?void 0:o.default;if(!e)throw new Error("rewardHelpDiagram element has no buffer");const{width:t,height:n}=e,s=e.getContext("2d");if(s.clearRect(0,0,t,n),!i)return;const r=Object.keys($n).indexOf(i);r!==-1&&(s.drawImage(Ey[r],0,0),qP(e))}const eI=["Escape","Backquote","Space","KeyM","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","KeyW","KeyS","KeyA","KeyD"],_f=["ButtonA","ButtonB","ButtonX","ButtonY","ButtonLB","ButtonRB","ButtonBack","ButtonStart","ButtonLS","ButtonRS","DPadUp","DPadDown","DPadLeft","DPadRight","ButtonLT","ButtonRT","AxisLX","AxisLY","AxisRX","AxisRY"],tI={ButtonA:0,ButtonB:1,ButtonX:2,ButtonY:3,ButtonLB:4,ButtonRB:5,ButtonBack:8,ButtonStart:9,ButtonLS:10,ButtonRS:11,DPadUp:12,DPadDown:13,DPadLeft:14,DPadRight:15},nI={ButtonLT:6,ButtonRT:7},iI={AxisLX:0,AxisLY:1,AxisRX:2,AxisRY:3};function jg(i,e){let t=e-i;return t=t%(2*Math.PI),t>Math.PI?t-=2*Math.PI:t<-Math.PI&&(t+=2*Math.PI),t}const sI={up:-Math.PI/2,down:Math.PI/2,left:Math.PI,right:0};let Va=null;function rI(i){const e=mn.AxisLX,t=mn.AxisLY;if(Math.abs(e)<.1&&Math.abs(t)<.1)return Va=null,!1;i.isUsingGamepad=!0;const n=Math.atan2(t,e);let s="right",r=1/0;for(const[l,c]of Object.entries(sI)){const u=Math.abs(jg(n,c));u<r&&(r=u,s=l)}const o=jg(Va,n);return typeof Va=="number"&&o<Math.PI/2||(Va=n,s==="left"&&Ks(i,"AxisLX",-1,n),s==="right"&&Ks(i,"AxisLX",1,n),s==="up"&&Ks(i,"AxisLY",-1,n),s==="down"&&Ks(i,"AxisLY",1,n)),!0}const mn={};for(const i of _f)mn[i]=!1;const Ph=(()=>{const i={};for(const e of _f)i[e]=!1;return i})();let Ga=-1;function oI(i){var t,n;let e;Ga===-1?e=navigator.getGamepads?navigator.getGamepads():[]:e=[navigator.getGamepads()[Ga]];for(const s of e){if(!s)continue;for(const[o,l]of Object.entries(tI)){const c=o,u=!!((t=s.buttons[l])!=null&&t.pressed);if(mn[c]=u,u&&!Ph[c]){Ga=s.index,i.isUsingGamepad=!0;let d=!1;if(d||(d=Ks(i,c,1)),!d){for(const a of Pn(i))if(a.keydown(i,c)){d=!0;break}}}else if(!u&&Ph[c]){for(const d of Pn(i))d.keyup(i,c);Ks(i,c,0)}Ph[c]=u}for(const[o,l]of Object.entries(nI)){const c=((n=s.buttons[l])==null?void 0:n.value)??0;Math.abs(c)>.1&&(i.isUsingGamepad=!0),mn[o]=c}for(const[o,l]of Object.entries(iI)){const c=s.axes[l]??0;mn[o]=c}rI(i)&&(Ga=s.index),Kg(i,mn.AxisLX,mn.AxisLY,ds,Zd,"left"),Kg(i,mn.AxisRX,mn.AxisRY,fs,Jd,"right")}}function Kg(i,e,t,n,s,r){if(Math.abs(e)>.01||Math.abs(t)>.01){const o=Math.hypot(e,t);o>1&&(e/=o,t/=o),ci[r]={x:e/2+.5,y:t/2+.5},s.display.forcedSliderState=ci[r],n.display.forcedState="pressed",s.display.forcedState="pressed",n.display.needsUpdate=!0}else s.display.forcedState==="pressed"&&(n.display.needsUpdate=!0,n.display.forcedState=void 0,s.display.forcedState=void 0,ci[r]=aI,delete i.game.gui.overrideLayoutRectangles[`${r}JoySlider`])}const aI={x:.5,y:.5};async function lI(i){i.currentGameName="free-cam";const e=i.layeredViewport.backRenderer;e.dispose(),e.domElement.remove();const t=document.createElement("canvas");t.id="backCanvas",document.body.appendChild(t),i.layeredViewport.backCanvas=t,i.layeredViewport.backRenderer=new nx({canvas:i.layeredViewport.backCanvas,antialias:!1}),i.orbitControls.domElement=t,document.documentElement.requestFullscreen(),await new Promise(n=>{requestAnimationFrame(()=>{requestAnimationFrame(()=>{i.onResize(),n()})})})}let Zg=!1,Jg=!1;const Vr=new Hn,xf=new $_;class cI{constructor(e){E(this,"didLoadAssets",!1);E(this,"config",BR);E(this,"currentGeneratorName");E(this,"generator");E(this,"style");E(this,"scene");E(this,"terrain");E(this,"tileGfx");E(this,"floraGroup");E(this,"sphereGroup");E(this,"currentGameName");E(this,"camera");E(this,"orbitControls");E(this,"game");E(this,"hasConnectedGamepad",null);E(this,"isUsingGamepad",!1);E(this,"transition");E(this,"midTransitionCallback");E(this,"isShowingSettingsMenu",!1);E(this,"isCovering",!1);E(this,"didBuildControls",!1);if(this.layeredViewport=e,Zg)throw new Error("SeaBlock constructed multiple times");Zg=!0}toggleSettings(e){typeof e>"u"&&(e=!this.isShowingSettingsMenu),this.isShowingSettingsMenu!==e&&(it.create("settings-menu").resetElementStates(this),this.isShowingSettingsMenu=e,this.isShowingSettingsMenu?(Ye("settingsOpen"),this.game.gui.closeDialogs(this),eR(),yr()):Ye("settingsClose"))}setGame(e){this.config.tree.children.game.value=e,this.config.flatConfig.game=e,this.currentGameName=e}init(){if(Jg)throw new Error("SeaBlock initialized multiple times");Jg=!0,this.currentGameName=this.config.flatConfig.game,this.currentGeneratorName=this.config.flatConfig.generator,this.generator=Dn.create(this.currentGeneratorName),hs.default=this.generator.style,this.style=da(this.config.flatConfig.style),this.camera=new gn(60,window.innerWidth/window.innerHeight,.1,1e3),this.orbitControls=new VA(this.camera,this.layeredViewport.backCanvas),this.orbitControls.enabled=!1,this.orbitControls.maxPolarAngle=Math.PI/2,this.orbitControls.minDistance=4,this.orbitControls.maxDistance=60,window.addEventListener("resize",()=>this.onResize()),window.addEventListener("gamepadconnected",t=>{const s=navigator.getGamepads()[t.gamepad.index].id.toLowerCase();(s.includes("playstation")||s.includes("dualshock")||s.includes("dual sense"))&&(this.hasConnectedGamepad="playstation"),this.hasConnectedGamepad="xbox"});const e=[pT(),bv(),new Promise((t,n)=>{const s=new cr.Howl({src:[Cd["retroindiejosh_mysterious-wave"].src],format:["ogg"]});s.once("load",t),s.once("loaderror",n)})];Promise.all(e).then(()=>{Iv();const t=[];t.push(MR(Qt.getAllShapes())),t.push(uP()),t.push(KP()),t.push(c2());for(const n of FR.NAMES)t.push(it.preload(n,this));for(const n of ry.NAMES)t.push(St.preload(n));Promise.all(t).then(()=>this.onFinishLoading())})}async update(e){const{transition:t,scene:n,terrain:s,sphereGroup:r,floraGroup:o,game:l,camera:c}=this;this.hasConnectedGamepad&&(oI(this),this.isUsingGamepad&&(document.documentElement.style.cursor="none"),jC(this),JC({seaBlock:this})),this.alignGuiMeshes(),t?(t.update(e),this.isCovering&&t.didFinishCover&&(this.isCovering=!1,this.midTransitionCallback&&(this.midTransitionCallback(),this.midTransitionCallback=void 0),t.doesAllowMidTransitionReset&&await this.onMidTransition(),t.cleanupHide()),t.didFinishUncover&&(t==null||t.cleanupShow(),this.transition=void 0)):mh(this),pR(Vr,this.camera,this.layeredViewport.screenRectangle),l.update({seaBlock:this,dt:e}),n.update(this.orbitControls.target);const u=Math.round(e/Ix);s.update(this,e,u),o.update(this,e,u),r.update(this,e,u),this.game.doesAllow3DRender()?this.layeredViewport.backRenderer.render(n.threeScene,c):this.layeredViewport.backRenderer.render(xf,c)}startTransition(e={}){const{transition:t,callback:n}=e;this.transition=t||of(this),this.isCovering=!0,this.midTransitionCallback=n,mh(this)}refreshGui(e=!1){var t;xr(this);for(const n of Pn(this))n.refreshLayout(this),e&&n.resetElementStates(this);(t=this.transition)==null||t.cleanupHide()}onResize(){var n;const{layeredViewport:e,camera:t}=this;e.handleResize(this),t.aspect=window.innerWidth/window.innerHeight,t.updateProjectionMatrix(),this.setCameraDistance(this.game.getCamOffset(this).length());for(const s of Pn(this))s.refreshLayout(this),s.resetElementStates(this);(n=this.transition)==null||n.cleanupHide(),this.alignGuiMeshes()}setCameraDistance(e){const{camera:t,orbitControls:n}=this,s=t.position.clone().sub(n.target).normalize();t.position.copy(n.target).add(s.multiplyScalar(e)),n.update()}onFinishLoading(){CR(this),window.addEventListener("keydown",e=>{this.game.gui.keydown(this,e.code)}),window.addEventListener("keyup",e=>{this.game.gui.keyup(this,e.code)}),this.didLoadAssets=!0}alignGuiMeshes(){for(const{layoutKey:e,mesh:t}of this.game.elements)if(t)if(e){this.scene.threeScene.remove(t),Vr.add(t);const n=this.game.gui.layoutRectangles[e];n&&mR(t,Vr,this.layeredViewport.screenRectangle,n)}else this.scene.threeScene.add(t),Vr.remove(t)}reset(){const e=Qt.create(this.config.flatConfig.tiling),t=new Wl(_r,_r,e);this.terrain=new bP(t,this).build(),this.floraGroup=new VP(this.terrain).build(),this.sphereGroup=new jR(10,this.terrain).build(),this.game=St.create(this.currentGameName,this),this.scene=zR(this),this.scene.setBackground(this.style.getBackgroundColor()),this.scene.add(Vr),this.tileGfx=this.terrain.gfxHelper,this.game.resetCamera(this),this.game.doesAllowOrbitControls(this)&&(this.orbitControls.enabled=!0)}onGameChange(){yr();for(const e of this.game.meshes)this.scene.threeScene.remove(e);this.game=St.create(this.config.flatConfig.game,this);for(const e of this.game.meshes)e.parent||this.scene.threeScene.add(e);this.layeredViewport.handleResize(this)}onCtrlChange(e){const{generator:t,terrain:n,scene:s}=this;this.config.refreshConfig(),Jt.refreshConfig(),t.refreshConfig();for(const o of Pn(this))o.resetElementStates(this);const r=this.config.flatConfig.game;if(r!==this.currentGameName){this.currentGameName=r,this.onGameChange();return}else as.refreshConfig(),this.orbitControls.enabled=this.game.doesAllowOrbitControls(this);if(e.resetOnChange==="full"){this.onMidTransition();return}else e.resetOnChange==="physics"?us.refreshConfig():(this.style=da(this.config.flatConfig.style),s.setBackground(this.style.getBackgroundColor()),n.resetColors(),this.refreshGui())}async onMidTransition(){this.currentGameName==="splash-screen"&&await lI(this);const{generator:e,scene:t}=this;this.config.refreshConfig(),e.refreshConfig(),this.currentGeneratorName=this.config.flatConfig.generator,this.generator=Dn.create(this.currentGeneratorName),hs.default=this.generator.style,this.style=da(this.config.flatConfig.style),this.currentGameName=this.config.flatConfig.game,this.style=da(this.config.flatConfig.style),t.setBackground(this.style.getBackgroundColor()),this.reset();const{x:n,y:s,w:r,h:o}=this.layeredViewport.screenRectangle;this.layeredViewport.ctx.clearRect(n,s,r,o),this.onResize(),xr(this),mh(this)}rebuildControls(){this.didBuildControls=!0,_y(this)}}class hI{constructor(){E(this,"allowedMoves",new Set);E(this,"hovered")}updateAllowedMoves(e){const{currentPhase:t,centerTile:n,player:s}=e,{allowedMoves:r}=this,{terrain:o}=e.context;if(r.clear(),t==="place-pawn"){const{x:l,z:c}=n;for(let u=-2;u<=2;u++){const d=o.grid.xzToIndex(l+u,c+2);d&&gf(d,{chess:e,terrain:o})&&!e.getPieceOnTile(d)&&r.add(d.i)}}else{const l=by({type:s.type,tile:s.tile,terrain:o,chess:e});for(const c of l){const u=e.getPieceOnTile(c);(!u||u.isEnemy)&&r.add(c.i)}}}}const Qg=300,uI=1;class Yl{constructor(e,t,n){E(this,"t",0);E(this,"isFinished",!1);this.startPos=e,this.endPos=t,this.endTile=n}update(e){return this.t+=e,this.isFinished=this.t>Qg,this.isFinished&&Ye("chessLand"),this.isFinished}getLivePosition(){const{startPos:e,endPos:t}=this,n=Math.min(this.t/Qg,1);Ih.lerpVectors(e,t,n);const s=4*n*(1-n);return Ih.y=e.y*(1-n)+t.y*n+uI*s,Ih}}const Ih=new A,br=[{id:"rook-first",description:"rook first level",requires:["rook"],layout:[["  ","  ","GG","  ","  "],["  ","  ","  ","  ","  "],["  ","  ","  ","  ","  "],["  ","BR","  ","  ","  "],["  ","  ","  ","  ","  "]]},{id:"rook-enemies",description:"rook intro to enemies",requires:["rook"],layout:[["WR","  ","GG","  ","  "],["  ","  ","  ","  ","  "],["WR","  ","WR","  ","  "],["~~","~~","  ","  ","  "],["~~","~~","BR","  ","  "]]},{id:"rook-bishop-capture",description:"rook intro to bishop and capturing",requires:["rook","bishop"],layout:[["GG","  ","WB","  ","  "],["  ","  ","  ","  ","WR"],["  ","  ","BR","  ","  "],["  ","  ","  ","  ","  "],["~~","WR","  ","  ","~~"]]},{id:"bishop-first",description:"bishop level",requires:["bishop"],layout:[["~~","~~","  ","  ","  "],["~~","WB","  ","  ","  "],["WB","  ","  ","  ","WB"],["  ","  ","  ","  ","~~"],["GG","  ","BB","~~","~~"]]},{id:"knight-first",description:"knight level",requires:["knight"],layout:[["GG","  ","  ","~~","~~"],["  ","  ","  ","~~","  "],["~~","~~","~~","  ","  "],["~~","~~","  ","  ","  "],["~~","  ","  ","  ","BH"]]},{id:"queen-first",description:"queen level",requires:["queen"],layout:[["WB","  ","~~","  ","GG"],["  ","  ","~~","  ","  "],["  ","~~","WK","~~","~~"],["  ","  ","~~","  ","  "],["WB","  ","  ","  ","BQ"]]},{id:"king-first",requires:["king"],layout:[["GG","  ","~~","  ","  "],["  ","  ","~~","  ","  "],["~~","~~","WH","  ","  "],["  ","  ","  ","WB","  "],["BK","  ","WH","  ","WR"]]}],dI={levels:br},fI=Object.freeze(Object.defineProperty({__proto__:null,default:dI,levels:br},Symbol.toStringTag,{value:"Module"}));function pI(){const{levels:i}=fI,e=[];for(let n=0;n<i.length;n++)if(!Ze.completedLevels.includes(n)&&mI(i[n],Ze.collected)){e.push(n);break}if(e.length===0)return 0;const t=e[Math.floor(Math.random()*e.length)];return Ty=br[t].id,t}let Ty=br[0].id;function mI(i,e){const{requires:t}=i;if(!t)return!0;const n=[...e];for(const s of t){const r=n.indexOf(s);if(r===-1)return!1;n.splice(r,1)}return!0}function gI(){Ze.completedLevels.push(ud)}let ud=0;function _I(i){ud=pI();const{terrain:e}=i.context,t=i.centerTile,n=new xI(ud,e);n.loadLevel(t);const{playerPiece:s,enemyPieces:r,boardTiles:o,goalTile:l}=n;if(!o||o.length===0)throw new Error("level has no chessboard tiles");if(!s)throw new Error('level has no player ("B_")');if(!l)throw new Error('level has no "GG" target cell');return{playerPiece:s,enemyPieces:r,boardTiles:o,goalTile:l}}class xI{constructor(e,t){E(this,"playerPiece");E(this,"enemyPieces",[]);E(this,"boardTiles",[]);E(this,"goalTile");this.levelIndex=e,this.terrain=t}loadLevel(e){var c;const{terrain:t}=this,n=br[this.levelIndex%br.length].layout,s=n.length,r=n[0].length,o=Math.floor(s/2),l=Math.floor(r/2);for(let u=0;u<r;u++)for(let d=0;d<s;d++){const a=e.x+d-l,h=e.z+u-o,f=t.grid.xzToIndex(a,h);let g=!1;if(f){const _=n[u][d];_==="  "||(_==="GG"?this.goalTile=f:_==="~~"?g=!0:_.startsWith("B")?this.playerPiece=e0(_,f):_.startsWith("W")&&this.enemyPieces.push(e0(_,f))),g||(c=this.boardTiles)==null||c.push(f.i)}}}}function e0(i,e){const t=i.at(1);if(!(t in t0))throw new Error(`invalid piece in chess level json: '${i}'`);return{color:i.at(1),type:t0[t],tile:e}}const t0={B:"bishop",H:"knight",R:"rook",K:"king",Q:"queen",P:"pawn"},yI={"player-anim":({pawns:i,enemies:e})=>i.length>0?"pawn-anim":e.length>0?"enemy-anim":"player-choice","pawn-anim":({enemies:i})=>i.length>0?"enemy-anim":"player-choice","enemy-anim":()=>"player-choice","player-choice":()=>"player-anim","place-pawn":()=>"player-choice","reward-choice":()=>"player-choice","game-over":()=>"game-over","reached-chest":()=>"reward-choice"};function vI(){const i=new Set;return W.enemies.map(e=>bI(e,i))}function bI(i,e){const{terrain:t}=W.context,n=by({type:i.type,tile:i.tile,terrain:t,chess:W});for(const s of n){if(e.has(s.i))continue;const r=W.getPieceOnTile(s);if(r&&!r.isEnemy)return e.add(s.i),new Yl(W.getPosOnTile(i.tile).clone(),W.getPosOnTile(s).clone(),s)}return null}function MI(){return W.pawns.map(i=>wI(i))}function wI(i){const{terrain:e}=W.context,{grid:t}=e,{x:n,z:s}=i.tile,r=[[n-1,s-1],[n+1,s-1]];Math.random()<.5&&r.reverse();for(const[l,c]of r){const u=t.xzToIndex(l,c);if(!u)continue;const d=W.getPieceOnTile(u);if(d&&d.isEnemy)return new Yl(W.getPosOnTile(i.tile).clone(),W.getPosOnTile(u).clone(),u)}const o=t.xzToIndex(n,s-1);return o&&gf(o,{type:i.type,tile:i.tile,terrain:e,chess:W})&&!W.getPieceOnTile(o)?new Yl(W.getPosOnTile(i.tile).clone(),W.getPosOnTile(o).clone(),o):null}const SI={layoutKey:"quitBtn",display:{type:"button",label:"quit chess",isVisible:!1},clickAction:()=>{Ye("click"),vf()}},Cy=[SI],EI={layoutKey:"pieceHelpPanel",display:{type:"panel",isVisible:!1}},AI={layoutKey:"pieceHelpCloseBtn",display:{type:"button",label:"CLOSE",isVisible:!1}},TI=In.map(i=>({layoutKey:"pieceHelpDiagram",display:{type:"diagram",label:`help-${i}`,isVisible:!1,description:`${i} help`}})),CI=[EI,...TI,AI],RI=[...Cy,...CI];let Wa=!1;function Ry(i,e){typeof e=="boolean"?Wa=e:Wa=!Wa;for(const{display:t}of Cy)t.isVisible=Wa,t.needsUpdate=!0;i.layeredViewport.handleResize(i)}const PI={"player-anim":"...","pawn-anim":"...","enemy-anim":"...","game-over":"Game Over","place-pawn":"Place Pawn","player-choice":"Reach Treasure","reached-chest":"Level Cleared","reward-choice":"Select Reward"},II="player-choice",Py=Object.fromEntries(ey.map(i=>[i,{layoutKey:"phaseLabel",isPickable:!1,display:{type:"panel",label:PI[i],isVisible:i===II}}])),LI=[...Object.values(Py)];function DI(i){for(const e of ey){const{display:t}=Py[e];e===i?(t.isVisible=!0,t.needsUpdate=!0):t.isVisible=!1}}let Gn;const Iy={layoutKey:"rewardsPanel",display:{type:"panel"}},dd={layoutKey:"leftReward",gamepadNavBox:"leftReward",display:{type:"button",gamepadPrompt:{offset:[0,16]}},clickAction:()=>{Gn==="left"?Gn=void 0:Gn="left",yf()}},Ly={layoutKey:"leftRewardDisplay",isPickable:!1,display:{type:"diagram",label:"chess-left-reward"}},fd={layoutKey:"rightReward",gamepadNavBox:"rightReward",display:{type:"button",gamepadPrompt:{offset:[0,16]}},clickAction:()=>{Gn==="right"?Gn=void 0:Gn="right",yf()}},Dy={layoutKey:"rightRewardDisplay",isPickable:!1,display:{type:"diagram",label:"chess-right-reward"}},UI={layoutKey:"leftRewardHelpBtn",display:{type:"button",label:"?",isVisible:!1},clickAction:()=>fc("left")},OI={layoutKey:"rightRewardHelpBtn",display:{type:"button",label:"?",isVisible:!1},clickAction:()=>fc("right")},FI={layoutKey:"confirmBtn",display:{type:"label"}},Zs={layoutKey:"confirmBtn",gamepadNavBox:"confirmBtn",display:{type:"button",label:"ACCEPT",isVisible:!1,gamepadPrompt:{offset:[-26,0]}},clickAction:()=>{fc(),Gn==="left"?W.collectReward(W.leftReward):W.collectReward(W.rightReward)}},Uy={layoutKey:"rewardsTitle",display:{type:"label",label:"CHOOSE ONE"}},Oy=Object.values($n).map(i=>({layoutKey:"rewardsTitle",display:{type:"label",label:i.title,isVisible:!1}}));function NI(){Hg(Ly,W.leftReward),Hg(Dy,W.rightReward),Gn=void 0,yf()}function yf(){let i=-1;dd.display.forcedState=void 0,fd.display.forcedState=void 0,Zs.display.forcedState=void 0,Zs.display.isVisible=!1,Gn==="left"?(i=Object.keys($n).indexOf(W.leftReward),dd.display.forcedState="pressed",Zs.display.isVisible=!0):Gn==="right"&&(i=Object.keys($n).indexOf(W.rightReward),fd.display.forcedState="pressed",Zs.display.isVisible=!0);for(const[e,t]of Oy.entries())t.display.isVisible=e===i;Uy.display.isVisible=i===-1,Iy.display.needsUpdate=!0}const kI=[Iy,Uy,...Oy,dd,Ly,UI,fd,Dy,OI,FI,Zs];function BI(i){const e=zI[W.currentPhase];e(i)}let Xa;const zI={"game-over":()=>{},"place-pawn":()=>{},"reached-chest":()=>{},"reward-choice":()=>{},"player-choice":()=>{},"player-anim":({dt:i})=>{const{currentMove:e}=W;if(e)if(e.update(i)){const{endTile:n}=e,s=W.getPieceOnTile(n);if(s){const o=W.enemies.indexOf(s);o>=0&&(Ye("chessGoodCapture"),W.enemies.splice(o,1),eo(W,W.player,[...W.pawns],[...W.enemies]))}const{player:r}=W;r.tile=n,W.currentMove=void 0,Si(r,W.getPosOnTile(r.tile)),r.tile.i===W.goalTile.i?(n0(),W.currentPhase="reached-chest"):(W.updateAllowedMoves(),W.gotoNextPhase())}else{const n=e.getLivePosition();Si(W.player,n)}else W.gotoNextPhase()},"pawn-anim":({dt:i})=>{const e=W.pawnMoves.findIndex(t=>t&&!t.isFinished);if(e>=0){const t=W.pawns[e],n=W.pawnMoves[e];n!==Xa&&(Xa=n,Ye("chessJump"));const s=n.update(i);if(Si(t,n.getLivePosition()),s){const{endTile:r}=n,o=W.getPieceOnTile(r);if(t.tile=r,r.i===W.goalTile.i&&n0(),o){const l=W.enemies.indexOf(o);l>=0&&(Ye("chessGoodCapture"),W.enemies.splice(l,1),eo(W))}}}else W.updateAllowedMoves(),W.gotoNextPhase()},"enemy-anim":({dt:i})=>{const e=W.enemyMoves.findIndex(t=>t&&!t.isFinished);if(e>=0){const t=W.enemies[e],n=W.enemyMoves[e];n.endTile===W.player.tile&&(i/=2),n!==Xa&&(Xa=n,Ye("chessJump"));const s=n.update(i);if(Si(t,n.getLivePosition()),s){t.tile=n.endTile;const r=W.getPieceOnTile(n.endTile);if(r){const o=W.pawns.indexOf(r);o>=0?(Ye("chessBadCapture"),W.pawns.splice(o,1),eo(W)):r===W.player&&(Ye("chessBadCapture"),W.currentPhase="game-over",Ry(W.context,!0))}}}else W.updateAllowedMoves(),W.gotoNextPhase()}};function n0(){gI(),Ye("chessCelebrate");const i=Math.random()<.5?$e.create("checkered",W.context):of(W.context);W.context.startTransition({transition:i,callback:()=>{W.currentPhase="reward-choice",xf.background=rP,W.context.game.gui.refreshLayout(W.context),NI()}})}const Js=class Js extends $e{constructor(){super(...arguments);E(this,"hideTarget");E(this,"startRect");E(this,"endRect");E(this,"hideImage");E(this,"zoomShow")}cleanupHide(){super.cleanupHide(),Js.target=void 0}reset(t){var x;this.hideTarget=Js.target||Object.values(t.game.gui.elements)[0];const n=t.game.gui.layoutRectangles[this.hideTarget.layoutKey],s=(x=this.hideTarget.display.imageset)==null?void 0:x.pressed;if(!n)throw new Error("hide target not in layout");if(!s)throw new Error("hide target has no pressed image");this.startRect=n,this.hideImage=s;const r=s.width,o=s.height,u=s.getContext("2d").getImageData(0,0,r,o).data,d=Math.floor(r/2),a=Math.floor(o/2);let h=1/0,f=d,g=a;for(let b=0;b<o;++b)for(let v=0;v<r;++v){const P=(b*r+v)*4,C=u[P],T=u[P+1],D=u[P+2];if(C<32&&T<32&&D<32){const w=(v-d)*(v-d)+(b-a)*(b-a);w<h&&(h=w,f=v,g=b)}}const _=this.layeredViewport.screenRectangle,m=_.w,p=_.h;this.endRect={x:_.x-f*m,y:_.y-g*p,w:r*m,h:o*p},$e.isLaunching?($e.isLaunching=!1,this.zoomShow=$e.create("drop",t)):$e.isFirstUncover?this.zoomShow=$e.create("ss",t):this.zoomShow=$e.create(hi(["ss","flat"]),t)}_hide(t,n){const s=this.layeredViewport.frontCtx;s.imageSmoothingEnabled=!1;const{width:r,height:o}=this.hideImage,l=Math.pow(n,5)*1.2,{x:c,y:u,w:d,h:a}=HI(this.startRect,this.endRect,l);s.drawImage(this.hideImage,0,0,r,o,c,u,d,a)}_show(t,n){this.zoomShow._show(t,n)}};$e.register("zoom",()=>new Js),E(Js,"target");let pd=Js;function HI(i,e,t){return{x:i.x+(e.x-i.x)*t,y:i.y+(e.y-i.y)*t,w:i.w+(e.w-i.w)*t,h:i.h+(e.h-i.h)*t}}const $a=new se,Hf=class Hf extends Dn{constructor(){super(...arguments);E(this,"label","Michael2-3B/Procedural-Perlin-Terrain");E(this,"url","https://github.com/Michael2-3B/Procedural-Perlin-Terrain");E(this,"config",fo);E(this,"style",{sides:{lightness:-.1}})}getTile(t,n){const s=t/this.xzScale,r=n/this.xzScale,o=this.getHeight(s,r),{waterLevel:l,yScale:c}=this.config.flatConfig,u=(o-l)*c+l;return{height:Math.max(u,l),color:this.getTileColor(s,r),isWater:o<=l,isFlora:!1}}gradient(t,n){const s=t*1836311903^n*2971215073^this.config.flatConfig.seed,o=new ad(s).next()*Math.PI*2;return[Math.cos(o),Math.sin(o)]}dotProduct(t,n){return t[0]*n[0]+t[1]*n[1]}easeInOutQuad(t){return t<.5?2*t*t:-1+(4-2*t)*t}lerp(t,n,s){return(1-s)*t+s*n}getHeight(t,n){const{offsetX:s,offsetZ:r,amplitude:o,peaks:l,exponent:c,persistence:u,octaves:d,wavelength:a}=this.config.flatConfig;let h=0,f=a,g=o;const _=t+s,m=n+r;for(let p=0;p<d;p++){const x=Math.floor(_/f),b=x+1,v=Math.floor(m/f),P=v+1,C=_/f-x,T=m/f-v,D=this.gradient(x,v),w=this.gradient(b,v),M=this.gradient(x,P),I=this.gradient(b,P),B=this.dotProduct(D,[C,T]),N=this.dotProduct(w,[C-1,T]),V=this.dotProduct(M,[C,T-1]),Y=this.dotProduct(I,[C-1,T-1]),$=this.easeInOutQuad(C),Q=this.easeInOutQuad(T),G=this.lerp(B,N,$),ce=this.lerp(V,Y,$),fe=this.lerp(G,ce,Q);h+=g/4-Math.abs(fe*g),f=Math.max(f/2,1),g*=u}return Math.max(0,Math.min(254,255*Math.pow((h+1)/2+l,c)))}getTileColor(t,n){const s=this.getHeight(t,n),{waterLevel:r}=this.config.flatConfig,o=s,l=this.getHeight(t+1,n),c=this.getHeight(t,n+1),u=this.getHeight(t+1,n+1),[d,a,h]=this.calculateSlopeDirection(o,l,c,u);return s<r?this.waterColorLookup(r-s):this.terrainColorLookup(s,d,a,h)}waterColorLookup(t){const{worldLight:n,lightHeight:s}=this.config.flatConfig,r=3*(s+90)/180+1,o=5-r;let l=90-s;l/=3-(s+90)/90;const c=[0,180-t/2,255-t/4];c[0]=Math.max(0,c[0]-l/r+Math.min(0,s)),c[1]=Math.max(0,c[1]-l/2+Math.min(0,s)),c[2]=Math.max(0,c[2]-l/o+Math.min(0,s));for(let u=0;u<3;u++)c[u]=Math.max(0,Math.min(255,c[u]+n-255));return $a.set(c[0]/255,c[1]/255,c[2]/255),$a}terrainColorLookup(t,n,s,r){const{waterLevel:o,beachSize:l,worldLight:c}=this.config.flatConfig;let u;t<o+l?u=[Math.min(t/3+150*1.3,255),Math.min(t/3+110*1.3,215),Math.min(t/3*1.3,105)]:t<100?u=[t,t+88,t]:t<130?u=[t,t+58,t]:t<160?u=[t,Math.min(t+29,255),t]:t<190?u=[t-10,t-10,t]:t<220?u=[t-40,t-40,t-30]:u=[Math.min(255,t+10),Math.min(255,t+10),Math.min(255,t+20)],u=this.addShading(u,n,s,r);for(let d=0;d<3;d++)u[d]=Math.max(0,Math.min(255,u[d]+c-255));return $a.set(u[0]/255,u[1]/255,u[2]/255),$a}addShading(t,n,s,r){const{lightPosition:o,lightHeight:l}=this.config.flatConfig;let c=90-l;c/=3-(l+90)/90;const u=3*(l+90)/180+1,d=5-u;t[0]=Math.max(0,t[0]-c/u+Math.min(0,l)),t[1]=Math.max(0,t[1]-c/2+Math.min(0,l)),t[2]=Math.max(0,t[2]-c/d+Math.min(0,l));let a=Math.abs(o-n);a=a>180?360-a:a,s===0&&r===0&&(a=-(l-90));for(let h=0;h<3;h++)t[h]=Math.min(255,Math.max(0,t[h]-a*Math.abs((l-90)/90)));return t}calculateSlopeDirection(t,n,s,r){const o=n-t,l=s-t,c=r-s,u=r-n,d=(o+c)/2,a=(l+u)/2;let h=Math.atan2(a,d)*180/Math.PI;return h=(h+360)%360,[h,d,a]}};Dn.register("Michael2-3B",()=>new Hf);let Mr=Hf;const Qi=class Qi extends Mr{constructor(){super(...arguments);E(this,"label","chess")}getTile(t,n){let s=super.getTile(t,n);if(Qi.currentMods.isAllOcean){const o=t/this.xzScale,l=n/this.xzScale,c=this.getHeight(o,l),u=this.waterColorLookup(132-c);s.isWater=!0,s.height=132,s.color=u}Qi.currentMods.isAllLand&&(s.isWater=!1);const r=VI(t-_r/2,n-_r/2);return s={...s,height:s.height+r},Qi.currentMods.isLandFlora&&(s.isFlora=!s.isWater),s}};Dn.register("chess",()=>new Qi),E(Qi,"currentMods",{});let rr=Qi;function VI(i,e){if(rr.currentMods.isUnwarped)return 0;const t=-30,n=12,s=Math.sqrt(i*i+e*e),r=t*Math.pow(Math.min(1,s/n),4);let o=1;return rr.currentMods.isBowl&&(o=-1),rr.currentMods.isSaddle&&(o=Math.sin(Math.atan2(i,e)*2)),r*o}function GI(i){const e=JSON.parse(JSON.stringify(i.config.flatConfig));e.style="custom";const{x:t,z:n}=i.terrain.centerXZ;return e.offsetX=t/Math.pow(10,-.6),e.offsetZ=n/Math.pow(10,-.6),{config:e,style:JSON.parse(JSON.stringify(hs.custom))}}function Lh(i,e){Fy(i.config.tree,(t,n)=>{if(t in e.config){const s=e.config[t];n.value=s}}),hs.custom=e.style}function Fy(i,e){for(const t in i.children){const n=i.children[t];"value"in n?e(t,n):"children"in n&&Fy(n,e)}}let Ya;class bo{static takeOriginalSnapshot(e){Ya=GI(e)}static applyLevelScenery(e,t){const n=XI[t],s=WI[n];rr.currentMods=s.tgMods||{},Lh(e,Ya),e.config.tree.children.game.value="chess",e.config.tree.children.tiling.value="square",Lh(e,s.snapshot)}static restoreOriginalSnapshot(e){Ya&&(Lh(e,Ya),e.config.tree.children.gfx.children.style.value="default")}}const WI={lava:{tgMods:{isAllOcean:!0},snapshot:{style:{background:{value:"#000"},top:{hue:-.5},sides:{hue:-.5,lightness:-.1}},config:{generator:"chess",style:"custom",visibleRadius:11}}},"mountain-wrap":{tgMods:{isUnwarped:!0},snapshot:{style:{},config:{style:"default",generator:"chess",visibleRadius:11,offsetX:-.4720616551544658,offsetZ:19.402819298061146,exponent:3}}},"tight-wrap":{tgMods:{},snapshot:{style:{},config:{style:"pastel",generator:"chess",visibleRadius:11,offsetX:-94.57554124214874,offsetZ:48.587894021613195,exponent:3}}},pringle:{tgMods:{isAllOcean:!0,isSaddle:!0},snapshot:{style:{background:{value:"#444"},top:{value:"#999"},sides:{value:"#000"}},config:{generator:"chess",style:"custom",visibleRadius:11}}},gumball:{snapshot:{style:{background:{hue:-.25,saturation:"+0.2",lightness:"+0.3"},top:{hue:-.25,saturation:"+0.7",lightness:"+0.1"},sides:{hue:-.25,saturation:"+0.5",lightness:"-0.1"}},config:{generator:"chess",style:"custom",visibleRadius:11}}},"neon-pastel":{snapshot:{style:{background:{value:"#222"},top:{hue:-.1,saturation:"+0.5",lightness:"+0.2"},sides:{hue:-.15,saturation:"+0.8",lightness:"+0.5"},"top@sea":{value:"#AACCFF"},"sides@sea":{value:"#aaccff73"}},config:{generator:"chess",style:"custom",visibleRadius:11,yScale:.34,offsetX:-658.6491056901409,offsetZ:747.0363572027585,persistence:.68,wavelength:98}}},ocean:{tgMods:{isAllOcean:!0},snapshot:{style:{background:{value:"#8c0b0bff"},sides:{lightness:-.1}},config:{generator:"chess",visibleRadius:11,style:"custom"}}},"ocean-bowl":{tgMods:{isAllOcean:!0,isBowl:!0},snapshot:{style:{background:{value:"#0a2233"},sides:{lightness:-.1}},config:{generator:"chess",visibleRadius:11,style:"custom"}}},"rough-reachable":{snapshot:{style:{},config:{generator:"chess",visibleRadius:11,yScale:.34,offsetX:-658.6491056901409,offsetZ:747.0363572027585,persistence:.68,wavelength:98}}}},XI={"rook-first":"ocean","rook-enemies":"ocean","rook-bishop-capture":"ocean-bowl","bishop-first":"pringle","knight-first":"mountain-wrap","queen-first":"neon-pastel","king-first":"lava"},qa=new xe;function Ny(i,e,t){const n=Ze.collected.includes("dual-vector-foil");if(qa.set(0,0),e&&typeof t=="number"){const l=i.context;let c=0;if(!n){const{camera:u,orbitControls:d}=l;c=-Math.PI/2+Math.atan2(u.position.z-d.target.z,u.position.x-d.target.x)}qa.set(e.x+Math.cos(t+c),e.z+Math.sin(t+c))}const s=[...i.hlTiles.allowedMoves];let r=null,o=1/0;for(const l of s){if(e&&e.i===l)continue;const c=i.context.terrain.grid.tileIndices[l],u=c.x-qa.x,d=c.z-qa.y,a=u*u+d*d;a<o&&(r=c,o=a)}if(r){const l=r;if(i.hlTiles.hovered=l,n){const c=yP(l);c&&ms(c)}else i.getPosOnTile(l,an.position),an.visible=!0,ms(an.position);rf({selectAction:(c,u)=>u?(Jr(l,c),!0):(Qr(l,c),!0),navAction:c=>{uf(),Ny(i,l,c)}})}}function $I(){return!(W.currentPhase==="reward-choice"||Ze.collected.includes("dual-vector-foil"))}function YI(){return W.currentPhase==="player-choice"||W.currentPhase==="place-pawn"}function qI(){return W.currentPhase==="reward-choice"}function jI(){ql=!0,Ze.collectedPawns=cy,Ze.collected=[...ly],Ze.completedLevels=[]}let ql=!0,W;function KI(i){ql&&(ql=!1,W=new Mo(i),ff.setChess(W)),uf(),yr(),i.toggleSettings(!1)}function vf(){const i=W.context,e=i.config.tree.children.game;e.value="free-cam",i.startTransition({callback:()=>{i.toggleSettings(!1),Ry(i,!1),jI(),bo.restoreOriginalSnapshot(i),hr(ic),i.onCtrlChange(e)}})}function ZI(){return(W==null?void 0:W.currentPhase)||"player-choice"}function JI(i){i.seaBlock.isUsingGamepad&&W.currentPhase!=="reward-choice"&&!i.seaBlock.isShowingSettingsMenu&&(!W.hlTiles.hovered||!oi)&&Ny(W),_P(),Ay&&(jP(i.dt),vo.display.needsUpdate=!0),W.update(i)}const QI=new A,Qs=class Qs{constructor(e){E(this,"waveMaker");E(this,"hlTiles");E(this,"centerTile");E(this,"centerPos");E(this,"boardTiles");E(this,"goalTile");E(this,"player");E(this,"playerElement");E(this,"pawns",[]);E(this,"enemies",[]);E(this,"currentPhase","player-choice");E(this,"currentMove");E(this,"pawnMoves",[]);E(this,"enemyMoves",[]);E(this,"leftReward",Bg(this));E(this,"rightReward",Bg(this));this.context=e,cf(),Xi.display.isVisible=!0,$i.display.isVisible=!1,Xi.display.needsUpdate=!0,$i.display.needsUpdate=!0;const{terrain:t}=e;this.hlTiles=new hI;const{x:n,z:s}=t.centerXZ,r=t.grid.positionToCoord(n,s),o=t.grid.xzToIndex(r.x,r.z);if(!o)throw new Error(`could not find center tile at position ${n.toFixed(2)},${s.toFixed(2)}`);const l=t.grid.indexToPosition(o);this.centerPos=l,this.centerTile=o;const{playerPiece:c,enemyPieces:u,boardTiles:d,goalTile:a}=_I(this);this.boardTiles=d,this.goalTile=a,Qs.queueHltUpdate(),eo(this,c,[],u),Ml(c.type),this.updateFlatView(),Zr.clickAction=({inputEvent:h})=>{dP(h)},Zr.unclickAction=({inputEvent:h})=>{fP(h)},this.waveMaker=new Dl(e.sphereGroup.members[1],e)}centerCameraOnChessBoard(e){const{orbitControls:t}=this.context,{target:n}=t,{x:s,z:r}=this.centerPos;n.x=s,n.z=r,n.y=12,t.update()}startPlacePawn(){if(Ze.collectedPawns<=0){Ye("chessCancel");return}Ml("pawn"),this.currentPhase="place-pawn",this.updateAllowedMoves(),Xi.display.isVisible=!1,$i.display.isVisible=!0,Xi.display.needsUpdate=!0,$i.display.needsUpdate=!0,this.context.layeredViewport.handleResize(this.context)}updateAllowedMoves(){this.hlTiles.updateAllowedMoves(this)}cancelPlacePawn(){Ml(this.player.type),this.currentPhase="player-choice",this.updateAllowedMoves(),Xi.display.isVisible=!0,$i.display.isVisible=!1,Xi.display.needsUpdate=!0,$i.display.needsUpdate=!0,this.context.layeredViewport.handleResize(this.context)}gotoNextPhase(){const e=yI[this.currentPhase](this);return e==="pawn-anim"&&(this.pawnMoves=MI()),e==="enemy-anim"&&(this.enemyMoves=vI()),this.currentPhase=e,e}static getHltUpdateQueued(){return this.isHltUpdateQueued}static queueHltUpdate(){this.isHltUpdateQueued||(W!=null&&W.hlTiles&&W.hlTiles.allowedMoves.clear(),this.isHltUpdateQueued=!0)}update(e){const{seaBlock:t,dt:n}=e,{terrain:s}=t;Qs.isHltUpdateQueued&&(Qs.isHltUpdateQueued=!1,this.updateAllowedMoves());const r=Math.floor(performance.now()/500)%2;for(const[l,c]of py.entries())c.isVisible=l===r,c.needsUpdate=!0;t.sphereGroup.members.includes(this.waveMaker.sphere)||(this.waveMaker=new Dl(t.sphereGroup.members[1],t)),this.waveMaker.updateWaveMaker(e),this.centerCameraOnChessBoard(n);const o=s.gfxHelper.getLiveHeight(this.goalTile);typeof o=="number"&&IR(o),DI(this.currentPhase),l2(),BI(e),cc(e),wf(e),this.updateFlatView()}identifyPiece(e,t){const n=[this.player,...this.pawns,...this.enemies];for(const s of n)if(s.type===e&&"index"in s&&s.index===t)return s}updateFlatView(){Ze.collected.includes("dual-vector-foil")&&!this.context.isShowingSettingsMenu?lP(this):Zr.display.isVisible=!1}collectReward(e){Ze.collected.push(e);const{collectAction:t}=$n[e];t&&t(),ql=!0;let n;Math.random()<.5?(pd.target=Zs,n=$e.create("zoom",this.context)):n=of(this.context),this.context.startTransition({transition:n,callback:()=>{xf.background=oP,this.context.onGameChange(),bo.applyLevelScenery(this.context,Ty),this.context.game.resetCamera(this.context)}})}switchCurrentPiece(){const e=In.indexOf(this.player.type),t=In.length;for(let n=1;n<t;n++){const s=(e+n)%t,r=In[s];if(r!==this.player.type&&r!=="pawn"&&Ze.collected.includes(r)){Ze.hasSwitchedPiece=!0,this.player.type=r;break}}eo(this),this.updateAllowedMoves(),dy(this.player.type)}movePlayerToTile(e){const t=this.player.tile,n=this.getPosOnTile(t).clone(),s=this.getPosOnTile(e).clone();this.currentMove=new Yl(n,s,e),this.currentPhase="player-anim",Ye("chessJump")}getPieceOnTile(e){const{i:t}=e;if(this.player.tile.i===t)return this.player;for(const n of this.pawns)if(n.tile.i===t)return n;for(const n of this.enemies)if(n.tile.i===t)return n}getPosOnTile(e,t){var l;const{x:n,z:s}=this.context.terrain.grid.indexToPosition(e),r=(l=this.context.terrain.generatedTiles[e.i])==null?void 0:l.liveHeight,o=t||QI;return o.set(n,r??13,s),o}};E(Qs,"isHltUpdateQueued",!1);let Mo=Qs;const ky=[new A(0,5,4),new A(1,5,4),new A(4,6,4)],e2=ky.map(i=>i.clone().multiplyScalar(1.6));function bf(i){const{w:e,h:t}=i.layeredViewport,n=t>e?e2:ky;return n[Math.floor(Math.random()*n.length)]}function t2(i){const{x:e,z:t}=i.terrain.centerXZ,n=bf(i),{y:s}=i.orbitControls.target;i.camera.position.set(e+n.x,s+n.y,t+n.z)}const n2=new se(16711680),i2=new se(3355443),wr={},md={};let Yi,Dh;const jl={isPickable:!0,meshLoader:async()=>{Yi=Uo("kenney/chest.obj").clone(),Dh=new gr({map:new Ju(wt("textures/kenney-colormap.png")),color:11184810});const i=new gr({map:new Ju(wt("textures/kenney-colormap.png")),color:16777215});return jl.defaultMat=Dh,jl.hoverMat=i,Yi=Kd(Yi,{scale:1.1,dilate:-.04}),vr(Yi,Dh),Yi.scale.multiplyScalar(.5),Yi}},By=In.map(i=>({isPickable:!0,meshLoader:async()=>{const e=Uo(`chess/${i}.obj`).clone();if(e.children.length!==1)throw new Error(`group has ${e.children.length} children (expected 1)`);const t=e.children[0];if(!(t instanceof at))throw new Error(`child is ${e.children} (expected Mesh)`);const n=t.geometry.clone();n.center(),n.computeBoundingBox();const{min:s}=n.boundingBox,r=.3;n.scale(r,r,r);let o=new Hn().add(new at(n,t.material));return o=Kd(o,{scale:1.1,dilate:-.04}),o.children.forEach(l=>{l.position.y-=s.y}),o.visible=!1,md[i]=o,o}})),s2=In.map(i=>({pieceType:i,isPickable:!0,meshLoader:async()=>{const e=Uo(`chess/${i}.obj`).clone();if(e.children.length!==1)throw new Error(`group has ${e.children.length} children (expected 1)`);const t=e.children[0];if(!(t instanceof at))throw new Error(`child is ${e.children} (expected Mesh)`);const n=t.geometry.clone();n.center(),n.computeBoundingBox();const s=n.boundingBox.min;n.translate(0,-s.y,0);const r=.3;n.scale(r,r,r);const o=new Zt(n,t.material,16);return o.setColorAt(0,new se),o.count=0,wr[i]=o,o}}));function Si(i,e){"instancedMesh"in i?r2(i,e):i.mesh.position.copy(e)}function r2(i,e){const{instancedMesh:t,index:n}=i,s=t.instanceMatrix.array;let r=n*16+12;const{x:o,y:l,z:c}=e;s[r++]=o,s[r++]=l,s[r++]=c,t.instanceMatrix.needsUpdate=!0,t.frustumCulled=!1}const o2=new A;function Uh(i,e){const t=o2;return"instancedMesh"in i?a2(i,t):t.copy(i.mesh.position),t}function a2(i,e){const{instancedMesh:t,index:n}=i,s=t.instanceMatrix.array;let r=n*16+12;e.set(s[r++],s[r++],s[r++])}function l2(){const{player:i,pawns:e,enemies:t,goalTile:n}=W;for(const s of[i,...e,...t])Si(s,W.getPosOnTile(s.tile));Yi.position.copy(W.getPosOnTile(n));for(const s of Object.values(wr))s.computeBoundingSphere()}function gd(i,e,t){const n=wr[i];if(!n)throw new Error(`missing mesh for ches piece ${i}`);const s=n.count;n.count++,n.visible=!0;const r=t?n2:i2;return n.setColorAt(s,r),n.instanceColor.needsUpdate=!0,{instancedMesh:n,index:s,tile:e,type:i,isEnemy:t}}function eo(i,e,t,n){e||(e=i.player),t||(t=[...i.pawns]),n||(n=[...i.enemies]),dy(e.type),i.enemies.length=0,i.pawns.length=0;for(const s in wr){const r=wr[s];r.count=0,r.visible=!0}i.player={isEnemy:!1,mesh:md[e.type],tile:e.tile,type:e.type},i.playerElement=By[In.indexOf(e.type)];for(const s of Object.values(md))s.visible=!1,fR(s);if(i.player.mesh.visible=!0,i.pawns.push(...t.map(({type:s,tile:r})=>gd(s,r,!1))),i.enemies.push(...n.map(({type:s,tile:r})=>gd(s,r,!0))),!i.player)throw new Error("no player piece mesh");Si(i.player,i.getPosOnTile(i.player.tile));for(const s of i.enemies)Si(s,i.getPosOnTile(s.tile))}const Fo={rook:{model:"chess/rook.obj",position:new A(0,12,0),icon:"icons/chess/16x16-rook.png",iconOffset:[9,14],title:"ROOK",subtitle:"CHESS PIECE",playAction:i=>{const e=i.config.tree.children.game;e.value="chess",Vl.desiredCameraOffset.copy(bf(i)),Vl.snapshotTerrain(i),bo.takeOriginalSnapshot(i),i.startTransition({transition:$e.create("seamless",i),callback:()=>{hr(Tv)}}),i.onCtrlChange(e)}},thruster:{model:"raft/thruster.obj",position:new A(10,12,0),icon:"icons/raft/16x16-thruster.png",iconOffset:[0,14],title:"THRUSTER",subtitle:"PART",playAction:i=>{bo.takeOriginalSnapshot(i),i.startTransition({callback:()=>{i.config.tree.children.generator.value="all-ocean";const e=i.config.tree.children.game;e.value="raft",i.onCtrlChange(e),hr(Cv)}})}}},zy={layoutKey:"grabbedMeshDiagram",display:{type:"diagram",label:"grabbed-mesh-diagram",isVisible:!1}};async function c2(){for(const i of Ar){const e=Fo[i];h2(e)}}const Hy=[];function h2(i){const e=document.createElement("canvas");e.width=64,e.height=40;const{width:t,height:n}=e,s=e.getContext("2d");s.clearRect(0,0,t,n),s.strokeStyle="black";const r=wt(i.icon);s.drawImage(r,...i.iconOffset,r.width,r.height),ps(s,{width:t,height:n,label:i.title,offset:[6,3]}),ps(s,{width:t,height:n,label:i.subtitle,font:"mini",offset:[0,-12]}),Di(e),Hy.push(e)}function u2(i){var o;const e=(o=zy.display.imageset)==null?void 0:o.default;if(!e)throw new Error("grabbedMeshDiagram element has no buffer");const{width:t,height:n}=e,s=e.getContext("2d");s.clearRect(0,0,t,n);const r=Ar.indexOf(i);r!==-1&&s.drawImage(Hy[r],0,0)}const _d={layoutKey:"grabbedMeshPanel",display:{type:"panel",isVisible:!1}},d2={layoutKey:"grabbedMeshPlayButton",hotkeys:["ButtonA","ButtonStart"],display:{type:"button",label:"Play",gamepadPrompt:{name:"A",offset:[-22,0]},isVisible:!1},clickAction:w2},f2={layoutKey:"grabbedMeshCancelButton",hotkeys:["ButtonB"],display:{type:"button",label:"Cancel",gamepadPrompt:{name:"B",offset:[-22,0]},isVisible:!1},clickAction:M2},Mf=[_d,zy,d2,f2],Ar=["rook","thruster"],p2=.005,Vy=[new se(5592405),new se(11184810)],wo=new dt({color:Vy[0]}),Gy=new dt({color:11184810}),Oh=new dt({color:14540253,depthTest:!1});let Kl,Zl=!0;const Xs=new A,Fh=new Pi;function m2(i){wo.color.lerpColors(...Vy,.5+.5*Math.sin(performance.now()*p2));for(const e of Ar){const t=_s[e].mesh,n=Eo[e].mesh;if(!t)throw new Error("missing pickablePieceMesh for freecam pickable");if(!n)throw new Error("missing targetMesh for freecam pickable");n.getWorldPosition(Xs),n.getWorldQuaternion(Fh),Zl?(t.position.copy(Xs),t.quaternion.copy(Fh)):(t.position.lerp(Xs,.01*i),t.quaternion.slerp(Fh,.01*i),e===Kl&&Xs.subVectors(Xs,t.position).lengthSq()<.01&&(Zl=!0))}}const g2=new A;function _2(i){const e={name:Ar[0],pos:g2,distSq:1/0};for(const[t,{mesh:n}]of Object.entries(_s)){if(!n)continue;const s=Xs.copy(n.position).sub(i).setY(0).lengthSq();s<e.distSq&&(e.name=t,e.pos.copy(n.position),e.distSq=s)}return e}function x2(i){const e=_s[i].mesh;if(e)return e.getWorldPosition(new A)}const _s=Object.fromEntries(Ar.map(i=>[i,y2(i,Fo[i])]));function y2(i,e){return{meshLoader:async()=>v2(i,e),defaultMat:wo,hoverMat:Gy,clickAction:t=>b2(t,i)}}function v2(i,e){let t=Uo(e.model).clone();t.traverse(s=>{s instanceof at&&(s.geometry=s.geometry.clone(),s.geometry.center(),s.geometry.rotateY(Math.PI*.5))});const n=1;return t.scale.set(n,n,n),t=Kd(t),vr(t,wo),t.name=`freecam-pickable-${i}`,t}function b2({seaBlock:i},e,t){if(Ye("click"),Eo[e].layoutKey==="grabbedMesh"){So(i);return}ms(null),So(i),Eo[e].layoutKey="grabbedMesh";const n=_s[e];n.defaultMat=Oh,n.hoverMat=Oh,vr(n,Oh),Kl=e,Zl=!1,Mf.forEach(({display:s})=>{s.isVisible=!0,s.needsUpdate=!0}),u2(Kl)}function M2({seaBlock:i}){Ye("click"),So(i)}function w2({seaBlock:i}){Ye("click");const e=Kl;So(i),e&&Fo[e].playAction(i)}function So(i){for(const[e,t]of Object.entries(Eo))if(t.layoutKey=void 0,t.mesh){const n=Fo[e];t.mesh.position.copy(n.position)}for(const e of Object.values(_s))e.defaultMat=wo,e.hoverMat=Gy,vr(e,wo);Zl=!1;for(const{display:e}of Mf)e.isVisible=!1;i.layeredViewport.handleResize(i)}const Eo=Object.fromEntries(Ar.map(i=>[i,S2(i,Fo[i])]));function S2(i,e){return{meshLoader:async()=>{const n=new at(new Bt(1,1,1),new dt({color:16711680}));return n.position.copy(e.position),n.visible=!1,n}}}const i0=Math.pow(10,2),s0=Math.pow(.1,2),E2=1e-4,ja=new A,r0=new A,A2={x:0,y:1,z:0},yi=new A,Ka=new A,Fn=new A,Vf=class Vf extends St{constructor(){super(...arguments);E(this,"config",as);E(this,"cameraAnchor");E(this,"waveMaker");E(this,"_lastAnchorPosition",new A)}doesAllowOrbitControls(){return!0}doesAllowGgui(){return!1}doesAllowGgui3DCursor(){return!_d.display.isVisible}reset(t){const{sphereGroup:n}=t;this.cameraAnchor=n.members[0],this.cameraAnchor.isGhost=!0,this.cameraAnchor.isVisible=!1,n.setInstanceColor(0,new se(65280));const{x:s,z:r}=t.terrain.centerXZ;this.cameraAnchor.position.set(s,30,r),this._lastAnchorPosition.copy(this.cameraAnchor.position),this.waveMaker=new Dl(n.members[1],t),this.centerOnAnchor(t)}resetCamera(t){const{x:n,z:s}=this.cameraAnchor.position,r=this.getCamOffset(t);t.camera.position.set(n+r.x,r.y,s+r.z)}update(t){const{seaBlock:n,dt:s}=t;m2(s);const r=this._moveWithWasdOrLeftJoystick(t);if(!_d.display.isVisible&&!n.isShowingSettingsMenu&&n.isUsingGamepad&&r.x===0&&r.z===0){const{name:o,pos:l,distSq:c}=_2(this.cameraAnchor.position);if(c<i0){const u=Math.max(0,(c-s0)/(i0-s0));this.accelSphere(this.cameraAnchor,l,s*E2*Math.pow(u,.1)),ms(l),an.position.copy(l),an.visible=!0,rf({selectAction:(d,a)=>{if(a===0)return;const{clickAction:h}=_s[o];if(h)return h({seaBlock:n}),!0},navAction:()=>{}})}else yr()}this.centerOnAnchor(n),this.waveMaker.wmRadius=n.config.flatConfig.visibleRadius/2,this.waveMaker.sphere.scalePressure=.5,this.waveMaker.updateWaveMaker(t),cc(t),wf(t)}_moveWithWasdOrLeftJoystick(t){const{seaBlock:n,dt:s}=t,{CAM_ACCEL:r}=this.config.flatConfig,{camera:o}=n;yi.set(o.position.x-this.cameraAnchor.position.x,0,o.position.z-this.cameraAnchor.position.z),yi.lengthSq()>0?yi.normalize():yi.set(0,0,1),Ka.crossVectors(yi,A2);const l=n.isShowingSettingsMenu,c=_n.upBtn&&!l,u=_n.downBtn&&!l,d=_n.leftBtn&&!l,a=_n.rightBtn&&!l;Fn.set(0,0,0),c&&Fn.sub(yi),u&&Fn.add(yi),d&&Fn.add(Ka),a&&Fn.sub(Ka);let h=0;Fn.lengthSq()>0&&(h=1);const f=_x();if(f){const{x:_,y:m}=f;h=Math.min(1,(Math.hypot(_,m)-gx)*2),Fn.addScaledVector(Ka,-_),Fn.addScaledVector(yi,m)}return r0.copy(this.cameraAnchor.position).addScaledVector(Fn,10),this.accelSphere(this.cameraAnchor,r0,s*r*h),Fn}accelSphere(t,n,s){ja.set(n.x-t.position.x,0,n.z-t.position.z).normalize(),ja.multiplyScalar(s),t.velocity.x+=ja.x,t.velocity.z+=ja.z}centerOnAnchor(t){const{cameraAnchor:n}=this,{terrain:s,camera:r,orbitControls:o}=t;if(!n)return;const{x:l,z:c}=n.position;r.position.set(l+(r.position.x-this._lastAnchorPosition.x),r.position.y,c+(r.position.z-this._lastAnchorPosition.z)),this._lastAnchorPosition.copy(n.position),o.target.set(l,sf.y,c),o.update(),s.panToCenter(l,c)}};St.register("free-cam",{factory:()=>new Vf,guiName:"free-cam",elements:[...Object.values(_s),...Object.values(Eo)]});let Ao=Vf;function wf(i){const{seaBlock:e,dt:t}=i,n=e.orbitControls,s=mn.ButtonLT-mn.ButtonRT,r=2*t*s;r<0?n._dollyIn(n._getZoomScale(r)):r>0&&n._dollyOut(n._getZoomScale(r))}const os=new vx(1);os.controlMode="raft";const jt=new Hn,T2={meshLoader:async()=>{for(const i of MT)jt.add(await i.meshLoader());for(const i of["leftFoot","rightFoot","torso"])os[i].mesh=await os[i].meshLoader(),jt.add(os[i].mesh);return jt.add(Ki),jt.add(wi),jt.add(Li),jt.add(Ui),jt.add(mo),jt}};let to;function C2(){return rs?Ax:Rx}function R2(i){j||Tf(i),j.hlTiles.clear(),os.reset(),cC(),to=RT(i)}function P2(i){cc(i),wf(i)}function I2(i){const{dt:e}=i;os.update(i),to.update(e),to.alignMesh(jt,e),i.seaBlock.isShowingSettingsMenu||P2(i),hC(os.torsoPos),zA(j.thrusters,to),L2(e)}function L2(i){o0.makeRotationY(.002*i);const e=Er.thruster;for(const[t,n]of j.thrusters.entries())n.isFiring&&(e.getMatrixAt(t,Nh),Nh.multiply(o0),e.setMatrixAt(t,Nh));e.instanceMatrix.needsUpdate=!0}const o0=new We,Nh=new We,Wy={layoutKey:"pieceDialogPanel",isPickable:!1,display:{type:"panel",isVisible:!1,shouldClearBehind:!0}},D2={cockpit:"Cockpit",floor:"Floor",button:"Button",thruster:"Thruster"},xd=Object.fromEntries(hx.map(i=>[i,{layoutKey:"pieceDialogPanel",isPickable:!1,display:{type:"label",label:D2[i],isVisible:!1}}])),pc={layoutKey:"pieceDeleteBtn",display:{type:"button",label:"DELETE",font:"mini",isVisible:!1},clickAction:()=>{j.currentPhase==="edit-button"?j.editingButton&&(j.deletePiece(j.raftPieces[j.editingButton.pieceIndex]),j.editingButton=void 0,j.startPhase("idle")):or&&(j.deletePiece(or),or=void 0)}},Xy=[Wy,...Object.values(xd),pc];function Sl({display:i},e){i.isVisible=e,i.needsUpdate=!0}let or;function a0(i){or=i,$y(i),Sl(pc,!0),yC({x:i.tile.x-j.centerTile.x,z:i.tile.z-j.centerTile.z})}function $y(i){for(const e in xd)Sl(xd[e],e===i.type);if(Sl(pc,!1),Sl(Wy,!0),j.currentPhase==="edit-button")go(j.editingButton);else if(j.currentPhase!=="show-all-wires"&&(Px(),i.type==="button")){const e=j.raftPieces.indexOf(i),t=j.buttons.find(n=>n.pieceIndex===e);t&&go(t)}}function Sf(i){for(const{display:e}of Xy)e.isVisible=!1,e.needsUpdate=!0;xr(i)}const Ef={layoutKey:"buildCancelBtn",hotkeys:["ButtonB"],display:{type:"button",label:"DONE",gamepadPrompt:{name:"B",offset:[0,-16]},font:"mini",isVisible:!1},clickAction:()=>j.cancelBuild()},U2={idle:"...","edit-button":"Button","show-all-wires":"show all wires","place-floor":"place floors","place-button":"place buttons","place-thruster":"place thrusters"},Af=Object.fromEntries(qd.map(i=>[i,{layoutKey:"buildPhasePanel",isPickable:!1,display:{type:"panel",label:U2[i],isVisible:!1}}]));function O2(i){for(const e of qd)no(Af[e],e===i);no(Ef,i!=="idle"),no(pc,i==="edit-button")}function no({display:i},e){i.isVisible=e,i.needsUpdate=!0}function F2(){for(const i of qd)no(Af[i],!1);no(Ef,!1)}const N2=[...Object.values(Af),Ef],k2=[{type:"floor",x:-2,z:-2},{type:"floor",x:-2,z:-1},{type:"floor",x:-2,z:0},{type:"floor",x:-2,z:1},{type:"floor",x:-2,z:2},{type:"floor",x:-1,z:-2},{type:"floor",x:-1,z:-1},{type:"floor",x:-1,z:0},{type:"floor",x:-1,z:1},{type:"floor",x:-1,z:2},{type:"floor",x:0,z:-2},{type:"floor",x:0,z:-1},{type:"floor",x:0,z:0},{type:"floor",x:0,z:1},{type:"floor",x:0,z:2},{type:"floor",x:1,z:-2},{type:"floor",x:1,z:-1},{type:"floor",x:1,z:0},{type:"floor",x:1,z:1},{type:"floor",x:1,z:2},{type:"floor",x:2,z:-2},{type:"floor",x:2,z:-1},{type:"floor",x:2,z:0},{type:"floor",x:2,z:1},{type:"floor",x:2,z:2},{type:"thruster",x:-3,z:2},{type:"thruster",x:-3,z:0},{type:"thruster",x:-3,z:-2},{type:"button",x:1,z:0,triggers:[27]},{type:"button",x:0,z:1,triggers:[28]},{type:"button",x:0,z:-1,triggers:[26]}],Za=3;let El,l0,j;function Tf(i,e){El||(El=new Wl(50,50,Qt.create("square")),l0=El.xzToIndex(25,25)),j=new z2(i,l0),V2(e??k2)}function B2(){const i=j.context,e=i.config.tree.children.game;e.value="free-cam",i.startTransition({callback:()=>{i.toggleSettings(!1),bo.restoreOriginalSnapshot(i),hr(ic),i.onCtrlChange(e)}})}class z2{constructor(e,t){E(this,"cameraDistance",10);E(this,"currentPhase","idle");E(this,"waveMaker");E(this,"grid");E(this,"allTiles");E(this,"hlTiles",new BA);E(this,"raftTiles");E(this,"raftPieces",[]);E(this,"thrusters",[]);E(this,"buttons",[]);E(this,"centerPos",new A);E(this,"editingButton");this.context=e,this.centerTile=t,this.grid=El,this.allTiles=this.grid.tileIndices.map(({i:s})=>s),this.getPosOnTile(t,this.centerPos),jt.position.copy(this.centerPos),Object.values(Er).forEach(s=>{s.position.set(0,0,0),s.count=0}),this.waveMaker=new Dl(e.sphereGroup.members[0],e),this.raftTiles=new Set([t.i]);const n={raft:this,mesh:wT,tile:t,type:"cockpit"};this.raftPieces.push(n)}_buildTestFloor(){const{centerTile:e}=this,t=2;for(let n=-t;n<=t;n++)for(let s=-t;s<=t;s++){const r=this.grid.xzToIndex(e.x+n,e.z+s);r&&this.buildPiece("floor",r)}}_buildTestThrusters(){const{centerTile:e}=this,t=-3;for(const n of[2,0,-2]){const s=this.grid.xzToIndex(e.x+t,e.z+n);s&&this.buildPiece("thruster",s)}}_buildTestButtons(){const[e,t,n]=this.thrusters;this._addButton(1,0,[t]),this._addButton(0,1,[n]),this._addButton(0,-1,[e])}_addButton(e,t,n){const{centerTile:s}=this,r=this.grid.xzToIndex(s.x+e,s.z+t);r&&this.buildPiece("button",r,n)}getPiecesOnTile(e){const t=[];for(const n of this.raftPieces)n.tile.i===e.i&&t.push(n);return t}getRelevantPiece(e){const t=this.getPiecesOnTile(e);if(t.length>1&&t[0].type==="floor")return t[1];if(t.length===1)return t[0]}getPickedPieceMesh(e){const{pickedMesh:t}=e;if(t){const n=t.gameElement;if(n&&"pieceName"in n){const s=n.pieceName,{instanceId:r}=e.rawPick;if(typeof r=="number")return this.identifyPiece(s,r)}}}identifyPiece(e,t){for(const n of this.raftPieces)if(n.type===e&&"index"in n&&n.index===t)return n}deletePiece(e){const t=this.raftPieces.indexOf(e);if(t===-1)throw new Error("piece to be deleted is not in raftPieces");if(e.type==="thruster"){const s=this.thrusters.find(({pieceIndex:r})=>r===t);if(!s)throw new Error("thruster piece to be deleted has no AutoThruster instance");for(const{triggers:r}of this.buttons){const o=r.indexOf(s);o>-1&&r.splice(o,1)}}if(this.raftPieces.splice(t,1),e.type==="thruster"){const s=this.thrusters.findIndex(({pieceIndex:r})=>r===t);if(s===-1)throw new Error("thruster piece to be deleted has no AutoThruster instance");this.thrusters.splice(s,1)}if(e.type==="button"){const s=this.buttons.findIndex(({pieceIndex:r})=>r===t);if(s===-1)throw new Error("button piece to be deleted has no RaftButton instance");this.buttons.splice(s,1)}for(const s of[...this.buttons,...this.thrusters]){if(s.pieceIndex===t)throw new Error("logical button/thruster to be deleted should have been removed");s.pieceIndex>t&&s.pieceIndex--}const n=Yy();Tf(this.context,n)}buildPiece(e,t,n){const s=ST(this,e,t);if(this.raftTiles.add(t.i),ET(s,this.getPosOnTile(t).sub(this.centerPos)),this.raftPieces.push(s),e==="thruster")this.thrusters.push({dx:t.x-this.centerTile.x,dz:t.z-this.centerTile.z,imIndex:this.thrusters.length,pieceIndex:this.raftPieces.length-1,direction:ux(s),isFiring:!1});else if(e==="button"){if(!n)throw new Error("raft button requires triggers");this.buttons.push({imIndex:this.buttons.length,pieceIndex:this.raftPieces.length-1,dx:t.x-this.centerTile.x,dz:t.z-this.centerTile.z,triggers:n,isPressed:!1})}}clickWorld(e){const{pickedTile:t}=e;if(t&&this.hlTiles.clickable.has(t.i)&&this.currentPhase.startsWith("place-")){const n=this.currentPhase.slice(6);return this.buildPiece(n,t),this.cancelBuild(),!0}return!1}startPhase(e){this.currentPhase=e,Sf(this.context),e==="idle"?(F2(),lx(),qs(),this.hlTiles.clear()):O2(this.currentPhase),xr(this.context),e==="show-all-wires"?go():Px()}cancelBuild(){this.startPhase("idle"),this.hlTiles.clear()}getPosOnTile(e,t){const{x:n,z:s}=this.grid.indexToPosition(e),r=12,o=t||H2;return o.set(n,r,s),o}}const H2=new A;function Yy(){const i=[],e=[...j.buttons];e.reverse();for(const{type:t,tile:n}of j.raftPieces){if(t==="cockpit")continue;const s=n.x-j.centerTile.x,r=n.z-j.centerTile.z;if(t==="button"){const o=e.pop();if(!o)throw new Error("raft.buttons does not agree with raft.raftPieces");const l=o.triggers.map(c=>c.pieceIndex);i.push({type:t,x:s,z:r,triggers:l})}else i.push({type:t,x:s,z:r})}return i}function V2(i){const{centerTile:e,grid:t}=j;for(const s of i){const{type:r,x:o,z:l}=s,c=t.xzToIndex(e.x+o,e.z+l);c&&j.buildPiece(r,c,[])}let n=0;for(const s of i)s.type==="button"&&G2(i,s,n++)}function G2(i,e,t){for(const n of e.triggers){if(i[n-1].type!=="thruster")throw new Error("button triggers non-thruster piece in blueprint");if(j.raftPieces[n].type!=="thruster")throw new Error("button triggers non-thruster piece in raft");const s=j.thrusters.find(r=>r.pieceIndex===n);if(!s)throw new Error("button trigger has no matching AutoThruster instance");j.buttons[t].triggers.push(s)}}const W2={children:{copyRaft:{label:"Copy Raft",action:()=>navigator.clipboard.writeText(JSON.stringify(Yy(),null,2)),hasNoEffect:!0},pasteRaft:{label:"Paste Raft",action:async i=>{const e=await navigator.clipboard.readText(),t=JSON.parse(e);Tf(i,t)}}}},Gf=class Gf extends tt{constructor(){super(...arguments);E(this,"tree",W2)}};tt.register("raft",()=>new Gf);let c0=Gf;tt.create("raft");const X2=[{x:1,z:0},{x:0,z:-1},{x:-1,z:-1},{x:-1,z:0},{x:0,z:1},{x:1,z:-1}],$2=[{x:1,z:0},{x:0,z:-1},{x:1,z:1},{x:-1,z:0},{x:0,z:1},{x:-1,z:1}],jr=Math.sqrt(3)/2,Y2=[{n:6,radius:jr,angle:Math.PI/6}],Wf=class Wf extends Qt{constructor(){super(...arguments);E(this,"shapes",Y2)}getShapeIndex(t,n){return 0}getAdjacent(t,n){return Math.abs(t)%2===1?$2:X2}getDiagonal(){return[]}positionToIndex(t,n){const s=Math.round(t/(1.5*jr)),r=Math.round(n/(Math.sqrt(3)*jr)-.5*(s&1));return{x:s,z:r}}indexToPosition(t,n){return{x:3/2*jr*t,z:Math.sqrt(3)*jr*(n+.5*(t&1))}}};Qt.register("hex",()=>new Wf);let h0=Wf;const qy=Math.SQRT2/(2*(1+Math.SQRT2)*Math.sin(Math.PI/8)),q2=(2-2*qy)*Math.cos(Math.PI/8),j2=[{n:8,radius:qy,angle:Math.PI/8},{n:4,radius:q2,angle:Math.PI/4}],Xf=class Xf extends Qt{constructor(){super(...arguments);E(this,"shapes",j2)}getShapeIndex(t,n){return Math.abs((t+n)%2)}positionToIndex(t,n){return{x:Math.round(t),z:Math.round(n)}}indexToPosition(t,n){return{x:t,z:n}}getAdjacent(t,n){return Math.abs((t+n)%2)===1?K2:Z2}getDiagonal(t,n){return[]}};Qt.register("octagon",()=>new Xf);let u0=Xf;const K2=[{x:1,z:0},{x:-1,z:0},{x:0,z:1},{x:0,z:-1}],Z2=[{x:1,z:0},{x:-1,z:0},{x:0,z:1},{x:0,z:-1},{x:1,z:1},{x:1,z:-1},{x:-1,z:1},{x:-1,z:-1}],J2=[{x:1,z:0},{x:-1,z:0},{x:0,z:1},{x:0,z:-1}],Q2=[{x:1,z:1},{x:1,z:-1},{x:-1,z:1},{x:-1,z:-1}],yd=[{n:4,radius:Math.sqrt(2)/2,angle:Math.PI/4}],$f=class $f extends Qt{constructor(){super(...arguments);E(this,"shapes",yd)}getShapeIndex(t,n){return 0}getAdjacent(){return J2}getDiagonal(){return Q2}positionToIndex(t,n){return{x:Math.floor(t),z:Math.floor(n)}}indexToPosition(t,n){return{x:t+.5,z:n+.5}}};Qt.register("square",()=>new $f);let vd=$f;const Jl=2,bd=Jl/Math.sqrt(3),kh=Jl*Math.sqrt(3)/2,eL=[{n:3,radius:bd,angle:0},{n:3,radius:bd,angle:Math.PI}],Yf=class Yf extends Qt{constructor(){super(...arguments);E(this,"shapes",eL)}getShapeIndex(t,n){return Math.abs((t+n)%2)}positionToIndex(t,n){const s=Math.round(t/(Jl/2)),r=Math.round(n/kh),o=[{x:s,z:r},{x:s,z:r+1},{x:s+1,z:r},{x:s+1,z:r+1}];let l=o[0],c=1/0;for(const u of o){const d=this.indexToPosition(u.x,u.z),a=Math.pow(d.x-t,2)+Math.pow(d.z-n,2);a<c&&(l=u,c=a)}return l}indexToPosition(t,n){const s=t*Jl/2;let r=n*kh;return Math.abs(t%2)===Math.abs(n%2)&&(r-=kh-bd),{x:s,z:r}}getAdjacent(t,n){return Math.abs(t%2)===Math.abs(n%2)?iL:tL}getDiagonal(t,n){return Math.abs(n%2)===Math.abs(t%2)?sL:nL}};Qt.register("triangle",()=>new Yf);let d0=Yf;const tL=[{x:1,z:0},{x:-1,z:0},{x:0,z:1}],nL=[{x:1,z:1},{x:1,z:-1},{x:-1,z:1},{x:-1,z:-1},{x:0,z:-1},{x:2,z:0},{x:2,z:1},{x:-2,z:0},{x:-2,z:1}],iL=[{x:1,z:0},{x:-1,z:0},{x:0,z:-1}],sL=[{x:1,z:1},{x:1,z:-1},{x:-1,z:1},{x:-1,z:-1},{x:0,z:1},{x:2,z:0},{x:2,z:-1},{x:-2,z:0},{x:-2,z:-1}],qf=class qf extends St{constructor(){super(...arguments);E(this,"reset",t=>{t.config.flatConfig.transitionMode==="skip"&&this.resetCamera(t),KI(t)});E(this,"resetCamera",t2);E(this,"getTerrainRenderPipeline",()=>ff);E(this,"update",JI);E(this,"doesAllowGgui",qI);E(this,"doesAllowGgui3DCursor",YI);E(this,"doesAllow3DRender",$I);E(this,"getCamOffset",bf)}};St.register("chess",{factory:()=>new qf,guiName:"chess",elements:[...s2,...By,jl]});let f0=qf;const jy=20;function rL(i){if(j.cameraDistance>jy)return!1;Ki.visible=!1,or||(wi.visible=!1,Sf(i.seaBlock));const e=Zy(i),t=j.grid.xzToIndex(j.centerTile.x+e.x,j.centerTile.z+e.z);return t&&io(e,t),!0}function io(i,e){if(j.currentPhase!=="edit-button"&&j.hlTiles.clickable.has(e.i))od(i,"buildable");else if(od(i,"default"),!or){const t=j.getRelevantPiece(e);t&&($y(t),document.documentElement.style.cursor="pointer")}}function oL(i){if(j.cameraDistance>jy)return!1;const e=Zy(i),t=j.grid.xzToIndex(j.centerTile.x+e.x,j.centerTile.z+e.z);return t?Ky(e,t):!1}function Ky(i,e){const t=j.getRelevantPiece(e);if(j.hlTiles.clickable.has(e.i)){if(j.currentPhase==="place-thruster")return j.buildPiece("thruster",e),j.hlTiles.updateBuildableTiles("thruster"),io(i,e),!0;if(j.currentPhase==="place-floor")return j.buildPiece("floor",e),j.hlTiles.updateBuildableTiles("floor"),io(i,e),!0;if(j.currentPhase==="place-button")return j.buildPiece("button",e,[]),j.hlTiles.updateBuildableTiles("button"),io(i,e),!0;if(j.currentPhase==="edit-button"&&j.editingButton&&(t==null?void 0:t.type)==="thruster"){const n=j.raftPieces.indexOf(t),s=j.thrusters.find(({pieceIndex:r})=>r===n);if(s){const{triggers:r}=j.editingButton;r.includes(s)?r.splice(r.indexOf(s),1):r.push(s),go(j.editingButton)}}}else if(od(i,"default"),j.currentPhase==="edit-button"&&t&&j.startPhase("idle"),t)if(t.type==="button"){a0(t);const n=j.raftPieces.indexOf(t);j.editingButton=j.buttons.find(({pieceIndex:s})=>s===n),j.startPhase("edit-button"),qs(),go(j.editingButton),j.hlTiles.highlightThrusters()}else j.startPhase("idle"),a0(t);else j.currentPhase!=="edit-button"&&(wi.visible=!1,Sf(j.context));return!1}const Ja=new A,Gr=new A,Bh=new We,zh=new A;function Zy(i){const e=jt,t=i.raycaster;if(Ja.copy(t.ray.origin),Gr.copy(t.ray.direction),Bh.copy(e.matrixWorld).invert(),Ja.applyMatrix4(Bh),Gr.transformDirection(Bh),Math.abs(Gr.y)<1e-6)return{x:0,z:0};const n=-Ja.y/Gr.y;return zh.copy(Ja).add(Gr.multiplyScalar(n)),{x:Math.round(zh.x),z:Math.round(zh.z)}}const Qa=new xe,Hh=new A;function Jy(i,e){if(Qa.set(0,0),i&&typeof e=="number"){const r=j.context,{camera:o,orbitControls:l}=r,c=-Math.PI/2+Math.atan2(o.position.z-l.target.z,o.position.x-l.target.x);jt.getWorldDirection(Hh);const u=-Math.PI/2+Math.atan2(Hh.z,Hh.x);Qa.set(i.x+Math.cos(e+c-u),i.z+Math.sin(e+c-u))}const t=j.currentPhase==="idle"?j.allTiles:[...j.hlTiles.clickable];let n=null,s=1/0;for(const r of t){if(i&&i.i===r)continue;const o=j.grid.tileIndices[r],l=o.x-Qa.x,c=o.z-Qa.y,u=l*l+c*c;u<s&&(n=o,s=u)}if(n){const r=n,o={x:r.x-j.centerTile.x,z:r.z-j.centerTile.z};io(o,r),j.getPosOnTile(r,an.position),jt.updateMatrixWorld(),an.position.applyMatrix4(jt.matrixWorld),an.visible=!0,ms(an.position),rf({selectAction:(l,c)=>{if(c===1)return Ky(o,r),!0},navAction:l=>{uf(),Jy(r,l)}})}}const Vh=5,aL=new A(Vh,Vh,Vh),Gh=10,lL=new A(Gh,Gh,Gh),jf=class jf extends Ao{getCamOffset(e){const{w:t,h:n}=e.layeredViewport;return n>t?lL:aL}reset(e){super.reset(e),this.cameraAnchor.isGhost=!0,R2(e)}update(e){e.seaBlock.isUsingGamepad&&j.currentPhase!=="idle"&&!e.seaBlock.isShowingSettingsMenu&&!an.visible&&Jy(),this.cameraAnchor.position=to.getCameraTarget(),this.cameraAnchor.isGhost=!0,this.centerOnAnchor(e.seaBlock),I2(e)}centerOnAnchor(e){const{cameraAnchor:t}=this,{terrain:n,camera:s,orbitControls:r}=e;if(!t)return;const{x:o,z:l}=t.position;s.position.set(o+(s.position.x-this._lastAnchorPosition.x),s.position.y,l+(s.position.z-this._lastAnchorPosition.z)),this._lastAnchorPosition.copy(t.position),r.target.set(o,13,l),r.update(),n.panToCenter(o,l)}};St.register("raft",{factory:()=>new jf,guiName:"raft",elements:[T2]});let p0=jf;const Kf=class Kf extends St{constructor(){super(...arguments);E(this,"player");E(this,"lastPlayerPosition")}reset(t){const{sphereGroup:n,camera:s}=t;this.player=n.members[0],this.player.isGhost=!1,this.player.isFish=!1,this.player.isVisible=!0,n.setInstanceColor(0,new se(16711680));const{x:r,z:o}=this.player.position;this.player.position=new A(r,30,o),this.lastPlayerPosition=this.player.position.clone();for(let c=1;c<n.members.length;c++)n.members[c].isGhost=!0;const l=this.getCamOffset(t);s.position.set(r+l.x,l.y,o+l.z),this.centerOnPlayer(t)}update(t){this.centerOnPlayer(t.seaBlock)}centerOnPlayer(t){const{player:n,lastPlayerPosition:s}=this,{terrain:r,camera:o,orbitControls:l}=t;if(!n)return;const{x:c,z:u}=n.position;o.position.set(c+(o.position.x-s.x),o.position.y,u+(o.position.z-s.z)),this.lastPlayerPosition=n.position.clone();const d=this.getCamTargetOffset();l.target.set(c+d.x,d.y,u+d.z),l.update(),r.panToCenter(c,u)}};St.register("sphere-test",{factory:()=>new Kf,guiName:"empty"});let m0=Kf;const cL=new A(-1e9,30,-1e9),hL=new A(6,20,6),uL=new A(0,-5,0),g0=new A,Zf=class Zf extends Ao{getCamOffset(){return hL}getCamTargetOffset(){return uL}doesAllowOrbitControls(){return!1}update(e){const{seaBlock:t}=e,{dt:n}=e,{terrain:s,orbitControls:r}=t;this.centerOnAnchor(t);const{CAM_ACCEL:o}=as.flatConfig;this.accelSphere(this.cameraAnchor,cL,n*o*.1);const{x:l,z:c}=s.centerXZ,u=10;g0.set(l+u,10,c+u),this.waveMaker.sphere.position=g0,this.waveMaker.sphere.scalePressure=.2;const d=this.getCamTargetOffset();r.target.set(l+d.x,d.y,c+d.z),r.update()}};St.register("splash-screen",{factory:()=>new Zf,guiName:"splash-screen"});let _0=Zf;const x0=Array.from({length:1e3},()=>new xe);let Wh=0;function dL(){return Wh=(Wh+1)%x0.length,x0[Wh]}function Cf(i,e){if(i.length===1)return i[0];const t=[];for(let n=1;n<i.length;n++)t.push(dL().lerpVectors(i[n-1],i[n],e));return Cf(t,e)}function Tn(i,e,t){const n=new xe;return n.set(i,e),n}function Kt(i,e){return i+(e-i)*Math.random()}const pt={scaffoldThickness:.002,vineThickness:.002,vinePadding:0,spiralDensity:[1.3,130],helixDist:[.1,.3],maxJump:.01,growthSpeed:1e-4,branchRate:.15,twigRate:.05,twigLen:[.01,.05],leafRate:.5,leafSize:[.002,.004],leafLen:[.011,.02]},_e={t:0,resetCountdown:1e3,resetDelay:20*1e3,hue:.5,hueVariance:.6,buffer:{},ctx:{},canvas:{},finalCtx:{},canvasOffsetX:0,canvasOffsetY:0,canvasScale:0,centerPos:Tn(.5,.5),screenCorners:[],allScaffolds:[],allVines:[],helix_d:0,hpid2:0};_e.helix_d=pt.scaffoldThickness+pt.vineThickness;_e.hpid2=Math.pow(Math.PI*_e.helix_d,2);const Rf={layoutKey:"smBanner",display:{type:"label",icon:"sm-banner-edge.png"}},Qy={layoutKey:"smStartBtn",gamepadNavBox:"smStartBtn",hotkeys:["Space","ButtonStart"],display:{type:"button",border:"16x16-btn-sm",label:"START",font:"mini",color:"white",shouldClearBehind:!0,gamepadPrompt:{offset:[0,16]}},clickAction:({seaBlock:i})=>{Ye("smStart"),$e.isFirstUncover=!0,i.config.tree.children.game.value="free-cam",i.startTransition({callback:()=>{hr(ic),_e.canvas.style.display="none"}})}},ev={layoutKey:"smSettingsBtn",gamepadNavBox:"smSettingsBtn",display:{type:"button",border:"16x16-btn-sm",label:"SETTINGS",font:"mini",color:"white",shouldClearBehind:!0,gamepadPrompt:{offset:[0,16]}},clickAction:({seaBlock:i})=>{if(i.toggleSettings(),i.isShowingSettingsMenu)for(const{display:e}of nv)e.isVisible=!1,e.needsUpdate=!0;i.refreshGui()}},tv={layoutKey:"smText",display:{type:"label",label:`    warning

flashing lights`,color:"white"}},nv=[Rf,Qy,ev,tv],ar=[{duration:1e3,elements:[]},{duration:2e3,elements:[tv]},{duration:1e3,triggers:["music"],elements:[]},{duration:1/0,triggers:["ivy"],elements:[Rf,Qy,ev]}];function fL(i){let e=i;for(const[t,n]of ar.entries())if(e-=n.duration,e<0)return t;return ar.length-1}function pL(i){for(const[e,{elements:t}]of ar.entries()){const n=e===i;for(const{display:s}of t)s.isVisible=n,s.needsUpdate=!0}}class Xh{constructor(e,t){E(this,"a");E(this,"b");E(this,"angle");E(this,"isOccupied",!1);E(this,"isEdge",!1);this.a=e.clone(),this.b=t.clone(),this.angle=Math.atan2(t.y-e.y,t.x-e.x)}draw(e){e.moveTo(this.a.x,this.a.y),e.lineTo(this.b.x,this.b.y)}}const y0=Array.from({length:1e5},()=>new xe);let $h=0;function Yh(){return $h=($h+1)%y0.length,y0[$h]}const iv=Math.PI,mL=2*iv;class gL{constructor(e,t,n){E(this,"a",Yh());E(this,"b",Yh());E(this,"c",Yh());E(this,"infront");E(this,"maxRad");E(this,"nSegs");E(this,"growthDuration");E(this,"t");E(this,"pt");this.infront=n,this.maxRad=Kt(...pt.leafSize);const s=Kt(...pt.leafLen);this.a.copy(e),this.b.set(e.x+Math.cos(t)*(s/2)+Math.cos(t+Math.PI/2)*Kt(-s/4,s/4),e.y+Math.sin(t)*(s/2)+Math.sin(t+Math.PI/2)*Kt(-s/4,s/4)),this.c.set(e.x+Math.cos(t)*s,e.y+Math.sin(t)*s),this.nSegs=Math.floor(s*1e3),this.growthDuration=10*s/pt.growthSpeed,this.t=0,this.pt=0}update(e){this.pt=this.t,this.t+=e}isDone(){return this.t>this.growthDuration}getNext(){return[]}draw(e){const t=this.nSegs,n=Math.floor(t*this.pt/this.growthDuration),s=Math.floor(t*this.t/this.growthDuration);for(let r=n;r<s&&r<t;r++){const o=Cf([this.a,this.b,this.c],r/t);let l=this.maxRad*Math.sin(Math.PI*r/t);l<pt.vineThickness/2&&(l=pt.vineThickness/2),e.beginPath(),e.moveTo(o.x,o.y),e.arc(o.x,o.y,l,0,2*Math.PI),e.fill();let c=this.maxRad*Math.sin(iv*r/t);c<pt.vineThickness/2&&(c=pt.vineThickness/2),e.beginPath(),e.moveTo(o.x,o.y),e.arc(o.x,o.y,c,0,mL),e.fill()}return[]}}const v0=Array.from({length:1e5},()=>new xe);let qh=0;function jh(){return qh=(qh+1)%v0.length,v0[qh]}class _L{constructor(e,t,n){E(this,"a",jh());E(this,"b",jh());E(this,"c",jh());E(this,"infront");E(this,"nSegs");E(this,"growthDuration");E(this,"t");E(this,"pt");this.infront=n;const s=Kt(...pt.twigLen);this.a.copy(e),this.b.set(e.x+Math.cos(t)*(s/2)+Math.cos(t+Math.PI/2)*Kt(-s,s),e.y+Math.sin(t)*(s/2)+Math.sin(t+Math.PI/2)*Kt(-s,s)),this.c.set(e.x+Math.cos(t)*s,e.y+Math.sin(t)*s),this.nSegs=Math.floor(s*1e3),this.growthDuration=s/pt.growthSpeed,this.t=0,this.pt=0}update(e){this.pt=this.t,this.t+=e}isDone(){return this.t>this.growthDuration}getNext(){if(Math.random()<pt.leafRate){const e=Math.atan2(this.c.y-this.b.y,this.c.x-this.b.x);return[new gL(this.b,e,this.infront)]}return[]}draw(e){const t=this.nSegs,n=Math.floor(t*this.pt/this.growthDuration),s=Math.floor(t*this.t/this.growthDuration);for(let r=n;r<s&&r<t;r++){const o=Cf([this.a,this.b,this.c],r/t);e.beginPath(),e.moveTo(o.x,o.y),e.arc(o.x,o.y,pt.vineThickness/2,0,2*Math.PI),e.fill()}return[]}}const b0=new xe,M0=Array.from({length:1e3},()=>new xe);let Kh=0;function el(){return Kh=(Kh+1)%M0.length,M0[Kh]}const xL=new xe,yL=new xe,To=Math.PI,w0=2*To,S0=To/2,E0=To/4;class is{constructor(e,t,n,s=!1,r=null){E(this,"scaffold");E(this,"start");E(this,"stop");E(this,"reverse");E(this,"reverseHelix");E(this,"startPadding");E(this,"stopPadding");E(this,"a",el());E(this,"prev",el());E(this,"b",el());E(this,"d",el());E(this,"amp");E(this,"norm");E(this,"nPeriods");E(this,"nSegs");E(this,"growthDuration");E(this,"t");E(this,"pt");this.scaffold=e,e.isOccupied=!0,this.start=t,this.stop=n,this.reverse=n<t,this.reverseHelix=s,r===null&&(r=Math.random()*pt.vinePadding),this.startPadding=r,this.stopPadding=Math.random()*pt.vinePadding;const o=this.a.lerpVectors(e.a,e.b,t);this.prev.copy(o);const l=this.b.lerpVectors(e.a,e.b,n),c=this.d.subVectors(l,o),u=c.length();this.amp=_e.helix_d/2,this.norm=Math.atan2(c.y,c.x)+Math.PI/2;const d=Kt(...pt.spiralDensity);let a=Math.floor(u*d);a<1&&(a=1),this.nPeriods=a,this.nSegs=this.nPeriods*100;const f=u/a,g=a*Math.sqrt(_e.hpid2+f*f);this.growthDuration=g/pt.growthSpeed,this.t=0,this.pt=0}update(e){this.pt=this.t,this.t+=e}isDone(){return this.t>this.growthDuration}getNext(){if(!this.reverse&&this.stop<.8){let n=this.stop+Kt(...pt.helixDist);return n>.8&&(n=1),[new is(this.scaffold,this.stop,n,this.reverseHelix)]}if(this.reverse&&this.stop>.2){let n=this.stop-Kt(...pt.helixDist);return n<.2&&(n=0),[new is(this.scaffold,this.stop,n,this.reverseHelix)]}const e=[],t=Math.random()<pt.branchRate;do{const n=this.getNextScaffolds(this.b);if(n.sort(()=>Math.random()-.5),n.length>0){const s=n.pop();if(s){let r=this.reverseHelix;Math.abs(s[0].angle-this.scaffold.angle)>.1&&(r=!r),s[1]?e.push(new is(s[0],0,Kt(...pt.helixDist),r)):e.push(new is(s[0],1,1-Kt(...pt.helixDist),r))}}else break}while(t);return e}getNextScaffolds(e){const t=Math.pow(pt.maxJump,2),n=[];return _e.allScaffolds.forEach(s=>{if(s.isOccupied)return;let r=b0.subVectors(e,s.a).lengthSq();r<t&&n.push([s,!0]),r=b0.subVectors(e,s.b).lengthSq(),r<t&&n.push([s,!1])}),n}draw(e){const t=[],n=this.a,s=this.b,r=this.nSegs,o=Math.floor(r*this.pt/this.growthDuration),l=Math.floor(r*this.t/this.growthDuration);for(let c=o;c<l&&c<r;c++){const u=w0*c/r*this.nPeriods,d=ef(this.startPadding,this.stopPadding,c/r),a=(u+S0)%w0<To;e.globalCompositeOperation=a?"destination-over":"source-over";let h=this.amp*Math.sin(u);this.reverseHelix&&(h*=-1),h+=Math.sign(h)*d;const f=xL.lerpVectors(n,s,c/r).add(yL.set(Math.cos(this.norm)*h,Math.sin(this.norm)*h));if(e.beginPath(),e.moveTo(this.prev.x,this.prev.y),e.lineTo(f.x,f.y),e.stroke(),Math.random()<pt.twigRate){let g=this.scaffold.angle+S0;h>0&&(g+=To),g+=Kt(-E0,E0),t.push(new _L(f,g,a))}this.prev.copy(f)}return t}}function vL(){_e.allScaffolds=[];let i=.09,e=.1;const t=.7;e*=t,i*=t;let n=0;for(let c=0;c<1;c+=e){let u=0;for(let d=0;d<1;d+=i){const a=u%2?0:e/2,h=(n+u%2)%3;h===0&&_e.allScaffolds.push(new Xh(Tn(c+a,d),Tn(c+a+e,d))),h===0&&_e.allScaffolds.push(new Xh(Tn(c+a,d),Tn(c+a-e/2,d+i))),h===1&&_e.allScaffolds.push(new Xh(Tn(c+a,d),Tn(c+a+e/2,d+i))),u+=1}n+=1}let s=1/0,r=-1/0,o=1/0,l=-1/0;for(const c of _e.allScaffolds)s=Math.min(s,c.a.x,c.b.x),r=Math.max(r,c.a.x,c.b.x),o=Math.min(o,c.a.y,c.b.y),l=Math.max(l,c.a.y,c.b.y);for(const c of _e.allScaffolds)(c.a.x===s||c.b.x===s||c.a.x===r||c.b.x===r||c.a.y===o||c.b.y===o||c.a.y===l||c.b.y===l)&&(c.isEdge=!0);_e.allVines=[];for(const c of _e.allScaffolds)c.isEdge&&(_e.allVines.push(new is(c,0,.2)),_e.allVines.push(new is(c,1,.8)))}function bL(){const i=[vL];i[Math.floor(Kt(0,i.length))]()}function ML(){const i=document.getElementById("ivyBuffer"),e=document.getElementById("ivyCanvas");e.style.display="block",_e.buffer=i,_e.canvas=e,_e.ctx=i.getContext("2d"),_e.finalCtx=e.getContext("2d")}let A0=-1,T0=-1;function C0(i=!1){const e=_e.canvas;if(i||e.offsetWidth!==A0||e.offsetHeight!==T0){A0=e.offsetWidth,T0=e.offsetHeight;const t=window.devicePixelRatio/Jt.flatConfig.pixelScale,n=window.innerWidth*t,s=window.innerHeight*t;e.width=n,e.height=s,_e.buffer.width=n,_e.buffer.height=s;const o=Math.max(e.width,e.height)+10*2;_e.canvasScale=o,_e.canvasOffsetX=(e.width-o)/2,_e.canvasOffsetY=(e.height-o)/2,_e.ctx.setTransform(_e.canvasScale,0,0,_e.canvasScale,_e.canvasOffsetX,_e.canvasOffsetY);const l=-_e.canvasOffsetX/_e.canvasScale,c=-_e.canvasOffsetY/_e.canvasScale;_e.screenCorners=[Tn(l,c),Tn(1-l,c),Tn(1-l,1-c),Tn(l,1-c)],wL()}}function wL(){_e.resetCountdown=_e.resetDelay,_e.hue=Math.random(),bL()}function SL(i){C0(),_e.t+=i,_e.allVines.forEach(t=>t.update(i));const e=[];_e.allVines=_e.allVines.filter(t=>t.isDone()?(e.push(...t.getNext()),!1):!0),_e.allVines.push(...e),_e.allVines.length===0&&(_e.resetCountdown>0?_e.resetCountdown-=i:C0(!0))}let Zh=0;const R0=mf(),P0=new se,EL=100,I0=Array.from({length:100},(i,e)=>{const t=e/EL;return P0.setHSL(t,.5,.3),"#"+P0.getHexString()});function AL({seaBlock:i,dt:e}){const t=_e.ctx,n=_e.hue+(Math.random()-.5)*_e.hueVariance,s=I0[Math.floor(n*I0.length)];t.strokeStyle=s,t.fillStyle=s,t.lineWidth=pt.vineThickness,t.lineCap="round";const r=_e.allVines.flatMap(d=>d.draw(t));_e.allVines.push(...r),_e.finalCtx.clearRect(0,0,_e.canvas.width,_e.canvas.height);const o=10,l=2;Zh+=e*2e-4;const c=.08,u=.5;for(let d=0;d<_e.canvas.height;d+=o-l)for(let a=0;a<_e.canvas.width;a+=o-l){const h=Math.min(o,_e.canvas.width-a),f=Math.min(o,_e.canvas.height-d),g=a*c,_=d*c,m=R0(g,_+Zh)*u,p=R0(g+100,_+Zh+100)*u;_e.finalCtx.drawImage(_e.buffer,a,d,h,f,a+m,d+p,h,f)}}let L0=0,Wr=-1,D0=!1,Jh=!1;function TL(i){const{seaBlock:e,dt:t}=i;for(const r in _n)_n[r]&&(e.isUsingGamepad=!0);L0+=t;const n=i.seaBlock.config.flatConfig.transitionMode==="skip"?ar.length-1:fL(L0);n!==Wr&&(Wr=n,pL(Wr),e.layeredViewport.handleResize(e));const{triggers:s}=ar[Wr];if(s!=null&&s.includes("music")&&!D0&&(hr(Rv),cr.Howler.ctx.state==="running"&&(D0=!0)),s!=null&&s.includes("ivy")&&(Jh||(Jh=!0,ML()),SL(t),AL(i)),Jh&&Rf.display.isVisible===!1&&!e.isShowingSettingsMenu)for(const{display:r}of ar[Wr].elements)r.isVisible=!0,r.needsUpdate=!0}const Jf=class Jf extends St{constructor(){super(...arguments);E(this,"update",TL)}reset(t){}doesAllowGgui(){return!0}doesAllow3DRender(){return!1}};St.register("start-menu",{factory:()=>new Jf,guiName:"start-menu",elements:[]});let U0=Jf;const CL={update:i=>{},steps:[...dc.steps,({current:i})=>i]},es=class es extends Ao{constructor(){super(...arguments);E(this,"distForFreeCam",120);E(this,"traveled",0)}getTerrainRenderPipeline(t){return CL}reset(t){super.reset(t),es.wasSkipped=!1,this.traveled=0;for(const[d,a]of Pf)a.isFinished=!1;const n=RL();for(const d in n)try{O0[d](n[d],t)}catch{}const{sphereGroup:s,camera:r,orbitControls:o}=t;for(let d=0;d<s.members.length;d++)s.members[d].isVisible=!1;const{x:l,z:c}=t.terrain.centerXZ,u=this.getCamOffset(t);r.position.set(l+u.x,u.y,c+u.z),o.update()}update(t){var h;const{seaBlock:n,dt:s}=t;if(es.wasSkipped&&((h=n.transition)!=null&&h.didFinishCover))return;this.waveMaker.wmRadius=0;const r=PL(this.traveled);for(const f in r){const g=r[f];typeof g=="number"&&O0[f](g,n)}if(this.traveled>=this.distForFreeCam){n.setGame("free-cam"),n.onGameChange();return}const{x:o,z:l}=this._lastAnchorPosition;this.centerOnAnchor(n),this.waveMaker.updateWaveMaker(t);const{CAM_ACCEL:c}=as.flatConfig;this.accelSphere(this.cameraAnchor,IL,s*c);const{x:u,z:d}=this._lastAnchorPosition,a=Math.hypot(u-o,d-l);this.traveled+=a}};St.register("start-sequence",{factory:()=>new es,guiName:"start-sequence"}),E(es,"colorTransformAnim",0),E(es,"wasSkipped",!1);let Md=es;function RL(){const i={};for(const[e,t]of Pf)i[e]=t.multipliers[0];return i}function PL(i){const e={};for(const[t,n]of Pf){if(n.isFinished)continue;let s;if(!(i<=n.distances[0])){if(i>=n.distances[1])s=n.multipliers[1],n.isFinished=!0;else{const[r,o]=n.distances,[l,c]=n.multipliers,u=(i-r)/(o-r);s=l+u*(c-l)}e[t]=s}}return e}const IL=new A(195e7,30,-1618e6),Pf=[["accel",{distances:[0,40],multipliers:[.3,1],isFinished:!1}],["visible-radius",{distances:[0,80],multipliers:[.1,.2],isFinished:!1}],["visible-radius",{distances:[80,90],multipliers:[.2,1],isFinished:!1}],["peaks",{distances:[0,100],multipliers:[0,1],isFinished:!1}]],O0={accel:i=>{as.flatConfig.CAM_ACCEL=as.tree.children.CAM_ACCEL.value*i},"visible-radius":i=>{Jt.flatConfig.visibleRadius=Jt.tree.children.visibleRadius.value*i},peaks:i=>{fo.flatConfig.peaks=fo.tree.children.terrainCustomization.children.peaks.value*i}};function LL(){const t=Qh(.5,"red"),n=[],s=[];for(let o=0;o<10;o++)n.push(Qh(.5,"yellow")),s.push(Qh(.5,"blue"));const r=new Sb(new A(0,1,0),new A(0,0,0),4,"red");return{center:t,adjacent:n,diagonal:s,normalArrow:r}}function Qh(i,e){const t=new Do(i,8,8),n=new dt({color:e});return new at(t,n)}const rn=LL(),Qf=class Qf extends St{reset(e){const{camera:t,terrain:n,sphereGroup:s,orbitControls:r}=e,{x:o,z:l}=n.centerXZ,c=this.getCamOffset(e);t.position.set(o+c.x,c.y,l+c.z),r.target.x=o,r.target.z=l,r.update();for(let u=0;u<s.members.length;u++)s.members[u].isVisible=!1,s.members[u].isGhost=!0}update(e){super.update(e);const{seaBlock:t}=e,{terrain:n}=t,{pickedTile:s}=this.gui;if(s){const{x:r,z:o,i:l}=s,c=n.grid,u=n.members[l];tl(rn.center,u),u!=null&&u.normal&&(tl(rn.normalArrow,u),rn.normalArrow.setDirection(u.normal));const d=n.grid.tiling.getAdjacent(r,o);for(const[h,f]of d.entries()){const g=c.xzToIndex(r+f.x,o+f.z);if(g){const _=n.members[g.i];tl(rn.adjacent[h],_)}}for(let h=d.length;h<rn.adjacent.length;h++)rn.adjacent[h].visible=!1;const a=n.grid.tiling.getDiagonal(r,o);for(const[h,f]of a.entries()){const g=c.xzToIndex(r+f.x,o+f.z);if(g){const _=n.members[g.i];tl(rn.diagonal[h],_)}}for(let h=a.length;h<rn.diagonal.length;h++)rn.diagonal[h].visible=!1}}};St.register("tile-inspector",{factory:()=>new Qf,guiName:"tile-inspector",elements:[{meshLoader:async()=>rn.center},...rn.adjacent.map(e=>({meshLoader:async()=>e})),...rn.diagonal.map(e=>({meshLoader:async()=>e})),{meshLoader:async()=>rn.normalArrow}]});let F0=Qf;function tl(i,e){if(!e){i.position.set(0,-1e3,0);return}const{x:t,z:n}=e.position;i.position.set(t,e.height,n),i.visible=!0}const Xr=new vx,ep=class ep extends St{reset(e){Xr.reset()}update(e){Xr.update(e),cc(e)}};St.register("walking-cube",{factory:()=>new ep,guiName:"free-cam",elements:[Xr.leftFoot,Xr.rightFoot,Xr.torso]});let N0=ep;const tp=class tp extends Mr{getTile(e,t){const n=e/this.xzScale,s=t/this.xzScale,r=this.getHeight(n,s);return{height:132,color:this.waterColorLookup(132-r),isWater:!0,isFlora:!1}}};Dn.register("all-ocean",()=>new tp);let k0=tp;const DL=new se(13421772),UL=new se(5592405),np=class np extends Mr{getTile(e,t){return{height:133,color:(Math.abs(e)+Math.abs(t))%2===0?DL:UL,isWater:!1,isFlora:!1}}};Dn.register("flat",()=>new np);let B0=np;const ip=class ip extends Mr{getTile(e,t){const n=super.getTile(e,t);return{...n,isFlora:!n.isWater}}};Dn.register("flora-test",()=>new ip);let z0=ip;const sv=mf(),H0=.002;function OL(i,e){return sv(i*H0,e*H0)}const sp=class sp extends Dn{constructor(){super(...arguments);E(this,"label","space-quest");E(this,"url","https://tessmero.github.io/space-quest");E(this,"style",{background:{value:"#000"},"sides@land":{lightness:-.1},"sides@sea":{lightness:"+0.1"},"top@sea":{saturation:"50%"}})}getTile(t,n){const s=OL((t+.5)*16,(n+.5)*16);let r=132,o=!0,l=FL;s>.35?(l=GL,r=133+(s-.35)*100,o=!1):Math.abs(s)%1e-6<2e-9?(l=kL,r=200+s*20,o=!0):s>.1&&(l=NL,r=133+(s-.1)*10,o=!1);const c=rv(l,t,n),u=c?new se(c):new se;return{height:r,color:u,isWater:o,isFlora:!1}}};Dn.register("space-quest",()=>new sp);let V0=sp;function rv(i,e,t){const{scale:n,colors:s}=i,r=e,o=t,l=sv(r*n,o*n),c=Object.entries(s),u=c.length;for(let d=0;d<u;d++){const[a,h]=c[d],{from:f=-1,to:g=1,data:_}=h;let m=g;if(m===1&&d+1<u){const[p,x]=c[d+1];typeof x.from=="number"&&(m=x.from)}if(l>=f&&l<m)return _?rv(_,e,t):a}return null}const FL={scale:.01,colors:{"#080808":{from:-1},"#101320":{from:-1},"#11152A":{from:-.25},"#22162A":{from:.25}}},NL={scale:.1,colors:{"#666":{from:-1},"#777":{from:-.25},"#AAA":{from:.25,to:1}}},kL={scale:.25657,colors:{"#7A1CAC":{from:-1},"#AD49E1":{from:-.25},"#EBD3F8":{from:.25,to:1}}},BL={scale:.05367,colors:{"#FF8A8A":{from:-1},"#CCE0AC":{from:-.25},"#F4DEB3":{from:.25,to:1}}},zL={scale:.177245,colors:{"#006769":{from:-1},"#40A578":{from:-.25},"#E6FF94":{from:.25,to:.28},"#9DDE8B":{from:.28,to:1}}},HL={scale:.08317,colors:{"#B1AFFF":{from:-1},"#BBE9FF":{from:-.25},"#FFFED3":{from:.25,to:1}}},VL={scale:.177245,colors:{"#E4003A":{from:-1},"#B60071":{from:-.25},"#E6FF23":{from:.25,to:.28},"#9D1111":{from:.28,to:1}}},GL={scale:4e-4,colors:{_d:{from:-1,data:VL},_a:{from:-.2,data:BL},_b:{from:-.1,data:zL},_c:{from:.1,data:HL}}};class xn{constructor(){E(this,"tileAnims");E(this,"initGrid")}getTileValue(e,t){const{t0:n,t1:s,val0:r,val1:o}=this.tileAnims[e.i%this.tileAnims.length],l=Math.max(0,Math.min(1,(t-n)/(s-n)));return r+l*(o-r)}init(e){this.initGrid=e;const t=[];for(const n of e.tileIndices)t.push(this.buildTileAnim(e,n));this.tileAnims=t}static register(e,t){if(e in this._registry)throw new Error(`grid anim already registered: '${e}'`);this._registry[e]=t}static create(e,t){if(!(e in this._registry))throw new Error(`grid anim not registered: ${e}: ${JSON.stringify(Object.keys(this._registry))}`);const{factory:n}=this._registry[e],s=n();return s.init(t),s}}E(xn,"_registry",{});const rp=class rp extends xn{buildTileAnim(e,t){const{i:n}=t,{n:s}=e,r=0,o=.7,l=.3;return{t0:r+(o-r)*(n/s),t1:l+(1-l)*(n/s),val0:0,val1:1}}};xn.register("flat-sweep",{factory:()=>new rp,assertions:{allAtStart:0,allAtEnd:1,minSpeed:3,maxSpeed:10}});let G0=rp;const op=class op extends xn{buildTileAnim(e,t){const{x:n,z:s}=t;return{t0:0,t1:1,val0:0,val1:Math.sqrt(n*n+s*s)/10}}};xn.register("radial-height-warp",{factory:()=>new op,assertions:{allAtStart:0,maxSpeed:10}});let W0=op;const ap=class ap extends xn{constructor(){super(...arguments);E(this,"orderedTiles")}init(t){const n=t.width/2,s=t.depth/2;this.orderedTiles=t.tileIndices.slice().sort((r,o)=>{const l=$0(r.x-n,r.z-s),c=$0(o.x-n,o.z-s);return l-c}),super.init(t)}buildTileAnim(t,n){const s=this.orderedTiles.findIndex(d=>d.i===n.i),{n:r}=t,o=0,l=.7,c=.3;return{t0:o+(l-o)*(s/r),t1:c+(1-c)*(s/r),val0:0,val1:1}}};xn.register("radial-sweep",{factory:()=>new ap,assertions:{allAtStart:0,allAtEnd:1,minSpeed:3,maxSpeed:10}});let X0=ap;function $0(i,e){return i*i+e*e}const lp=class lp extends xn{constructor(){super(...arguments);E(this,"shuffledIndices")}init(t){const n=Array.from({length:t.n},(s,r)=>r);this.shuffledIndices=gR(n),super.init(t)}buildTileAnim(t,n){const s=this.shuffledIndices[n.i],{n:r}=t,o=0,l=.7,c=.3;return{t0:o+(l-o)*(s/r),t1:c+(1-c)*(s/r),val0:0,val1:1}}};xn.register("random-sweep",{factory:()=>new lp,assertions:{allAtStart:0,allAtEnd:1,minSpeed:3,maxSpeed:10}});let Y0=lp,q0=!1,j0=!1;class WL{constructor(){E(this,"backCanvas");E(this,"midCanvas");E(this,"frontCanvas");E(this,"backRenderer");E(this,"ctx");E(this,"frontCtx");E(this,"pixelRatio");E(this,"w");E(this,"h");E(this,"screenRectangle");if(q0)throw new Error("LayeredViewport constructed multiple times");q0=!0}handleResize(e){this.pixelRatio=window.devicePixelRatio/Jt.flatConfig.pixelScale,this.w=window.innerWidth*this.pixelRatio,this.h=window.innerHeight*this.pixelRatio,this.screenRectangle={x:0,y:0,w:this.w,h:this.h},this.backRenderer.setSize(window.innerWidth,window.innerHeight),typeof e.currentGameName>"u"||e.currentGameName==="splash-screen"?this.backRenderer.setPixelRatio(window.devicePixelRatio/6):this.backRenderer.setPixelRatio(this.pixelRatio),this.midCanvas.width=this.w,this.midCanvas.height=this.h,this.frontCanvas.width=this.w,this.frontCanvas.height=this.h,xr(e)}init(e){if(j0)throw new Error("LayeredViewport initialized multiple times");j0=!0,this.backCanvas=document.getElementById("backCanvas"),this.midCanvas=document.getElementById("midCanvas"),this.frontCanvas=document.getElementById("frontCanvas"),this.backRenderer=new nx({canvas:this.backCanvas,antialias:!0}),this.ctx=this.midCanvas.getContext("2d"),this.frontCtx=this.frontCanvas.getContext("2d"),this.handleResize(e)}}const wd=50,K0=-wd/2,Z0=10,XL=1500,$L=10,J0=Array.from({length:$L}).map(()=>new Float32Array(XL));let eu=0;function YL(){const i=J0[eu];return eu=(eu+1)%J0.length,i}const ao=class ao extends $e{constructor(){super(...arguments);E(this,"lastWidth",0);E(this,"lastHeight",0);E(this,"hideColors",[[0,0,0],[0,0,0]]);E(this,"chunkBuffer",YL());E(this,"chunkSize",Z0);E(this,"chunkScale",1);E(this,"widthInChunks");E(this,"heightInChunks");E(this,"hideGrid");E(this,"showGrid");E(this,"chunkGrid");E(this,"hideAnim");E(this,"showAnim");E(this,"hideImageset");E(this,"showImageset");E(this,"imageset");E(this,"tiling");E(this,"forceFlatSweep");E(this,"isHiding",!0)}reset(){this.forceFlatSweep=ao.forceFlatSweep,this.pickChunkSize(),this.chunkBuffer.fill(0),this.lastWidth=0,this.lastHeight=0}pickTiling(){return this.tiling||Qt.create(hi(af.NAMES))}_getPaddedDims(){let t=Math.ceil(window.screen.width*this.layeredViewport.pixelRatio),n=Math.ceil(window.screen.height*this.layeredViewport.pixelRatio);return t+=wd,n+=wd,{w:t,h:n}}pickChunkSize(){const{w:t,h:n}=this._getPaddedDims();if(t===this.lastWidth&&n===this.lastHeight)return this.chunkSize;this.lastWidth=t,this.lastHeight=n,this.chunkSize=Z0,this.chunkScale=1,this.widthInChunks=Math.ceil(t/this.chunkSize),this.heightInChunks=Math.ceil(n/this.chunkSize),this.hideGrid=new Wl(this.widthInChunks,this.heightInChunks,this.pickTiling());const s=this.forceFlatSweep?"flat-sweep":hi(["flat-sweep","radial-sweep","random-sweep"]);return this.hideAnim=xn.create(s,this.hideGrid),this.hideImageset=Ug(this.hideGrid.tiling,this.hideColors),this.chunkGrid=this.hideGrid,this.imageset=this.hideImageset,this.chunkSize}*getChangedChunks(t){for(const n of this.chunkGrid.tileIndices){const{i:s}=n,r=this.chunkBuffer[s],c=(this.isHiding?this.hideAnim:this.showAnim).getTileValue(n,t);r!==c&&(yield{tileIndex:n,value:c}),this.chunkBuffer[s]=c}}_hide(t,n){this.isHiding=!0,this.fillChangedTiles(t,n)}_show(t,n){const s=this.layeredViewport.frontCtx;if(s.globalCompositeOperation="destination-out",this.isHiding){this.showGrid=new Wl(this.widthInChunks,this.heightInChunks,this.pickTiling());const r=this.forceFlatSweep?"flat-sweep":hi(["flat-sweep","radial-sweep","random-sweep"]);this.showAnim=xn.create(r,this.showGrid),this.showImageset=Ug(this.showGrid.tiling,[[0,0,0],[0,0,0]]),this.chunkBuffer.fill(0),this.chunkGrid=this.showGrid,this.imageset=this.showImageset}this.isHiding=!1,this.fillChangedTiles(t,n),s.globalCompositeOperation="source-over"}fillChangedTiles(t,n){const s=this.pickChunkSize(),r=this.layeredViewport.frontCtx;for(const{tileIndex:o,value:l}of this.getChangedChunks(n)){const{x:c,z:u}=o,d=this.chunkGrid.tiling.getShapeIndex(c,u);this.chunkGrid.tiling.shapes[d];const a=this.imageset[d],h=this.chunkGrid.tiling.indexToPosition(c,u);SR({ctx:r,x:Math.floor(h.x*s+K0),y:Math.floor(h.z*s+K0),scale:l,chunkScale:this.chunkScale},a)}}};$e.register("flat",()=>new ao),E(ao,"forceFlatSweep",!1);let Ql=ao;function so(i,e){Ql.forceFlatSweep=!0;const t=$e.create("flat",i,e);return Ql.forceFlatSweep=!1,{...e,transition:t,isFinished:!1}}const Sd=6,ov=.5,qL=(1-ov)/(Sd-1);function av(){const i=ZL(),e="#808080",t="#000000",n=[];for(let s=0;s<Sd;++s){const r=s*qL,o=r+ov;let l;s===0?l=e:s===Sd-1?l=t:l=i[(s-1)%i.length],n.push({t0:r,t1:o,colors:[l,l]})}return n}function jL(){return[{t0:0,t1:.2,colors:["black","black"]},{t0:.1,t1:.3,colors:["0xaaccff","0xaaccff"]}]}function KL(){const i=Qt.create(hi(["triangle","octagon","hex"]));return[{t0:0,t1:.7,colors:["black","black"]},{t0:.1,t1:.8,colors:["white","white"]},{t0:.2,t1:.9,colors:["black","black"],tiling:i},{t0:.3,t1:1,colors:["black","black"],tiling:i}]}const Q0=[["#888c92","#6a7a8c","#4a5a6a","#222428"],["#8c9288","#7d8c7a","#5a6a4a","#23241f"],["#928c88","#8c837a","#6a5a4a","#23211f"],["#889292","#6a8c8c","#4a6a6a","#1f2323"],["#929288","#8c8c6a","#6a6a4a","#23231f"],["#928c88","#8c7a6a","#6a5a4a","#231f1f"]];function ZL(){return Q0[Math.floor(Math.random()*Q0.length)]}const JL=av(),tu=KL(),cp=class cp extends $e{constructor(){super(...arguments);E(this,"totalDuration",3e3);E(this,"context");E(this,"ssdHide");E(this,"ssdShow")}reset(t){this.context=t,$e.isFirstUncover?this.ssdHide=tu.map(n=>so(this.context,n)):this.ssdHide=this.buildSsHideSegments().map(n=>so(t,n))}buildSsHideSegments(){return JL}_hide(t,n){for(const[s,r]of this.ssdHide.entries())if(!r.isFinished&&!(n<r.t0)){if(t<r.t1||n>r.t0){const o=Math.max(0,Math.min(1,(t-r.t0)/(r.t1-r.t0))),l=Math.max(0,Math.min(1,(n-r.t0)/(r.t1-r.t0)));r.transition._hide(o,l)}t>r.t1&&(r.isFinished=!0)}}_initSsShow(){this.ssdShow||(this.ssdShow=tu.map(t=>so(this.context,t)))}_show(t,n){this._initSsShow();const s=tu.length;for(const[r,o]of this.ssdShow.entries())if(!o.isFinished&&!(n<o.t0)){if(t<o.t1||n>o.t0){const l=Math.max(0,Math.min(1,(t-o.t0)/(o.t1-o.t0))),c=Math.max(0,Math.min(1,(n-o.t0)/(o.t1-o.t0)));r===s-1?o.transition._show(l,c):o.transition._hide(l,c)}t>o.t1&&(o.isFinished=!0)}}};$e.register("ss",()=>new cp);let Ed=cp;const hp=class hp extends Ed{buildSsHideSegments(){return[{t0:0,t1:.6,tiling:tD,colors:QL()},{t0:.4,t1:1,colors:["black","black"]}]}};$e.register("checkered",()=>new hp);let e_=hp;const t_=[["#D1BB9E","#E1E2EF"],["#81E28F","#E1E2EF"],["#B3CFFF","#E1E2EF"]];function QL(){return t_[Math.floor(Math.random()*t_.length)]}class eD extends vd{constructor(){super();E(this,"shapes",[yd[0],yd[0]])}getShapeIndex(t,n){const s=Math.floor(t/n_),r=Math.floor(n/n_);return Math.abs((s+r)%2)}}const tD=new eD,n_=4,qt=class qt extends $e{getExtraPipelineStep(){return({current:e,tileIndex:t})=>{let n=0;if(qt.gridAnim){const s=qt.gridAnim.getTileValue(t,qt.t);n=500*nD(1-s,1)}return e.yOffset=n,e}}reset(){qt.gridAnim=xn.create("random-sweep",this.terrain.grid),qt.t=0}_hide(e,t){qt.t=t}_show(e,t){qt.t=1-t}cleanupHide(){qt.t=1}cleanupShow(){qt.t=0}};$e.register("drop",()=>new qt),E(qt,"t",0),E(qt,"gridAnim");let Ad=qt;function nD(i,e){if(i>e)return 0;const t=Math.min(i/e,1);return 1-(1-Math.pow(1-t,4))}const iD=av(),i_=jL(),up=class up extends $e{constructor(){super(...arguments);E(this,"context");E(this,"ssdHide");E(this,"ssdShow");E(this,"ssdFinalShow")}getExtraPipelineStep(){return this.ssdFinalShow.getExtraPipelineStep()}reset(t){this.context=t,this.ssdHide=this.buildSsdHideSegments().map(n=>so(t,n)),this.ssdFinalShow=$e.create("drop",this.context)}buildSsdHideSegments(){return iD}_hide(t,n){for(const[s,r]of this.ssdHide.entries())if(!r.isFinished&&!(n<r.t0)){if(t<r.t1||n>r.t0){const o=Math.max(0,Math.min(1,(t-r.t0)/(r.t1-r.t0))),l=Math.max(0,Math.min(1,(n-r.t0)/(r.t1-r.t0)));r.transition._hide(o,l)}t>r.t1&&(r.isFinished=!0)}}cleanupHide(){const{frontCtx:t,w:n,h:s}=this.layeredViewport;t.fillStyle="black",t.fillRect(0,0,n,s),this._initSsdShow(),this.ssdFinalShow.cleanupHide()}cleanupShow(){this._initSsdShow(),this.ssdShow.length>0&&this.ssdShow[0].transition.cleanupShow(),this.ssdFinalShow.cleanupShow()}_initSsdShow(){this.ssdShow||(this.ssdShow=i_.map(t=>so(this.context,t)))}_show(t,n){this._initSsdShow();const s=i_.length;for(const[r,o]of this.ssdShow.entries())if(!o.isFinished&&!(n<o.t0)){if(t<o.t1||n>o.t0){const l=Math.max(0,Math.min(1,(t-o.t0)/(o.t1-o.t0))),c=Math.max(0,Math.min(1,(n-o.t0)/(o.t1-o.t0)));r===s-1?o.transition._show(l,c):o.transition._hide(l,c)}t>o.t1&&(o.isFinished=!0)}n>.5&&this.ssdFinalShow._show(Math.max(0,(t-.5)*2),Math.min(1,(n-.5)*2))}};$e.register("ssd",()=>new up);let s_=up;const sD={display:{type:"button",icon:"icons/16x16-config.png",gamepadPrompt:{name:"start",offset:[-16,0]}},layoutKey:"settingsBtn",hotkeys:["Escape","ButtonStart"],clickAction:({seaBlock:i})=>{i.toggleSettings(),i.refreshGui()}},rD={display:{type:"button",label:"~",gamepadPrompt:{name:"back",offset:[16,0]}},layoutKey:"debugBtn",hotkeys:["Backquote","ButtonBack"],clickAction:({seaBlock:i})=>{NP(i)}};function oD(i){const{layoutKey:e,itemLabel:t,options:n,value:s,onChange:r}=i;let o=s;const l={};for(const u of n)l[u]={layoutKey:`${e}.valueLabel`,display:{type:"label",label:u,isVisible:u===s}};function c(u,d){l[o].display.isVisible=!1;const a=n.indexOf(o);o=n[(a+d+n.length)%n.length],l[o].display.isVisible=!0,r(u,o),xr(u)}return[{layoutKey:`${e}.mainBtn`,display:{type:"button",border:"16x16-btn-square"},clickAction:({seaBlock:u})=>{c(u,1)}},{layoutKey:`${e}.itemLabel`,display:{type:"label",label:t,font:"mini",textAlign:"top-left"}},...Object.values(l),{layoutKey:`${e}.prevBtn`,display:{type:"button",icon:"icons/16x16-arrow-left.png",border:"16x16-btn-square"},clickAction:({seaBlock:u})=>{c(u,-1)}},{layoutKey:`${e}.nextBtn`,display:{type:"button",icon:"icons/16x16-arrow-right.png",border:"16x16-btn-square"},clickAction:({seaBlock:u})=>{c(u,1)}}]}const{btn:aD}=yn,lD={phaseLabel:{height:16,"top@portrait":16,"width@landscape":100,left:"auto"},topBar:{height:16},topLeftDisplay:{parent:"topBar",width:36},topCenterDisplay:{parent:"topBar",width:100,left:"auto"},topRightBtn:{parent:"topBar",...aD,right:0},flatViewport:{width:112,height:112,left:"auto",top:"auto"},switchPieceHint:{height:16,width:64,bottom:20},bottomLeft:{height:20,width:64,bottom:0},currentPieceButton:{parent:"bottomLeft"},currentPieceLabel:{parent:"currentPieceButton",left:4},currentPieceIcon:{parent:"currentPieceButton",width:20,right:0},pawnBtn:{width:40,height:20,bottom:0,right:0},cancelPawnBtn:{width:60,height:20,bottom:0,right:0},pawnHint:{width:64,height:16,bottom:16,right:0}},cD={},hD={pieceHelpPanel:{width:80,height:96,left:0,top:0},pieceHelpDiagram:{parent:"pieceHelpPanel",margin:8,width:64,height:64,top:16},pieceHelpCloseBtn:{parent:"pieceHelpPanel",right:8,top:8,width:32,height:20}},uD={pauseMenuPanel:{width:80,height:48,left:"auto",top:"auto"},pauseMenuInner:{parent:"pauseMenuPanel",margin:8},resetBtn:{parent:"pauseMenuInner",height:16},resumeBtn:{parent:"pauseMenuInner",height:16},quitBtn:{parent:"pauseMenuInner",height:16,bottom:0}},r_={...lD,...hD,...uD,...cD},{btn:dD}=yn,fD={rewardHelpPanel:{parent:"rewardsPanel"},rewardHelpDiagram:{parent:"rewardHelpPanel",margin:8,width:64,height:64,top:16},rewardHelpCloseBtn:{parent:"rewardsPanel",...dD,right:0}},{btn:nl}=yn,o_={rewardsPanel:{width:80,height:96,left:"auto",top:"auto"},rewardsInner:{parent:"rewardsPanel",margin:8},rewardsTitle:{parent:"rewardsInner",height:20},leftReward:{parent:"rewardsInner",width:32,height:40,top:"auto"},leftRewardDisplay:{parent:"leftReward",...nl,left:"auto",top:"auto"},leftRewardHelpBtn:{parent:"rewardsPanel",...nl,right:0},rightReward:{parent:"rewardsInner",width:32,height:40,top:"auto",right:0},rightRewardDisplay:{parent:"rightReward",...nl,left:"auto",top:"auto"},rightRewardHelpBtn:{parent:"rewardsPanel",...nl,right:0},confirmBtn:{parent:"rewardsInner",height:20,bottom:0},...fD},pD=[...LI,...sP,...RI,...kI,...ZP],dp=class dp extends it{click(e){let t=super.click(e);return t||(t=mP(e)),t}unclick(e){super.unclick(e),gP(e)}move(e){const t=super.move(e);return t||pP(e),t}};it.register("chess",{factory:()=>new dp,allLayouts:[r_,o_],layoutFactory:()=>ZI()==="reward-choice"?o_:r_,elements:pD});let a_=dp;[...il({layoutKey:"styleOption",itemLabel:"COLORS",item:Jt.tree.children.style}),...il({layoutKey:"tilingOption",itemLabel:"TILING",item:yl.tree.children.tiling}),...il({layoutKey:"generatorOption",itemLabel:"TERRAIN",item:yl.tree.children.generator}),...il({layoutKey:"layoutOption",itemLabel:"CONTROLS",item:yl.tree.children.freeCamLayout})];function il(i){const{layoutKey:e,itemLabel:t,item:n}=i;return oD({layoutKey:e,itemLabel:t,options:n.options,value:n.value,onChange:(s,r)=>{n.value=r,s.onCtrlChange(n)}})}const fp=class fp extends it{};it.register("empty",{factory:()=>new fp,layoutFactory:()=>({}),elements:[]});let l_=fp;const{btn:sl,pad:Gs,point:c_}=yn,lv={debugBtn:{...sl,top:Gs,left:Gs},settingsBtn:{...sl,top:Gs,right:Gs},raftBtn:{...sl,width:40,top:Gs,right:sl.width+2*Gs},grabbedMesh:{...c_,"left@landscape":"33%","top@landscape":"auto","left@portrait":"auto","top@portrait":"33%"},sgpAnchor:{...c_,"left@landscape":"67%","top@landscape":"auto","left@portrait":"auto","top@portrait":"67%"},grabbedMeshPanel:{parent:"sgpAnchor",width:80,height:80,left:"auto",top:"auto"},grabbedMeshDiagram:{parent:"grabbedMeshPanel",width:-16,left:"auto",height:40},grabbedMeshPlayButton:{parent:"grabbedMeshPanel",width:64,height:20,left:"auto",bottom:28},grabbedMeshCancelButton:{parent:"grabbedMeshPanel",width:64,height:20,left:"auto",bottom:8}},nu={...lv,...Cx},{joy:mD,pad:gD,joySlider:_D}=yn,Al={...lv,leftJoy:{...mD,bottom:gD},leftJoySlider:{parent:"leftJoy",..._D,left:"auto",top:"auto"}},{joy:xD,joySlider:yD,pad:h_}=yn,iu={...Al,rightJoy:{...xD,bottom:h_,right:h_},rightJoySlider:{parent:"rightJoy",...yD,left:"auto",top:"auto"}},pp=class pp extends it{closeDialogs(e){super.closeDialogs(e),So(e)}};it.register("free-cam",{factory:()=>new pp,elements:[rD,sD,ds,Zd,fs,Jd,...yx,...Mf],allLayouts:[nu,iu,Al],layoutFactory:e=>{const t=e.config.flatConfig.freeCamLayout;if(t==="portrait")return Al;if(t==="landscape")return iu;if(t==="desktop")return nu;if(rs){const{layeredViewport:n}=e,{w:s,h:r}=n;return s>r?iu:Al}return nu}});let u_=pp;const mp=class mp extends it{click(e){let t=super.click(e);return t||(t=oL(e)),t}move(e){const t=super.move(e);return t||rL(e),t}};it.register("raft",{factory:()=>new mp,layoutFactory:C2,allLayouts:[Rx,Ax,Ex],elements:[ds,Zd,fs,Jd,...yx,WT,XT,...Mx,$T,...N2,...Xy]});let d_=mp;const{btn:vD}=yn,si=8,cv=68,bD=50,su={height:si,width:cv,left:"auto"},ru={height:si,width:bD,left:"auto"},MD={settingsPanel:{width:80,height:80,left:"auto",top:"auto"},settingsTitleBar:{parent:"settingsPanel",top:0,height:si},settingsCloseBtn:{parent:"settingsPanel",...vD,right:0},settingsPanelInner:{parent:"settingsPanel",top:4},musicVolumeLabel:{parent:"settingsPanelInner",top:si*1,...ru},musicVolumeRegion:{parent:"settingsPanelInner",top:si*2,...su},musicVolumeSlider:{parent:"musicVolumeRegion",width:10},sfxVolumeLabel:{parent:"settingsPanelInner",top:si*3,...ru},sfxVolumeRegion:{parent:"settingsPanelInner",top:si*4,...su},sfxVolumeSlider:{parent:"sfxVolumeRegion",width:10},pixelScaleLabel:{parent:"settingsPanelInner",top:si*5,...ru},pixelScaleRegion:{parent:"settingsPanelInner",top:si*6,...su},pixelScaleSlider:{parent:"pixelScaleRegion",width:10},settingsQuitBtn:{parent:"settingsPanel",width:cv,height:16,left:"auto",bottom:0}},wD={layoutKey:"settingsPanel",display:{type:"panel",border:"16x16-dark-panel"}},ec={musicVolume:{elements:ou("musicVolume",{label:"MUSIC"}),item:Ci.tree.children.musicVolume,onChange:Pv},sfxVolume:{elements:ou("sfxVolume",{label:"SOUNDS"}),item:Ci.tree.children.sfxVolume,onChange:Lv},pixelScale:{elements:ou("pixelScale",{label:"SCALE"}),item:Jt.tree.children.pixelScale,onChange:i=>{i.onCtrlChange(Jt.tree.children.pixelScale),i.onResize()}}};function ou(i,e){const{label:t,icon:n}=e;return{label:{layoutKey:`${i}Label`,display:{type:"label",label:t,icon:n,font:"mini"}},region:{layoutKey:`${i}Region`,display:{type:"ss-region"}},slider:{layoutKey:`${i}Slider`,slideIn:`${i}Region`,gamepadNavBox:`${i}Region`,display:{type:"button",border:"16x16-btn-sm",shouldSnapToPixel:!0,gamepadPrompt:{isHidden:!0}},clickAction:r=>{f_(i,r)},dragAction:r=>{f_(i,r)}}}}function f_(i,e){const{seaBlock:t,sliderState:n}=e,s=ec[i],{item:r,onChange:o}=s;if(!n)return;const{min:l,max:c,step:u}=r;if(typeof l!="number"||typeof c!="number"||typeof u!="number")throw new Error("numeric item used for in-game settings must define min,max,step");r.value=u*Math.round(ef(l,c,n.x)/u),o(t),hv(s)}function SD(){for(const i in ec){const e=ec[i];hv(e)}}function hv(i){const{elements:e,item:t}=i,{slider:n,region:s}=e,{value:r,min:o,max:l}=t;if(typeof o!="number"||typeof l!="number")throw new Error("numeric item used for in-game settings must define min,max");n.display.forcedSliderState={x:(r-o)/(l-o),y:0},s.display.needsUpdate=!0,n.display.needsUpdate=!0}const ED={layoutKey:"settingsCloseBtn",gamepadNavBox:"settingsTitleBar",hotkeys:["ButtonB"],display:{type:"button",icon:"icons/16x16-x.png",gamepadPrompt:{offset:[-12,0]}},clickAction:({seaBlock:i})=>{i.toggleSettings(!1),i.refreshGui()}},au={layoutKey:"settingsQuitBtn",gamepadNavBox:"settingsQuitBtn",display:{type:"button",label:"QUIT",gamepadPrompt:{offset:[-20,0]}},clickAction:({seaBlock:i})=>{if(i.currentGameName==="chess"){vf();return}if(i.currentGameName==="raft"){B2();return}i.toggleSettings(),i.currentGameName==="free-cam"?i.config.tree.children.game.value="start-menu":i.config.tree.children.game.value="free-cam",i.startTransition()}},lu={layoutKey:"settingsQuitBtn",gamepadNavBox:"settingsQuitBtn",display:{type:"button",label:"OKAY",gamepadPrompt:{offset:[-20,0]}},clickAction:({seaBlock:i})=>{i.toggleSettings(!1),i.refreshGui()}},gp=class gp extends it{resetElementStates(e){super.resetElementStates(e),e.currentGameName==="start-menu"?(lu.display.isVisible=!0,au.display.isVisible=!1):(lu.display.isVisible=!1,au.display.isVisible=!0)}refreshLayout(e){super.refreshLayout(e),SD()}};it.register("settings-menu",{factory:()=>new gp,layoutFactory:()=>MD,elements:[wD,ED,...Object.values(ec).flatMap(e=>Object.values(e.elements)),au,lu]});let p_=gp;const AD={launch:{width:64,height:32,left:"auto",top:"auto"}},TD=[{display:{type:"button",label:"LAUNCH"},layoutKey:"launch",hotkeys:[...eI,..._f],isSticky:!0,clickAction:({seaBlock:i})=>{i.startTransition({})}}],_p=class _p extends it{};it.register("splash-screen",{factory:()=>new _p,elements:TD,layoutFactory:()=>AD});let m_=_p;const rl=16,ol=16,CD={backPanel:{},titleBar:{parent:"backPanel",height:rl},titleBarLabel:{parent:"titleBar",width:-rl},closeBtn:{parent:"titleBar",width:rl,right:0},_main:{parent:"backPanel",height:-rl,bottom:0},viewPanel:{parent:"_main",width:-ol},scrollBar:{parent:"_main",width:ol,right:0,bottom:0},scrollBarSlider:{parent:"scrollBar",width:ol,height:2*ol}},If={layoutKey:"scrollBar",display:{type:"panel"}},Zi={layoutKey:"scrollBarSlider",slideIn:"scrollBar",display:{type:"button"},clickAction:i=>{i!=null&&i.sliderState&&(lr=i.sliderState,nc())},dragAction:i=>{i!=null&&i.sliderState&&(lr=i.sliderState,nc())}};let al,ll,lr={x:0,y:0};const RD=100,tc={layoutKey:"viewPanel",display:{type:"sprite-atlas"},clickAction:({inputEvent:i})=>{i&&(al=i.lvPos.clone(),ll=lr,Zi.display.forcedState="pressed",Zi.display.needsUpdate=!0,If.display.needsUpdate=!0)},dragAction:({inputEvent:i})=>{if(i&&al&&ll){const t=-i.lvPos.clone().sub(al).y/(Qd()-RD);lr={x:0,y:Math.max(0,Math.min(1,ll.y+t))},Zi.display.forcedSliderState=lr,nc()}},unclickAction:()=>{al=void 0,ll=void 0,Zi.display.forcedState=void 0,Zi.display.needsUpdate=!0}};function nc(){tc.display.needsUpdate=!0,Zi.display.needsUpdate=!0,If.display.needsUpdate=!0,tc.display.needsUpdate=!0}const xp=class xp extends it{drawAtlasView(e,t){const{x:n,y:s,w:r,h:o}=t,{imageset:l}=tc.display;if(!l)return;const c=l.default,u=c.getContext("2d");u.fillStyle="#c0c0c0",u.fillRect(0,0,r,o),LT({ctx:u,yFraction:lr.y,viewHeight:o}),e.drawImage(c,0,0,r,o,n,s,r,o)}refreshLayout(e){super.refreshLayout(e),nc()}};it.register("sprite-atlas",{factory:()=>new xp,layoutFactory:()=>CD,elements:[{layoutKey:"backPanel",display:{type:"panel"}},tc,If,Zi,{layoutKey:"titleBar",display:{type:"panel"}},{layoutKey:"titleBarLabel",display:{type:"label",label:"SPRITE ATLAS",font:"mini"}},{layoutKey:"closeBtn",display:{type:"button",icon:"icons/16x16-x.png",border:"16x16-btn-square"},clickAction:({seaBlock:e})=>{const t=e.config.tree.children.testGui;t.value="none",e.onCtrlChange(t)}}]});let g_=xp;const PD={smText:{},_middle:{height:0,top:"auto"},smBanner:{parent:"_middle",width:80,height:80,left:"auto",top:-50},smStartBtn:{parent:"smBanner",width:38,height:16,left:0,bottom:0},smSettingsBtn:{parent:"smBanner",width:38,height:16,right:0,bottom:0}},yp=class yp extends it{};it.register("start-menu",{factory:()=>new yp,layoutFactory:()=>PD,elements:[...nv]});let __=yp;const{pad:x_}=yn,ID={skip:{width:48,height:16,right:x_,bottom:x_}},LD={display:{type:"button",label:"SKIP"},layoutKey:"skip",hotkeys:["Escape","Space"],clickAction:({seaBlock:i})=>{i.config.tree.children.game.value="free-cam",$e.isFirstUncover=!1,Ad.t=0,i.startTransition({transition:$e.create("flat",i)}),Md.wasSkipped=!0}},vp=class vp extends it{};it.register("start-sequence",{factory:()=>new vp,layoutFactory:()=>ID,elements:[LD]});let y_=vp;const bp=class bp extends it{constructor(){super(...arguments);E(this,"pickedTile")}move(t){const n=super.move(t);return this.pickedTile=void 0,n||(this.pickedTile=t.pickedTile),n}};it.register("tile-inspector",{factory:()=>new bp,layoutFactory:()=>({}),elements:[]});let v_=bp;function DD(i){return{getSetting:e=>i.config.flatConfig[e],applySetting:(e,t)=>{i.config.tree.children[e].value=t,i.config.flatConfig[e]=t},getGameState:()=>i.didLoadAssets?i.transition?"transition":i.currentGameName:"loading",getCameraPos:()=>{const{x:e,y:t,z:n}=i.camera.position;return[e,t,n]},getCursorState:()=>"mousePosForTestSupport"in i?{x:i.mousePosForTestSupport.x,y:i.mousePosForTestSupport.y,style:document.documentElement.style.cursor}:null,locateElement(e){if(e.startsWith("chessBoard")){const c=e.match(/chessBoard\(([-\d]+),([-\d]+)\)/);if(!c)return;const u=parseInt(c[1]),d=parseInt(c[2]),a=W.context.terrain.grid.xzToIndex(W.centerTile.x+u,W.centerTile.z-d);return a?bg(i,W.getPosOnTile(a)):void 0}if(e==="rookMesh"){const c=x2("rook");if(c)return bg(i,c)}const t=i.game.gui.layoutRectangles[e];if(!t)return;const{x:n,y:s,w:r,h:o}=t,l=i.config.flatConfig.pixelScale;return[n*l,s*l,r*l,o*l]}}}async function UD(){const i=new WL;Jt.refreshConfig(),await AC();const e=new cI(i);await it.preload("splash-screen",e),await St.preload("splash-screen"),i.init(e),e.config.refreshConfig(),e.config.flatConfig.generator="all-ocean",e.config.flatConfig.style="black-and-white",e.config.flatConfig.game="splash-screen",e.config.flatConfig.tiling=hi(af.NAMES),e.init(),e.reset(),window.TestSupport=DD(e);let t=performance.now();async function n(){requestAnimationFrame(n);const s=performance.now(),r=Math.min(50,s-t);t=s,await e.update(r)}n()}UD();
