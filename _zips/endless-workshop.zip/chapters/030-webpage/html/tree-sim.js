/**
 * @file TreeSim
 * tree doodle Simulation
 */

const global = {
  // total time elapsed in milliseconds
  t: 0,

  // growth animation delay (ms)
  growthDelay: 5,

  iterationsDrawn: 0,

  segLen: 1,

  maxActors: 1000,

  branchOdds: 5e-2,
};

/**
 *
 */
class TreeSim extends Simulation {

  /**
   *
   * @param branch
   */
  _randTurn(branch) {
    return branch.curliness * 5e-3 * MathUtil.randRange(0.2, 1) * (0.003 * branch.depth) * (branch.spiralDepth + 10);
  }

  /**
   *
   * @param {...any} args
   */
  constructor(...args) {
    super(...args);

    // use smaller chunks
    this.chunkSize = CHUNK_SIZE / 4;
  }

  /**
   *
   */
  init() {
    super.init();

    this._spawnRandomSegment();
    return this;
  }

  /**
   *
   */
  _spawnRandomSegment() {

    if (!this.canvas.culledRegions) {
      return;
    }
    if (this.canvas.culledRegions.length === 0) {
      return;
    }
    const region = this.canvas.culledRegions[Math.floor(2 * Math.random())];// this.canvas.visibleRegion
    if (!region) {
      return;
    }
    const [x, y, w, h] = region;

    // // if( w < 10 || h < 10 ){
    // //   return
    // // }

    // // const angle = Math.random()*2*Math.PI

    // const x = 0
    // const y = 0
    // const w = QUAD_WIDTH
    // const h = QUAD_HEIGHT

    if (!this.canvas.rect) {
      return;
    }
    const position = { x: x + Math.random() * w, y: y + Math.random() * h };
    if (!this._isInView(position)) {
      return;
    }

    const center = { x: CENTER.x - this.canvas.rect[0], y: CENTER.y - this.canvas.rect[1] };

    // const angle = MathUtil.getAngle(MathUtil.subtract(center, position));
    const angle = Math.random() * 2 * Math.PI;
    const delta = MathUtil.polarToCartesian(angle, global.segLen);
    this.actors.push(this._newSegmentActor({ position, delta }));
  }

  /**
   *
   * @param dt
   */
  update(dt) {

    global.t = global.t + dt;
    const n = Math.floor(global.t / global.growthDelay);

    const ctx = this.canvas.ctx;

    if (this.actors.length === 0) {
      this._spawnRandomSegment();
    }

    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = global.iterationsDrawn; i < n; i++) {
      this.actors = this.actors.filter((actor) => this._tryAddSegment(actor));
      for (const { position, delta } of this.actors) {
        // ctx.moveTo(position.x - delta.x, position.y - delta.y);
        // ctx.lineTo(position.x, position.y);
        ctx.moveTo(position.x - delta.x, position.y - delta.y);
        ctx.lineTo(position.x, position.y);
      }
      this.actors = this.actors.flatMap((s) => this._grow(s));

      if (this.actors.length > global.maxActors) {

        // this.actors = this.actors.sort((a,b) => b.spiralDepth-a.spiralDepth);
        this.actors = this.actors.slice(0, global.maxActors);
      }

    }
    ctx.stroke();

    global.iterationsDrawn = n;

    // console.log(`tree iteration ${n} (${this.actors.length} actors)`);
  }

  /**
   *
   * @param position
   */
  _isInView(position) {

    const x = position.x + this.canvas.rect[0];
    const y = position.y + this.canvas.rect[1];
    if (
      (x < TOP_LEFT.x) ||
    (y < TOP_LEFT.y) ||
    (x >= BOTTOM_RIGHT.x) ||
    (y >= BOTTOM_RIGHT.y)) {
      return false;
    }
    return true;
  }

  /**
   * return true if the given segment
   * does not intersect any existing segments
   *
   * if true then the given segment will
   * be considered in future intersection checks
   * @param seg
   */
  _tryAddSegment(seg) {

    // debug
    // return true

    // check if out of expanded viewport
    if (!this._isInView(seg.position)) {
      return false;
    }

    // identify relevant chunks
    let chunkIds = seg.chunkIds;

    // check for intersections with
    // lines in relevant chunks
    // chunkIds = chunkIds.filter((i) => !seg.parentChunkIds.includes(i));
    chunkIds = chunkIds.filter((aChunk) =>
      !seg.parentChunkIds.some((sChunk) => this.arraysEqual(aChunk, sChunk))
    );

    let intersects = false;
    if (!seg.forceAdd) {
      intersects = chunkIds.some((i) => this.getChunk(...i));

      if (intersects) {
        return false;
      }
    }

    // check for intersections ahead of the new segment
    const delta = MathUtil.polarToCartesian(seg.angle, this.chunkSize / 2);// global.segMargin);
    const ahead = this._newSegmentActor({
      delta,
      position: MathUtil.add(seg.position, delta),
    });

    // const aheadChunkIds = ahead.chunkIds.filter((i) => !seg.chunkIds.includes(i));
    const aheadChunkIds = ahead.chunkIds.filter((aChunk) =>
      !seg.chunkIds.some((sChunk) => this.arraysEqual(aChunk, sChunk))
    );
    intersects = aheadChunkIds.some((i) => this.getChunk(...i));
    if (intersects) {
      return false;
    }

    // set relevent chunks as filled
    chunkIds.forEach((i) => this.setChunk(...i, true));
    return true;
  }

  /**
   *
   * @param a
   * @param b
   */
  arraysEqual(a, b) {
    return a.length === b.length && a.every((val, i) => val === b[i]);
  }

  /**
   *
   * @param params
   */
  _newSegmentActor(params) {

    const result = { ...params };

    const { position, delta, depth = 0, parentChunkIds = [] } = params;

    const angle = MathUtil.getAngle(delta);
    result.angle = angle;

    result.depth = depth;
    result.parentChunkIds = parentChunkIds;
    result.chunkIds = this._getChunkCoordGroup(result);

    return result;
  }

  /**
   * given a line segemnt,
   * get a list of 1, 2, or 3 relevant chunk IDs
   * @param seg
   */
  _getChunkCoordGroup(seg) {
    const start = MathUtil.subtract(seg.position, seg.delta);
    const ca = this._getChunkCoords(start);
    const cb = this._getChunkCoords(seg.position);

    if (ca === cb) {
      // both ends of the segment are in the same chunk
      return [ida];
    }

    // segment in two diagonal chunks
    // add a third chunk
    if ((ca[0] != cb[0]) && (ca[1] != cb[1])) {

      const midx = Math.max(ca[0], cb[0]) * this.chunkSize;
      const midy = Math.max(ca[1], cb[1]) * this.chunkSize;
      const mb = this._getMb(start, seg.position);
      const segy = mb.m * midx + mb.b;
      const cc = (segy > midy) == (cb[1] > ca[1]) ?
        [ca[0], cb[1]] : [cb[0], ca[1]];
      return [ca, cb, cc];
    }

    // segment in two adjacent
    return [ca, cb];
  }

  /**
   *
   * @param start
   * @param end
   */
  _getMb(start, end) {
    const m = (end.y - start.y) / (end.x - start.x);
    const b = start.y - m * start.x;
    return { m, b };
  }

  /**
   *
   * @param p
   */
  _getChunkCoords(p) {
    const x = Math.floor(p.x / this.chunkSize);
    const y = Math.floor(p.y / this.chunkSize);
    return [x, y];
  }

  /**
   *
   * @param actor
   */
  _grow(actor) {

    const branch = actor;

    // handle doodle-tree specific properties
    if (!Object.hasOwn(branch, 'spiralDepth')) {
      branch.spiralDepth = 0;
    }
    if (!Object.hasOwn(branch, 'spiralDir')) {
      branch.spiralDir = (Math.random() < 0.5) ? -1 : 1;
    }
    if (!Object.hasOwn(branch, 'curliness')) {
      branch.curliness = MathUtil.randRange(0.5, 1);
    }

    // continue in spiral
    let turn = branch.spiralDir * this._randTurn(branch);

    let delta = MathUtil.polarToCartesian(branch.angle + turn, global.segLen);
    let s = this._newSegmentActor({
      position: MathUtil.add(branch.position, delta),
      delta,
      depth: branch.depth + 1,
      parentChunkIds: branch.chunkIds,
      spiralDepth: branch.spiralDepth,
      spiralDir: branch.spiralDir,
      curliness: branch.curliness,
    });

    const result = [s];

    // possible spawn a new branch spiraling the opposite direction
    const spawn = Math.random() < global.branchOdds;
    if (spawn) {
      turn = -branch.spiralDir * this._randTurn(branch);
      delta = MathUtil.polarToCartesian(branch.angle + turn, global.segLen);
      s = this._newSegmentActor({
        position: MathUtil.add(branch.position, delta),
        delta,
        depth: branch.depth + 1,
        parentChunkIds: branch.chunkIds,
        spiralDepth: Math.min(3, branch.spiralDepth + 1),
        spiralDir: -branch.spiralDir,
        curliness: branch.curliness,
        forceAdd: true, // override intersection check
      });
      result.push(s);
    }

    return result;
  }

  /**
   *
   * @param rawActor
   */
  recieveActor(rawActor) {
    if (this._tryAddSegment(rawActor)) {
      this.actors.unshift(rawActor);
    }
  }
}
