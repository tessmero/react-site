/**
 * @file simulation
 * one member of a quad-simulations group
 */
class Simulation {

  /**
   *
   * @param canvas
   */
  constructor(canvas) {
    this.canvas = canvas;
    canvas.sim = this;
    this.dx = canvas.quad.dx;
    this.dy = canvas.quad.dy;

    // simulation-specific chunk size
    this.chunkSize = CHUNK_SIZE;

    // objects with position:{x,y}
    this.actors = [];
  }

  /**
   * called after construction
   */
  init() {

    // initialize chunks
    this.chunkCols = Math.round(QUAD_WIDTH / this.chunkSize); // width in chunks
    this.chunkRows = Math.round(QUAD_HEIGHT / this.chunkSize); // height in chunks
    this.nChunks = this.chunkRows * this.chunkCols; // total number of chunks
    this._chunks = new Array(this.nChunks).fill(false); // all start inactive

    return this;
  }

  /**
   *
   */
  update() {
    throw new Error(`not implemented in ${this.constructor.name}`);
  }

  /**
   *
   * @param ctx
   */
  debugActors(ctx) {
    for (const actor of this.actors) {

      const { x, y } = actor.position;

      const rad = 5;
      ctx.fillSyle = 'red';
      ctx.fillRect(x - rad, y - rad, 2 * rad, 2 * rad);
    }
  }

  /**
   *
   */
  passOobActors() {
    const { xNeighbor, yNeighbor } = this;
    this.actors = this.actors.filter((actor) => {

      let { x, y } = actor.position;

      // check if xy is out of bounds
      const loX = (x < 0);
      const hiX = (x >= QUAD_WIDTH);
      const loY = (y < 0);
      const hiY = (y >= QUAD_HEIGHT);

      let parent = this; // simulation to pass actor to

      // check if xy is out of bounds
      if (loX) {
        parent = parent.xNeighbor;
        x = x + QUAD_WIDTH;
      }
      if (hiX) {
        parent = parent.xNeighbor;
        x = x - QUAD_WIDTH;
      }
      if (loY) {
        parent = parent.yNeighbor;
        y = y + QUAD_HEIGHT;
      }
      if (hiY) {
        parent = parent.yNeighbor;
        y = y - QUAD_HEIGHT;
      }

      if (parent === this) {

        // check for special case
        if (loX || hiX || loY || hiY) {

          // crossed two edges, ending up back here in new position
          actor.position = { x, y };
        }

        // actor is in-bounds
        return true; // keep in this simulation
      }

      // pass out-of-bounds actor to neighboring simulation
      actor.position = { x, y };
      parent.recieveActor(actor); // add to neighbor
      console.log('passed actor');
      return false; // remove from this simulation
    });
  }

  /**
   *
   * @param actor
   */
  recieveActor(actor) {
    this.actors.push(actor);
  }

  /**
   *
   * @param ctx
   */
  debugChunks(ctx) {
    const chunkSize = this.chunkSize; // simulation-specific chunk size

    ctx.clearRect(0, 0, QUAD_WIDTH, QUAD_HEIGHT);

    ctx.strokeStyle = 'black';
    ctx.lineWidth = 3;
    const pad = 6;
    for (let x = 0; x < this.chunkCols; x++) {
      for (let y = 0; y < this.chunkRows; y++) {
        ctx.strokeRect(x * chunkSize, y * chunkSize, chunkSize, chunkSize);

        if (this.getChunk(x, y)) {
          ctx.strokeRect(x * chunkSize + pad,
            y * chunkSize + pad,
            chunkSize - pad * 2, chunkSize - pad * 2);
        }
      }
    }
  }

  /**
   *
   * @param index
   */
  _chunkCoords(index) {
    return {
      x: index % this.chunkCols,
      y: Math.floor(index / this.chunkCols),
    };
  }

  /**
   *
   * @param x
   * @param y
   */
  _chunkIndex(x, y) {
    return y * this.chunkCols + x;
  }

  /**
   *
   * @param x
   * @param y
   */
  getChunk(x, y) {
    const { xNeighbor, yNeighbor, chunkRows, chunkCols } = this;

    // check if xy is out of bounds
    if (x < 0) {
      return xNeighbor.getChunk(x + chunkCols, y);
    }
    if (x >= chunkCols) {
      return xNeighbor.getChunk(x - chunkCols, y);
    }
    if (y < 0) {
      return yNeighbor.getChunk(x, y + chunkRows);
    }
    if (y >= chunkRows) {
      return yNeighbor.getChunk(x, y - chunkRows);
    }

    // xy is in bounds
    const i = this._chunkIndex(x, y);
    if (this._tempChunks) {
      return this._tempChunks[i];
    }
    return this._chunks[i];
  }

  /**
   *
   * @param x
   * @param y
   * @param value
   */
  setChunk(x, y, value) {
    const { chunkRows, chunkCols } = this;
    if (x < 0) {
      return;
    }
    if (x >= chunkCols) {
      return;
    }
    if (y < 0) {
      return;
    }
    if (y >= chunkRows) {
      return;
    }

    const i = this._chunkIndex(x, y);
    this._chunks[i] = value;
  }

}
