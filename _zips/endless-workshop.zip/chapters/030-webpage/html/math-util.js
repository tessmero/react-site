/**
 * @file math-util.js
 * utility functions involving 2D vectors
 * Vectors are objects with properties x and y
 */
class MathUtil {

  /**
   *
   * @param min
   * @param max
   */
  static randRange(min, max) {
    return min + (max - min) * Math.random();
  }

  /**
   * non-negative modulo
   * same as regular modulo, but result is always >= 0
   * @param a The dividend
   * @param b The divisor
   */
  static nnmod(a, b) {
    const result = a % b;
    if (result < 0) {
      return result + b;
    }
    return result;
  }

  /**
   * Compute a weighted average between two vectors or numbers.
   * @param {number|Vector} a
   * @param {number|Vector} b
   * @param {number} r Optional ratio
   */
  static avg(a, b, r = 0.5) {
    if (typeof a === 'number') {
      return a * (1 - r) + b * r; // average numbers
    }

    // average vectors
    return {
      x: MathUtil.avg(a.x, b.x, r),
      y: MathUtil.avg(a.y, b.y, r),
    };
  }

  /**
   * Convert from polar coordinates (angle,radius)
   * to Cartesian coordinates (x,y).
   * @param {number} angle
   * @param {number} radius
   * @returns {Vector} The equivalent (x,y) vector.
   */
  static polarToCartesian(angle, radius) {
    return {
      x: radius * Math.cos(angle),
      y: radius * Math.sin(angle),
    };
  }

  /**
   * Get the direction of the vector.
   * @param {Vector} vector
   * @returns {number} The angle in radians.
   */
  static getAngle(vector) {
    const { x, y } = vector;
    return Math.atan2(y, x);
  }

  /**
   *
   * @param rect
   */
  static rectCenter(rect) {
    const [x, y, w, h] = rect;
    return { x: x + w / 2, y: y + h / 2 };
  }

  /**
   *
   * @param {Vector} vector
   * @returns {number}
   */
  static getLengthSquared(vector) {
    const { x, y } = vector;
    return x * x + y * y;
  }

  /**
   * Get the magnitude/length/distance of the vector.
   * @param {Vector} vector
   * @returns {number}
   */
  static getLength(vector) {
    return Math.sqrt(MathUtil.getLengthSquared(vector));
  }

  /**
   * Add together two or more vectors.
   * @param {...Vector} vectors
   * @returns {Vector}
   */
  static add(...vectors) {
    let totalX = 0;
    let totalY = 0;
    for (const { x, y } of vectors) {
      totalX = totalX + x;
      totalY = totalY + y;
    }
    return { x: totalX, y: totalY };
  }

  /**
   * Compute the difference between two vectors
   * @param {Vector} a
   * @param {Vector} b
   * @returns {Vector} The difference a-b
   */
  static subtract(a, b) {
    return {
      x: a.x - b.x,
      y: a.y - b.y,
    };
  }

  /**
   * Multiply a vector by a number
   * @param {Vector} vector
   * @param {number} scalar
   */
  static multiply(vector, scalar) {
    const { x, y } = vector;
    return {
      x: x * scalar,
      y: y * scalar,
    };
  }

}
