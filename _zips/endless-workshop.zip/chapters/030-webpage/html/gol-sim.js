/**
 * @file GolSim
 * Game of Life Simulation
 */
class GolSim extends Simulation {

  /**
   *
   */
  init() {
    super.init();

    // prepare deep copy of chunks to use during update
    this._altChunks = [...this._chunks];

    // add starting shape
    const name = 'gosperGliderGun';
    const specs = GolSim._startState.trim().split('\n').map((line) => line.trim());
    const offsets = [{ x: 5, y: 5 }]; // place a copy at each offset
    for (const off of offsets) {
      for (let x = 0; x < this.chunkCols && x < specs[0].length; x++) {
        for (let y = 0; y < this.chunkRows && y < specs.length; y++) {
          const code = specs[y].substring(x, x + 1);
          const value = (code === 'O');
          const cellX = off.x + x;
          const cellY = off.y + y;
          this.setChunk(cellX, cellY, value);
          this._drawGolCell(cellX, cellY, value);
        }
      }
    }

    // // add test actors
    const n = 10;
    const speed = 1;
    for (let i = 0; i < n; i++) {
      const angle = 2 * Math.PI * Math.random();// i / n
      this.actors.push({
        position: { x: QUAD_WIDTH / 2, y: QUAD_HEIGHT / 2 },
        velocity: { x: speed * Math.cos(angle), y: speed * Math.sin(angle) },
      });
    }

    // test crossing corner exactly (crossing two borders in one step)
    this.actors.push({
      position: { x: 100, y: 100 },
      velocity: { x: -1, y: -1 },
    });

    return this;
  }

  /**
   *
   * @param x
   * @param y
   */
  _countGolNeighbors(x, y) {

    // iterate over 3x3 chunks centered at x,y
    let count = 0;
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        if (dx === 0 && dy === 0) { continue; } // Skip the cell itself
        count = count + this.getChunk(x + dx, y + dy); // Sum live neighbors
      }
    }
    return count;
  }

  frameDuration = 100;
  countdown = 0;
  stepCount = 0;

  /**
   *
   * @param dt
   */
  update(dt) {
    this._tempChunks = null;

    // update test actors
    for (const { position, velocity } of this.actors) {
      position.x = position.x + velocity.x;
      position.y = position.y + velocity.y;
    }

    this.countdown = this.countdown - dt;
    if (this.countdown < 0) {
      this.countdown = this.frameDuration;
      this.stepCount++;
      console.log(`gol step ${this.stepCount}`);
    }
    else {
      return;
    }

    // update alt state based on current state
    for (let x = 0; x < this.chunkCols; x++) {
      for (let y = 0; y < this.chunkRows; y++) {
        const chunkIndex = this._chunkIndex(x, y);

        const liveNeighbors = this._countGolNeighbors(x, y);
        const currentState = this._chunks[chunkIndex];// this.getChunk(x,y)

        let newState;
        if (currentState) {
          // Apply GoL rules for live cells
          newState = (liveNeighbors === 2 || liveNeighbors === 3);
        }
        else {
          // Apply GoL rule for dead cells
          newState = (liveNeighbors === 3);
        }
        this._altChunks[chunkIndex] = newState;

        // check if cell changed state
        if (newState !== currentState) {
          this._drawGolCell(x, y, newState);
        }

        // this.setChunk(x,y,newState)
      }
    }

    // swap state buffers
    const temp = this._chunks;
    this._chunks = this._altChunks;
    this._altChunks = temp;
    this._tempChunks = temp;
  }

  /**
   *
   * @param x
   * @param y
   * @param state
   */
  _drawGolCell(x, y, state) {
    const ctx = this.canvas.ctx;
    const xywh = [x * CHUNK_SIZE, y * CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE];
    if (state) {

      // fill rectangle
      ctx.fillRect(...xywh);

    }
    else {

      // clear dilated rectangle
      ctx.lineWidth = 2 / devicePixelRatio;
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillRect(...xywh);
      ctx.strokeRect(...xywh);
      ctx.globalCompositeOperation = 'source-over';

    }
  }

  // GOL state
  static _startState = `
    OOO
    O..
    .O.
  `;
}
