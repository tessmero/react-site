/**
 * @file Canvas
 * One member in a quad-canvases group
 */
class Canvas {

  /**
   *
   * @param params
   */
  constructor(params) {
    this.params = params;
    const { quad } = params;
    this.quad = quad;

    const { htmlElem, ctx } = this._getElem(
      'quad', // prefix for element ID
      {
        'background-color': (DEBUG_QUADS ? quad.debugColor : '#AAA'),
        'z-index': 1, // behind base canvas (3) and debug canvas (2)
      }
    );
    this.htmlElem = htmlElem;
    this.ctx = ctx;

  }

  /**
   *
   * @param prefix
   * @param styles
   */
  _getElem(prefix, styles = {}) {
    const id = `${prefix}-${JSON.stringify(this.quad)}`;
    let htmlElem = document.getElementById(id);
    if (!htmlElem) {

      // one-time build html element
      htmlElem = document.createElement('canvas');
      htmlElem.id = id;
      document.body.appendChild(htmlElem);
    }

    // set dimensions in element and element style
    Canvas.setStyles(htmlElem, {
      width: `${QUAD_WIDTH}px`,
      height: `${QUAD_HEIGHT}px`,
      'position': 'absolute',
      'overflow': 'hidden',
      ...styles,
    });

    // set dimensions in graphics context
    const pixelated = 2;
    htmlElem.width = QUAD_WIDTH * devicePixelRatio / pixelated;
    htmlElem.height = QUAD_HEIGHT * devicePixelRatio / pixelated;
    const ctx = htmlElem.getContext('2d');
    ctx.setTransform(devicePixelRatio / pixelated, 0, 0, devicePixelRatio / pixelated, 0, 0);

    return { htmlElem, ctx };
  }

  /**
   *
   */
  get debugCtx() {
    if (!this._debugCtx) {

      const { htmlElem, ctx } = this._getElem(
        'debug-quad',
        {
          'background-color': 'transparent',
          'z-index': 2, // in front of main canvas
        }
      );
      this._debugElem = htmlElem;
      this._debugCtx = ctx;
    }
    return this._debugCtx;
  }

  /**
   *
   * @param styles
   */
  setStyles(styles) {
    Canvas.setStyles(this.htmlElem, styles);

    if (this._debugElem) {
      Canvas.setStyles(this._debugElem, styles);
    }
  }

  /**
   *
   * @param elem
   * @param styles
   */
  static setStyles(elem, styles) {
    for (const [key, val] of Object.entries(styles)) {
      elem.style[key] = val;
    }
  }

  /**
   *
   * @param params
   */
  updatePosition(params) {
    const { camera } = params;
    const { quad: { dx, dy } } = this.params;

    const xNum = camera.x + dx * QUAD_WIDTH;
    let quadX = MathUtil.nnmod(xNum, 2 * QUAD_WIDTH);
    if (quadX + QUAD_WIDTH < TOP_LEFT.x) {
      quadX = quadX + 2 * QUAD_WIDTH;
    }
    if (quadX > BOTTOM_RIGHT.x) {
      quadX = quadX - 2 * QUAD_WIDTH;
    }

    const yNum = camera.y + dy * QUAD_HEIGHT;
    let quadY = MathUtil.nnmod(yNum, 2 * QUAD_HEIGHT);
    if (quadY + QUAD_HEIGHT < TOP_LEFT.y) {
      quadY = quadY + 2 * QUAD_HEIGHT;
    }
    if (quadY > BOTTOM_RIGHT.y) {
      quadY = quadY - 2 * QUAD_HEIGHT;
    }

    const pixel = 1 / devicePixelRatio;
    quadX = pixel * Math.round(quadX / pixel);
    quadY = pixel * Math.round(quadY / pixel);
    this.setStyles({
      left: `${quadX}px`,
      top: `${quadY}px`,
    });

    const rect = [quadX, quadY, QUAD_WIDTH, QUAD_HEIGHT];
    this.rect = rect;

    const viewport = [TOP_LEFT.x, TOP_LEFT.y, QUAD_WIDTH, QUAD_HEIGHT];
    if (this._prevRect) {
      this.clearCullRegions({
        ctx: this.ctx,
        viewport,
        prevCanvas: this._prevRect,
        currCanvas: rect,
      });
    }
    this._prevRect = rect;

    // if( DEBUG_CULLING && this.culledRegions ){
    //   const fillStyle = 'red'
    //   for( const culledRect of this.culledRegions ){
    //     this.debugCtx.fillRect(...culledRect)
    //   }
    // }
  }

  /**
   * Clears (or fills) the regions that just passed out of view when the canvas moves.
   * Expands the cleared regions slightly outward for robustness.
   * @param {object} params
   * @param {CanvasRenderingContext2D} params.ctx
   * @param {number[]} params.viewport - [x, y, w, h]
   * @param {number[]} params.prevCanvas - [x, y, w, h]
   * @param {number[]} params.currCanvas - [x, y, w, h]
   */
  clearCullRegions(params) {

    this.culledRegions = [];

    const { ctx, viewport, prevCanvas, currCanvas } = params;
    const [vx, vy, vw, vh] = viewport;
    const [ox, oy, ow, oh] = prevCanvas;
    const [cx, cy, cw, ch] = currCanvas;

    // Expand amount in pixels
    const margin = 2;

    // Horizontal culling
    if (ox > cx) {
      // Canvas moved right: clear left strip
      const dx = ox - cx + margin;
      this._cullRect(
        vx - cx - margin,
        vy - cy - margin,
        dx,
        vh + 2 * margin
      );
    }
    else if (ox < cx) {
      // Canvas moved left: clear right strip
      const dx = cx - ox + margin;
      this._cullRect(
        vx + vw - dx - cx + margin,
        vy - cy - margin,
        dx,
        vh + 2 * margin
      );
    }

    // Vertical culling
    if (oy > cy) {
      // Canvas moved down: clear top strip
      const dy = oy - cy + margin;
      this._cullRect(
        vx - cx - margin,
        vy - cy - margin,
        vw + 2 * margin,
        dy
      );
    }
    else if (oy < cy) {
      // Canvas moved up: clear bottom strip
      const dy = cy - oy + margin;
      this._cullRect(
        vx - cx - margin,
        vy + vh - dy - cy + margin,
        vw + 2 * margin,
        dy
      );
    }

  }

  /**
   *
   * @param {...any} rect
   */
  _cullRect(...rect) {
    if (ENABLE_CULLING) {
      this.ctx.clearRect(...rect); // cull graphics
      if (this.sim) {
        this._cullChunks(rect); // cull logical chunks
      }
    }
    this.culledRegions.push(rect);
  }

  /**
   *
   * @param rect
   */
  _cullChunks(rect) {
    const chunkSize = this.sim.chunkSize;
    const [x, y, w, h] = rect;

    // get bounds in units of chunks
    const startX = Math.round(x / chunkSize);
    const endX = Math.round((x + w - 1) / chunkSize);
    const startY = Math.round(y / chunkSize);
    const endY = Math.round((y + h - 1) / chunkSize);

    for (let cx = startX; cx <= endX; cx++) {
      for (let cy = startY; cy <= endY; cy++) {
        this.sim.setChunk(cx, cy, false);
      }
    }
  }

}
