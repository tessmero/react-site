/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const DEBUG_QUADS = false; // color-code the 4 canvases
const DEBUG_SCREEN = false; // trace screen boundaries
const DEBUG_SHRINK = false; // shrink screen boundaries
const DEBUG_CHUNKS = false; // trace simulation chunks
const DEBUG_ACTORS = false;

const ENABLE_CULLING = true; // clear canvas and simulation outside of view



const MAX_CHUNKS = 256; // default number of chunks per simulation

// assume document has one canvas
// to be used as a placeholder or for debugging
// it will always fill the REAL viewport
const BASE_CANVAS = document.getElementsByTagName('canvas')[0];
Canvas.setStyles(BASE_CANVAS, {
  'background-color': 'transparent',
  'z-index': 3,
});

const CENTER = {
  x: window.innerWidth / 2,
  y: window.innerHeight / 2,
};

// pick adjusted quad shape and define global variables
const {
  CHUNK_SIZE, // square chunk
  VIEW_WIDTH, VIEW_HEIGHT, // viewport dimensions
  QUAD_WIDTH, QUAD_HEIGHT, // expanded dimensions
  TOP_LEFT, // corner matching viewport
  BOTTOM_RIGHT, // expanded corner
} = QuadUtil.setupQuadShape();

// get array of 4 Canvas instances
const quadCvs = QuadUtil.setupQuadCanvases();

// build 4 simulations
const quadSims = quadCvs.map((canvas) => new TreeSim(canvas).init());

// link neighboring simulations
for (const a of quadSims) {
  for (const b of quadSims) {
    if (a !== b) {
      if (a.dx === b.dx) { a.yNeighbor = b; }
      else if (a.dy === b.dy) { a.xNeighbor = b; }
    }
  }
}



const CAMERA_RADIUS = 10000; 
const CAMERA_PERIOD = 300000;

// (milliseconds) system time
let time = Date.now();

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // compute time elapsed since last frame
  const newTime = Date.now();
  const dt = Math.min(50, newTime - time); // limit to 50 ms in case of lag
  time = newTime;

  const angle = time / CAMERA_PERIOD;
  const rawCam = { x: CAMERA_RADIUS * Math.sin(angle), y: CAMERA_RADIUS * Math.cos(angle) };

  const pixel = 1/devicePixelRatio
  const camera = { x: pixel*Math.round(rawCam.x/pixel), y: pixel*Math.round(rawCam.y/pixel) };
  
  for (const cvs of quadCvs) {
    cvs.updatePosition({ camera });
  }
  for (const sim of quadSims) {
    sim.update(dt);
  }
  for (const sim of quadSims) {
    sim.passOobActors(); // pass out-of-bounds actors to neighbors

    if (DEBUG_ACTORS || DEBUG_CHUNKS) {

      // display overlay on quad (bad for performance)
      const ctx = sim.canvas.debugCtx;
      ctx.clearRect(0, 0, QUAD_WIDTH, QUAD_HEIGHT);
      if (DEBUG_ACTORS) { sim.debugActors(ctx); }
      if (DEBUG_CHUNKS) { sim.debugChunks(ctx); }
    }
  }



// debug viewport or quads or chunks
  QuadUtil.drawDebugOverlays()
  
}
requestAnimationFrame(animationLoop); // queue first loop