/**
 * @file _build-html.js
 * IDE v0.0.2 (June 2025) eval this and expect a function
 *
 * - parameters are html strings
 * - return value should be an html string
 *
 * For endless-workshop we output the script
 * in a sandbox behind the content.
 *
 * For projects that don't have this file,
 * the default build only includes script (ignores content)
 * with a minimal html->body->canvas.
 */

// 
({ script, content }) => {

  // helper to render html/scripts inside of rendered javascript backticks
  function escapeJs(htmlString) {
    return htmlString
      .replace(/\\/g, '\\\\') // Escape backslashes first
      .replace(/`/g, '\\`') // Escape backticks
      .replace(/\$\{/g, '\\${') // Escape ${ for interpolation
      .replace(/<\/script>/g, '<\\/script>');
  }

  // content for inner iframe
  const innerContent = `
<!DOCTYPE html>
<html>
  <head>
    <style>
      html, body { margin: 0; padding: 0; overflow:hidden }
      canvas {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: #AAA;
      }
    </style>
  </head>
  <body>
    <canvas></canvas>
    ${script}
  </body>
</html>
`;

  return `
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Preview</title>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        color: #333;
        background-color: transparent;
      }
      #previewFrame {
        border: none;
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 0;
        overflow: hidden;
      }
      .content {
        position: relative;
        z-index: 1;
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
      }
      summary {
        cursor: pointer;
      }
    </style>
  </head>
  <body>
    <iframe id="previewFrame"></iframe>
    <div class="content">
      ${content}
    </div>
    <script>
      const innerSrc = \`
        ${escapeJs(innerContent)}
      \`;
      const sandbox = document.getElementById('previewFrame');
      sandbox.srcdoc = innerSrc 
      window.addEventListener('resize', () => {
        sandbox.srcdoc = innerSrc;
      });
    <\/script>
  </body>
</html>
`;
};
