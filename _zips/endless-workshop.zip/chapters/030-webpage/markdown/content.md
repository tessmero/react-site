# The Endless Story of the Infinite Canvas

### Infinite Canvas

We stitch together a group of canvas elements and occasionally swap them around. Then we can pan over a 2D scene infinitely in any direction without having to constantly redraw the scene.

### Endless Story

Similarly, we stitch together a group of independent simulations. We define a base Simulation class that handles the stitching logic. Then we extend it to implement Conway's Game of Life and space-filling trees.
