var myObject = {
  boxA: {
    width: 161.803,
    height: 100,
    left: 15,
    top: 15
  },
  boxB: {
    width: 100,
    height: 100,
    left: 'auto',
    top: 'auto'
  },
  boxC: {
    width: 100,
    height: 61.803,
    right: 15,
    bottom: 15
  }
};