/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const filename = 'content.js'
const parserParams = {
  delimiters: {
    ignoreLinesWith: ['='],
    boxStart: /^(.+?):\s*\{$/, // :{ with whitespace allowed in between
    boxEnd: /}/,
    propertyValue: ':',
    propertyEnd: ',',
  }
}






const STEP_DELAY = 300 // miliseconds per step in autoplay
let stepCountdown = STEP_DELAY // milliseconds remaining until next step

// prepare to draw on the canvas element in our html document
const canvas = document.getElementsByTagName('canvas')[0];
canvas.width = innerWidth * devicePixelRatio;
canvas.height = innerHeight * devicePixelRatio;
const ctx = canvas.getContext('2d')

let mode = 'playing' // playing or paused
const pad = 20
const padBottom = 200
const padSide = 100
const defaultBox = {x:[padSide,canvas.width-2*padSide],y:[pad,canvas.height-pad-padBottom]}
const parser = new StringParser(defaultBox,parserParams)
let currentLine = 0 // line number in css

function htmlElem(tagName, attributes) {
  const { id } = attributes;
  let elem = document.getElementById(id);

  if (!elem) {

    // add new html element
    elem = document.createElement(tagName);
    for (const [key, value] of Object.entries(attributes)) {
      elem.setAttribute(key, value);
    }
    document.getElementById('input-container').appendChild(elem);
  }
  return elem;
}
const playButton = htmlElem('input', {
  id: 'playButton',
  type: 'button',
  value: 'PAUSE',
});
const stepButton = htmlElem('input', {
  id: 'stepButton',
  type: 'button',
  value: 'STEP',
})

let repaintRequested = true
let playing = true

function togglePlay(){ 
  playing = !playing
  stepCountdown = STEP_DELAY
  if( playing && currentLine >= cssLines.length ){
    setCurrentLine(0)
  }
  playButton.setAttribute('value', playing ? 'PAUSE' : 'PLAY' )
}
playButton.onclick = togglePlay;
    
function setCurrentLine(lineIndex){
  parser.reset()
  currentLine = 0
  while( currentLine < lineIndex ){
    const before = currentLine
    step()
    if( before === currentLine ){
      console.log(`step failed with currentLine ${currentLine}`)
      break // step not working, prevent infinite loop
    }
  }
  playing = false
  playButton.setAttribute('value', 'PLAY' )
  window.parent.postMessage({ 
    type: 'ide-highlight-line',
    tab:filename, 
    line: currentLine-1, 
  }, '*');
}

function step(){
  

    parser.parseLine(cssLines[currentLine])
    currentLine = currentLine + 1

    if( currentLine >= cssLines.length ){
      setCurrentLine(0)
    } else {
      repaintRequested = true
    }
}
stepButton.onclick = () => {
  playing = false;
  step();
  window.parent.postMessage({ tab:filename, line: currentLine-1, type: 'ide-highlight-line' }, '*');
}

window.addEventListener('message', function(event) {

  if( event.data.type === 'ide-line-clicked' ){
    const clickedLine = event.data.line + 1

    console.log(`inner line clicked (${clickedLine})`)

    if( clickedLine !== currentLine ){

      console.log('inner line cliked (change current line)', `${currentLine} -> ${clickedLine}`)
      setCurrentLine(clickedLine)
      console.log(`new currentLine after setCurrentLine(${clickedLine}) is ${currentLine}`)
      stepCountdown = STEP_DELAY
    }

  }

})

// get lines from cssString (assigned in _build-html.js)
const cssLines = cssString.split('\n') 



// (milliseconds) system time
let time = Date.now();




// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  if( playing ){
    // compute time elapsed since last frame
    const newTime = Date.now();
    const dt = Math.min(50, newTime - time); // limit to 50 ms in case of lag
    time = newTime;
    stepCountdown = stepCountdown - dt
    if( stepCountdown <= 0 ){
      step()
      window.parent.postMessage({ tab:filename, line: currentLine-1, type: 'ide-highlight-line' }, '*');
      stepCountdown = STEP_DELAY
    }
  }

  if( repaintRequested ){
    repaintRequested = false
    

    if( parser.pseudocodeBullet ){
      const bullet = parser.pseudocodeBullet
      console.log('inner highlight', bullet)
      const selector = `li:has(> .${bullet})`
      window.parent.parent.postMessage({ type: 'workshop-highlight', selector }, '*');
    }

    
    const report = {
      'Line Number': currentLine,
      'Line': cssLines[currentLine-1],
      'Interpretation': parser._parsedLineReport,
      'Before': JSON.stringify(parser._previousBox),
      'After': JSON.stringify(parser._currentBox),
    }


ctx.clearRect(0, 0, canvas.width, canvas.height);

ctx.font = '16px serif';
const dy = 20;
const xCenter = 150;
const yStart = canvas.height - 150;

// Draw each label and value
ctx.fillStyle = 'black';
let i = 0;
for (const [label, value] of Object.entries(report)) {
  const y = yStart + dy * i;

  ctx.textAlign = 'right';
  ctx.fillText(label + ':', xCenter - 5, y);

  ctx.textAlign = 'left';
  ctx.fillText(value, xCenter + 5, y);

  i++;
}

    BoxGraphics.drawBox(ctx, {name: '_default', box: defaultBox })

    for( const [name,box] of Object.entries(parser._parsedBoxes) ){
      BoxGraphics.drawBox(ctx, {name,box})
    }

    if( parser._currentBox ){
      BoxGraphics.drawBox(ctx, {current: true, name: parser._currentBoxName, box: parser._currentBox })
    }

  }



}
requestAnimationFrame(animationLoop); // queue first loop


window.addEventListener('resize', () => window.location.reload() ); 