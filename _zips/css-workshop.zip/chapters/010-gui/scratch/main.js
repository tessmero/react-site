/**
 * @file main.js entry point
 * top-level objects and main loop
 */



// pick screens in screen, one portrait and one landscape
// leaving bottom-left corner open
function maxGoldenRectangles(W, H) {
  const phi = (1 + Math.sqrt(5)) / 2;
  const s1 = Math.min(W / (1 + phi), H / phi);
  const l1 = phi * s1;
  return {
    landscape: { x: [0, l1],  y: [0, s1] },
    portrait: { x: [l1, l1 + s1], y: [0, l1] },
  }
}


// prepare to draw on the canvas element in our html document
const canvas = document.getElementsByTagName('canvas')[0];
canvas.width = innerWidth * devicePixelRatio;
canvas.height = innerHeight * devicePixelRatio;
const ctx = canvas.getContext('2d')


const {landscape,portrait} = maxGoldenRectangles(canvas.width, canvas.height);

// parse css (assigned in _build-html.js)
const cssObj = eval(cssString)
const landscapeBoxes = BoxParser.parseBoxes(landscape, cssObj, {landscape:true});
const portraitBoxes = BoxParser.parseBoxes(portrait, cssObj, {portrait:true});

for (const [name, box] of Object.entries(landscapeBoxes)) {
  BoxGraphics.drawBox(ctx, {name, box});
}
for (const [name, box] of Object.entries(portraitBoxes)) {
  BoxGraphics.drawBox(ctx, {name, box});
}
