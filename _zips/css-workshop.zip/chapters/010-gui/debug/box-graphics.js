/**
 * @file BoxGraphics 2d box graphics
 */
class BoxGraphics {
  
  static drawBox(ctx, params){
    const {name,box,current=false} = params

    const hidden = name.startsWith('_')

    const {x,y} = box
    if( current ){

      // current box - thick green outline
      ctx.strokeStyle = 'green'
      ctx.lineWidth = 3
      ctx.setLineDash([])
    } else if (hidden ){

      // helper box - dashed outline
      ctx.strokeStyle = 'gray'
      ctx.lineWidth = 3
      ctx.setLineDash([5,5])

    } else {

      // regular box - thin black outline 
      ctx.strokeStyle = 'black'
      ctx.lineWidth = 3
      ctx.setLineDash([])
    }

    ctx.strokeRect( x[0], y[0], x[1]-x[0], y[1]-y[0] )

    if( !hidden ){

      // draw box label
      ctx.font = '32px serif';
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle';
      ctx.fillStyle = current ? 'green' : 'black'
      ctx.fillText( name.replace('#',''), (x[0]+x[1])/2, (y[0]+y[1])/2 )

    }
  }
}