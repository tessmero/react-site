
myLayout = {

  _frame: {
    margin: 10,
  },

  titleBar: {
    parent: '_frame',
    height: 50,
    top: 0,
  },

  x: {
    parent: '_frame',
    width: 25,
    height: 25,
    right: 0, 
    top: 0,
  },

  mainPanel: {
    parent: '_frame',
    'width@landscape': '50%',
    left: 0,
    top: 50,
    height: 'auto',
  },

  'extraPanel@landscape': {
    parent: '_frame',
    width: '50%',
    right: 0,
    top: 50,
    height: 'auto',
  },

}