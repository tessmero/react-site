/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const filename = 'content.js'
const parserParams = {
  delimiters: {
    ignoreLinesWith: ['='],
    boxStart: /^(.+?):\s*\{$/, // :{ with whitespace allowed in between
    boxEnd: /}/,
    propertyValue: ':',
    propertyEnd: ',',
  }
}



/**
 * @file pair-main-suffix
 */

// pick screens in screen, one portrait and one landscape
// leaving bottom-left corner open
function maxGoldenRectangles(W, H) {
  const phi = (1 + Math.sqrt(5)) / 2;
  const s1 = Math.min(W / (1 + phi), H / phi);
  const l1 = phi * s1;
  return {
    landscape: { x: [0, l1], y: [0, s1] },
    portrait: { x: [l1, l1 + s1], y: [0, l1] },
  };
}

const STEP_DELAY = 300; // miliseconds per step in autoplay
let stepCountdown = STEP_DELAY; // milliseconds remaining until next step

// prepare to draw on the canvas element in our html document
const canvas = document.getElementsByTagName('canvas')[0];
canvas.width = innerWidth * devicePixelRatio;
canvas.height = innerHeight * devicePixelRatio;
const ctx = canvas.getContext('2d');

const { landscape, portrait } = maxGoldenRectangles(canvas.width, canvas.height);
const allScreens = [
  {
    defaultBox: landscape,
    atParams: { landscape: true },
  },
  {
    defaultBox: portrait,
    atParams: { portrait: true },
  },
];

const mode = 'playing'; // playing or paused
const pad = 20;
const padBottom = 200;
const padSide = 100;
const defaultBox = { x: [padSide, canvas.width - 2 * padSide], y: [pad, canvas.height - pad - padBottom] };
const allParsers = allScreens.map(({ defaultBox, atParams }) => new StringParser(defaultBox, {...parserParams, atParams}));
let currentLine = 0; // line number in css

function htmlElem(tagName, attributes) {
  const { id } = attributes;
  let elem = document.getElementById(id);

  if (!elem) {

    // add new html element
    elem = document.createElement(tagName);
    for (const [key, value] of Object.entries(attributes)) {
      elem.setAttribute(key, value);
    }
    document.getElementById('input-container').appendChild(elem);
  }
  return elem;
}
const playButton = htmlElem('input', {
  id: 'playButton',
  type: 'button',
  value: 'PAUSE',
});
const stepButton = htmlElem('input', {
  id: 'stepButton',
  type: 'button',
  value: 'STEP',
});

let repaintRequested = true;
let playing = true;

function togglePlay() {
  playing = !playing;
  stepCountdown = STEP_DELAY;
  if (playing && currentLine >= cssLines.length) {
    setCurrentLine(0);
  }
  playButton.setAttribute('value', playing ? 'PAUSE' : 'PLAY');
}
playButton.onclick = togglePlay;

function setCurrentLine(lineIndex) {
  for( const parser of allParsers ){
    parser.reset();
  }
  currentLine = 0;
  while (currentLine < lineIndex) {
    const before = currentLine;
    step();
    if (before === currentLine) {
      break; // step not working, prevent infinite loop
    }
  }
  playing = false;
  playButton.setAttribute('value', 'PLAY');
  window.parent.postMessage({
    type: 'ide-highlight-line',
    tab: filename,
    line: currentLine - 1,
  }, '*');
}

function step() {

  for (const parser of allParsers) {
    parser.parseLine(cssLines[currentLine]);
  }
  currentLine = currentLine + 1;

  if (currentLine >= cssLines.length) {
    setCurrentLine(0);
  }
  else {
    repaintRequested = true;
  }
}
stepButton.onclick = () => {
  playing = false;
  step();
  window.parent.postMessage({ tab: filename, line: currentLine - 1, type: 'ide-highlight-line' }, '*');
};

window.addEventListener('message', (event) => {

  if (event.data.type === 'ide-line-clicked') {
    const clickedLine = event.data.line + 1;

    if (clickedLine !== currentLine) {
      setCurrentLine(clickedLine);
      stepCountdown = STEP_DELAY;
    }

  }

});

// get lines from cssString (assigned in _build-html.js)
const cssLines = cssString.split('\n');

// (milliseconds) system time
let time = Date.now();

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  if (playing) {
    // compute time elapsed since last frame
    const newTime = Date.now();
    const dt = Math.min(50, newTime - time); // limit to 50 ms in case of lag
    time = newTime;
    stepCountdown = stepCountdown - dt;
    if (stepCountdown <= 0) {
      step();
      window.parent.postMessage({ tab: filename, line: currentLine - 1, type: 'ide-highlight-line' }, '*');
      stepCountdown = STEP_DELAY;
    }
  }

  if (repaintRequested) {
    repaintRequested = false;

    // highlight pseudocode based on one representative
    const parser = allParsers[0];
    if (parser.pseudocodeBullet) {
      const bullet = parser.pseudocodeBullet;
      const selector = `li:has(> .${bullet})`;
      window.parent.parent.postMessage({ type: 'workshop-highlight', selector }, '*');
    }
    const report = {
      'Line Number': currentLine,
      'Line': cssLines[currentLine - 1],
      'Interpretation': parser._parsedLineReport,
      'Before': JSON.stringify(parser._previousBox),
      'After': JSON.stringify(parser._currentBox),
    };

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.font = '16px serif';
    const dy = 20;
    const xCenter = 150;
    const yStart = canvas.height - 150;

    // Draw each label and value
    ctx.fillStyle = 'black';
    let i = 0;
    for (const [label, value] of Object.entries(report)) {
      const y = yStart + dy * i;

      ctx.textAlign = 'right';
      ctx.fillText(`${label }:`, xCenter - 5, y);

      ctx.textAlign = 'left';
      ctx.fillText(value, xCenter + 5, y);

      i++;
    }

    for (const parser of allParsers) {

      BoxGraphics.drawBox(ctx, { name: '_default', box: parser._defaultBox });

      for (const [name, box] of Object.entries(parser._parsedBoxes)) {
        BoxGraphics.drawBox(ctx, { name, box });
      }

      if (parser._currentBox) {
        BoxGraphics.drawBox(ctx, { current: true, name: parser._currentBoxName, box: parser._currentBox });
      }
    }

  }

}
requestAnimationFrame(animationLoop); // queue first loop


window.addEventListener('resize', () => window.location.reload() ); 
