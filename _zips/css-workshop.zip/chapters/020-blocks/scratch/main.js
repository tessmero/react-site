/**
 * @file main.js entry point
 * top-level objects and main loop
 */







// parse css (assigned in _build-html.js)
const cssObject = eval(cssString)
const defaultBox = {x:[0,100],y:[0,100],z:[0,100]}
BoxParser.flipY() // positive y means up in 3d scene
const parsedBoxes = BoxParser.parseBoxes(defaultBox,cssObject)


BoxGraphics.init()

// (milliseconds) system time
let time = Date.now();

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop


  BoxGraphics.drawScene({ boxes: Object.values(parsedBoxes) });

}
requestAnimationFrame(animationLoop); // queue first loop
