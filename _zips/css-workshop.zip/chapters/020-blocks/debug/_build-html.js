/**
 * @file _build-html.js
 * IDE v0.0.2 (June 2025) eval this and expect a function
 *
 * - parameters are html strings
 * - return value should be an html string
 *
 * For endless-workshop we output the script
 * in a sandbox behind the content.
 *
 * For projects that don't have this file,
 * the default build only includes script (ignores content)
 * with a minimal html->body->canvas.
 */

// 
({ script, content }) => {


  // same as default build
  return `
<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <canvas></canvas>
    <div class="input-container" id="input-container"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.1/three.min.js"></script>
    <script src="https://unpkg.com/three@0.131.2/examples/js/controls/OrbitControls.js"></script>
    <script>
      const cssString = \`${content}\`
    </script>
    ${script}
    <style>


        canvas { border: none; }
        * { margin: 0; padding: 0;}
        body, html { height:100%; overflow: hidden; background-color: #AAA; }
        canvas { position:absolute; left: 0px; top:0px; width:100%; height:100%; background-color:transparent }

      .input-container {
        position: absolute;
        display: flex;
        height: 100%;
      }
      input {
        display: block;
        align-self: flex-start;
        z-index: 2;
        margin: 2px;
      }
    </style>
  </body>
</html>
`;
};
