/**
 * @file BoxParser computes absolute boxes from css rules.
 * Also respects @param=value suffixes added to keys.
 *
 * An absolute box is defined by axis:[min,max] for any applicable axis
 *
 * usage:
 *
 * const myViewport = {x:[0,100], y:[0,100]}
 *
 * BoxParser.parseBoxes{ myViewport,
 *   {myBox: {top:10,left:10,width:50,height:50}},
 * }
 *
 * out:
 * {myBox: {x:[10,60],y:[10,60]}}
 */
class BoxParser {

  /**
   * Axis semantics mapping.
   * For each axis, define the negative extreme, positive extreme, and dimension.
   */


  static AXIS_SEMANTICS = {
    x: { neg: 'left', pos: 'right', dim: 'width' },
    y: { neg: 'top', pos: 'bottom', dim: 'height' }, // default flipped y for 2D canvas
    z: { neg: 'front', pos: 'back', dim: 'depth' },
    time: { neg: 'start', pos: 'end', dim: 'duration' },
  };

  static flipY(){
    if( this._flippedY ){
      return
    }
    this._flippedY = true

    const y = BoxParser.AXIS_SEMANTICS.y
    const temp = y.neg
    y.neg = y.pos
    y.pos = temp
  }


  /**
   * Compute absolute boxes from css rulesets (box-language).
   * @param {object} defaultBox The base starting absolute box
   * @param {object} boxObject The named boxes in box-language
   * @returns {object} named absolute boxes
   */
  static parseBoxes(defaultBox, boxObject, atParams={}) {
    const glp = new BoxParser(defaultBox, boxObject, atParams);
    return glp.#computedBoxes;
  }

  // current parent absolute box set during parsing
  #parent;

  // final parsed absolute boxes
  #computedBoxes = {};

  /**
   * Called in computeRects
   * @param {object} defaultBox The base starting absolute box
   * @param {object} boxObject The named boxes in box-language
   */
  constructor(defaultBox, boxObject, atParams={}) {
    this._atParams = atParams

    // start parsing
    // iterate over rulesets
    for (const [rawKey, cssRuleset] of Object.entries(boxObject)) {

      // check for @param=value condition after box name
      const [boxName, atCondition] = rawKey.split('@');
      if (this._shouldParse(atCondition)) {

        // parse ruleset for one box
        this.#computedBoxes[boxName] = this._computeRect(defaultBox, cssRuleset);
      }
    }
  }

  /**
   * @param  {string} atCondition The suffix after @
   */
  _shouldParse(atCondition) {
    if (!atCondition) {
      return true;
    }

    return this._atParams[atCondition]
  }

  /**
   *
   * @param {number[]} screenRect
   * @param {object} cssRules
   */
  _computeRect(screenRect, cssRules) {

    // use screen rectangle as starting point
    // and default parent to align within
    this.#parent = screenRect;
    let result = screenRect;

    // iterate over rules
    for (const [rawKey, cssVal] of Object.entries(cssRules)) {

      // check for @param=value condition after css key
      const [cssKey, atCondition] = rawKey.split('@')
      if (this._shouldParse(atCondition)) {

        // modify rectangle
        const { currentBox, parentBox } = BoxParser._applyRule({ 
          currentBox: result, parentBox: this.#parent, 
          cssKey, cssVal,
          parsedBoxes: this.#computedBoxes,
        });
        result = currentBox;
        this.#parent = parentBox;
      }
    }

    // return final rectangle
    return result;
  }

  /**
   * Given a key like 'left', 'right', 'width', etc., find the axis and its semantic.
   * Returns { axis, semantic } or null if not found.
   * @param cssKey
   */
  static _parseAxisKey(cssKey) {
    for (const [axis, { neg, pos, dim }] of Object.entries(BoxParser.AXIS_SEMANTICS)) {
      if (cssKey === neg) { return { axis, semantic: 'neg' }; }
      if (cssKey === pos) { return { axis, semantic: 'pos' }; }
      if (cssKey === dim) { return { axis, semantic: 'dim' }; }
      if (cssKey === `max-${neg}`) { return { axis, semantic: 'max-neg' }; }
      if (cssKey === `max-${pos}`) { return { axis, semantic: 'max-pos' }; }
      if (cssKey === `max-${dim}`) { return { axis, semantic: 'max-dim' }; }
    }

    // Support arbitrary axis: cssKey === axis, 'hi-axis', 'dim-axis'
    const hiMatch = cssKey.match(/^!(.+)$/);
    const dimMatch = cssKey.match(/^dim-(.+)$/);
    if (hiMatch) { return { axis: hiMatch[1], semantic: 'pos' }; }
    if (dimMatch) { return { axis: dimMatch[1], semantic: 'dim' }; }

    if (cssKey in BoxParser.AXIS_SEMANTICS) { return { axis: cssKey, semantic: 'neg' }; }

    return { axis: cssKey, semantic: 'neg' };
  }

  /**
   * Abstract box rule application for arbitrary axes.
   * @param {object} rect - {axis: [min, max], ...}
   * @param {string} cssKey
   * @param {number|string} cssVal
   * @param params
   * @returns {object} currentBox and parentBox
   */
  static _applyRule(params) {

    const {
      currentBox,
      parentBox,
      parsedBoxes,
      cssKey, cssVal,
    } = params;

    const rect = currentBox;
    const p = parentBox;

    if (cssKey === 'parent') {
      const newp = parsedBoxes[cssVal];
      if (!newp) { throw new Error(`parent css not defined: ${cssVal}`); }
      return { currentBox: JSON.parse(JSON.stringify(newp)), parentBox: newp };
    }

    // Clone box
    const r = {};
    for (const k in rect) { r[k] = [rect[k][0], rect[k][1]]; }

    if( cssKey === 'margin' ){
      const marginAxis = Object.keys(r)[0]
      const marginDist = BoxParser._parseDistanceVal({ currentBox: r, parentBox: p, axis: marginAxis, cssVal });
      for( const axis of Object.keys(r) ){
        const [min,max] = r[axis]
        r[axis] = [min+marginDist,max-marginDist]
      }
      return { currentBox: r, parentBox: p };
    }

    const axisInfo = BoxParser._parseAxisKey(cssKey);
    if (!axisInfo) { return r; } // Unknown key, no change

    const { axis, semantic } = axisInfo;
    const d = BoxParser._parseDistanceVal({ currentBox: r, parentBox: p, axis, cssVal, semantic });

    // If axis is missing, initialize from parent or zero
    if (!(axis in r)) {
      r[axis] = p && p[axis] ? [p[axis][0], p[axis][1]] : [0, 0];
    }
    if (p && !(axis in p)) {
      p[axis] = [0, 0];
    }

    const min = r[axis][0]; const max = r[axis][1];
    const pmin = p ? p[axis][0] : 0; const pmax = p ? p[axis][1] : 0;
    const size = max - min;
    const psize = pmax - pmin;

    switch (semantic) {
    case 'neg': // left/top/front/start/axis
      r[axis] = [pmin + d, pmin + d + size];
      break;
    case 'max-neg':
      r[axis] = [Math.min(pmin + d, min), max];
      break;
    case 'pos': // right/bottom/back/end/hi-axis
      r[axis] = [pmax - size - d, pmax - d];
      break;
    case 'max-pos':
      {
        const curExtreme = pmax - max;
        if (curExtreme < d) {
          // no change
        }
        else {
          r[axis] = [pmax - size - d, pmax - d];
        }
      }
      break;
    case 'dim': // width/height/depth/duration/dim-axis
      r[axis] = [min, min + d];
      break;
    case 'max-dim':
      r[axis] = [min, min + Math.min(d, size)];
      break;
    default:
      // no change
      break;
    }
    return { currentBox: r, parentBox: p };
  }

  /**
   * Compute absolute distance represented by a css value.
   * @param params
   */
  static _parseDistanceVal(params) {

    const { parentBox: p, currentBox: r, axis, semantic } = params;

    let {cssVal} = params;

    if( typeof cssVal === 'number' ){
      return cssVal
    }

    if( cssVal.endsWith('%') ){

      // compute percentage of parent width or height
      const mul = parseFloat(cssVal.slice(0, -1)) / 100;
      const [min, max] = p[axis];
      const pctResult = (max - min) * mul;
      return pctResult
    }


    if( cssVal === 'auto' ){
      if (semantic === 'dim') {
        // pick new width or height to align with bottom or right of parent
        return p[axis][1] - r[axis][0];
      }

      // assume key is 'top' or 'left'
      // pick distance to center inside parent
      return (p[axis][1]-p[axis][0]) / 2 - (r[axis][1]-r[axis][0]) / 2;
    }

    let test = parseFloat(cssVal);
    if (!isNaN(test)) {
      cssVal = test;
    }

    if (typeof(cssVal) === 'string') {
    
      if( cssVal.endsWith('px') ){
        return parseFloat(cssVal.slice(0,-2))
      }

      throw new Error('css distance value must be number, auto, or percentage');
    }

    // not a string
    return cssVal;
  }
}
