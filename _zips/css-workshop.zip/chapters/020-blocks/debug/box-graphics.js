/**
 * @file three.js marbles and boxes BoxGraphics
 */

const GFX_MAX_BOXES = 10

/**
 *
 */
class BoxGraphics {

  static _meshes = {


    boxes: {
      count: ({ boxes }) => boxes.length,
      geometry: new THREE.BoxGeometry(),
      material: BoxGraphics._m('MeshLambertMaterial',{alpha:.5}),
    },
  };

  static _getDistinctPaleColors(amount) {
  const colors = [];
  const saturation = 0.8; 
  const lightness = 0.5; 

  for (let i = 0; i < amount; i++) {
    const hue = i / amount; // Evenly spaced hues in [0,1]
    const color = new THREE.Color();
    color.setHSL(hue, saturation, lightness); // [page:Float h], [page:Float s], [page:Float l][1]
    colors.push(color);
  }
  return colors;
}

  /**
   *
   * @param physObjects
   */
  static _initInstancedMeshes() {
    const im = {};

    const dummy = new THREE.Object3D();
    dummy.scale.set(0, 0, 0);
    dummy.updateMatrix();

    const paleColors = BoxGraphics._getDistinctPaleColors(5);


    for (const [name, params] of Object.entries(BoxGraphics._meshes)) {
      const { count, geometry, material } = params;
      const n = GFX_MAX_BOXES;
      const mesh = new THREE.InstancedMesh(geometry, material, n);
      mesh.instanceColor = new THREE.InstancedBufferAttribute(
        new Float32Array(n * 3), 3
      );
      for( let i = 0 ; i < n ; i++ ){
        const {r,g,b} = paleColors[i%paleColors.length]
        mesh.instanceColor.setXYZ(
          i,r,g,b
        );
        mesh.setMatrixAt(i, dummy.matrix); // make invisible initially 
      }
      BoxGraphics.scene.add(mesh);
      im[name] = mesh;
    }
    BoxGraphics._instancedMeshes = im;
    return im;
  }

  static resetCamera(){

    const {camera,controls} = BoxGraphics
    if( camera) {
      camera.position.set(...this._camStartPos);
      camera.lookAt(50, 50, 50);
    }

    if( controls ){
      controls.target.set(50, 50, 50);
      controls.update();
    }
  }

  /**
   *
   * @param sceneParams
   */
  static init(sceneParams) {
    const canvas = document.getElementsByTagName('canvas')[0];
    BoxGraphics.canvas = canvas



    // always build new scene
    const scene = new THREE.Scene();
    BoxGraphics.scene = scene;

    let camera = BoxGraphics.camera;
    if (!camera) {

      // start one-time camera setup
      camera = new THREE.PerspectiveCamera(
        30, // FOV in degrees
        window.innerWidth / window.innerHeight, // aspect ratio
        0.1, // near
        10000, // far
      );

      const camScale = 15;
      this._camStartPos = [10 * camScale, 12 * camScale, 14 * camScale]
      camera.position.set(...this._camStartPos);
      camera.lookAt(50, 50, 50);

      BoxGraphics.camera = camera; // finished one-time setup
    }

    // light everything
    scene.add(new THREE.AmbientLight(0xffffff, 1));

    // light from one direction
    scene.add(BoxGraphics._l({
      color: 0xffffff,
      intensity: 2,
      position: [-500, 1000, 750],
      target: [50, 50, 50],
    }));

    // light from one direction
    scene.add(BoxGraphics._l({
      color: 0xffffff,
      intensity: 1,
      position: [-250, 500, -750],
      target: [50, 50, 50],
    }));

    let renderer = BoxGraphics.renderer
    if( !renderer ){

      // start one-time renderer setup
      const renderer = new THREE.WebGLRenderer({ alpha: true, canvas });
      function updateScreenShape() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
      }
      window.addEventListener('resize', updateScreenShape); // update when necessary
      updateScreenShape() // update now

      const controls = new THREE.OrbitControls(camera, renderer.domElement);
      BoxGraphics.controls = controls
      controls.enableZoom = false;
      controls.target.set(50, 50, 50);
      controls.update();


      BoxGraphics.renderer = renderer // finished one-time setup



    }

    const im = this._initInstancedMeshes();




  }

  /**
   * @param params
   */
  static drawScene(params) {

    BoxGraphics.updateBoxPositions(params);

    const { renderer, scene, camera } = BoxGraphics;
    console.log('cam', camera.position)

    // fix objects popping in and out
    for (const mesh of Object.values(BoxGraphics._instancedMeshes)) {
      mesh.frustumCulled = false;
    }

    renderer.render(scene, camera);

  }

  /**
   *
   * @param sphereMesh.boxes
   */
  static updateBoxPositions({ boxes }={}) {
    if( !boxes ){
      return
    }
    
    const im = BoxGraphics._instancedMeshes;
    const dummy = new THREE.Object3D();

    let imIndex = 0
    for (const box of boxes) {

      // position mesh for box
      dummy.scale.set(...BoxGraphics.getScale(box));
      dummy.position.set(...BoxGraphics.getCenter(box));
      dummy.updateMatrix();
      im.boxes.setMatrixAt(imIndex++, dummy.matrix);
    }

    // clear non-specified boxes
    dummy.scale.set(0,0,0)
    dummy.updateMatrix();
    while( imIndex < GFX_MAX_BOXES ){
      im.boxes.setMatrixAt(imIndex++, dummy.matrix)
    }

    im.boxes.instanceMatrix.needsUpdate = true;

  }

  static getScale(box){
    return (['x','y','z']).map( (ax) => box[ax][1]-box[ax][0] )
  }

  static getCenter(box){
    return (['x','y','z']).map( (ax) => (box[ax][0]+box[ax][1])/2 )
  }

  /**
   *
   * @param type
   * @param params
   */
  static _m(type, params = {}) {
    const Clazz = THREE[type];
    const result = new Clazz(params);

    // handle params that don't work in constructor
    const { opacity = 1 } = params;
    result.opacity = opacity;
    if (opacity < 1) {
      result.transparent = true;
    }

    return result;
  }

  /**
   *
   * @param params
   */
  static _l(params = {}) {

    const { color = 0xffffff, intensity = 3, position, target } = params;

    const type = position ? 'DirectionalLight' : 'AmbientLight';
    const Clazz = THREE[type];
    const result = new Clazz(color, intensity);

    if (position) {
      result.position.set(...position);
    }

    if (target) {
      const dummy = new THREE.Object3D();
      dummy.position.set(...target);
      result.target = dummy;
    }

    return result;
  }

}
