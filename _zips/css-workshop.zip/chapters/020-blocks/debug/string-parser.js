/**
 * @file StringParser
 * like box parser for alternate syntaxes
 */
class StringParser {

  reset(){

    this._parsedLineReport = null
    this._previousBox = null
    this._currentBox = null

    this._parsedBoxes = {}

    console.log('reset parser', JSON.stringify(this._defaultBox))
  }

  constructor(defaultBox, params={}){
    this._defaultBox = defaultBox
    this.reset()


    // Delimiters for flat CSS
    const {
      delimiters = {
        boxStart: /^(.+)\{$/,
        boxEnd: /}/,
        propertyValue: ':',
        propertyEnd: ';',
      },
      ignores = [],
      atParams = {},
    } = params;
    this.delimiters = delimiters
    this.ignores = ignores
    this._atParams = atParams;
  }

  _shouldParse(condition){
    if( !condition ){
      return true
    }
    return this._atParams[condition]
  }

  _highlightInWorkshop(bullet){
    this.pseudocodeBullet = bullet
  }

  /**
   * Tokenizes a single line of flat CSS.
   * Returns an object describing the line type and its parts.
   */
  parseLine(line) {
      this._parsedLineReport = `ignored`

    this._previousBox = this._currentBox

    if(!line){
      return false;
    }

    const {boxStart,boxEnd,propertyValue,propertyEnd} = this.delimiters

    // Trim whitespace
    const trimmed = line.trim();

    if( this.ignores.some((regexp) => trimmed.match(regexp))) {
      return false;
    }

    // Ignore empty lines
    if (!trimmed) return false; // do not halt for debugger

    // Ignore skipped-box properties
    if( this._skippingBox ){
      if (trimmed.match(boxEnd)) { // Box end: e.g., "}"

        // finished skipping
        this._skippingBox = false
        this._parsedLineReport = 'finished skipping box with false @param'
        this._highlightInWorkshop('box-lpc-end-box')
        return true; // halt for debugger
      }

      // still skipping
      return false; // do not halt for debugger
    }


    // Box start: e.g., "#myBox {"
    const boxStartMatch = trimmed.match(boxStart);
    if (boxStartMatch) {
      const quotedKey = boxStartMatch[1].trim()
      const rawKey = quotedKey.replace(/^['"]+|['"]+$/g, '');
      this._highlightInWorkshop('box-lpc-box-name')

      // check for @param=value condition after box name
      const [boxName, atCondition] = rawKey.split('@');

      if( this._shouldParse(atCondition) ){
        this._currentBoxName = boxName
        this._currentBox = JSON.parse(JSON.stringify(this._defaultBox))
        this._highlightInWorkshop('box-lpc-new-box')
        this._parsedLineReport = `start new box with selector ${rawKey}`
        return true; // halt for debugger
      } else {
        this._skippingBox = true // start skipping until end of box
        this._highlightInWorkshop('box-lpc-skip-box')
        this._parsedLineReport = `start skipping box with false @param`
        return false; // do not halt for debugger
      }
    }

    // Box end: e.g., "}"
    if (this._currentBox && trimmed.match(boxEnd)) {
      this._highlightInWorkshop('box-lpc-end-box')
      this._parsedLineReport = `end of box ${this._currentBoxName}`
      this._parsedBoxes[this._currentBoxName] = this._currentBox
      this._currentBox = null // prevent further changes
      return true; // do halt for debugger
    }

    // Property line: e.g., "left: 10px;"
    if (trimmed.includes(propertyValue)) {

      const propLine = trimmed.endsWith(propertyEnd) ? trimmed.slice(0, -propertyEnd.length) : trimmed; // remove trailing ';'
      const [quotedKey, quotedCssVal] = propLine.split(propertyValue).map(s => s.trim());
      const rawKey = quotedKey.replace(/^['"]+|['"]+$/g, '');
      const cssVal = quotedCssVal.replace(/^['"]+|['"]+$/g, '');
      this._parsedLineReport = `Property with key "${rawKey}" and value "${cssVal}"`

      const [cssKey,atCondition] = rawKey.split('@')
      if( this._shouldParse(atCondition) ){

        if( cssKey === 'parent' ){

          this._highlightInWorkshop('box-lpc-prop-parent')
          this._parentBox = this._parsedBoxes[cssVal]
          this._currentBox = JSON.parse(JSON.stringify(this._parentBox))

        } else {

          // regular css property
          this._highlightInWorkshop('box-lpc-prop-css')
          const {currentBox,parentBox} = BoxParser._applyRule({
            currentBox:this._currentBox, 
            parentBox:this._parentBox || this._defaultBox, 
            parsedBoxes: this._parsedBoxes,
            cssKey,cssVal })
          this._currentBox = currentBox
          this._parentBox = parentBox
          return true; // do halt for debugger
        }
      } else {

        // property has false @condition
        this._highlightInWorkshop('box-lpc-skip-prop')
        return true; // do halt for debugger
      }

      return true; // do halt for debugger
    }

    // Unrecognized line
    this._highlightInWorkshop('box-lpc-unrecognized')
    return false; // do not halt
  }
}