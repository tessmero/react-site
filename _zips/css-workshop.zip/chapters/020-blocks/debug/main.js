/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const filename = 'content.js'
const parserParams = {
  delimiters: {
    ignoreLinesWith: ['='],
    boxStart: /^(.+?):\s*\{$/, // :{ with whitespace allowed in between
    boxEnd: /}/,
    propertyValue: ':',
    propertyEnd: ',',
  }
}






const STEP_DELAY = 300 // miliseconds per step in autoplay
let stepCountdown = STEP_DELAY // milliseconds remaining until next step

let mode = 'playing' // playing or paused
const defaultBox = {x:[0,100],y:[0,100],z:[0,100]}
BoxParser.flipY() // positive y means up in 3d scene
const parser = new StringParser(defaultBox,parserParams)
let currentLine = 0 // line number in css


function htmlElem(tagName, attributes) {
  const { id } = attributes;
  let elem = document.getElementById(id);

  if (!elem) {

    // add new html element
    elem = document.createElement(tagName);
    for (const [key, value] of Object.entries(attributes)) {
      elem.setAttribute(key, value);
    }
    document.getElementById('input-container').appendChild(elem);
  }
  return elem;
}
const playButton = htmlElem('input', {
  id: 'playButton',
  type: 'button',
  value: 'PAUSE',
});
const stepButton = htmlElem('input', {
  id: 'stepButton',
  type: 'button',
  value: 'STEP',
});

let boxUpdateRequested = true
let repaintRequested = true
let playing = true

function togglePlay(){ 
  playing = !playing
  stepCountdown = STEP_DELAY
  if( playing && currentLine >= cssLines.length ){
    setCurrentLine(0)
  }
  playButton.setAttribute('value', playing ? 'PAUSE' : 'PLAY' )
}
playButton.onclick = togglePlay;
    
function setCurrentLine(lineIndex){
  BoxGraphics.resetCamera()
  parser.reset()
  currentLine = 0
  while( currentLine < lineIndex ){
    const before = currentLine
    step()
    if( before === currentLine ){
      break // step not working, prevent infinite loop
    }
  }
  playing = false
  playButton.setAttribute('value', 'PLAY' )
  window.parent.postMessage({ 
    type: 'ide-highlight-line',
    tab:filename, 
    line: currentLine-1, 
  }, '*');
}

function step(){
  parser.parseLine(cssLines[currentLine])
  currentLine = currentLine + 1

  if (currentLine >= cssLines.length) {
    setCurrentLine(0);
  }
  else {
    boxUpdateRequested = true;
  }
}
stepButton.onclick = () => {
  playing = false;
  step();
  window.parent.postMessage({ tab: filename, line: currentLine - 1, type: 'ide-highlight-line' }, '*');
};

window.addEventListener('message', function(event) {

  if( event.data.type === 'ide-line-clicked' ){
    const clickedLine = event.data.line + 1

    if( clickedLine !== currentLine ){

      setCurrentLine(clickedLine)
      stepCountdown = STEP_DELAY
    }

  }

})

// get lines from cssString (assigned in _build-html.js)
const cssLines = cssString.split('\n') 



// (milliseconds) system time
let time = Date.now();

BoxGraphics.init()

// queue repaint when orbit controls are dragged
if( BoxGraphics.controls )
  BoxGraphics.controls.addEventListener('change', () => {repaintRequested = true});

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  if( playing ){
    // compute time elapsed since last frame
    const newTime = Date.now();
    const dt = Math.min(50, newTime - time); // limit to 50 ms in case of lag
    time = newTime;
    stepCountdown = stepCountdown - dt
    if( stepCountdown <= 0 ){
      step()
      window.parent.postMessage({ tab:filename, line: currentLine-1, type: 'ide-highlight-line' }, '*');
      stepCountdown = STEP_DELAY
    }
  }

  if( boxUpdateRequested  || repaintRequested){
    if( boxUpdateRequested ){

    BoxGraphics.drawScene({ boxes: Object.values(parser._parsedBoxes) });
  } else {

    // draw without changing boxes
    BoxGraphics.drawScene();
  }
    boxUpdateRequested = false;
    repaintRequested = false;
  }
}
requestAnimationFrame(animationLoop); // queue first loop

