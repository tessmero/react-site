
myObject = {

  floor: {
    width: 100,
    depth: 100,
    height: 10,
    left: 'auto',
    front: 'auto',
    bottom: 0,
  },

  block: {
    parent: 'floor',
    width: 40,
    height: 40,
    depth: 40,

    left: 'auto',
    front: 'auto',
    bottom: '100%',
  },

  child: {
    parent: 'block',
    width: '50%',
    height: '50%',
    depth: '50%',

    left: 'auto',
    front: 'auto',
    bottom: '100%',
  },

  grandChild: {
    parent: 'child',
    width: '50%',
    height: '50%',
    depth: '50%',

    left: 'auto',
    front: 'auto',
    bottom: '100%',
  },

}