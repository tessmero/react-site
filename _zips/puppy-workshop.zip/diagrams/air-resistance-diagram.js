/**
 * @file rest diagram
 * ball coming to rest, involving "restitution"
 */

let rand;

/* eslint-disable */
//https://stackoverflow.com/a/47593316
function cyrb128(str) {
  let h1 = 1779033703; let h2 = 3144134277;
  let h3 = 1013904242; let h4 = 2773480762;
  for (let i = 0, k; i < str.length; i++) {
    k = str.charCodeAt(i);
    h1 = h2 ^ Math.imul(h1 ^ k, 597399067);
    h2 = h3 ^ Math.imul(h2 ^ k, 2869860233);
    h3 = h4 ^ Math.imul(h3 ^ k, 951274213);
    h4 = h1 ^ Math.imul(h4 ^ k, 2716044179);
  }
  h1 = Math.imul(h3 ^ (h1 >>> 18), 597399067);
  h2 = Math.imul(h4 ^ (h2 >>> 22), 2869860233);
  h3 = Math.imul(h1 ^ (h3 >>> 17), 951274213);
  h4 = Math.imul(h2 ^ (h4 >>> 19), 2716044179);
  return [(h1 ^ h2 ^ h3 ^ h4) >>> 0, (h2 ^ h1) >>> 0, (h3 ^ h1) >>> 0, (h4 ^ h1) >>> 0];
}

function sfc32(a, b, c, d) {
  return function() {
    a = a >>> 0; b = b >>> 0; c = c >>> 0; d = d >>> 0;
    let t = (a + b) | 0;
    a = b ^ b >>> 9;
    b = c + (c << 3) | 0;
    c = (c << 21 | c >>> 11);
    d = d + 1 | 0;
    t = t + d | 0;
    c = c + t | 0;
    return (t >>> 0) / 4294967296;
  };
}
/* eslint-enable */

function randomString(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result = result + characters.charAt(Math.floor(Math.random() * charactersLength));
    counter = counter + 1;
  }
  return result;
}

const randomSeed = cyrb128(randomString(10));

/**
 *
 */
function resetRand() {
  rand = sfc32(...randomSeed);
}

/**
 *
 * @param {number} min
 * @param {number} max
 */
function randRange(min, max) {
  return min + rand() * (max - min);
}

/**
 * @param {object[]} options
 */
function randChoice(options) {
  return options[Math.floor(rand() * options.length)];
}

/**
 *
 */
class AirResistanceDiagram extends Diagram {

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    this.floorY = 0.85 * this.height;
    this.startPos = { x: this.width / 4, y: this.floorY };
    this.acc = { x: 0, y: 1 };
    const target = { x: this.width / 2, y: 10 * this.height / 300 };
    this.startVel = this._initVel(this.startPos, target, this.acc);
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    const relX = 1 - this.relX;

    const params = {
      airFriction: relX * 1e-1,
    };

    ctx.fillStyle = 'blue';
    const trajRad = this.trajRad;
    for (const { x, y } of this._trajectory(params)) {
      ctx.fillRect(x - trajRad, y - trajRad, 2 * trajRad, 2 * trajRad);
    }

    // ctx.fillStyle = 'red';
    ctx.fillStyle = 'rgba(255,100,100,.2)';
    const size = trajRad * 4;
    resetRand();
    for (const { x, y } of this._air(params)) {
      ctx.fillRect(x - size / 2, y - size / 2, size, size);
    }

    this.bottomText(`${Math.round(params.airFriction * 100)}% AIR RESISTANCE`);

    this.launcher(ctx, { center: this.startPos, angle: VectorMath.getAngle(this.startVel) });

  }

  /**
   *
   * @param {object} params
   */
  * _air(params) {
    const { airFriction } = params;

    const n = Math.floor(2e-1 * airFriction * this.width * this.height / devicePixelRatio / devicePixelRatio);
    for (let i = 0; i < n; i++) {
      yield {
        x: this.width * rand(),
        y: this.floorY * rand(),
      };
    }
  }

  /**
   *
   * @param {object} params
   */
  * _trajectory(params) {
    let pos = this.startPos;
    let vel = this.startVel;
    const acc = this.acc;
    const { airFriction } = params;

    const maxSteps = 1000;
    for (let i = 0; i < maxSteps; i++) {
      pos = VectorMath.add(pos, vel);
      vel = VectorMath.add(vel, acc);
      vel = VectorMath.multiply(vel, 1 - airFriction);
      if (pos.y > this.floorY) {
        return;
      }
      if (pos.x > this.width) {
        return;
      }
      yield pos;
    }
  }

  /**
   *
   * @param {Vector} pos
   * @param {Vector} target
   * @param {Vector} acc
   */
  _initVel(pos, target, acc) {
    const g = acc.y;
    const v0y = Math.sqrt(Math.abs(2 * g * (target.y - pos.y)));
    const t_apex = v0y / g;
    const dx = target.x - pos.x;
    const v0x = dx / t_apex;
    return { x: v0x, y: -v0y };
  }
}

new AirResistanceDiagram().setup();
