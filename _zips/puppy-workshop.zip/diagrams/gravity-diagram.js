/**
 * @file gravity diagram
 */

/**
 *
 */
class GravityDiagram extends Diagram {

  /**
   *
   */
  _defaultMousePos() {
    return { x: this.width / 2 - 65, y: 0 };
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {
    this.startPos = { x: this.width / 4, y: this.height - 10 };

    const delta = VectorMath.subtract(this.mousePos, this.startPos);
    const angle = VectorMath.getAngle(delta);

    // const distance = VectorMath.getLength(delta);
    const trajectory = this._trajectory({ angle });

    let i = 0;
    let alpha = -0.4;
    const trajRad = this.trajRad;
    for (const center of trajectory) {
      ctx.fillStyle = 'blue';
      ctx.fillRect(center.x - trajRad, center.y - trajRad, 2 * trajRad, 2 * trajRad);

      if ((i++) % 4 === 0) {
        alpha = alpha + 0.2;

        if (alpha > 0 && alpha <= 1) {
          this.circle(ctx, {
            center,
            radius: 0.1 * this.height,
            fillStyle: `rgba(100,100,255,${alpha / 5})`,
            strokeStyle: `rgba(0,0,255,${alpha})`,
            lineWidth: 2,
            showRadiusLine: false,
          });

          const arrowStart = VectorMath.add(center, { x: 0, y: 0.1 * this.height });
          const arrowEnd = VectorMath.add(arrowStart, { x: 0, y: 0.1 * this.height });
          this.arrow(ctx, {
            vertices: [arrowStart, arrowEnd],
            strokeStyle: 'red',
            lineWidth: 4,
          });
        }
      }
    }

    this._drawLauncher(ctx, angle);

    // this.bottomText('l')
  }

  /**
   *
   * @param {object} ctx
   * @param {number} rawAngle
   */
  _drawLauncher(ctx, rawAngle) {
    const angle = rawAngle;// + Math.PI

    const da = VectorMath.polarToCartesian(angle, this.rad);
    const start = this.startPos;
    const end = VectorMath.add(this.startPos, da);

    this.path(ctx, {
      vertices: [start, end],
      strokeStyle: 'red',
      lineWidth: 2,
      lineDash: [5, 10],
    });

    this.launcher(ctx, {
      center: start,
      angle,
    });
  }

  /**
   *
   * @param {object} params
   */
  * _trajectory(params) {

    const scale = this.height / 200;
    const { angle, speed = 20 * scale } = params;

    let pos = this.startPos;
    let vel = VectorMath.polarToCartesian(angle, speed);
    const acc = { x: 0, y: 1 * scale };

    const maxSteps = 100;
    for (let i = 0; i < maxSteps; i++) {
      pos = VectorMath.add(pos, vel);
      vel = VectorMath.add(vel, acc);
      if (pos.y > this.height) {
        return;
      }
      if (pos.x > this.width) {
        return;
      }
      yield pos;
    }
  }
}

new GravityDiagram().setup();
