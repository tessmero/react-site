/**
 * @file damping diagram
 */
class DampingDiagram extends Diagram {

  // _defaultMousePos() {
  //   return { x: this.width / 4, y: 0 };
  // }

  /**
   *
   * @param ctx
   */
  _draw(ctx) {

    const m = this.width / 2 * devicePixelRatio; // mass (m)
    const k = 1; // spring constant (k)
    const criticalDamping = 2 * Math.sqrt(m * k);

    const relX = Math.min(0.99, Math.pow(1 - this.relX, 5e0));
    const damping = criticalDamping * relX;

    // compute spring length over time
    const plot = [...this._computeDampedSpringPoints(
      1, // Initial amplitude (A0)
      damping, // Damping coefficient (b)
      m, // Mass (m)
      k, // Spring constant (k)
      0, // Phase angle (phi)
      this.width, // Time steps
    )];

    // plot spring length over time

    ctx.fillStyle = 'blue';
    const trajRad = this.trajRad;
    for (const { x, y } of plot) {
      ctx.fillRect(x - trajRad, y - trajRad, 2 * trajRad, 2 * trajRad);
    }

    // this.path(ctx,{
    //   vertices: plot,
    //   closed: false,
    //   lineWidth: 2,
    //   strokeStyle: 'blue',
    // })

    // plot horizontal line at rest length
    this.path(ctx, {
      vertices: [{ x: 0, y: this.height / 2 }, { x: this.width, y: this.height / 2 }],
      strokeStyle: 'blue',
      lineWidth: 1,
      lineDash: [5, 10],
    });

    // draw springs
    const dx = 0.2 * this.height;
    const springX = [-2, -1, 0, 1, 2];
    const springAlpha = [0.1, 0.2, 0.3, 0.5, 1];
    for (let i = 0; i < springX.length; i++) {
      const alpha = springAlpha[i];
      const { x, y } = plot.find((point) => point.x >= (this.width / 2 + springX[i] * dx));

      // draw disk at end of spring
      this.circle(ctx, {
        center: { x, y },
        radius: 0.1 * this.height,
        fillStyle: `rgba(100,100,255,${alpha / 5})`,
        strokeStyle: `rgba(0,0,255,${alpha})`,
        lineWidth: 2,
        showRadiusLine: false,
      });

      // draw spring
      this.spring(ctx, {
        start: { x, y: -0.1 * this.height },
        end: { x, y },
        radius: 0.04 * this.height, n: 9, pad: 0.08 * this.height, // control zig-zag shape
        strokeStyle: `rgba(255,0,0,${alpha})`,
      });

      // // draw line
      // this.path(ctx,{
      //   vertices: [{x,y:0},{x,y}],
      //   closed: false,
      //   strokeStyle: `rgba(0,0,255,${alpha})`,
      //   lineWidth: 2,
      // })
    }

    this.bottomText(`${Math.round(100 * relX)}% DAMPING`);

  }

  /**
   *
   * @param A0
   * @param b
   * @param m
   * @param k
   * @param phi
   * @param timeSteps
   */
  * _computeDampedSpringPoints(A0, b, m, k, phi, timeSteps) {
    const omega = Math.sqrt(k / m - Math.pow(b / (2 * m), 2)); // Angular frequency [4][7]

    for (let t = 0; t <= timeSteps; t = t + 10) {
      const decay = A0 * Math.exp(-b / (2 * m) * t); // Exponential decay envelope [4][8]
      const oscillation = Math.cos(omega * t + phi); // Oscillation component [6][7]
      yield { x: t * this.width / timeSteps, y: this.center.y * (1 + 0.5 * decay * oscillation) };
    }
  }

}

new DampingDiagram().setup();
