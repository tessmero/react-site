/**
 * @file restitution diagram
 */
class RestitutionDiagram extends Diagram {

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    this.floorY = 0.85 * this.height;
    this.startPos = { x: 30, y: this.floorY };
    this.acc = { x: 0, y: 1 };
    const target = { x: this.height / 2, y: 10 };
    this.startVel = this._initVel(this.startPos, target, this.acc);
  }

  /**
   *
   * @param {Vector} pos
   * @param {Vector} target
   * @param {Vector} acc
   */
  _initVel(pos, target, acc) {
    const g = acc.y;
    const v0y = Math.sqrt(Math.abs(2 * g * (target.y - pos.y)));
    const t_apex = v0y / g;
    const dx = target.x - pos.x;
    const v0x = dx / t_apex;
    return { x: v0x, y: -v0y };
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    const restitution = VectorMath.avg(0.7, 1, this.relX);

    ctx.fillStyle = 'blue';
    ctx.strokeStyle = 'blue';
    ctx.lineWidth = 2;

    const vel = this.startVel;

    const parabolas = this._getBouncingParabolas(20, vel.x, -vel.y, this.acc.y, restitution);

    const trajRad = this.trajRad;

    let x = 0;
    for (const parab of parabolas) {

      // // draw horizontal line at peak
      // const {maxHeight,start,end}  = parab
      // const peakX = this.startPos.x+VectorMath.avg( start.x, end.x )
      // const peakY = this.startPos.y-maxHeight
      // ctx.beginPath()
      // ctx.moveTo( peakX-50, peakY )
      // ctx.lineTo( peakX+50, peakY )
      // ctx.stroke()

      for (const point of this._getParabolaPoints(parab)) {
        x = this.startPos.x + point.x - trajRad;
        ctx.fillRect(
          x,
          this.startPos.y - point.y - trajRad,
          2 * trajRad, 2 * trajRad);
      }
    }

    if (x < this.width) {
      ctx.fillRect(x, this.startPos.y - trajRad, this.width - x, 2 * trajRad);
    }

    // let desc = 'MED'
    // if( relX < .3 ){
    //   desc = 'LOW'
    // } else if (relX > .7 ){
    //   desc = 'HI'
    // }
    // this.bottomText( `${desc} RESTITUTION` )

    this.bottomText(`${Math.round(100 * restitution)}% RESTITUTION`);

    this.launcher(ctx, { center: this.startPos, angle: VectorMath.getAngle(this.startVel) });

  }

  /**
   *
   * @param {number} n
   * @param {number} vx
   * @param {number} vy
   * @param {number} g
   * @param {number} restitution
   */
  _getBouncingParabolas(n, vx, vy, g, restitution) {
    const parabolas = [];
    let x0 = 0;
    const currVx = vx;
    let currVy = vy;

    for (let i = 0; i < n; i++) {
      if (x0 > this.width) {
        break;
      }

      // Time to hit the ground: y(t) = y0 + vy*t - 0.5*g*t^2 = 0
      // Solve quadratic: 0 = y0 + currVy*t - 0.5*g*t^2
      // t = [currVy + sqrt(currVy^2 + 2*g*y0)] / g
      const discriminant = currVy * currVy;
      const t_flight = (currVy + Math.sqrt(discriminant)) / g;

      // Maximum height: y0 + (currVy^2)/(2*g)
      const maxHeight = (currVy * currVy) / (2 * g);

      if (maxHeight < 0.5) {
        break;
      }

      // Horizontal distance: x0 + currVx * t_flight
      const x1 = x0 + currVx * t_flight;

      parabolas.push({
        g,
        bounce: i + 1,
        start: { x: x0, y: 0 },
        vx: currVx,
        vy: currVy,
        t_flight,
        maxHeight,
        end: { x: x1, y: 0 },
      });

      // Update for next bounce
      x0 = x1;
      currVy = currVy * restitution;
    }

    return parabolas;
  }

  /**
   *
   * @param {object} parabola
   */
  * _getParabolaPoints(parabola) {
    const { start, vx, vy, g, t_flight } = parabola;
    const { x, y } = start;

    for (let t = 0; t < t_flight; t = t + 1) {
      yield {
        x: x + vx * t,
        y: y + vy * t - 0.5 * g * t * t,
      };
    }
  }
}

new RestitutionDiagram().setup();
