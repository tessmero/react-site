/**
 * @file CollisionDiagram
 */
class CollisionDiagram extends Diagram {

  /**
   *
   */
  _defaultMousePos() {
    const { center, height } = this;
    return VectorMath.add(center, { x: -height / 2, y: 0 });
  }

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    const { center, height } = this;

    // build obstacle
    const { vertices } = VectorMath.parseVertices({
      center, // this.add(center,{x:height/4,y:0}),
      radius: height / 2.5,
      n: 5,
      angle: -Math.PI / 2,
    });
    this.vertices = vertices;
    this.segments = [];

    // process line segments
    for (let i = 0; i < vertices.length; i++) {
      const start = vertices[i];
      const end = vertices[(i + 1) % vertices.length];
      const delta = VectorMath.subtract(end, start);
      const angle = VectorMath.getAngle(delta);
      const lengthSquared = VectorMath.getLengthSquared(delta);
      this.segments.push({
        start, end, delta,
        angle, lengthSquared,
      });
    }
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    const disk = {
      position: this.mousePos,
      radius: this.height / 4,
    };

    const dotRad = 5 * devicePixelRatio * this.height / 400;

    const {
      nearestPoint, collided,
    } = this.collisionCheck(disk);

    // draw disk
    this.circle(ctx, {
      center: disk.position,
      radius: disk.radius,
      fillStyle: 'rgba(100,100,255,.2)',
      strokeStyle: 'blue',
      lineWidth: 2,
    });

    // draw obstacle
    this.path(ctx, {
      vertices: this.vertices,
      fillStyle: 'rgba(255,100,100,.2)',
      strokeStyle: 'red',
      lineWidth: 2,
    });

    // draw line from center to near point
    this.path(ctx, {
      vertices: [disk.position, nearestPoint],
      strokeStyle: 'red',
      lineWidth: '2',
    });

    // draw near point
    this.circle(ctx, {
      center: nearestPoint,
      radius: dotRad,
      fillStyle: 'red',
    });

    // draw center
    this.circle(ctx, {
      center: disk.position,
      radius: dotRad,
      fillStyle: 'blue',
    });

    if (collided) {
      this.bottomText('INTERSECTING');
    }

  }

  /**
   * Check if the given disk is intersecting this obstacle.
   * @param {object} disk The Disk instance
   * @returns {object} result The collision data or null
   */
  collisionCheck(disk) {
    const {
      nearestSegment,
      nearestPoint,
    } = this._getNearestWallPoint(disk.position);

    const delta = VectorMath.subtract(nearestPoint, disk.position);
    const distance = VectorMath.getLength(delta);

    return {
      nearestSegment, nearestPoint,
      collided: distance < disk.radius,
    };
  }

  /**
   * Find the edge point nearest to the given point
   * @param {Vector} point
   */
  _getNearestWallPoint(point) {

    let nearestSegment = null;
    let nearestPoint = null;
    let shortestDistance = Infinity;

    // Iterate through each edge line segment
    for (const segment of this.segments) {

      // find nearest point on this segment
      const edgePoint = this._np(segment, point);

      // check distance to target point
      const distance = VectorMath.getLength(VectorMath.subtract(edgePoint, point));

      // check if this is the new best candidate
      if (distance < shortestDistance) {
        shortestDistance = distance;
        nearestSegment = segment;
        nearestPoint = edgePoint;
      }
    }

    // return best candidate
    return {
      nearestSegment, nearestPoint,
    };
  }

  /**
   * Get the point on the line segment nearest to point p.
   * @param {object} segment
   * @param {Vector} p
   */
  _np(segment, p) {
    const d = VectorMath.subtract(p, segment.start);
    let r = (d.x * segment.delta.x + d.y * segment.delta.y) / segment.lengthSquared;

    if (r < 0) { r = 0; }
    if (r > 1) { r = 1; }

    return VectorMath.add(segment.start, VectorMath.multiply(segment.delta, r));
  }
}

new CollisionDiagram().setup();
