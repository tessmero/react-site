/**
 * @file puppy x-ray diagram
 */

// add front layer canvas
const canvas = document.getElementsByTagName('canvas')[0];
canvas.insertAdjacentHTML('afterend', '<canvas style="z-index:2; position:absolute; top: 0px;"></canvas>');

/**
 *
 */
class Puppy {
  puppyColor = 'rgb(200,200,100)';
  points = {
    backHip: [0, 0],
    frontHip: [1, 0],
    backShoulder: [0, -0.5],
    frontShoulder: [1, -0.5],
    backFoot: [0, 0.3],
    frontFoot: [1, 0.3],
    head: [1.3, -0.5],
    tail: [-0.3, -0.6],
  };

  // specification for springs between points
  links = {
    backLeg: {
      connects: ['backHip', 'backFoot'], // connect points
      display: 'limb', // draw as part of puppy body
    },
    frontLeg: {
      connects: ['frontHip', 'frontFoot'],
      display: 'limb',
    },

    // springs used for walking animation
    backFootAnim: {
      connects: ['frontHip', 'backFoot'],
    },
    frontFootAnim: {
      connects: ['backHip', 'frontFoot'],
    },

    torso: {
      // connect all combinations
      connects: ['backShoulder', 'frontShoulder', 'backHip', 'frontHip'],
      display: 'limb',
    },

    headDisplay: {
      connects: ['frontShoulder', 'head'],
      display: 'head', // display as puppy head with ears and face
    },

    tailDisplay: {
      connects: ['backShoulder', 'tail'],
      display: 'tail', // display as wagging puppy tail
    },

    // hold head and tail in position with hidden springs
    headSupport: {
      connects: ['head', ['frontHip']], // connect one to many
    },
    tailSupport: {
      connects: ['tail', ['backHip']],
    },

    // // extra support for legs
    // backSupport: {
    //   connects: ['backFoot', 'backShoulder'],
    // },
    // frontSupport: {
    //   connects: ['frontFoot', 'frontShoulder'],
    // },
  };

  /**
   *
   * @param params
   */
  constructor(params) {
    const {
      position,
      screenHeight,
    } = params;

    this.radius = 0.12 * screenHeight;// radius of balls

    this.pointScale = this.radius * 15 / 4;

    const { x, y } = position;
    const radius = this.radius; // radius of balls

    // build balls defined by points
    this.namedBalls = {};
    for (const [ballName, pos] of Object.entries(this.points)) {
      this.namedBalls[ballName] = {
        x: x + this.pointScale * pos[0] - 0.2 * screenHeight,
        y: y + this.pointScale * pos[1] + 0.1 * screenHeight,
      };
    }
    this.balls = Object.values(this.namedBalls);

    // build springs defined by links
    this.displaySprings = {}; // springs for drawing
    this.namedSprings = {}; // springs for debugging/animating
    this.springs = []; // complete list of springs
    for (const [key, val] of Object.entries(this.links)) {
      this._parseLink(key, val);
    }
  }

  /**
   *
   * @param key
   * @param val
   */
  _parseLink(key, val) {
    const { connects, display } = val;

    const newSprings = this._parseConnects(key, connects);

    for (const spring of newSprings) {
      if (display) {
        this._addDisplaySpring(display, spring);
      }
      this.springs.push(spring);
    }
  }

  /**
   *
   * @param key
   * @param connects
   */
  _parseConnects(key, connects) {

    if (Array.isArray(connects[1])) {

      // parse one-to-many link
      const fromBall = this.namedBalls[connects[0]];
      const to = connects[1].map((ballName) => this.namedBalls[ballName]);
      return to.map((toBall) => [fromBall, toBall]);

    }
    else if (connects.length === 2) {

      // parse single named spring which could potentially be animated
      const [fromName, toName] = connects;
      const spring = [this.namedBalls[fromName], this.namedBalls[toName]];
      this.namedSprings[key] = spring;
      return [spring];

    }

    // build spring for all combination of two
    const balls = connects.map((ballName) => this.namedBalls[ballName]);
    const result = [];
    for (let i = 0; i < connects.length; i++) {
      for (let j = i + 1; j < connects.length; j++) {
        result.push([balls[i], balls[j]]);
      }
    }
    return result;

  }

  /**
   *
   * @param display
   * @param spring
   */
  _addDisplaySpring(display, spring) {

    if (!Object.hasOwn(this.displaySprings, display)) {
      this.displaySprings[display] = [];
    }
    this.displaySprings[display].push(spring);
  }

  /**
   * Draw a puppy.
   * @param {object} ctx The graphics context
   * @param {object} puppy The Puppy instance to draw
   */
  static drawPuppy(ctx, puppy) {

    // draw "limb" type torso and legs
    ctx.strokeStyle = puppy.puppyColor;
    ctx.lineWidth = puppy.radius * 2;
    ctx.lineCap = 'round';
    ctx.setLineDash([]);

    ctx.beginPath();
    for (const [pos1, pos2] of puppy.displaySprings.limb) {
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(pos2.x, pos2.y);
    }
    ctx.stroke();

    // draw wagging tail
    ctx.lineWidth = puppy.radius * 1.5;
    ctx.beginPath();
    for (const [pos1, pos2] of puppy.displaySprings.tail) {
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(pos2.x, pos2.y);

    }
    ctx.stroke();

    // draw head with face and ears
    for (const [pos1, pos2] of puppy.displaySprings.head) {
      Puppy._drawHead(ctx, puppy, pos1, pos2);
    }

  }

  /**
   *
   * @param ctx
   * @param puppy
   * @param pos1
   * @param pos2
   */
  static _drawHead(ctx, puppy, pos1, pos2) {

    ctx.fillStyle = puppy.puppyColor;

    const scale = 55 * puppy.radius;
    const rad = puppy.radius * 2; // head radius
    const eaDist = 0.038 * scale;
    const eaDa = 0.7; // radians offset between ears
    const eaRad = 0.015 * scale; // ear radius

    const { add, subtract, getAngle, polarToCartesian: polar } = VectorMath;

    const angle = getAngle(subtract(pos2, pos1)) - Math.PI / 2;
    const pos = pos2;

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, rad, 0, Math.PI * 2);
    ctx.fill();

    const eaCenters = [
      add(pos, polar(angle + eaDa, eaDist)),
      add(pos, polar(angle - eaDa, eaDist)),
    ];
    eaCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, eaRad, 0, Math.PI * 2);
      ctx.fill();
    });

    Puppy._drawFace(ctx, puppy, pos, angle);
  }

  /**
   *
   * @param ctx
   * @param puppy
   * @param pos
   * @param angle
   */
  static _drawFace(ctx, puppy, pos, angle) {

    ctx.strokeStyle = 'black';
    ctx.fillStyle = 'black';
    ctx.lineWidth = 0.1 * puppy.radius;

    const { add, polarToCartesian: polar } = VectorMath;
    const scale = 55 * puppy.radius;

    // mouth
    const mDist = 0.02 * scale;
    const mDa = 0.3; // radians
    const mRad = 0.008 * scale;
    const mArc = 0.7; // radius
    const mO = polar(angle, -0.022 * scale);

    const mCenters = [
      add(pos, polar(angle + mDa, mDist), mO),
      add(pos, polar(angle - mDa, mDist), mO),
    ];
    mCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, mRad, Math.PI + angle - mArc, Math.PI + angle + mArc);
      ctx.stroke();
    });

    // nose
    const nCenter = add(pos, polar(angle, -0.0065 * scale));
    ctx.beginPath();
    ctx.ellipse(nCenter.x, nCenter.y,
      0.002 * scale, // height
      0.003 * scale, // width
      angle, 0, Math.PI * 2);
    ctx.fill();

    // eyes
    const eyeDist = 0.012 * scale;
    const eyeDa = 0.9; // radians
    const eyeRad = 0.004 * scale;
    const eyeCenters = [
      add(pos, polar(angle + eyeDa, eyeDist)),
      add(pos, polar(angle - eyeDa, eyeDist)),
    ];

    ctx.fillStyle = 'black';
    eyeCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, eyeRad, 0, 2 * Math.PI);
      ctx.fill();
    });

  }
}

/**
 *
 */
class XrayDiagram extends Diagram {

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    this.frontCtx = document.getElementsByTagName('canvas')[1].getContext('2d');

    // this.ctx = this.frontCtx
    this.puppy = new Puppy({ position: this.center, screenHeight: this.height });
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    // draw puppy on front canvas
    const front = this.frontCtx;
    front.globalCompositeOperation = 'source-over';
    front.clearRect(0, 0, this.width, this.height);
    Puppy.drawPuppy(front, this.puppy);

    // erase x-ray circle area on front canvas
    front.globalCompositeOperation = 'destination-out';
    this.circle(front, {
      center: this.mousePos,
      radius: this.height * 0.3,
      fillStyle: 'black',
    });
    front.globalCompositeOperation = 'source-over';

    // outline x-ray area on front canvas
    this.circle(front, {
      center: this.mousePos,
      radius: this.height * 0.3,
      strokeStyle: 'black',
      lineDash: [5, 10],
      lineWidth: 2,
      showRadiusLine: false,
    });

    // draw springs on back canvas
    for (const [pos1, pos2] of this.puppy.springs) {
      this.path(ctx, {
        vertices: [pos1, pos2],
        strokeStyle: 'red',
        lineWidth: 2,
      });
    }

    // draw hoverable joints on back canvas
    const radius = this.puppy.radius;
    let nearestD2 = radius * radius;
    let nearestJointName = null;
    for (const [jointName, joint] of Object.entries(this.puppy.namedBalls)) {

      // draw joint
      this.circle(ctx, {
        center: joint,
        radius,
        fillStyle: 'rgba(100,100,255,.2)',
        strokeStyle: 'blue',
        lineWidth: 2,
        showRadiusLine: false,
      });

      // check if joint is hovered
      const d2 = VectorMath.getLengthSquared(
        VectorMath.subtract(joint, this.mousePos));
      if (d2 < nearestD2) {
        nearestD2 = d2;
        nearestJointName = jointName;
      }
    }

    if (nearestJointName) {

      // highlight hovered ball
      const joint = this.puppy.namedBalls[nearestJointName];
      this.circle(ctx, {
        center: joint,
        radius,
        strokeStyle: 'yellow',
        lineWidth: 2,
        showRadiusLine: false,
      });
      this.bottomText(nearestJointName);
    }

  }
}

new XrayDiagram().setup();
