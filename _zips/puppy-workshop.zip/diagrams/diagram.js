/**
 * @file Diagram
 */
class Diagram {

  /**
   *
   */
  _isInsideHiddenIframe() {
    try {
      if (window.self !== window.top) { // Check if inside an iframe
        const iframe = window.frameElement;
        if (!iframe) {
          return false; // In an iframe, but can't find the element (unlikely)
        }
        return iframe.offsetParent === null || iframe.style.display === 'none' || iframe.style.visibility === 'hidden';
      }
    }
    catch (e) {
      // Handle cross-origin errors: if an error is thrown, assume it's not hidden
      return false;
    }
    return false; // Not in an iframe
  }

  /**
   *
   */
  setup() {
    if (this._isInsideHiddenIframe()) {
      return;
    }
    this._setupCanvas();
    this.draw();
  }

  /**
   *
   */
  draw() {

    // this.ctx.fillStyle = 'white'
    this.ctx.clearRect(0, 0, this.width, this.height);

    this._draw(this.ctx);
  }

  /**
   *
   */
  _defaultMousePos() {
    return this.center;
  }

  /**
   *
   * @param {object} _ctx
   */
  _draw(_ctx) {
    throw new Error(`not implemented in ${this.constructor.name}`);
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  path(ctx, params) {
    const { vertices, closed = true } = params;

    ctx.beginPath();
    for (const { x, y } of vertices) {
      ctx.lineTo(x, y);
    }
    if (closed) {
      ctx.closePath();
    }

    this._strokeFill(ctx, params);
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  launcher(ctx, params) {
    const {
      center, angle, fillStyle = 'black',
    } = params;

    const baseRad = 17 * this.height / 300;
    const muzzleRad = 6 * this.height / 300;
    const muzzleLength = 30 * this.height / 300;

    ctx.fillStyle = fillStyle;

    // fill launcher base
    ctx.beginPath();

    // ctx.arc(center.x, center.y, baseRad, 0, 2 * Math.PI);
    ctx.arc(center.x, center.y, baseRad, 1 + Math.PI / 2, 2 * Math.PI - 1 + Math.PI / 2);
    ctx.fill();

    // fill launcher muzzle
    const shape = [[-1, 0], [-1, 1], [1, 1], [1, 0]];
    ctx.beginPath();
    for (const [x, y] of shape) {
      const p = VectorMath.add(center,
        VectorMath.rotate(
          { x: x * muzzleRad, y: y * muzzleLength },
          angle - Math.PI / 2
        )
      );
      ctx.lineTo(p.x, p.y);
    }
    ctx.closePath();
    ctx.fill();
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  arrow(ctx, params) {
    const {
      vertices, // [start,end]
      headLength = 5, // base to head distance
      tailWidth = 5, // distance between tail tips
      tailSweep = 1, // distance for tails to fall back behind base
    } = params;

    ctx.lineJoin = 'miter';

    const [start, end] = vertices;
    const angle = VectorMath.getAngle(VectorMath.subtract(end, start));
    const base = VectorMath.add(end, VectorMath.polarToCartesian(angle, -headLength));
    const leftTail = VectorMath.add(base,
      VectorMath.polarToCartesian(angle + Math.PI / 2, tailWidth),
      VectorMath.polarToCartesian(angle, -tailSweep)
    );
    const rightTail = VectorMath.add(base,
      VectorMath.polarToCartesian(angle - Math.PI / 2, tailWidth),
      VectorMath.polarToCartesian(angle, -tailSweep)
    );

    this.path(ctx, {
      ...params,
      vertices: [
        start, base, leftTail, end, rightTail, base,
      ],
    });
  }

  /**
   *
   * @param ctx
   * @param params
   */
  spring(ctx, params) {
    const { start, end } = params;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    this.path(ctx, {
      vertices: this._zigzag(params),
      closed: false,
      strokeStyle: 'red',
      lineWidth: 2,
      ...params,
    });
  }

  /**
   *
   * @param params
   */
  * _zigzag(params) {

    const { add, subtract, getAngle, avg, polarToCartesian } = VectorMath;

    const {
      start, end,
      radius = 0.15 * this.height,
      n = 19,
      pad = 0.25 * this.height,
    } = params;

    const delta = subtract(end, start);
    const angle = getAngle(delta);

    // padding  -> straight segments at ends
    const padding = polarToCartesian(angle, pad);
    const a = add(start, padding);
    const b = subtract(end, padding);

    // offset from straight line and zig zag points
    const ribDelta = polarToCartesian(angle + Math.PI / 2, radius);

    // straight segment at start
    yield start;
    yield avg(a, b, 0.5 / n);

    // zigzag segments
    for (let i = 1; i < n; i++) {
      const straightPoint = avg(a, b, i / n);
      if (i % 2) {
        yield add(straightPoint, ribDelta);
      }
      else {
        yield subtract(straightPoint, ribDelta);
      }
    }

    // straight segment at end
    yield avg(b, a, 0.5 / n);
    yield end;
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  arc(ctx, params) {
    const {
      center, radius,
      startAngle = 0,
      endAngle = 2 * Math.PI,
    } = params;

    const { x, y } = center;

    ctx.beginPath();
    ctx.arc(x, y, radius, startAngle, endAngle);

    this._strokeFill(ctx, params);
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  circle(ctx, params) {
    const {
      center, radius,
      showRadiusLine = true,
    } = params;

    const { x, y } = center;

    ctx.beginPath();
    if (showRadiusLine) {
      ctx.moveTo(x, y);
    }
    ctx.arc(x, y, radius, 0, 2 * Math.PI);

    this._strokeFill(ctx, params);
  }

  /**
   *
   * @param {object} ctx
   * @param {object} params
   */
  _strokeFill(ctx, params) {
    const { fillStyle, strokeStyle, lineWidth = 1, lineDash = [] } = params;

    if (fillStyle) {
      ctx.fillStyle = fillStyle;
      ctx.fill();
    }
    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      const scale = devicePixelRatio * this.height / 300;
      ctx.lineWidth = lineWidth * scale;
      ctx.setLineDash(lineDash.map((v) => v * scale));
      ctx.stroke();
    }
  }

  /**
   *
   */
  get relX() {
    return Math.max(0, Math.min(1, this.mousePos.x / this.width));
  }

  /**
   *
   */
  get relY() {
    return Math.max(0, Math.min(1, this.mousePos.y / this.height));
  }

  /**
   *
   */
  get trajRad() { return 0.01 * this.height; }

  /**
   *
   * @param {string} label
   */
  bottomText(label) {
    const { ctx, center, height } = this;
    ctx.fillStyle = 'black';
    ctx.fillText(label, center.x, height);
  }

  /**
   * Set up the graphics context and start listening for mouse and touch input.
   */
  _setupCanvas() {

    // prepare to draw on the canvas element in our html document
    //
    const allCanvases = document.getElementsByTagName('canvas');
    for (let i = 0; i < allCanvases.length; i++) {
      const canvas = allCanvases[i];
      const ctx = canvas.getContext('2d');

      canvas.width = canvas.offsetWidth * devicePixelRatio;
      canvas.height = canvas.offsetHeight * devicePixelRatio;

      if (i === 0) {

        this.canvas = canvas;
        this.ctx = ctx;
        this.center = {
          x: canvas.width / 2,
          y: canvas.height / 2,
        };
        this.width = canvas.width;
        this.height = canvas.height;
        this.mousePos = this._defaultMousePos();

        // distance that will always end up OOB
        this.rad = Math.sqrt(Math.pow(this.width, 2) + Math.pow(this.height, 2));

        // prepare font (only used for bottom text)
        const fontSize = 0.07 * this.height * Math.sqrt(devicePixelRatio);
        ctx.font = `${fontSize}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
      }

      if (i === (allCanvases.length - 1)) { // only for front-most canvas

        // (one time) start listening for different types of input events
        if (!this._addedListeners) {
          this._addedListeners = true;
          const listenFor = ['mousedown', 'mousemove', 'touchstart', 'touchmove'];
          listenFor.forEach((eventType) => {
            canvas.addEventListener(eventType, (event) => {

              // standardize and pass to common mouseMove listener (main.js)
              this.mousePos = this._getStandardMousePos(event);
              this.draw();

              event.preventDefault();
            });
          });
        }
      }
    }

    // init on future resize
    window.onresize = () => {
      this._setupCanvas();
      this.draw();
    };
  }

  /**
   * Compute the mouse position indicated by the event.
   * @param {object} rawEvent The mouse/touch event
   */
  _getStandardMousePos(rawEvent) {

    // coerce event into having familiar properties
    let event = rawEvent;
    if (event.touches) {
      const touch = event.touches[0];
      if (touch.clientX) {
        event = touch;
      }
      else {
        event = {
          clientX: touch[0].pageX,
          clientY: touch[0].pageY,
        };
      }
    }

    // convert event position to standard coordinate system
    const mousePos = {
      x: event.clientX * devicePixelRatio,
      y: event.clientY * devicePixelRatio,
    };

    return mousePos;
  }
}
