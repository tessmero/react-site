/**
 * @file BounceDiagram
 */
class BounceDiagram extends Diagram {

  /**
   *
   */
  _defaultMousePos() {
    const { center, height } = this;
    return VectorMath.add(center, { x: -height / 2, y: -0.45 * height });
  }

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    this.intersection = VectorMath.add(this.center, { x: 0, y: this.height / 4 });

    this.arrowLength = 0.3 * this.height;
    this.arrowDistance = 0.6 * this.height;
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    // surface
    this.surfaceAngle = VectorMath.avg(-Math.PI / 8, Math.PI / 8, this.relX);

    // velocity
    this.approachAngle = VectorMath.avg(2.25 * Math.PI / 2, 2.5 * Math.PI / 2, this.relY);

    this._drawSurface(ctx);
    this._drawNormal(ctx);
    this._drawBeforeTraj(ctx);
    this._drawAfterTraj(ctx);

  }

  /**
   *
   * @param {object} ctx
   */
  _drawBeforeTraj(ctx) {
    const angle = this.approachAngle;
    const polar = VectorMath.polarToCartesian;

    const da = polar(angle, this.rad);
    const start = VectorMath.add(this.intersection, da);
    const end = this.intersection;

    this.path(ctx, {
      vertices: [start, end],
      strokeStyle: 'blue',
      lineWidth: 2,
      lineDash: [5, 10],
    });

    const arrowEnd = VectorMath.add(end, polar(angle, this.arrowDistance));
    const arrowStart = VectorMath.add(arrowEnd, polar(angle, this.arrowLength));
    this.arrow(ctx, {
      vertices: [arrowStart, arrowEnd],
      strokeStyle: 'blue',
      lineWidth: 5,
    });

    // draw angle indicator
    this.arc(ctx, {
      center: end,
      startAngle: this.surfaceAngle + 3 * Math.PI,
      endAngle: this.approachAngle,
      radius: 0.2 * this.height,
      strokeStyle: 'blue',
      lineWidth: 2,
    });
  }

  /**
   *
   * @param {object} ctx
   */
  _drawAfterTraj(ctx) {
    const angle = 2 * this.surfaceAngle - this.approachAngle;

    const polar = VectorMath.polarToCartesian;

    const da = VectorMath.polarToCartesian(angle, -this.rad);
    const start = this.intersection;
    const end = VectorMath.add(this.intersection, da);

    this.path(ctx, {
      vertices: [start, end],
      strokeStyle: 'blue',
      lineWidth: 2,
      lineDash: [5, 10],
    });

    const arrowStart = VectorMath.add(start, polar(angle, -this.arrowDistance));
    const arrowEnd = VectorMath.add(arrowStart, polar(angle, -this.arrowLength));
    this.arrow(ctx, {
      vertices: [arrowStart, arrowEnd],
      strokeStyle: 'blue',
      lineWidth: 5,
    });

    // draw angle indicator
    this.arc(ctx, {
      center: start,
      startAngle: angle + Math.PI,
      endAngle: this.surfaceAngle,
      radius: 0.2 * this.height,
      strokeStyle: 'blue',
      lineWidth: 2,
    });

  }

  /**
   *
   * @param {object} ctx
   */
  _drawNormal(ctx) {
    const {
      polarToCartesian: polar,
      add,
    } = VectorMath;

    const angle = this.surfaceAngle - Math.PI / 2;

    // draw angle A
    const da = polar(angle, this.rad);
    const start = this.intersection;// this.add(this.center,da)
    const end = add(this.intersection, da);

    this.path(ctx, {
      vertices: [start, end],
      strokeStyle: 'red',
      lineWidth: 2,
      lineDash: [5, 10],
    });

    // draw 90 degree angle indicator
    const size = 0.1 * this.height;
    const up = polar(angle, size);
    const right = polar(angle + Math.PI / 2, size);
    this.path(ctx, {
      vertices: [
        add(start, up),
        add(start, up, right),
        add(start, right),
      ],
      strokeStyle: 'red',
      lineWidth: 2,
      closed: false,
    });
  }

  /**
   *
   * @param {object} ctx
   */
  _drawSurface(ctx) {

    const angle = this.surfaceAngle;

    const da = VectorMath.polarToCartesian(angle, this.rad);

    const start = VectorMath.add(this.intersection, da);
    const end = VectorMath.add(this.intersection, VectorMath.multiply(da, -1));

    // make two vertices offscreen for fill region
    const drop = VectorMath.polarToCartesian(angle + Math.PI / 2, this.rad);
    const dropStart = VectorMath.add(start, drop);
    const dropEnd = VectorMath.add(end, drop);

    // draw angle A
    this.path(ctx, {
      lineWidth: 2,
      strokeStyle: 'red',
      fillStyle: 'rgba(255,100,100,.2)',
      vertices: [
        start, end, dropEnd, dropStart,
      ],
    });

  }
}

new BounceDiagram().setup();
