/**
 * @file walking diagram
 */

/**
 *
 */
class Puppy {
  puppyColor = 'rgb(200,200,100)';
  points = {
    backHip: [0, 0],
    frontHip: [1, 0],
    backShoulder: [0, -0.5],
    frontShoulder: [1, -0.5],
    backFoot: [0, 0.3],
    frontFoot: [1, 0.3],
    head: [1.3, -0.5],
    tail: [-0.3, -0.6],
  };

  // specification for springs between points
  links = {
    backLeg: {
      connects: ['backHip', 'backFoot'], // connect points
      display: 'limb', // draw as part of puppy body
    },
    frontLeg: {
      connects: ['frontHip', 'frontFoot'],
      display: 'limb',
    },

    // springs used for walking animation
    backFootAnim: {
      connects: ['frontHip', 'backFoot'],
    },
    frontFootAnim: {
      connects: ['backHip', 'frontFoot'],
    },

    torso: {
      // connect all combinations
      connects: ['backShoulder', 'frontShoulder', 'backHip', 'frontHip'],
      display: 'limb',
    },

    headDisplay: {
      connects: ['frontShoulder', 'head'],
      display: 'head', // display as puppy head with ears and face
    },

    tailDisplay: {
      connects: ['backShoulder', 'tail'],
      display: 'tail', // display as wagging puppy tail
    },

    // hold head and tail in position with hidden springs
    headSupport: {
      connects: ['head', ['frontHip']], // connect one to many
    },
    tailSupport: {
      connects: ['tail', ['backHip']],
    },

    // // extra support for legs
    // backSupport: {
    //   connects: ['backFoot', 'backShoulder'],
    // },
    // frontSupport: {
    //   connects: ['frontFoot', 'frontShoulder'],
    // },
  };

  /**
   *
   * @param params
   */
  constructor(params) {
    const {
      position,
      screenHeight,
    } = params;

    this.radius = 0.12 * screenHeight;// radius of balls

    this.pointScale = this.radius * 15 / 4;

    const { x, y } = position;
    const radius = this.radius; // radius of balls

    // build balls defined by points
    this.namedBalls = {};
    for (const [ballName, pos] of Object.entries(this.points)) {
      this.namedBalls[ballName] = {
        x: x + this.pointScale * pos[0] - 0.2 * screenHeight,
        y: y + this.pointScale * pos[1] + 0.1 * screenHeight,
      };
    }
    this.balls = Object.values(this.namedBalls);

    // build springs defined by links
    this.namedSprings = {}; // springs for debugging/animating
    this.springs = []; // complete list of springs
    for (const [key, val] of Object.entries(this.links)) {
      this._parseLink(key, val);
    }
  }

  /**
   *
   * @param key
   * @param val
   */
  _parseLink(key, val) {
    const { connects, display } = val;

    const newSprings = this._parseConnects(key, connects);

    for (const spring of newSprings) {
      this.springs.push(spring);
    }
  }

  /**
   *
   * @param key
   * @param connects
   */
  _parseConnects(key, connects) {

    if (Array.isArray(connects[1])) {

      // parse one-to-many link
      return connects[1].map((toBall) => [connects[0], toBall]);

    }
    else if (connects.length === 2) {

      // parse single named spring which could potentially be animated
      const [fromName, toName] = connects;
      const spring = [fromName, toName];
      this.namedSprings[key] = spring;
      return [spring];

    }

    // build spring for all combination of two
    const result = [];
    for (let i = 0; i < connects.length; i++) {
      for (let j = i + 1; j < connects.length; j++) {
        result.push([connects[i], connects[j]]);
      }
    }
    return result;

  }
}

/**
 *
 */
class WalkingDiagram extends Diagram {

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();
    this.puppy = new Puppy({ position: this.center, screenHeight: this.height });

    // compute default rest length for animated springs
    this.legLength = this._getSpringLength(this.puppy.namedSprings.frontLeg);
    this.defaultRestLength = this._getSpringLength(this.puppy.namedSprings.frontFootAnim);
  }

  /**
   *
   * @param spring
   */
  _getSpringLength(spring) {
    const [pos1, pos2] = spring.map((name) => this.puppy.namedBalls[name]);
    return VectorMath.getLength(VectorMath.subtract(pos2, pos1));
  }

  /**
   *
   * @param ctx
   */
  _draw(ctx) {

    // compute foot positions
    const frac = VectorMath.avg(0.8, 1.2, this.relX);
    const animLength = frac * this.defaultRestLength;
    const { backHip, frontHip } = this.puppy.namedBalls;
    this.puppy.namedBalls.backFoot = this._intersectCircles(backHip, this.legLength, frontHip, animLength);
    this.puppy.namedBalls.frontFoot = this._intersectCircles(frontHip, this.legLength, backHip, animLength);
    const { backFoot, frontFoot } = this.puppy.namedBalls;

    // draw springs
    for (const ballNames of this.puppy.springs) {
      this.path(ctx, {
        vertices: ballNames.map((name) => this.puppy.namedBalls[name]),
        strokeStyle: 'black',
        lineWidth: 1,
      });
    }

    // highLight animated springs
    this.path(ctx, {
      vertices: [frontFoot, backHip],
      strokeStyle: 'red',
      lineWidth: 4,
    });
    this.path(ctx, {
      vertices: [backFoot, frontHip],
      strokeStyle: 'red',
      lineWidth: 4,
    });

    // draw joints
    const radius = this.puppy.radius;
    for (const [jointName, joint] of Object.entries(this.puppy.namedBalls)) {

      // draw joint
      this.circle(ctx, {
        center: joint,
        radius,
        fillStyle: 'rgba(100,100,255,.2)',
        strokeStyle: 'blue',
        lineWidth: 2,
        showRadiusLine: false,
      });
    }

    const pct = Math.round(100 * frac);
    this.bottomText(`${pct}% REST LENGTH`);

  }

  /**
   *
   * @param pos1
   * @param r1
   * @param pos2
   * @param r2
   */
  _intersectCircles(pos1, r1, pos2, r2) {
    const { x: x1, y: y1 } = pos1;
    const { x: x2, y: y2 } = pos2;

    const dx = x2 - x1;
    const dy = y2 - y1;
    const d = Math.sqrt(dx * dx + dy * dy);

    // Check for no intersection or coincident circles
    if (d > r1 + r2 || d < Math.abs(r1 - r2) || d === 0) { return []; }

    // Calculate intersection points
    const a = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
    const h = Math.sqrt(r1 * r1 - a * a);

    const px = x1 + (a * dx) / d;
    const py = y1 + (a * dy) / d;

    const candidates = [
      { x: px - (h * dy) / d, y: py + (h * dx) / d },
      { x: px + (h * dy) / d, y: py - (h * dx) / d },
    ];

    if (candidates[0].y > candidates[1].y) {
      return candidates[0];
    }
    return candidates[1];
  }
}

new WalkingDiagram().setup();
