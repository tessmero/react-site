/**
 * @file RaycastDiagram
 */
class RaycastDiagram extends Diagram {

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    const { center, height } = this;

    // build obstacle
    const { vertices } = VectorMath.parseVertices({
      center, // this.add(center,{x:height/4,y:0}),
      radius: height / 2.5,
      n: 5,
      angle: -Math.PI / 2,
    });
    this.vertices = vertices;
    this.segments = [];

    // process line segments
    for (let i = 0; i < vertices.length; i++) {
      const start = vertices[i];
      const end = vertices[(i + 1) % vertices.length];
      const delta = VectorMath.subtract(end, start);
      const angle = VectorMath.getAngle(delta);
      const lengthSquared = VectorMath.getLengthSquared(delta);
      this.segments.push({
        start, end, delta,
        angle, lengthSquared,
      });
    }
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    const {
      isInside, crossings,
    } = this.collisionCheck({ position: this.mousePos });

    const dotRad = 5 * devicePixelRatio * this.height / 400;

    // draw mouse position
    this.circle(ctx, {
      center: this.mousePos,
      radius: dotRad,
      fillStyle: 'blue',
    });

    // draw ray
    const farRight = { x: this.width, y: this.mousePos.y };
    this.path(ctx, {
      vertices: [this.mousePos, farRight],
      strokeStyle: 'blue',
      lineWidth: 2,
    });

    // draw obstacle
    this.path(ctx, {
      vertices: this.vertices,
      fillStyle: 'rgba(255,100,100,.2)',
      strokeStyle: 'red',
      lineWidth: 2,
    });

    // draw crossings

    for (const crossing of crossings) {
      this.circle(ctx, {
        center: crossing,
        radius: dotRad,
        fillStyle: 'red',
      });
    }

    this.bottomText(`(${crossings.length}) ${isInside ? 'INSIDE' : 'OUTSIDE'}`);
  }

  /**
   * Check if the given disk is intersecting this obstacle.
   * @param {object} disk The Disk instance
   * @returns {object} result The collision data or null
   */
  collisionCheck(disk) {

    // check if the CENTER of the disk is inside this obstacle
    const inside = this.isPointInPolygon(disk.position, this.vertices);

    return inside;
  }

  /**
   * Check if the point is contained by the polygon and find ray intersections
   * @param {Vector} point The point to check
   * @param {Vector[]} verts The vertices of the shape to check
   * @returns {object} Contains 'inside' boolean and 'crossings' array
   */
  isPointInPolygon(point, verts) {
    const { x, y } = point;
    let isInside = false;
    const crossings = [];

    for (let i = 0; i < verts.length; i++) {
      const j = (i + 1) % verts.length;
      const xi = verts[i].x;
      const yi = verts[i].y;
      const xj = verts[j].x;
      const yj = verts[j].y;

      // Check if edge spans the point's y-level
      if ((yi > y) !== (yj > y)) {
      // Calculate intersection X coordinate
        const xIntersect = ((xj - xi) * (y - yi)) / (yj - yi) + xi;

        // Check if ray path crosses this segment
        if (x < xIntersect) {
          isInside = !isInside;
          crossings.push({ x: xIntersect, y });
        }
      }
    }

    return { isInside, crossings };
  }

}

new RaycastDiagram().setup();
