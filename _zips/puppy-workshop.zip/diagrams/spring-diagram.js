/**
 * @fie spring diagram
 */
class SpringDiagram extends Diagram {

  /**
   *
   */
  _defaultMousePos() {
    return {
      x: this.width - this.height / 2,
      y: this.height / 2 };
  }

  /**
   *
   */
  _setupCanvas() {
    super._setupCanvas();

    this.fixedBall = {
      center: {
        x: this.height / 2,
        y: this.height / 2,
      },
      radius: 0.1 * this.height,
    };

    this.movableBall = {
      center: {
        x: this.width - this.height / 2,
        y: this.height / 2,
      },
      radius: 0.1 * this.height,
    };

    this.restLength = 0.6 * VectorMath.getLength(
      VectorMath.subtract(this.movableBall.center, this.fixedBall.center));
  }

  /**
   *
   * @param {object} ctx
   */
  _draw(ctx) {

    // move one ball to mouse position
    this.movableBall.center = this.mousePos;

    // draw balls
    const ballStyle = {
      fillStyle: 'rgba(100,100,255,.2)',
      strokeStyle: 'blue',
      lineWidth: 2,
      showRadiusLine: false,
    };
    this.circle(ctx, { ...ballStyle, ...this.fixedBall });
    this.circle(ctx, { ...ballStyle, ...this.movableBall });

    const start = this.fixedBall.center;
    const end = this.movableBall.center;

    // draw spring
    this.spring(ctx, { start, end });

    // draw force arrows
    const { getAngle, getLength, add, subtract, polarToCartesian } = VectorMath;
    const offset = (getLength(subtract(end, start)) - this.restLength);
    const arrowDistance = 0.1 * this.height;
    const arrowLength = offset * 0.2;
    const lineWidth = 2 + Math.abs(offset / this.height) * 3;
    const angle = getAngle(subtract(end, start));

    const sign = Math.sign(offset);

    // force on fixed ball
    this.arrow(ctx, {
      vertices: [
        add(start, polarToCartesian(angle, sign * arrowDistance)),
        add(start, polarToCartesian(angle, sign * arrowDistance + arrowLength)),
      ],
      strokeStyle: 'red',
      lineWidth,
    });

    // force on movable ball
    this.arrow(ctx, {
      vertices: [
        add(end, polarToCartesian(angle, -sign * arrowDistance)),
        add(end, polarToCartesian(angle, -sign * arrowDistance - arrowLength)),
      ],
      strokeStyle: 'red',
      lineWidth,
    });
  }
}

new SpringDiagram().setup();
