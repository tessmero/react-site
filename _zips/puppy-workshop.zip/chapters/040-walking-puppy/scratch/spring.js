/**
 * @file Spring constraint between two balls
 */
class Spring {

  /**
   * Create a new spring.
   * @param {object} ball1 The first ball to connect
   * @param {object} ball2 The second ball to connect
   * @param {object} params The optional parameters
   * @param {number} params.stiffness
   * @param {number} params.damping
   */
  constructor(ball1, ball2, params = {}) {
    const {
      stiffness = SPRING_STIFFNESS,
      damping = SPRING_DAMPING,
    } = params;

    this.ball1 = ball1;
    this.ball2 = ball2;
    this.stiffness = stiffness;
    this.damping = damping;

    this.prevLength = VectorMath.getLength(
      VectorMath.subtract(this.ball2.position, this.ball1.position));

    this.restLength = this.prevLength;
  }

  /**
   * Adjust rest length. Used for walking animation.
   * @param {number} length
   */
  setRestLength(length) {
    this.restLength = length;
  }

  /**
   *
   */
  applyForces() {

    // check the current state of the spring
    const displacement = VectorMath.subtract(this.ball2.position, this.ball1.position);
    const currentLength = VectorMath.getLength(displacement);
    let dAngle = VectorMath.getAngle(displacement);

    // Calculate the force exerted by the spring
    let forceMagnitude = this.stiffness * (currentLength - this.restLength);
    let tooLong = true;
    if (forceMagnitude < 0) {

      // make forceMagnitude positive
      tooLong = false;
      dAngle = dAngle + Math.PI;
      forceMagnitude = forceMagnitude * -1;
    }

    // apply damping
    const relativeSpeed = (currentLength - this.prevLength);
    if (tooLong === (relativeSpeed < 0)) {
      const dampingMagnitude = Math.abs(relativeSpeed) * this.damping;
      forceMagnitude = Math.max(0, forceMagnitude - dampingMagnitude);
    }
    this.prevLength = currentLength;

    // Calculate the net force including spring force and damping
    const force = VectorMath.polarToCartesian(dAngle, forceMagnitude);

    // Apply the force to the balls
    this.ball1.velocity = VectorMath.add(this.ball1.velocity, force);
    this.ball2.velocity = VectorMath.subtract(this.ball2.velocity, force);
  }
}
