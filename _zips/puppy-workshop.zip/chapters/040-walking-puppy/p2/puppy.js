/**
 * @file puppy
 * balls-and-springs physics object
 */
class Puppy {
  radius = 4; // radius of balls

  // walking animation where springs are adjusted
  feetWalkPeriod = 500; // milliseconds
  feetIn = 0.9; // multiplier for rest length
  feetOut = 1.1;

  // tail wagging in graphics only
  tailWagPeriod = 250; // milliseconds
  wagUp = 0.4; // offset angle of tail in radians
  wagDown = -0.4;

  // body parts (balls) in neutral standing pose
  pointScale = 15;
  points = {
    backHip: [0, 0],
    frontHip: [1, 0],
    backShoulder: [0, -0.5],
    frontShoulder: [1, -0.5],
    backFoot: [0, 0.3],
    frontFoot: [1, 0.3],
    head: [1.3, -0.5],
    tail: [-0.3, -0.6],
  };

  // specification for springs between points
  links = {
    backLeg: {
      connects: ['backHip', 'backFoot'], // connect points
      display: 'limb', // draw as part of puppy body
    },
    frontLeg: {
      connects: ['frontHip', 'frontFoot'],
      display: 'limb',
    },

    // springs used for walking animation
    backFootAnim: {
      connects: ['frontHip', 'backFoot'],
    },
    frontFootAnim: {
      connects: ['backHip', 'frontFoot'],
    },

    torso: {
      // connect all combinations
      connects: ['backShoulder', 'frontShoulder', 'backHip', 'frontHip'],
      display: 'limb',
    },

    headDisplay: {
      connects: ['frontShoulder', 'head'],
      display: 'head', // display as puppy head with ears and face
    },

    tailDisplay: {
      connects: ['backShoulder', 'tail'],
      display: 'tail', // display as wagging puppy tail
    },

    // hold head and tail in position with hidden springs
    headSupport: {
      connects: ['head', ['backShoulder', 'backHip', 'frontHip']], // connect one to many
    },
    tailSupport: {
      connects: ['tail', ['backShoulder', 'frontShoulder', 'backHip', 'frontHip']],
    },

    // extra support for legs
    backSupport: {
      connects: ['backFoot', 'backShoulder'],
    },
    frontSupport: {
      connects: ['frontFoot', 'frontShoulder'],
    },
  };

  /**
   *
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   */
  constructor(params) {
    const {
      position,
      velocity = { x: 0, y: 0 },
    } = params;

    const { x, y } = position;
    const radius = this.radius; // radius of balls

    // build balls defined by points
    this.namedBalls = {};
    for (const [ballName, pos] of Object.entries(this.points)) {
      this.namedBalls[ballName] = new Ball({
        position: {
          x: x + this.pointScale * pos[0],
          y: y + this.pointScale * pos[1],
        },
        velocity,
        radius,
      });
    }
    this.balls = Object.values(this.namedBalls);

    // build springs defined by links
    this.displaySprings = {}; // springs for drawing
    this.namedSprings = {}; // springs for debugging/animating
    this.springs = []; // complete list of springs
    for (const [key, val] of Object.entries(this.links)) {
      this._parseLink(key, val);
    }

    //
    const { ball1, ball2 } = this.namedSprings.frontFootAnim;
    this.standingSpringLength = VectorMath.getLength(
      VectorMath.subtract(ball1.getPosition(), ball2.getPosition()));
  }

  /**
   *
   */
  updateWalkAnim() {

    // compute anim state [0-1] looping
    const loopingState = (Date.now() / this.feetWalkPeriod) % 1;
    const out = loopingState < 0.5;

    // compute anim state oscillating between 0 and 1
    const anim = 0.5 + 0.5 * Math.cos(loopingState * (2 * Math.PI));

    // update springs
    const lengthMult = VectorMath.avg(this.feetIn, this.feetOut, anim);
    for (const springName of (['frontFootAnim', 'backFootAnim'])) {
      const spring = this.namedSprings[springName];
      spring.setRestLength(this.standingSpringLength * lengthMult);
    }

    // update grip on feet
    this.namedBalls.frontFoot.setFriction(out ? 1 : 0);
    this.namedBalls.backFoot.setFriction(out ? 0 : 1);
  }

  /**
   *
   * @param {string} key
   * @param {object} val
   */
  _parseLink(key, val) {
    const { connects, display } = val;

    const newSprings = this._parseConnects(key, connects);

    for (const spring of newSprings) {
      if (display) {
        this._addDisplaySpring(display, spring);
      }
      this.springs.push(spring);
    }
  }

  /**
   *
   * @param {string} display The display category
   * @param {object} spring
   */
  _addDisplaySpring(display, spring) {

    if (!Object.hasOwn(this.displaySprings, display)) {
      this.displaySprings[display] = [];
    }
    this.displaySprings[display].push(spring);
  }

  /**
   *
   * @param {string} key
   * @param {object} connects
   */
  _parseConnects(key, connects) {

    if (Array.isArray(connects[1])) {

      // parse one-to-many link
      const fromBall = this.namedBalls[connects[0]];
      const to = connects[1].map((ballName) => this.namedBalls[ballName]);
      return to.map((toBall) => new Spring(fromBall, toBall));

    }
    else if (connects.length === 2) {

      // parse single named spring which could potentially be animated
      const [fromName, toName] = connects;
      const spring = new Spring(this.namedBalls[fromName], this.namedBalls[toName]);
      this.namedSprings[key] = spring;
      return [spring];

    }

    // build spring for all combination of two
    const balls = connects.map((ballName) => this.namedBalls[ballName]);
    const result = [];
    for (let i = 0; i < connects.length; i++) {
      for (let j = i + 1; j < connects.length; j++) {
        result.push(new Spring(balls[i], balls[j]));
      }
    }
    return result;

  }
}
