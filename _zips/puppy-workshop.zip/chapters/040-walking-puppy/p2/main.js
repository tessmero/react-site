/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 2e-4 };
const AIR_RESISTANCE = 1e-3;
const RESTITUTION = 0.9;
const SPRING_STIFFNESS = 1e-2;
const SPRING_DAMPING = 1e-2;

// p2.js collision groups
const BALL_GROUP = 1;
const PLATFORM_GROUP = 2;

// p2.js materials
const PLATFORM_MAT = new p2.Material();
const SLIPPERY_BALL_MAT = new p2.Material();
const STICKY_BALL_MAT = new p2.Material();

// walking puppy scene
const thick = 10; // thickness of walls

const scene = {

  // no loose balls
  balls: [],

  // one puppy
  puppies: [
    { position: { x: 20, y: 20 } },
  ],

  // some solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left wall
    { box: [100 - thick, 0, thick, 100] }, // right wall
    { box: [0, 0, 100, thick] }, // ceiling
    { box: [0, 100 - thick, 100, thick] }, // floor

  ],
};

// construct Ball, and Platform instances based on scene
let balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// construct Puppies composed of Ball and Spring instances
let springs = [];
const puppies = [];
for (const puppyParams of scene.puppies) {
  const puppy = new Puppy(puppyParams);
  puppies.push(puppy);
  balls = [...balls, ...puppy.balls];
  springs = [...springs, ...puppy.springs];
}

// initialize p2.js physics world
const p2World = new p2.World({
  gravity: [GRAVITY.x, GRAVITY.y],
});

p2World.addContactMaterial(new p2.ContactMaterial(
  PLATFORM_MAT, SLIPPERY_BALL_MAT, {
    friction: 0,
    restitution: RESTITUTION,
  }
));
p2World.addContactMaterial(new p2.ContactMaterial(
  PLATFORM_MAT, STICKY_BALL_MAT, {
    friction: 1e6,
    restitution: RESTITUTION,
  }
));

// register physics objects to p2 engine
for (const { body } of ([...balls, ...platforms])) {
  p2World.addBody(body);
}
for (const { p2obj } of springs) {
  p2World.addSpring(p2obj);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  mouseMove: ({ x, y }) => {
    platforms[0].body.position = [x, y];
  },
});

const STEP_DURATION = 3; // (milliseconds) simulation time resolution
let time = Date.now() // (milliseconds) system time

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // check how much time has passed since the last frame was drawn
  const newTime = Date.now();
  const dt = newTime - time;
  time = newTime;
  if (dt > 200) {
    return; // lagging or regained focus, do nothing this frame
  }
  const nSteps = Math.round(dt / STEP_DURATION);

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    for (const puppy of puppies) {
      puppy.updateWalkAnim();
    }
    p2World.step(STEP_DURATION);
  }

// draw the updated scene
ctx.clearRect(...clearRect);

for (const platform of platforms) {
  Graphics.drawPlatform(ctx, platform);
}

for (const puppy of puppies) {
  Graphics.drawPuppy(ctx, puppy);
}

// for (const ball of balls) {
//   Graphics.drawBall(ctx, ball);
// }
// for(const spring of springs) {
//   Graphics.drawSpring(ctx,spring)
// }


}
requestAnimationFrame(animationLoop) // queue first loop