/**
 * @file Graphics
 *
 * Routines for drawing the balls and springs scene on the
 * canvas 2d graphics context.
 */
class Graphics {

  /**
   * Draw a bouncy ball.
   * @param {object} ctx The graphics context
   * @param {object} ball The Ball instance to draw
   */
  static drawBall(ctx, ball) {

    const { x, y } = ball.getPosition();
    const angle = ball.getAngle();

    ctx.strokeStyle = 'black';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(x, y, ball.radius, angle, angle + Math.PI * 2);
    ctx.stroke();
  }

  /**
   * Draw a solid platform.
   * @param {object} ctx The graphics context
   * @param {object} platform The Platform instance to draw
   */
  static drawPlatform(ctx, platform) {

    ctx.fillStyle = 'black';

    ctx.beginPath();
    for (const { x, y } of platform.getVertices()) {
      ctx.lineTo(x, y);
    }
    ctx.closePath();

    ctx.fill();
  }

  /**
   * Draw a spring.
   * @param {object} ctx The graphics context
   * @param {object} spring The Spring instance to draw
   */
  static drawSpring(ctx, spring) {

    const path = [
      spring.ball1.getPosition(),
      spring.ball2.getPosition(),
    ];

    ctx.strokeStyle = 'red';
    ctx.lineWidth = 1;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    for (const { x, y } of path) {
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  static puppyColor = 'rgb(200,200,100)';

  /**
   * Draw a puppy.
   * @param {object} ctx The graphics context
   * @param {object} puppy The Puppy instance to draw
   */
  static drawPuppy(ctx, puppy) {

    // draw "limb" type torso and legs
    ctx.strokeStyle = Graphics.puppyColor;
    ctx.lineWidth = puppy.radius * 2;
    ctx.lineCap = 'round';
    ctx.beginPath();
    for (const spring of puppy.displaySprings.limb) {
      const pos1 = spring.ball1.getPosition();
      const pos2 = spring.ball2.getPosition();
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(pos2.x, pos2.y);
    }
    ctx.stroke();

    // draw wagging tail
    ctx.lineWidth = puppy.radius * 1.5;
    ctx.beginPath();
    for (const spring of puppy.displaySprings.tail) {
      const pos1 = spring.ball1.getPosition();
      const pos2 = spring.ball2.getPosition(); // default tail tip

      // compute position of tip with wagging animation
      const { avg, add, subtract, getAngle, getLength, polarToCartesian: polar } = VectorMath;
      const delta = subtract(pos2, pos1);
      const angleOffset = avg(
        puppy.wagUp, puppy.wagDown,
        0.5 + 0.5 * Math.sin(Date.now() / puppy.tailWagPeriod * (2 * Math.PI))
      );
      const wagTip = add(pos1, polar(getAngle(delta) + angleOffset, getLength(delta)));
      ctx.moveTo(pos1.x, pos1.y);
      ctx.lineTo(wagTip.x, wagTip.y);

    }
    ctx.stroke();

    // draw head with face and ears
    for (const spring of puppy.displaySprings.head) {
      const pos1 = spring.ball1.getPosition();
      const pos2 = spring.ball2.getPosition();
      Graphics._drawHead(ctx, puppy, pos1, pos2);
    }

  }

  /**
   * Draw puppy head, ears, and face.
   * @param {object} ctx
   * @param {object} puppy
   * @param {Vector} pos1
   * @param {Vector} pos2
   */
  static _drawHead(ctx, puppy, pos1, pos2) {

    ctx.fillStyle = Graphics.puppyColor;

    const rad = puppy.radius * 2; // head radius
    const scale = 55 * puppy.radius;
    const eaDist = 0.038 * scale;
    const eaDa = 0.7; // radians offset between ears
    const eaRad = 0.015 * scale; // ear radius

    const { add, subtract, getAngle, polarToCartesian: polar } = VectorMath;

    const angle = getAngle(subtract(pos2, pos1)) - Math.PI / 2;
    const pos = pos2;

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, rad, 0, Math.PI * 2);
    ctx.fill();

    const eaCenters = [
      add(pos, polar(angle + eaDa, eaDist)),
      add(pos, polar(angle - eaDa, eaDist)),
    ];
    eaCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, eaRad, 0, Math.PI * 2);
      ctx.fill();
    });

    Graphics._drawFace(ctx, puppy, pos, angle);
  }

  /**
   * Draw puppy eyes and mouth.
   * @param {object} ctx
   * @param {object} puppy
   * @param {Vector} pos
   * @param {number} angle
   */
  static _drawFace(ctx, puppy, pos, angle) {

    ctx.strokeStyle = 'black';
    ctx.fillStyle = 'black';
    ctx.lineWidth = 0.5;

    const { add, polarToCartesian: polar } = VectorMath;
    const scale = 55 * puppy.radius;

    // mouth
    const mDist = 0.02 * scale;
    const mDa = 0.3; // radians
    const mRad = 0.008 * scale;
    const mArc = 0.7; // radius
    const mO = polar(angle, -0.022 * scale);
    const mCenters = [
      add(pos, polar(angle + mDa, mDist), mO),
      add(pos, polar(angle - mDa, mDist), mO),
    ];
    mCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, mRad, Math.PI + angle - mArc, Math.PI + angle + mArc);
      ctx.stroke();
    });

    // nose
    const nCenter = add(pos, polar(angle, -0.0065 * scale));
    ctx.beginPath();
    ctx.ellipse(nCenter.x, nCenter.y,
      0.002 * scale, // height
      0.003 * scale, // width
      angle, 0, Math.PI * 2);
    ctx.fill();

    // eyes
    const eyeDist = 0.012 * scale;
    const eyeDa = 0.9; // radians
    const eyeRad = 0.004 * scale;
    const eyeCenters = [
      add(pos, polar(angle + eyeDa, eyeDist)),
      add(pos, polar(angle - eyeDa, eyeDist)),
    ];

    ctx.fillStyle = 'black';
    eyeCenters.forEach((p) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, eyeRad, 0, 2 * Math.PI);
      ctx.fill();
    });

  }
}
