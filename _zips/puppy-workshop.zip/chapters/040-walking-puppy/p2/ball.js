/**
 * @file Ball
 * bouncy ball
 */
class Ball {

  /**
   * Construct a bouncy ball.
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   * @param {number} params.radius The size of the ball
   */
  constructor(params) {
    const { position, velocity, radius } = params;

    // build p2.js circle body
    const body = new p2.Body({
      mass: 1,
      position: [position.x, position.y],
      velocity: [velocity.x, velocity.y],
      damping: AIR_RESISTANCE,
      angularDamping: 1,
    });
    const shape = new p2.Circle({
      radius,
      material: SLIPPERY_BALL_MAT,
    });
    shape.collisionGroup = BALL_GROUP; // is ball
    shape.collisionMask = PLATFORM_GROUP; // collides with platforms
    body.addShape(shape);

    // body will be registered in p2 engine
    // also used to check the position for drawing
    this.body = body;

    // radius used for drawing
    this.radius = radius;
  }

  /**
   * Set friction (grip). Used in walking animation.
   * @param {number} friction
   */
  setFriction(friction) {
    const mat = friction ? STICKY_BALL_MAT : SLIPPERY_BALL_MAT;
    for (const shape of this.body.shapes) {
      shape.material = mat;
    }
  }

  /**
   * Get position for purposes of drawing
   * @returns {Vector} The position of the body
   */
  getPosition() {
    const [x, y] = this.body.position;
    return { x, y };
  }

  /**
   * Get angle for purposes of drawing
   * @returns {number} The angle of the body
   */
  getAngle() {
    return this.body.angle;
  }
}
