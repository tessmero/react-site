/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 1e-3 };
const AIR_RESISTANCE = 1e-3;
const RESTITUTION = 0.99;
const SPRING_STIFFNESS = 8e-3;
const SPRING_DAMPING = 8e-3;

// matter.js collision categories
const BALL_CATEGORY = 1;
const PLATFORM_CATEGORY = 2;

// walking puppy scene
const thick = 10; // thickness of walls

const scene = {

  // no loose balls
  balls: [],

  // one puppy
  puppies: [
    { position: { x: 20, y: 20 } },
  ],

  // some solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left wall
    { box: [100 - thick, 0, thick, 100] }, // right wall
    { box: [0, 0, 100, thick] }, // ceiling
    { box: [0, 100 - thick, 100, thick] }, // floor

  ],
};

// construct Ball, and Platform instances based on scene
let balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// construct Puppies composed of Ball and Spring instances
let springs = [];
const puppies = [];
for (const puppyParams of scene.puppies) {
  const puppy = new Puppy(puppyParams);
  puppies.push(puppy);
  balls = [...balls, ...puppy.balls];
  springs = [...springs, ...puppy.springs];
}

const engine = Matter.Engine.create({ gravity: GRAVITY });

// enable elastic bouncing
// https://github.com/liabru/matter-js/issues/394
Matter.Resolver._restingThresh = 0;

// add physics objects to matter.js engine
for (const { body } of ([...balls, ...platforms])) {
  Matter.World.add(engine.world, body);
}
for (const { matterObj } of springs) {
  Matter.World.add(engine.world, matterObj);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  mouseMove: (mousePos) => {
    Matter.Body.setPosition(platforms[0].body, mousePos);
  },
});

const STEP_DURATION = 3; // (milliseconds) simulation time resolution
let time = Date.now() // (milliseconds) system time

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // check how much time has passed since the last frame was drawn
  const newTime = Date.now();
  const dt = newTime - time;
  time = newTime;
  if (dt > 200) {
    return; // lagging or regained focus, do nothing this frame
  }
  const nSteps = Math.round(dt / STEP_DURATION);

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    for (const puppy of puppies) {
      puppy.updateWalkAnim();
    }
    Matter.Engine.update(engine, STEP_DURATION * (1000 / 60));
  }

// draw the updated scene
ctx.clearRect(...clearRect);

for (const platform of platforms) {
  Graphics.drawPlatform(ctx, platform);
}

for (const puppy of puppies) {
  Graphics.drawPuppy(ctx, puppy);
}

// for (const ball of balls) {
//   Graphics.drawBall(ctx, ball);
// }
// for(const spring of springs) {
//   Graphics.drawSpring(ctx,spring)
// }


}
requestAnimationFrame(animationLoop) // queue first loop