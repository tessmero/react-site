/**
 * @file Spring constraint between two balls
 */
class Spring {

  /**
   * Create a new spring.
   * @param {object} ball1 The first ball to connect
   * @param {object} ball2 The second ball to connect
   * @param {object} params The optional parameters
   * @param {number} params.stiffness
   * @param {number} params.damping
   */
  constructor(ball1, ball2, params = {}) {
    const {
      stiffness = SPRING_STIFFNESS,
      damping = SPRING_DAMPING,
    } = params;

    this.ball1 = ball1;
    this.ball2 = ball2;

    this.matterObj = Matter.Constraint.create({
      bodyA: ball1.body,
      bodyB: ball2.body,
      stiffness, damping,
    });
  }

  /**
   * Adjust rest length. Used for walking animation.
   * @param {number} length
   */
  setRestLength(length) {
    this.matterObj.length = length;
  }
}
