/**
 * @file Platform
 * a solid barrier that the ball can collide with
 */
class Platform {

  /**
   * Construct an platform based on flexible shape parameters.
   * @param {object} params The (center/radius/n) or box:[x,y,w,h] or vertices
   */
  constructor(params) {

    // interpret flexible parameters as standard shape
    const { center, vertices } = VectorMath.parseVertices(params);

    // create matter.js body to be registered in physics engine
    this.body = Matter.Bodies.fromVertices(
      center.x, center.y, // center position
      [vertices], // vertex sets
      {
        isStatic: true,
        friction: 0,
        frictionStatic: 0,
        restitution: RESTITUTION,
      }
    );

    // prepare to account for changes in body position when drawing
    this._originalCenter = center;
    this._originalVertices = vertices;
  }

  /**
   * Get vertices for purposes of drawing, accounting for changes in body position.
   */
  * getVertices() {
    const delta = VectorMath.subtract(this.body.position, this._originalCenter);
    for (const vert of this._originalVertices) {
      yield VectorMath.add(vert, delta);
    }
  }

}
