/**
 * @file Graphics
 *
 * Routines for drawing the bouncy ball on the
 * canvas 2d graphics context.
 */
class Graphics {

  /**
   * Draw a sliding ball.
   * @param {object} ctx The graphics context
   * @param {object} ball The Ball instance to draw
   */
  static drawBall(ctx, ball) {

    const { x, y } = ball.getPosition();
    const angle = ball.getAngle();

    ctx.fillStyle = 'black';
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(x, y, ball.radius, angle, angle + Math.PI * 2);
    ctx.stroke();
  }

  /**
   * Draw a solid platform.
   * @param {object} ctx The graphics context
   * @param {object} platform The Platform instance to draw
   */
  static drawPlatform(ctx, platform) {

    ctx.fillStyle = 'black';

    ctx.beginPath();
    for (const { x, y } of platform.getVertices()) {
      ctx.lineTo(x, y);
    }
    ctx.closePath();

    ctx.fill();
  }
}
