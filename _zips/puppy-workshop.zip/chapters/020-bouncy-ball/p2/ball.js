/**
 * @file Ball
 * bouncy ball
 */
class Ball {

  /**
   * Construct a bouncy ball.
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   * @param {number} params.radius The size of the ball
   */
  constructor(params) {
    const { position, velocity, radius } = params;

    // build p2.js circle body
    const body = new p2.Body({
      mass: 1,
      position: [position.x, position.y],
      velocity: [velocity.x, velocity.y],
      damping: AIR_RESISTANCE,
    });
    const shape = new p2.Circle({ radius });
    body.addShape(shape);

    // body will be registered in p2 engine
    // also used to check the position for drawing
    this.body = body;

    // radius used for drawing
    this.radius = radius;
  }

  /**
   * Get position for purposes of drawing
   * @returns {Vector} The position of the body
   */
  getPosition() {
    const [x, y] = this.body.position;
    return { x, y };
  }

  /**
   * Get angle for purposes of drawing
   * @returns {number} The angle of the body
   */
  getAngle() {
    return this.body.angle;
  }
}
