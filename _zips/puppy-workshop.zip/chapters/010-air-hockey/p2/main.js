/**
 * @file main.js entry point
 * top-level objects and main loop
 */

// air hockey scene
const thick = 10; // thickness of walls
const scene = {

  // one sliding disk
  disks: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0.15, y: 0.1 },
      radius: 5,
    },
  ],

  // 5 solid obstacles
  obstacles: [

    // center obstacle that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // four outer walls
    { box: [0, 0, thick, 100] }, // left
    { box: [100 - thick, 0, thick, 100] }, // right
    { box: [0, 0, 100, thick] }, // top
    { box: [0, 100 - thick, 100, thick] }, // bottom
  ],
};

// construct Disk and Obstacle instances
const disks = scene.disks.map((p) => new Disk(p));
const obstacles = scene.obstacles.map((p) => new Obstacle(p));

// initialize p2.js physics world
const p2World = new p2.World({
  gravity: [0, 0],
});

// enable elastic bouncing
p2World.defaultContactMaterial.restitution = 1;
p2World.defaultContactMaterial.friction = 0;

// add disks and obstacles to p2 engine
for (const { body } of ([...disks, ...obstacles])) {
  p2World.addBody(body);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first obstacle to the mouse position
  mouseMove: ({ x, y }) => {
    obstacles[0].body.position = [x, y];
  },
});

// sanity check for first few steps
// change in disk position should equal its velocity
let totalSteps = 0;
function sanityCheck() {
  totalSteps++;
  if (totalSteps < 10) {
    const diskStart = scene.disks[0]; // initial disk state
    const delta = VectorMath.subtract(disks[0].getPosition(), diskStart.position);
    const expectedLength = STEP_DURATION * totalSteps * VectorMath.getLength(diskStart.velocity);
    const actualLength = VectorMath.getLength(delta);
    const score = Math.round(100 * actualLength / expectedLength);
    console.log({ totalSteps, score, expectedLength, actualLength });
  }
}


const STEP_DURATION = 3; // (milliseconds) simulation time resolution
let time = Date.now() // (milliseconds) system time

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // check how much time has passed since the last frame was drawn
  const newTime = Date.now();
  const dt = newTime - time;
  time = newTime;
  if (dt > 200) {
    return; // lagging or regained focus, do nothing this frame
  }
  const nSteps = Math.round(dt / STEP_DURATION);

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    p2World.step(STEP_DURATION);

    // sanityCheck();
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const disk of disks) {
    Graphics.drawDisk(ctx, disk);
  }
  for (const obstacle of obstacles) {
    Graphics.drawObstacle(ctx, obstacle);
  }

}
requestAnimationFrame(animationLoop) // queue first loop