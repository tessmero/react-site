/**
 * @file Disk
 * sliding circle on airhockey table
 */
class Disk {

  /**
   * Construct a sliding disk.
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   * @param {number} params.radius The size of the disk
   */
  constructor(params) {
    const { position, velocity, radius } = params;

    // build p2.js circle body
    const body = new p2.Body({
      mass: 1,
      position: [position.x, position.y],
      velocity: [velocity.x, velocity.y],
      damping: 0, // no air friction
    });
    const shape = new p2.Circle({ radius });
    body.addShape(shape);

    // body will be registered in p2 engine
    // also used to check the position for drawing
    this.body = body;

    // radius used for drawing
    this.radius = radius;
  }

  /**
   * Get position for purposes of drawing
   * @returns {Vector} The position of the body
   */
  getPosition() {
    const [x, y] = this.body.position;
    return { x, y };
  }

  /**
   * Get angle for purposes of drawing
   * @returns {number} The angle of the body
   */
  getAngle() {
    return this.body.angle;
  }
}
