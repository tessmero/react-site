/**
 * @file Obstacle
 * a solid barrier that the disk can collide with
 */
class Obstacle {

  /**
   * Construct an obstacle based on flexible shape parameters.
   * @param {object} params The (center/radius/n) or box:[x,y,w,h] or vertices
   */
  constructor(params) {

    // interpret flexible parameters as standard shape
    const { center, vertices } = VectorMath.parseVertices(params);

    // construct body to be registered in p2 physics engine
    const body = new p2.Body({
      mass: 0,
      position: [center.x, center.y],
    });
    const shape = new p2.Convex({

      // vertices relative to center
      vertices: vertices.map(({ x, y }) => [x - center.x, y - center.y]),
    });
    body.addShape(shape);

    // body will be registered in
    this.body = body;

    // prepare to account for changes in body position when drawing
    this._originalCenter = center;
    this._originalVertices = vertices;
  }

  /**
   * Get vertices for purposes of drawing, accounting for changes in body position.
   */
  * getVertices() {
    const [x, y] = this.body.position; // current position
    const delta = VectorMath.subtract({ x, y }, this._originalCenter);
    for (const vert of this._originalVertices) {
      yield VectorMath.add(vert, delta);
    }
  }

}
