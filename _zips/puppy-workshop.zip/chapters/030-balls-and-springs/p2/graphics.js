/**
 * @file Graphics
 *
 * Routines for drawing the balls and springs scene on the
 * canvas 2d graphics context.
 */
class Graphics {

  /**
   * Draw a bouncy ball.
   * @param {object} ctx The graphics context
   * @param {object} ball The Ball instance to draw
   */
  static drawBall(ctx, ball) {

    const { x, y } = ball.getPosition();
    const angle = ball.getAngle();

    ctx.strokeStyle = 'black';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(x, y, ball.radius, angle, angle + Math.PI * 2);
    ctx.stroke();
  }

  /**
   * Draw a solid platform.
   * @param {object} ctx The graphics context
   * @param {object} platform The Platform instance to draw
   */
  static drawPlatform(ctx, platform) {

    ctx.fillStyle = 'black';

    ctx.beginPath();
    for (const { x, y } of platform.getVertices()) {
      ctx.lineTo(x, y);
    }
    ctx.closePath();

    ctx.fill();
  }

  /**
   * Draw a spring.
   * @param {object} ctx The graphics context
   * @param {object} spring The Spring instance to draw
   */
  static drawSpring(ctx, spring) {

    const path = Graphics._zigzag({
      start: spring.ball1.getPosition(),
      end: spring.ball2.getPosition(),
    });

    ctx.strokeStyle = 'red';
    ctx.lineWidth = 1;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    for (const { x, y } of path) {
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  /**
   *
   * @param {object} params
   */
  static* _zigzag(params) {

    const {
      start, end,
      radius = 2, // distance from straight line center to vertices
      n = 5, // number of vertices
      pad = 5, // length of straight segments at either end
    } = params;

    const { add, subtract, getAngle, avg, polarToCartesian } = VectorMath;

    const delta = subtract(end, start);
    const angle = getAngle(delta);

    // account for straight segments at ends
    const padding = polarToCartesian(angle, pad);
    const a = add(start, padding);
    const b = subtract(end, padding);

    // offset from straight line and zig zag points
    const ribDelta = polarToCartesian(angle + Math.PI / 2, radius);

    // straight segment at start
    yield start;
    yield avg(a, b, 0.5 / n);

    // zigzag segments in middle
    for (let i = 1; i < n; i++) {
      const straightPoint = avg(a, b, i / n);
      if (i % 2) {
        yield add(straightPoint, ribDelta);
      }
      else {
        yield subtract(straightPoint, ribDelta);
      }
    }

    // straight segment at end
    yield avg(b, a, 0.5 / n);
    yield end;
  }
}
