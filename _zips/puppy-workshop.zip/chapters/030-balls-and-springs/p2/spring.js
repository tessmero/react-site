/**
 * @file Spring constraint between two balls
 */
class Spring {

  /**
   * Create a new spring.
   * @param {object} ball1 The first ball to connect
   * @param {object} ball2 The second ball to connect
   * @param {object} params The optional parameters
   * @param {number} params.stiffness
   * @param {number} params.damping
   */
  constructor(ball1, ball2, params = {}) {
    const {
      stiffness = SPRING_STIFFNESS,
      damping = SPRING_DAMPING,
    } = params;

    this.ball1 = ball1;
    this.ball2 = ball2;

    this.p2obj = new p2.LinearSpring(
      ball1.body, ball2.body,
      { stiffness, damping },
    );
  }
}
