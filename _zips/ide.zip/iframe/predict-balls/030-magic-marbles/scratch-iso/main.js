/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const STEP_DURATION = 3; // milliseconds
const GRAVITY = { x: 1e-5, y: -1e-3, z: 1e-5 }; // change in velocity per step
const AIR_RESISTANCE = 4e-3; // fraction of speed lost per step
const RESTITUTION = 0.9; // fraction of speed maintained in bounce

const SPHERE_RADIUS = 5; // size of spheres

// settings for springs between neighboring spheres
const SPHERE_STIFFNESS = 0.04;
const SPHERE_DAMPING = 0.02;
const SPHERE_COHESION = 0; // how much spheres stick together

const {targets,spheres,boxes} = new Scene()

// set up graphics context and start listening for input

const predictSteps = 10000; // how many steps to predict
const record = new Record(predictSteps, spheres.length);

// precompute physics simulation and save record
for (let i = 0; i < predictSteps; i++) {

  // advance by one step
  for (const sphere of spheres) {
    sphere.step(boxes); // collide sphere with boxes
  }
  for (let a = 0; a < spheres.length; a++) {
    for (let b = 0; b < a; b++) {
      spheres[a].collideSphere(spheres[b]); // collide sphere with sphere
    }
  }

  // finished one step
  // record all the sphere's positions
  record.saveSnapshot(i, spheres);
}

// now spheres are in their final recorded state
// check their positions and apply colors
for (const sphere of spheres) {
  const { z } = sphere.position;
  for (const { region: [min, max], color } of targets) {
    if (z > min && z < max) {
      sphere.color = color;
    }
  }
}

// get system time in units of steps
function getStepTime() {
  return Date.now() / STEP_DURATION;
}

// start keeping track of time
let time = getStepTime();

Graphics.init({ boxes, spheres });

let playbackStepIndex = 0;
function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;
  playbackStepIndex = playbackStepIndex + nSteps;

  if (playbackStepIndex < predictSteps) {

    // set the sphere positions based on the record
    record.loadSnapshot(playbackStepIndex, spheres);
  }

  // draw the updated scene
  Graphics.drawScene({ boxes, spheres });

  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop
