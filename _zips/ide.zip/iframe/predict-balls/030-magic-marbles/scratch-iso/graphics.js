/**
 * @file Graphics
 *
 * Routines for drawing the air hockey scene on the
 * canvas 2d graphics context.
 */

const GFX_SPHERE_RADIUS = 2.5; // size of spheres

// positions in 3d world
const UNIT_CUBE_3D = [
  { x: 50, y: 50, z: 50 }, // origin
  { x: 51, y: 50, z: 50 }, // right +x
  { x: 50, y: 51, z: 50 }, // up +y
  { x: 50, y: 50, z: 51 }, // left +z
];

const UNIT_CUBE_2D = [
  { x: 50, y: 50 }, // origin
  { x: 50.4, y: 50.2 }, // right (+x)
  { x: 50, y: 49.5 }, // up (+y)
  { x: 49.5, y: 50.15 }, // left (+z)
];

const d2x = {
  x: UNIT_CUBE_2D[1].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[1].y - UNIT_CUBE_2D[0].y,
};
const d2y = {
  x: UNIT_CUBE_2D[2].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[2].y - UNIT_CUBE_2D[0].y,
};
const d2z = {
  x: UNIT_CUBE_2D[3].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[3].y - UNIT_CUBE_2D[0].y,
};

// Compute the magnitude of each 2D direction
function mag2D(v) {
  return Math.sqrt(v.x * v.x + v.y * v.y);
}

const mx = mag2D(d2x);
const my = mag2D(d2y);
const mz = mag2D(d2z);

// Camera direction inversely proportional to 2D projection lengths
const camDir = {
  x: 1 / mx,
  y: 1 / my,
  z: 1 / mz,
};

// Normalize the direction
const len = VectorMath.getLength(camDir);
const normDir = {
  x: camDir.x / len,
  y: camDir.y / len,
  z: camDir.z / len,
};

// Place camera far along this direction
const scale = 1000;
const CAMERA = {
  x: UNIT_CUBE_3D[0].x + normDir.x * scale,
  y: UNIT_CUBE_3D[0].y + normDir.y * scale,
  z: UNIT_CUBE_3D[0].z + normDir.z * scale,
};

/**
 *
 */
class Graphics {

  /**
   *
   */
  static init() {

    // prepare to draw on the canvas element in our html document
    const canvas = document.getElementsByTagName('canvas')[0];
    canvas.width = canvas.offsetWidth * devicePixelRatio;
    canvas.height = canvas.offsetHeight * devicePixelRatio;

    // set up graphics context with standard coordinate system
    // where (50,50) is the center of the display area
    const canvasSize = Math.min(canvas.width, canvas.height);
    const offsetX = (canvas.width - canvasSize) / 2;
    const offsetY = (canvas.height - canvasSize) / 2;
    const ctx = canvas.getContext('2d');
    const scale = canvasSize / 100;
    ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY);

    Graphics.ctx = ctx;

    // compute x,y,w,h of the whole display in standard coordinates
    Graphics.clearRect = [
      (0 - offsetX) / scale,
      (0 - offsetY) / scale,
      canvas.width / scale,
      canvas.height / scale,
    ];

  }

  /**
   * Draw an array of Sphere instances
   * @param {object} ctx The graphics context
   * @param {object} params The parameters
   * @param {object[]} params.boxes The Box instances to draw
   * @param {object[]} params.spheres The Sphere instances to draw
   */
  static drawScene(params) {
    const ctx = Graphics.ctx;
    ctx.clearRect(...Graphics.clearRect);
    const { boxes, spheres } = params;

    // sort spheres by their distance from the camera
    // (used for spheres to occlude other spheres)
    const sortedSpheres = spheres
      .map((sphere) => ({
        sphere,
        dist: Math.hypot(
          sphere.position.x - CAMERA.x,
          sphere.position.y - CAMERA.y,
          sphere.position.z - CAMERA.z
        ),
      }))
      .sort((a, b) => b.dist - a.dist)
      .map((obj) => obj.sphere);

    // categorize spheres into foreground and background
    // (hack for boxes to occlude spheres)
    const backSpheres = [];
    const frontpheres = [];
    for (const sphere of sortedSpheres) {
      const { position } = sphere;
      if (position.x < 0 || position.y < 0 || position.z < 0) {
        backSpheres.push(sphere);
      }
      else {
        frontpheres.push(sphere);
      }
    }

    // draw spheres behind boxes, starting with those farthest away
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = 'black';
    for (const sphere of backSpheres) {
      this._drawSphere(ctx, sphere);
    }

    // draw all boxes
    // (assume they are sorted to occlude eachother)
    for (const box of boxes) {
      if (!box.hidden) {
        this._drawBox(ctx, box);
      }
    }

    // draw spheres in front of boxes, starting with those farthest away
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = 'black';
    for (const sphere of frontpheres) {
      this._drawSphere(ctx, sphere);
    }

    // draw hidden boxes as wireframes
    for (const box of boxes) {
      if (box.hidden) {
        this._drawBox(ctx, box);
      }
    }

  }

  /**
   *
   * @param ctx
   * @param sphere
   */
  static _drawSphere(ctx, sphere) {

    // project 3d position onto 2d isometric screen
    const center2D = Graphics._isoProject(sphere.position);
    ctx.fillStyle = sphere.color;
    ctx.beginPath();
    ctx.arc(center2D.x, center2D.y, GFX_SPHERE_RADIUS, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  /**
   * Draw a solid box.
   * @param {object} ctx The graphics context
   * @param {object} box The Box instance to draw
   */
  static _drawBox(ctx, box) {

    const { left, right, top } = Graphics._getFaces(box);

    if (box.hidden) {

      // draw hidden box as wireframe
      ctx.lineWidth = 0.05;
      const style = { strokeStyle: 'black' };
      Graphics._drawFace(ctx, { face: top, ...style });
      Graphics._drawFace(ctx, { face: left, ...style });
      Graphics._drawFace(ctx, { face: right, ...style });

    }
    else {

      ctx.lineWidth = 0.05;
      const style = { strokeStyle: 'black' }

      // fill regular box
      Graphics._drawFace(ctx, { face: top, fillStyle: '#FBFBFB', ...style });
      Graphics._drawFace(ctx, { face: left, fillStyle: '#DDD', ...style });
      Graphics._drawFace(ctx, { face: right, fillStyle: '#CCC', ...style });
    }
  }

  /**
   *
   * @param ctx
   * @param params
   */
  static _drawFace(ctx, params) {

    const { face, fillStyle, strokeStyle } = params;

    const vertices3D = face;
    const vertices2D = vertices3D.map((v) => Graphics._isoProject(v));

    ctx.beginPath();

    // Draw front face (first 4 vertices)
    for (const { x, y } of vertices2D) {
      ctx.lineTo(x, y);
    }
    ctx.closePath();

    if (fillStyle) {
      ctx.fillStyle = fillStyle;
      ctx.fill();
    }

    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      ctx.stroke();
    }
  }

  /**
   *
   * @param box
   */
  static _getFaces(box) {
    const b = box.bounds;
    return {
      'right': [
        { x: b.maxX, y: b.minY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.minY, z: b.maxZ },
      ],
      'left': [
        { x: b.minX, y: b.minY, z: b.maxZ },
        { x: b.minX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.minY, z: b.maxZ },
      ],
      'top': [
        { x: b.minX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.minX, y: b.maxY, z: b.maxZ },
      ],
    };
  }

  /**
   *  project a 3D point to 2D canvas cube mapping
   * @param point3D
   */
  static _isoProject(point3D) {
    // Basis: origin, x+, y+, z+ (indices 0,1,2,3)
    const [p0, p1, p2, p3] = UNIT_CUBE_3D;
    const [q0, q1, q2, q3] = UNIT_CUBE_2D;

    // Compute weights for each axis
    const dx = point3D.x - p0.x;
    const dy = point3D.y - p0.y;
    const dz = point3D.z - p0.z;

    // For a unit cube, dx,dy,dz are in [0,1]
    // Interpolate along axes
    return {
      x: q0.x + (q1.x - q0.x) * dx + (q2.x - q0.x) * dy + (q3.x - q0.x) * dz,
      y: q0.y + (q1.y - q0.y) * dx + (q2.y - q0.y) * dy + (q3.y - q0.y) * dz,
    };
  }
}
