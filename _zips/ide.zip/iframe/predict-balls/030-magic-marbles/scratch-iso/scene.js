/**
 * @file magic marbles scene
 */

/**
 *
 */
class Scene {


  /**
   *
   */
  constructor() {

    const thick = 3 // thickness of walls
    const width = 50 
    const tall = 200
    const inner = width - 2 * thick // inner dimension after accounting for both walls
    this._params = {tall,width,thick,inner} 

    // stack of spheres above scene
    this._spheres = [
      {
        stack: 100,
        position: { x: 50, y: 200, z: 50 },
        velocity: { x: 0, y: 0, z: 0 },
        radius: 5,
      },
    ];


    // color-coded target regions for the marbles to land in
    this._targets = this._buildTargets() 


    // rectangular objects
    this._boxes = [
      ...this._buildWalls(),
      ...this._buildRods(),
    ]

  }

  _buildTargets(){
    const {tall,width,thick,inner} = this._params

    const colors = ['#0079FF', '#89CFF0', '#00DFA2', '#F6FA70', '#FFA07A', '#FF0060'];
    const minX = 50-width/2;   
    const maxX = 50+width/2;  
    const numRegions = colors.length;
    const step = (maxX - minX) / numRegions;
    const targets = [];
    for (let i = 0; i < numRegions; i++) {
      targets.push({
        color: colors[i],
        region: [minX + i * step, minX + (i + 1) * step],
      });
    }
    return targets
  }

  _buildWalls(){
    const {tall,width,thick,inner} = this._params

    return [

      // Bottom Wall (Y- axis)
      {
        center: { x: 50, y: 50 - tall / 2 - thick / 2, z: 50 },
        dimensions: { x: inner, y: thick, z: inner },
      },

      // Top Wall (Y+ axis)
      // {
      //   center: { x: 50, y: 100 - thick / 2, z: 50 },
      //   dimensions: { x: inner, y: thick, z: inner },
      //   hidden: true,
      // },

      // Back Left Wall (X- axis)
      {
        center: { x: 50 - width / 2 + thick / 2, y: 50, z: 50 },
        dimensions: { x: thick, y: tall, z: inner },
        display: 'wall',
      },

      // Back right Wall (Z- axis)
      {
        center: { x: 50, y: 50, z: 50 - width / 2 + thick / 2 },
        dimensions: { x: inner, y: tall, z: thick },
        display: 'wall',
      },

      // Front Left Wall (Z+ axis)
      {
        center: { x: 50, y: 50, z: 50 + width / 2 - thick / 2 },
        dimensions: { x: inner, y: tall, z: thick },
        display: 'wall',
        hidden: true, // only used for iso graphics
      },

      // front Right Wall (X+ axis, right)
      {
        center: { x: 50 + width / 2 - thick / 2, y: 50, z: 50 },
        dimensions: { x: thick, y: tall, z: inner },
        display: 'wall',
        hidden: true, // only used for iso graphics
      },
    ];
  }

  _buildRods(){

    const {tall,width,thick,inner} = this._params
    const noiseAmp = inner/2 - thick

    const y0 = 50-tall/4
    const y1 = 50+tall/4
    const nRods = 20

    const rods = []

    for( let i = 0 ; i < nRods ; i++ ){
      const y = VectorMath.avg(y0,y1,i/nRods)
      const noise = (2*Math.random()-1) * noiseAmp


      const rod = Math.random() > .5 ? {

        // horizontal along x axis
        center: { x: 50, y, z: 50+noise },
        dimensions: { x: width, y: thick, z: thick },
        display: 'rod',

      } : {

        // horizontal along z axis
        center: { x: 50+noise, y, z: 50 },
        dimensions: { x: thick, y: thick, z: width },
        display: 'rod',
      }
      
      rods.push(rod)
    }

    return rods;
  }

  get targets(){
    return this._targets;
  }

  /**
   *
   */
  get spheres() {

    // construct Sphere and Box instances
    const spheres = [];
    for (const proto of this._spheres) {
      const count = proto.stack || 1;
      for (let i = 0; i < count; ++i) {
      // Deep copy and offset position
        const sphere = { ...proto };
        const gm = -1.2e4;
        sphere.position = {
          x: proto.position.x + gm * GRAVITY.x * i + Math.random() * 0.001,
          y: proto.position.y + gm * GRAVITY.y * i + Math.random() * 0.001,
          z: proto.position.z + gm * GRAVITY.z * i + Math.random() * 0.001,
        };
        spheres.push(new Sphere(sphere));
      }
    }
    return spheres;
  }

  /**
   *
   */
  get boxes() {
    return this._boxes.map((p) => new Box(p));
  }

}
