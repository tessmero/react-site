/**
 * @file three.js marbles and boxes graphics
 */

const GFX_SPHERE_RADIUS = 5; // size of spheres


/**
 *
 */
class Graphics {

  static _outlineThickness = 0.3;

  static _meshes = {

    spheres: { // colored balls
      count: ({ spheres }) => spheres.length,
      geometry: new THREE.SphereGeometry(GFX_SPHERE_RADIUS, 16, 16), // detail level
      material: new THREE.MeshLambertMaterial(),
    },

    disks: { // outlines around spheres
      count: ({ spheres }) => spheres.length,
      geometry: new THREE.CylinderGeometry(
        GFX_SPHERE_RADIUS + Graphics._outlineThickness, // a bit wider than sphere
        GFX_SPHERE_RADIUS + Graphics._outlineThickness,
        Graphics._outlineThickness, 32) // detail level
        .rotateX(Math.PI / 2),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    },

    boxes: { // rods and walls
      count: ({ boxes }) => boxes.length,
      geometry: new THREE.BoxGeometry(),
      material: Graphics._m('MeshBasicMaterial', {
        color: 0xffffff,
        opacity: 0.5,
      }),
    },

    edges: { // box edge segments
      count: ({ boxes }) => boxes.length * 12, // 12 edges per box
      geometry: new THREE.BoxGeometry(),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    },

    holes: { // squares where rods intersect walls
      count: ({ rods }) => rods.length * 4, // 4 squares per rod
      geometry: new THREE.BoxGeometry(),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    }
  };

  /**
   *
   * @param physObjects
   */
  static _initInstancedMeshes(physObjects) {
    const im = {};
    for (const [name, params] of Object.entries(Graphics._meshes)) {
      const { count, geometry, material } = params;
      const n = count(physObjects);
      const mesh = new THREE.InstancedMesh(geometry, material, n);
      Graphics.scene.add(mesh);
      im[name] = mesh;
    }
    Graphics._instancedMeshes = im;
    return im;
  }

  /**
   *
   * @param params
   */
  static init(params) {


    const { boxes, spheres } = params;

    const scene = new THREE.Scene();
    Graphics.scene = scene;
    const camera = new THREE.PerspectiveCamera(
      30, // FOV in degrees
      window.innerWidth / window.innerHeight, // aspect ratio
      0.1, // near
      10000, // far
    );

    const camScale = 30;
    camera.position.set(10 * camScale, 12 * camScale, 14 * camScale);
    camera.lookAt(50, 50, 50);

    // light everything
    scene.add(new THREE.AmbientLight(0xffffff, 1));

    // light from one direction
    scene.add(Graphics._l({
      color: 0xffffff,
      intensity: 2,
      position: [-500, 1000, 500],
      target: [50, 50, 50],
    }));

    Graphics.camera = camera;
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    Graphics.renderer = renderer;
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    const rods = boxes.filter( (box) => box.display === 'rod' )
    const im = this._initInstancedMeshes({ boxes, rods, spheres });

    const dummy = new THREE.Object3D();

    // init all boxes (rods and walls) and their edges
    Graphics._initBoxes(boxes);

    // init holes - extra edges where rods cross walls
    //Graphics._initHoles(rods)

    // init spheres
    spheres.forEach((sphere, i) => {
      const { position: { x, y, z }, color } = sphere;
      dummy.position.set(x, y, z);
      dummy.updateMatrix();
      im.spheres.setMatrixAt(i, dummy.matrix);
      im.spheres.setColorAt(i, new THREE.Color(color));
    });

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.target.set(50, 50, 50);
    controls.update();

  }

  /**
   * @param params
   */
  static drawScene(params) {
    const { boxes, spheres } = params;

    Graphics.updateSpheresPositions(spheres);

    const { renderer, scene, camera } = Graphics;

    // fix objects popping in and out
    for (const mesh of Object.values(Graphics._instancedMeshes)) {
      mesh.frustumCulled = false;
    }

    renderer.render(scene, camera);

  }

  /**
   *
   * @param sphereMesh
   * @param spheres
   */
  static updateSpheresPositions(spheres) {
    const im = Graphics._instancedMeshes;

    const dummy = new THREE.Object3D();

    spheres.forEach((sphere, i) => {
      const { position: { x, y, z } } = sphere;
      dummy.position.set(x, y, z);
      dummy.lookAt(Graphics.camera.position); // Make disk face camera
      dummy.updateMatrix();
      im.spheres.setMatrixAt(i, dummy.matrix);
      im.disks.setMatrixAt(i, dummy.matrix);
    });

    im.spheres.instanceMatrix.needsUpdate = true;
    im.disks.instanceMatrix.needsUpdate = true;
  }

  /**
   *
   * @param boxes
   */
  static _initBoxes(boxes) {

    const dummy = new THREE.Object3D();
    const im = Graphics._instancedMeshes;
    boxes.forEach((box, boxIndex) => {
      const { center: { x, y, z }, dims: { x: width, y: height, z: depth } } = box;
      dummy.position.set(x, y, z);
      dummy.scale.set(width, height, depth);
      dummy.updateMatrix();
      im.boxes.setMatrixAt(boxIndex, dummy.matrix);

      // Edge thickness
      const edgeThickness = 0.3;

      const edgeParams = [
        { // 4 edges along x axis
          scale: [width, edgeThickness, edgeThickness],
          offsets: [
            [0, height / 2, depth / 2],
            [0, height / 2, -depth / 2],
            [0, -height / 2, depth / 2],
            [0, -height / 2, -depth / 2],
          ],
        },
        { // 4 edges along y axis
          scale: [edgeThickness, height, edgeThickness],
          offsets: [
            [width / 2, 0, depth / 2],
            [width / 2, 0, -depth / 2],
            [-width / 2, 0, depth / 2],
            [-width / 2, 0, -depth / 2],
          ],
        },
        { // 4 edges along z axis
          scale: [edgeThickness, edgeThickness, depth],
          offsets: [
            [width / 2, height / 2, 0],
            [width / 2, -height / 2, 0],
            [-width / 2, height / 2, 0],
            [-width / 2, -height / 2, 0],
          ],
        },
      ];

      let edgeIndex = 0;
      edgeParams.forEach(({ scale, offsets }) => {
        offsets.forEach(([xOff,yOff,zOff]) => {
          dummy.position.set(x + xOff, y + yOff, z + zOff);
          dummy.scale.set(...scale);
          dummy.rotation.set(0, 0, 0);
          dummy.updateMatrix();
          im.edges.setMatrixAt(boxIndex * 12 + edgeIndex, dummy.matrix);
          edgeIndex++;
        });
      });

    });
  }


static _m(type, params = {}) {
  const Clazz = THREE[type];
  const result = new Clazz(params);

  // handle params that don't work in constructor
  const { opacity = 1 } = params;
  result.opacity = opacity;
  if (opacity < 1) {
    result.transparent = true;
  }

  return result;
}

static _l(params = {}) {

  const { color = 0xffffff, intensity = 3, position, target } = params;

  const type = position ? 'DirectionalLight' : 'AmbientLight';
  const Clazz = THREE[type];
  const result = new Clazz(color, intensity);

  if (position) {
    result.position.set(...position);
  }

  if (target) {
    const dummy = new THREE.Object3D();
    dummy.position.set(...target);
    result.target = dummy;
  }

  return result;
}

}
