/**
 * @file CanvasUtil
 *
 * Used in main.js to help with
 * 1. setting up graphics
 * 2. processing mouse/touch input
 *
 * These two purposes are grouped together here because
 * the mouse position needs to be interpreted in a way that
 * agrees with the graphics being drawn.
 *
 * Outside of this file, we use a standardized coordinate
 * system where (50,50) is the center of the display.
 */
class CanvasUtil {

  /**
   * Set up the graphics context and start listening for mouse or touch input.
   * @param {object} listeners
   * @param {Function} listeners.mouseMove The function to call when any input is detected
   */
  static setupCanvas(listeners) {

    // prepare to draw on the canvas element in our html document
    const canvas = document.getElementsByTagName('canvas')[0];
    canvas.width = canvas.offsetWidth * devicePixelRatio;
    canvas.height = canvas.offsetHeight * devicePixelRatio;

    // set up graphics context with standard coordinate system
    // where (50,50) is the center of the display area
    const canvasSize = Math.min(canvas.width, canvas.height);
    const offsetX = (canvas.width - canvasSize) / 2;
    const offsetY = (canvas.height - canvasSize) / 2;
    const ctx = canvas.getContext('2d');
    const scale = canvasSize / 100;
    ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY);

    // compute x,y,w,h of the whole display in standard coordinates
    const clearRect = [
      (0 - offsetX) / scale,
      (0 - offsetY) / scale,
      canvas.width / scale,
      canvas.height / scale,
    ];

    // start listening for different types of input events
    if (listeners) {
      const { mouseMove } = listeners;
      const listenFor = ['mousedown', 'mousemove', 'touchstart', 'touchmove'];
      listenFor.forEach((eventType) => {
        canvas.addEventListener(eventType, (event) => {

          // standardize and pass to common mouseMove listener (main.js)
          const mousePos = this._getStandardMousePos(event, canvas, ctx);
          mouseMove(mousePos);

          // prevent default behavior like scrolling screen on mobile
          event.preventDefault();
        });
      });
    }

    // return graphics context to draw on (main.js)
    return {
      canvas, // canvas html element
      ctx, // canvas graphics context
      clearRect, // x,y,w,h of rectangle covering the whole canvas
    };
  }

  /**
   * Compute the mouse position indicated by the event.
   * @param {object} rawEvent The mouse/touch event
   * @param {object} canvas The canvas html element
   * @param {object} ctx The graphics context
   */
  static _getStandardMousePos(rawEvent, canvas, ctx) {

    // coerce event into having familiar properties
    let event = rawEvent;
    if (event.touches) {
      const touch = event.touches[0];
      if (touch.clientX) {
        event = touch;
      }
      else {
        event = {
          clientX: touch[0].pageX,
          clientY: touch[0].pageY,
        };
      }
    }

    // convert event position to standard coordinate system
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) * (canvas.width / rect.width);
    const y = (event.clientY - rect.top) * (canvas.height / rect.height);
    const transform = ctx.getTransform();
    const inverse = transform.invertSelf();
    const mousePos = {
      x: inverse.a * x + inverse.c * y + inverse.e,
      y: inverse.b * x + inverse.d * y + inverse.f,
    };

    return mousePos;
  }
}
