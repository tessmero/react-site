/**
 * @file quad-util
 * used for setup in main.js
 * used for debugging in main.js
 */
class QuadUtil {

  /**
   *
   */
  static setupQuadCanvases() {

    // real viewport dimensions in px
    const w = window.innerWidth;
    const h = window.innerHeight;

    // define pseudo-viewport rectangle
    let TOP_LEFT;
    let BOTTOM_RIGHT;
    if (DEBUG_SHRINK) {

      // use miniature viewport for debugging
      const pad = 0.1;
      TOP_LEFT = { x: w * pad, y: h * pad };
      BOTTOM_RIGHT = { x: w * (1 - pad), y: h * (1 - pad) };
    }
    else {

      // use actual viewport
      TOP_LEFT = { x: 0, y: 0 };
      BOTTOM_RIGHT = { x: w, y: h };
    }

    // starting from viewport corners,
    // build larger rectangle made of convenient square chunks
    //  - whole number of device pixels per chunk
    //  - whole number of chunks per canvas

    // estimate chunk size by dividing total area
    const VIEW_WIDTH = BOTTOM_RIGHT.x - TOP_LEFT.x;
    const VIEW_HEIGHT = BOTTOM_RIGHT.y - TOP_LEFT.y;
    const viewArea = VIEW_WIDTH * VIEW_HEIGHT;
    const chunkArea = viewArea / MAX_CHUNKS;
    let CHUNK_SIZE = Math.sqrt(chunkArea);

    // round chunk size up to nearest device pixel
    const pixel = 1/devicePixelRatio;
    CHUNK_SIZE = pixel * Math.ceil(CHUNK_SIZE / pixel);

    // round quad size up to nearest chunk
    const QUAD_WIDTH = CHUNK_SIZE * Math.ceil(VIEW_WIDTH / CHUNK_SIZE);
    const QUAD_HEIGHT = CHUNK_SIZE * Math.ceil(VIEW_HEIGHT / CHUNK_SIZE);
    BOTTOM_RIGHT = { x: TOP_LEFT.x + QUAD_WIDTH, y: TOP_LEFT.y + QUAD_HEIGHT };

    // define unique properties for the quad-canvases
    const quads = [
      { dx: 0, dy: 0, debugColor: 'rgba(255,0,0,.5)' }, // red
      { dx: 1, dy: 0, debugColor: 'rgba(0,255,0,.5)' }, // green
      { dx: 0, dy: 1, debugColor: 'rgba(0,0,255,.5)' }, // blue
      { dx: 1, dy: 1, debugColor: 'rgba(255,255,0,.5)' }, // yellow
    ];

    // build/recover 4 html canvas elements
    const quadCvs = quads.map((quad) => new Canvas({ quad, QUAD_WIDTH, QUAD_HEIGHT }));

    return {

      quadCvs, // 4 canvases

      // values to be set as global constants in main.js
      CHUNK_SIZE, // square chunk
      VIEW_WIDTH, VIEW_HEIGHT, // viewport dimensions
      QUAD_WIDTH, QUAD_HEIGHT, // expanded dimensions
      TOP_LEFT, // corner matching viewport
      BOTTOM_RIGHT, // expanded corner

    };
  }

  /**
   *
   */
  static drawDebugOverlays() {

    // if (DEBUG_CHUNKS) { // draw chunk rectangles on each quad canvases
    //   for (let i = 0; i < 4; i++) {
    //     const sim = quadSims[i];
    //     const cvs = quadCvs[i];
    //     sim.debugChunks(cvs.ctx);
    //   }
    // }

    if (DEBUG_SCREEN) { // draw screen rectangle on main canvas
      const ctx = BASE_CANVAS.getContext('2d');
      Canvas.setStyles(BASE_CANVAS, {
        top: '0px',
        left: '0px',
        width: `${window.innerWidth}px`,
        height: `${window.innerHeight}px`,
        position: 'absolute',
      });
      BASE_CANVAS.width = window.innerWidth;
      BASE_CANVAS.height = window.innerHeight;
      ctx.lineWidth = 1;

      ctx.strokeStyle = 'black';
      ctx.setLineDash([]);
      ctx.strokeRect(TOP_LEFT.x, TOP_LEFT.y, VIEW_WIDTH, VIEW_HEIGHT);

      ctx.strokeStyle = 'white';
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(TOP_LEFT.x, TOP_LEFT.y, QUAD_WIDTH, QUAD_HEIGHT);
    }
  }
}
