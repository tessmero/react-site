/**
 * @file Canvas
 * One member in a quad-canvases group
 */
class Canvas {
  
  constructor(params){
    this.params = params;
    const {quad,QUAD_WIDTH,QUAD_HEIGHT} = params
    this.quad = quad

    const id = `canvas-${JSON.stringify(quad)}`
    let htmlElem = document.getElementById(id)
    if( !htmlElem ){

      // one-time build html element
      htmlElem = document.createElement('canvas')
      htmlElem.id = id
      document.body.appendChild(htmlElem)
    }

    // set dimensions in element and element style
    htmlElem.width = QUAD_WIDTH
    htmlElem.height = QUAD_HEIGHT
    this.htmlElem = htmlElem
    this.setStyles({
      'background-color': (DEBUG_QUADS ? quad.debugColor : 'transparent'),
      width: `${QUAD_WIDTH}px`,
      height: `${QUAD_HEIGHT}px`,
      'position': 'absolute',
      'overflow': 'hidden',
      'z-index': -1, // behind main canvas
    })

    // set dimensions in graphics context
    this.ctx = htmlElem.getContext('2d')
    this.ctx.width = QUAD_WIDTH * devicePixelRatio
    this.ctx.height = QUAD_HEIGHT * devicePixelRatio

  }

  setStyles(styles){
    Canvas.setStyles(this.htmlElem,styles)
  }

  static setStyles(elem,styles){
    for( const [key,val] of Object.entries(styles) ){
      elem.style[key] = val
    }
  }

  nnmod(a,b) {
      const result = a%b
      if( result < 0 ){
        return result + b
      }
      return result
    }

  updatePosition(params){
    const {camera} = params;
    const {quad:{dx,dy} } = this.params;


    const xNum = camera.x + dx * QUAD_WIDTH;
    let quadX = this.nnmod(xNum, 2 * QUAD_WIDTH);
    if (quadX + QUAD_WIDTH < TOP_LEFT.x) {
      quadX = quadX + 2 * QUAD_WIDTH;
    }
    if (quadX > BOTTOM_RIGHT.x) {
      quadX = quadX - 2 * QUAD_WIDTH;
    }

    const yNum = camera.y + dy * QUAD_HEIGHT;
    let quadY = this.nnmod(yNum, 2 * QUAD_HEIGHT);
    if (quadY + QUAD_HEIGHT < TOP_LEFT.y) {
      quadY = quadY + 2 * QUAD_HEIGHT;
    }
    if (quadY > BOTTOM_RIGHT.y) {
      quadY = quadY - 2 * QUAD_HEIGHT;
    }

    this.setStyles({
      left: `${quadX}px`,
      top: `${quadY}px`,
    })
  }
}