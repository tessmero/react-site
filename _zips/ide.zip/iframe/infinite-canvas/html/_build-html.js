({ scriptTags, contentTags }) => {

  // escape html that contains scripts
  // used to render inner iframe in script
  function escapeJs(htmlString){
    return htmlString
      .replace(/\\/g, '\\\\')   //  \ backslash
      .replace(/`/g, '\\`')     //  ` backtick
      .replace(/\$\{/g, '\\${') //  ${ string template literal
      .replace(/<\/script>/g, '<\\/script>'); // closing script tag
  }

  // wrap scriptTags in html document for inner iframe
  const innerContent = `
<!DOCTYPE html>
<html>
  <head>
    <style>
      html, body { margin: 0; padding: 0; }
      canvas {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: #AAA;
      }
    </style>
  </head>
  <body>
    <canvas></canvas>
    ${scriptTags}
  </body>
</html>
`;

  // render final outer html with content
  // and backgound iframe that contains code from IDE
  return `
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Preview</title>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        color: #333;
        background-color: transparent;
      }
      #sandbox {
        border: none;
        position: absolute;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 0;
        overflow: hidden;
      }
      .content {
        position: relative;
        z-index: 1;
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
      }
    </style>
  </head>
  <body>
    <iframe id="sandbox"></iframe>
    <div class="content">
      ${contentTags}
    </div>
    <script>
      const sandbox = document.getElementById('sandbox');
      sandbox.srcdoc = \`
        ${escapeJs(innerContent)}
      \`;
    <\/script>
  </body>
</html>
`;
}
