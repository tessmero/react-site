var Vt=Object.defineProperty;var Nt=(t,e,i)=>e in t?Vt(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var f=(t,e,i)=>Nt(t,typeof e!="symbol"?e+"":e,i);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))s(n);new MutationObserver(n=>{for(const r of n)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function i(n){const r={};return n.integrity&&(r.integrity=n.integrity),n.referrerPolicy&&(r.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?r.credentials="include":n.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(n){if(n.ep)return;n.ep=!0;const r=i(n);fetch(n.href,r)}})();class A{constructor(){f(this,"flatConfig")}refreshConfig(){this.flatConfig=xt(this.tree)}static register(e,i){if(e in this._registry)throw new Error(`configurable already registered: '${e}'`);this._registry[e]=i}static create(e){const i=this._registry[e],s=i();return s.refreshConfig(),s}}f(A,"_registry",{});function xt(t,e={}){for(const[i,s]of Object.entries(t.children))"action"in s||("value"in s?e[i]=s.value:xt(s,e));return e}const Yt={label:"Graphics",children:{}},Me=class Me extends A{constructor(){super(...arguments);f(this,"tree",Yt)}};A.register("gfx-config",()=>new Me);let Ue=Me;const vt=A.create("gfx-config"),Ct={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:50,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:50,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:40,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const t of Object.values(Ct.children))t.onChange=e=>{At.refreshConfig(),e.onResize()};const Re=class Re extends A{constructor(){super(...arguments);f(this,"tree",Ct)}};A.register("layout-config",()=>new Re);let Ke=Re;const At=A.create("layout-config"),Gt={label:"Level One",children:{nParticles:{tooltip:"number of graphical particles to reprsent motion",value:100,min:0,max:1e3,step:1,onChange:()=>H.refreshConfig()},particleFriction:{value:.005,min:0,max:1,step:1e-10,onChange:()=>H.refreshConfig()},particleAngularFriction:{value:5e-4,min:0,max:1,step:1e-10,onChange:()=>H.refreshConfig()},particleThrustScale:{tooltip:"scale effect of thrust on particle field graphics",value:.1,min:0,max:10,step:.001,onChange:()=>H.refreshConfig()},particleTorqueScale:{tooltip:"scale effect of torwue on particle field graphics",value:5e-6,min:0,max:1e-4,step:1e-10,onChange:()=>H.refreshConfig()}}},Fe=class Fe extends A{constructor(){super(...arguments);f(this,"tree",Gt)}};A.register("one-config",()=>new Fe);let qe=Fe;const H=A.create("one-config"),Xt={NAMES:["icons-preloader","text-preloader"]},j={NAMES:["empty-gui","zero-gui"]},Et={NAMES:["zero-game"]},jt={NAMES:["reports-frame","changelog-frame","demo-list-frame","demo-frame"]},Ut=!1;let le=!1;function Kt(){var i;le=!le;const t=document.getElementById("innerFrame");if(!t)return;const e=t.contentDocument||((i=t.contentWindow)==null?void 0:i.document);e&&e.body&&(le?(e.body.style.opacity="0",e.body.style.background="transparent"):(e.body.style.opacity="",e.body.style.background=""))}const qt={children:{ghostInnerFrame:{action:Kt},checkInnerFrame:{action:t=>{const e=document.getElementById("innerFrame");t.currentFrame.registerElements(e)}},game:{value:"zero-game",options:Et.NAMES,onChange:(t,e)=>{t.switchToGame(e)}},interludeDelay:{tooltip:"delay before loading bar appear on interlude screen",value:500,min:0,max:1e4,step:1},interludeDuration:{tooltip:"duration of interlude screen at startup and between levels",value:3e3,min:500,max:1e4,step:1},flashPeriod:{value:1e3,min:100,max:1e4,onChange:()=>Le.refreshConfig()}}},Te=class Te extends A{constructor(){super(...arguments);f(this,"tree",qt)}};A.register("top-config",()=>new Te);let Je=Te;const Le=A.create("top-config"),Jt={label:"Level Zero",children:{gridSize:{value:5,min:1,max:10,step:1,onChange:t=>{throw new Error("not allowed")}},changeSpeed:{value:.01,min:1e-4,max:.1,onChange:()=>R.refreshConfig()},zeroCellOffsetScale:{tooltip:"scale of cell fidgetting offsets",value:100,min:0,max:1e4,step:1,onChange:()=>R.refreshConfig()},zeroCellSpring:{tooltip:"force pulling cells to neutral position",value:.001,min:0,max:1,step:1e-5,onChange:()=>R.refreshConfig()},zeroCellFriction:{value:.01,min:0,max:1,step:1e-5,onChange:()=>R.refreshConfig()},zeroBlankClickAccel:{tooltip:"downward force on clicking empty cell",value:.01,min:0,max:1,step:1e-5,onChange:()=>R.refreshConfig()},quarkMaxAccel:{tooltip:"tangential force on quark extremities",value:.002,min:0,max:1,step:1e-5,onChange:()=>R.refreshConfig()},quarkFidgetPeriod:{tooltip:"duration of quark idle animation cycle",value:1e3,min:100,max:1e5,step:1,onChange:()=>R.refreshConfig()}}},Oe=class Oe extends A{constructor(){super(...arguments);f(this,"tree",Jt)}};A.register("zero-config",()=>new Oe);let Ze=Oe;const R=A.create("zero-config"),Zt={label:"Level Two",children:{twoSimSpeed:{value:1,min:1,max:10,step:1,onChange:()=>{_t.refreshConfig()}},raftAngleThreshold:{value:.2,min:0,max:3,step:1e-10,onChange:()=>D.refreshConfig()},raftFriction:{value:.001,min:0,max:1,step:1e-10,onChange:()=>D.refreshConfig()},raftThrustScale:{value:15e-5,min:0,max:.01,step:1e-10,onChange:()=>D.refreshConfig()},raftAngularFriction:{value:.002,min:0,max:1,step:1e-10,onChange:()=>D.refreshConfig()},raftTorqueScale:{value:2e-6,min:0,max:.01,step:1e-10,onChange:()=>D.refreshConfig()}}},Pe=class Pe extends A{constructor(){super(...arguments);f(this,"tree",Zt)}};A.register("two-config",()=>new Pe);let Qe=Pe;const D=A.create("two-config"),Qt={label:"Level Three",children:{threeBattleSpeed:{value:1,min:1,max:1e3,step:1,onChange:t=>t.config.refreshConfig()},gridSize:{value:30,min:5,max:100,step:1,onChange:t=>{fe.refreshConfig(),t.game.helper=t.game.reset(t)}},playerAnimDuration:{value:150,min:1,max:1e3,step:1,onChange:()=>fe.refreshConfig()}}},Be=class Be extends A{constructor(){super(...arguments);f(this,"tree",Qt)}};A.register("three-config",()=>new Be);let et=Be;const fe=A.create("three-config"),ei={children:{...Le.tree.children,...vt.tree.children,layout:At.tree,zero:R.tree,one:H.tree,two:D.tree,three:fe.tree}},ze=class ze extends A{constructor(){super(...arguments);f(this,"tree",ei)}};A.register("recursio-config",()=>new ze);let tt=ze;const _t=A.create("recursio-config");function ti(t,e,i){const s=t.canvas.width,n=t.canvas.height,r=t.getImageData(0,0,s,n),o=r.data;for(let l=0;l<o.length;l+=4)o[l]===e[0]&&o[l+1]===e[1]&&o[l+2]===e[2]&&o[l+3]===e[3]&&(o[l]=i[0],o[l+1]=i[1],o[l+2]=i[2],o[l+3]=i[3]);t.putImageData(r,0,0)}const ii=["png/icons/9x9-cursor-default.png","png/icons/9x9-cursor-pointer.png","png/icons/9x9-check.png","png/icons/9x9-play.png","png/icons/9x9-music.png","png/icons/9x9-sound.png","png/icons/9x9-sort.png","png/icons/9x9-sort-down.png","png/icons/9x9-sort-up.png","png/icons/9x9-menu.png","png/icons/9x9-collapsed.png","png/icons/9x9-expanded.png"];function si(t){return new Promise((e,i)=>{const s=new Image;s.onload=()=>{for(const[n,{rgba:r}]of Object.entries(ni)){const o=document.createElement("canvas");o.width=s.width,o.height=s.height;const l=o.getContext("2d");l.drawImage(s,0,0),ti(l,[0,0,0,255],r);const a=new Image;a.src=o.toDataURL(),ee[n]||(ee[n]={}),ee[n][t]=a}e(s)},s.onerror=()=>i(new Error(`Failed to load image at ${t}`)),s.src=t})}const ni={black:{rgba:[0,0,0,255]},white:{rgba:[255,255,255,255]},red:{rgba:[255,0,0,255]}},ee={};function k(t,e="black"){const i=ee[e][t];if(!i)throw new Error(`image not preloaded: ${t}`);return i}async function oi(){try{const t=ii.map(si),e=await Promise.all(t)}catch(t){console.error("One or more images failed to load:",t.message)}}function ge(t,e,i={}){const{fillStyle:s=void 0,strokeStyle:n="black"}=i;let[r,o,l,a]=e.map(h=>Math.round(h));const c=1;r+=1,o+=1,l-=2,a-=2;const d=[[r+c,o,l-2*c,c],[r,o+c,c,a-2*c],[r+c,o+a-c,l-2*c,c],[r+l-c,o+c,c,a-2*c]];s&&(t.fillStyle=s,t.fillRect(r+c,o+c,l-2*c,a-2*c)),t.fillStyle=n;for(const h of d)t.fillRect(...h)}const ae={};function Se(t){return t in ae||(ae[t]=ri(t)),ae[t]}function ri(t){var o,l;const e=[];let i=[];const s=document.createElement("div");if(t.length>1e3)return console.log("returning empty results for long label"),e;t.includes("<img")&&console.log("parse label with img tag"),s.innerHTML=t.toUpperCase().replaceAll("<CODE>","").replaceAll("</CODE>","");function n(a,c){for(let d=0;d<a.length;d++){const h=a[d];if(h==="~"){if(a[d+1]!=="N")throw new Error('Invalid tilde usage: only "~n" is allowed.');e.push(i),i=[],d++}else i.push({char:h,color:c})}}function r(a){var c,d;a.nodeType===Node.TEXT_NODE?n(((c=a.textContent)==null?void 0:c.trim())||"","default"):a.nodeType===Node.ELEMENT_NODE&&a.nodeName==="SPAN"&&n(` ${(d=a.textContent)==null?void 0:d.trim()} `,"blue")}s.childNodes.forEach(a=>r(a)),e.push(i);for(const a of e){for(;((o=a[0])==null?void 0:o.char)===" ";)a.splice(0,1);for(;((l=a.at(-1))==null?void 0:l.char)===" ";)a.length=a.length-1}return e}const li=.04;let $e=!1,me=null,G=0,ce=0;function ai(){$e=!1}function ci(){$e||(me=null)}function hi(t){$e=!0;const i=(Se(t.htmlElem.innerHTML)[0].length+1)*4,s=t.rect[2];if(i<=s)return 0;const n=i-s,r=performance.now();if(t!==me)me=t,G=0,ce=r;else{const o=Math.min(50,r-ce);ce=r,G+=li*o,G=Math.min(n,G)}return-Math.round(G)}const q=class q{constructor(){f(this,"generated",{});f(this,"fetched",{});f(this,"images");f(this,"name","UNNAMED");f(this,"_didFetchAllImages",!1);f(this,"_didGenerateAllImages",!1)}getImage(e){return this.fetched[e]??this.generated[e]}async fetchAllImages(){if(this._didFetchAllImages)throw new Error("already fetched all images");return this._didFetchAllImages=!0,Promise.all(this.keys.map(async e=>{this.fetched[e]=await this.fetchImage(e)}))}generateAllImages(){if(this._didGenerateAllImages)throw new Error("already generated all images");this._didGenerateAllImages=!0;for(const e of this.keys)this.generated[e]=this.generateImage(e)}async fetchImage(e){const i=this.getImageUrl(e),s=await fetch(i);if(!s.ok)throw new Error(`HTTP error! status: ${s.status} 
        preloader ${this.name} fetching key ${e} from url ${i}`);const n=await s.blob(),r=await createImageBitmap(n),o=new OffscreenCanvas(r.width,r.height);return o.getContext("2d").drawImage(r,0,0),o}getImageUrl(e){return`png/preloaded/${this.name}/${e}.png`}static register(e,i){if(e in this._registry)throw new Error(`configurable already registered: '${e}'`);q._registry[e]=i}static async preload(e,i=!1){const s=this._registry[e],n=s();this._preloaded[e]=n,n.name=e,n.generateAllImages();const r={};for(const o of n.keys)r[o]=n.getImage(o);n.images=r}static create(e){if(e in this._preloaded)return this._preloaded[e];throw new Error(`preloader '${e}' was not preloaded`)}};f(q,"_registry",{}),f(q,"_preloaded",{});let T=q;const Lt="3x5 uppercase letters only",St=5,$t=!0,ke={0:{offset:0,pixels:[[0,1,0],[1,0,1],[1,0,1],[1,0,1],[0,1,0]]},1:{offset:0,pixels:[[0,1,0],[1,1,0],[0,1,0],[0,1,0],[1,1,1]]},2:{offset:0,pixels:[[1,1,0],[0,0,1],[0,1,0],[1,0,0],[1,1,1]]},3:{offset:0,pixels:[[1,1,0],[0,0,1],[0,1,0],[0,0,1],[1,1,0]]},4:{offset:0,pixels:[[1,0,1],[1,0,1],[1,1,1],[0,0,1],[0,0,1]]},5:{offset:0,pixels:[[1,1,1],[1,0,0],[1,1,0],[0,0,1],[1,1,0]]},6:{offset:0,pixels:[[0,1,1],[1,0,0],[1,1,0],[1,0,1],[0,1,0]]},7:{offset:0,pixels:[[1,1,1],[0,0,1],[0,1,0],[0,1,0],[0,1,0]]},8:{offset:0,pixels:[[0,1,0],[1,0,1],[0,1,0],[1,0,1],[0,1,0]]},9:{offset:0,pixels:[[0,1,0],[1,0,1],[0,1,1],[0,0,1],[1,1,0]]},",":{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,1,0],[1,0,0]]},"'":{offset:0,pixels:[[0,1,0],[0,1,0],[0,0,0],[0,0,0],[0,0,0]]},'"':{offset:0,pixels:[[1,0,1],[1,0,1],[0,0,0],[0,0,0],[0,0,0]]},"✓":{offset:0,pixels:[[1,0,1],[1,0,1],[0,1,0],[1,0,1],[1,0,1]]},"(":{offset:0,pixels:[[0,1,0],[1,0,0],[1,0,0],[1,0,0],[0,1,0]]},")":{offset:0,pixels:[[0,1,0],[0,0,1],[0,0,1],[0,0,1],[0,1,0]]},"%":{offset:0,pixels:[[1,0,1],[0,0,1],[0,1,0],[1,0,0],[1,0,1]]},"-":{offset:0,pixels:[[0,0,0],[0,0,0],[1,1,1],[0,0,0],[0,0,0]]},">":{offset:0,pixels:[[1,0,0],[0,1,0],[0,0,1],[0,1,0],[1,0,0]]},"<":{offset:0,pixels:[[0,0,1],[0,1,0],[1,0,0],[0,1,0],[0,0,1]]},$:{offset:0,pixels:[[0,1,0],[1,1,1],[1,0,0],[1,1,1],[0,1,0]]},":":{offset:0,pixels:[[0,0,0],[0,1,0],[0,0,0],[0,1,0],[0,0,0]]},"!":{offset:0,pixels:[[0,1,0],[0,1,0],[0,1,0],[0,0,0],[0,1,0]]},"/":{offset:0,pixels:[[0,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,0]]}," ":{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]},_:{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[1,1,1]]},A:{offset:0,pixels:[[0,1,0],[1,0,1],[1,1,1],[1,0,1],[1,0,1]]},B:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,1],[1,1,0]]},C:{offset:0,pixels:[[0,1,1],[1,0,0],[1,0,0],[1,0,0],[0,1,1]]},D:{offset:0,pixels:[[1,1,0],[1,0,1],[1,0,1],[1,0,1],[1,1,0]]},E:{offset:0,pixels:[[1,1,1],[1,0,0],[1,1,0],[1,0,0],[1,1,1]]},F:{offset:0,pixels:[[1,1,1],[1,0,0],[1,1,0],[1,0,0],[1,0,0]]},G:{offset:0,pixels:[[0,1,1],[1,0,0],[1,0,1],[1,0,1],[0,1,1]]},H:{offset:0,pixels:[[1,0,1],[1,0,1],[1,1,1],[1,0,1],[1,0,1]]},I:{offset:0,pixels:[[1,1,1],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},J:{offset:0,pixels:[[0,0,1],[0,0,1],[0,0,1],[1,0,1],[0,1,0]]},K:{offset:0,pixels:[[1,0,1],[1,1,0],[1,0,0],[1,1,0],[1,0,1]]},L:{offset:0,pixels:[[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,1,1]]},M:{offset:0,pixels:[[1,0,1],[1,1,1],[1,0,1],[1,0,1],[1,0,1]]},N:{offset:0,pixels:[[1,0,1],[1,1,1],[1,1,1],[1,0,1],[1,0,1]]},O:{offset:0,pixels:[[0,1,0],[1,0,1],[1,0,1],[1,0,1],[0,1,0]]},P:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,0],[1,0,0]]},Q:{offset:0,pixels:[[0,1,0],[1,0,1],[1,0,1],[1,1,1],[0,1,1]]},R:{offset:0,pixels:[[1,1,0],[1,0,1],[1,1,0],[1,0,1],[1,0,1]]},S:{offset:0,pixels:[[0,1,1],[1,0,0],[0,1,0],[0,0,1],[1,1,0]]},T:{offset:0,pixels:[[1,1,1],[0,1,0],[0,1,0],[0,1,0],[0,1,0]]},U:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[1,0,1],[0,1,0]]},V:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[0,1,0],[0,1,0]]},W:{offset:0,pixels:[[1,0,1],[1,0,1],[1,0,1],[1,1,1],[1,0,1]]},X:{offset:0,pixels:[[1,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,1]]},Y:{offset:0,pixels:[[1,0,1],[1,0,1],[0,1,0],[0,1,0],[0,1,0]]},Z:{offset:0,pixels:[[1,1,1],[0,0,1],[0,1,0],[1,0,0],[1,1,1]]},".":{offset:0,pixels:[[0,0,0],[0,0,0],[0,0,0],[0,1,0],[0,1,0]]}},di={description:Lt,lineHeight:St,isFixedWidth:$t,glyphs:ke},pi=Object.freeze(Object.defineProperty({__proto__:null,default:di,description:Lt,glyphs:ke,isFixedWidth:$t,lineHeight:St},Symbol.toStringTag,{value:"Module"})),kt="https://raw.githubusercontent.com/hgcummings/pixel-fonts/refs/heads/master/data/seven-plus.json",It=7,Mt=`7x4 numbers, 7x5 upper case 
and variable-width lower case letters`,Rt=!1,Ft={0:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},1:{offset:0,pixels:[[0,0,1,0],[0,1,1,0],[1,0,1,0],[0,0,1,0],[0,0,1,0],[0,0,1,0],[1,1,1,1]]},2:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0],[1,1,1,1]]},3:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,1,1,0],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},4:{offset:0,pixels:[[0,0,1,0],[0,1,1,0],[1,0,1,0],[1,1,1,1],[0,0,1,0],[0,0,1,0],[0,0,1,0]]},5:{offset:0,pixels:[[1,1,1,1],[1,0,0,0],[1,0,0,0],[1,1,1,0],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},6:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},7:{offset:0,pixels:[[1,1,1,1],[0,0,0,1],[0,0,1,0],[0,0,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]]},8:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},9:{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[1,0,0,1],[0,1,1,0]]},A:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},B:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},C:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,1],[0,1,1,1,0]]},D:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},E:{offset:0,pixels:[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},F:{offset:0,pixels:[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},G:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},H:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},I:{offset:0,pixels:[[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[1,1,1,1,1]]},J:{offset:0,pixels:[[1,1,1,1,1],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[1,0,0,1,0],[0,1,1,0,0]]},K:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,1,0],[1,0,1,0,0],[1,1,0,0,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},L:{offset:0,pixels:[[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},M:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,1,0,1,1],[1,0,1,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},N:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,1,0,0,1],[1,0,1,0,1],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1]]},O:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},P:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},Q:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},R:{offset:0,pixels:[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},S:{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[0,1,1,1,0],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},T:{offset:0,pixels:[[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},U:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},V:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0]]},W:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},X:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,1,0,1,0],[1,0,0,0,1],[1,0,0,0,1]]},Y:{offset:0,pixels:[[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},Z:{offset:0,pixels:[[1,1,1,1,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},a:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},b:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0]]},c:{offset:2,pixels:[[0,1,1,1],[1,0,0,0],[1,0,0,0],[1,0,0,0],[0,1,1,1]]},d:{offset:0,pixels:[[0,0,0,1],[0,0,0,1],[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},e:{offset:2,pixels:[[0,1,1,0],[1,0,0,1],[1,1,1,1],[1,0,0,0],[0,1,1,1]]},f:{offset:0,pixels:[[0,0,1,1],[0,1,0,0],[1,1,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]]},g:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,1,1,0]]},h:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1]]},i:{offset:0,pixels:[[0,1,0],[0,0,0],[1,1,0],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},j:{offset:0,pixels:[[0,0,1],[0,0,0],[0,1,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[1,1,0]]},k:{offset:0,pixels:[[1,0,0,0],[1,0,0,0],[1,0,0,1],[1,0,1,0],[1,1,0,0],[1,0,1,0],[1,0,0,1]]},l:{offset:0,pixels:[[1,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[1,1,1]]},m:{offset:2,pixels:[[1,1,1,1,0],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1]]},n:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1]]},o:{offset:2,pixels:[[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]]},p:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0],[1,0,0,0],[1,0,0,0]]},q:{offset:2,pixels:[[0,1,1,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,0,0,1]]},r:{offset:2,pixels:[[1,1,1,0],[1,0,0,1],[1,0,0,0],[1,0,0,0],[1,0,0,0]]},s:{offset:2,pixels:[[0,1,1,1],[1,0,0,0],[0,1,1,0],[0,0,0,1],[1,1,1,0]]},t:{offset:0,pixels:[[0,1,0,0],[0,1,0,0],[1,1,1,0],[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,0,1,1]]},u:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1]]},v:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,1,0],[0,1,0,0]]},w:{offset:2,pixels:[[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},x:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[0,1,1,0],[1,0,0,1],[1,0,0,1]]},y:{offset:2,pixels:[[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,1,1,0]]},z:{offset:2,pixels:[[1,1,1,1],[0,0,0,1],[0,1,1,0],[1,0,0,0],[1,1,1,1]]}," ":{offset:0,pixels:[[0,0,0]]},"!":{offset:0,pixels:[[1],[1],[1],[1],[1],[0],[1]]},'"':{offset:0,pixels:[[1,0,1],[1,0,1]]},"#":{offset:0,pixels:[[0,1,0,1,0],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[0,1,0,1,0]]},$:{offset:0,pixels:[[0,0,1,0,0],[0,1,1,1,1],[1,0,1,0,0],[0,1,1,1,0],[0,0,1,0,1],[1,1,1,1,0],[0,0,1,0,0]]},"%":{offset:0,pixels:[[1,1,0,0,1],[1,1,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,1,1],[1,0,0,1,1]]},"&":{offset:0,pixels:[[0,1,1,0,0],[1,0,0,1,0],[1,0,1,0,0],[0,1,0,0,1],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},"'":{offset:0,pixels:[[1],[1]]},"(":{offset:0,pixels:[[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[0,1]]},")":{offset:0,pixels:[[1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[1,0]]},"*":{offset:1,pixels:[[1,0,1],[0,1,0],[1,0,1]]},"+":{offset:2,pixels:[[0,1,0],[1,1,1],[0,1,0]]},",":{offset:6,pixels:[[1],[1]]},"-":{offset:3,pixels:[[1,1,1]]},".":{offset:6,pixels:[[1]]},"/":{offset:0,pixels:[[0,0,1],[0,0,1],[0,1,0],[0,1,0],[0,1,0],[1,0,0],[1,0,0]]},":":{offset:4,pixels:[[1],[0],[1]]},";":{offset:4,pixels:[[1],[0],[1],[1]]},"<":{offset:1,pixels:[[0,0,1],[0,1,0],[1,0,0],[0,1,0],[0,0,1]]},"=":{offset:2,pixels:[[1,1,1],[0,0,0],[1,1,1]]},">":{offset:1,pixels:[[1,0,0],[0,1,0],[0,0,1],[0,1,0],[1,0,0]]},"?":{offset:0,pixels:[[0,1,1,0],[1,0,0,1],[0,0,0,1],[0,0,1,0],[0,1,0,0],[0,0,0,0],[0,1,0,0]]},"@":{offset:0,pixels:[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,1,1],[1,0,1,0,1],[1,0,1,1,1],[1,0,0,0,0],[0,1,1,1,0]]},"[":{offset:0,pixels:[[1,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1]]},"\\":{offset:0,pixels:[[1,0,0],[1,0,0],[0,1,0],[0,1,0],[0,1,0],[0,0,1],[0,0,1]]},"]":{offset:0,pixels:[[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,1]]},"^":{offset:0,pixels:[[0,1,0],[1,0,1]]},_:{offset:6,pixels:[[1,1,1,1,1]]},"`":{offset:0,pixels:[[1,0],[0,1]]},"{":{offset:0,pixels:[[0,0,1],[0,1,0],[0,1,0],[1,0,0],[0,1,0],[0,1,0],[0,0,1]]},"|":{offset:0,pixels:[[1],[1],[1],[1],[1],[1],[1]]},"}":{offset:0,pixels:[[1,0,0],[0,1,0],[0,1,0],[0,0,1],[0,1,0],[0,1,0],[1,0,0]]},"~":{offset:2,pixels:[[0,1,0,0,0],[1,0,1,0,1],[0,0,0,1,0]]},"":{offset:0,pixels:[[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]]}},ui={source:kt,lineHeight:It,description:Mt,isFixedWidth:Rt,glyphs:Ft},fi=Object.freeze(Object.defineProperty({__proto__:null,default:ui,description:Mt,glyphs:Ft,isFixedWidth:Rt,lineHeight:It,source:kt},Symbol.toStringTag,{value:"Module"})),gi=2;function mi(t){return t==="default"?fi:pi}function yi(t,e="default"){const i=mi(e),{glyphs:s,lineHeight:n}=i,r=n+gi,o=[];for(let a=0;a<r;a++)o[a]=[];let l=!0;for(const a of t){const c=s[a];if(!c)continue;if(!l)for(let h=0;h<r;h++)o[h].push(0);l=!1;const d=new Array(c.pixels[0].length).fill(0);for(let h=0;h<r;h++){const p=c.pixels[h-c.offset]||d;o[h].push(...p)}}return o}const ye=Object.keys(ke).join(""),X=4,te=5,wi=["black","white","blue"],We=class We extends T{constructor(){super(...arguments);f(this,"keys",wi)}generateImage(i){const s=X*ye.length,n=te,r=new OffscreenCanvas(s,n),o=r.getContext("2d");if(!o)throw new Error("Failed to create buffer canvas context");const l=yi(ye,"mini");o.fillStyle=i;for(let a=0;a<l.length;a++)for(let c=0;c<l[a].length;c++)l[a][c]&&o.fillRect(c,a,1,1);return r}};T.register("text-preloader",()=>new We);let it=We;function st(t){return Se(t)[0].length*4+5}function U(t,e,i,s,n=!1){const{black:r,white:o,blue:l}=T.create("text-preloader").images,a=n?o:r;if(!a)throw new Error("Text pixel buffer not initialized. Call preloadTextPixelImages first.");if(!a.getContext("2d"))throw new Error("Failed to retrieve buffer canvas context");const d=Se(e),h=i;let p=s;for(const w of d){for(let u=0;u<w.length;u++){const{char:b,color:x}=w[u],y=ye.indexOf(b);if(y===-1)continue;const g=y*X;t.drawImage(x==="default"?a:l,g,0,X,te,h+u*X,p,X,te)}p+=te+2}}function Tt(t,e,i={}){let{padLeft:s=0}=i;e.htmlElem.matches(":hover")&&(s=hi(e)),S(t,e,{isTextClipped:!0,...i,padLeft:s}),t.restore()}function V(t,e,i={}){const s=window.getComputedStyle(e.htmlElem);let{fillStyle:n,strokeStyle:r}=i;r=r??s.borderColor,n=n??s.backgroundColor;const[o,l,a,c]=e.rect.map(d=>Math.round(d));t.lineWidth=1,t.strokeStyle=r,t.fillStyle=n,t.globalAlpha=1,t.fillRect(o+.5,l+.5,a-1,c-1),t.strokeRect(o+.5,l+.5,a-1,c-1)}function S(t,e,i={}){const s=window.getComputedStyle(e.htmlElem),{padLeft:n=0,isTextWhite:r=s.color==="rgb(255, 255, 255)",isTextClipped:o=!1,isRounded:l=!1}=i;let{fillStyle:a,strokeStyle:c}=i;c=c??s.borderColor,a=a??s.backgroundColor;const[d,h,p,w]=e.rect.map(u=>Math.round(u));l?ge(t,[d-1,h-1,p+2,w+2],{fillStyle:a,strokeStyle:c}):(t.lineWidth=1,t.strokeStyle=c,t.fillStyle=a,t.globalAlpha=1,t.fillRect(d+.5,h+.5,p-1,w-1),t.strokeRect(d+.5,h+.5,p-1,w-1)),o&&(t.save(),t.beginPath(),t.rect(d+2,h,p-4,w),t.clip()),U(t,e.htmlElem.innerHTML,d+3+n,h+3,r),o&&t.restore()}let N=null;const re={navbar:{overrides:{width:240},detector:t=>t.id==="navbar",renderer:function(t,e){const[i,s,n,r]=e.rect;t.globalAlpha=1,t.fillStyle="black",t.fillRect(i+.5,s+.5,n-1,r-1),N=e.rect}},"navbar-brand":{overrides:{width:"text",height:11,left:3,top:3},detector:t=>t.matches(".navbar-brand"),renderer:function(t,e){S(t,e,{isTextWhite:!0,strokeStyle:"black"})}},"navbar-toggler":{overrides:{width:11,height:11,right:15,top:3},detector:t=>t.classList.contains("navbar-toggler-replacement"),renderer:function(t,e){V(t,e,{});const[i,s,n,r]=e.rect;t.drawImage(k("png/icons/9x9-menu.png"),Math.round(i+1),Math.round(s+1))}},"nav-link":{overrides:{height:11,width:150,"margin-left":40},detector:t=>t.matches(".nav-link"),renderer:function(t,e){if(N){if(N[3]<20)return;t.save(),t.beginPath(),t.rect(...N.map(i=>Math.round(i))),t.clip(),S(t,e,{isTextWhite:!0}),t.restore()}}}},J=class J{constructor(){f(this,"name","");f(this,"iframeRect",null);f(this,"relems",{})}init(e,i){var p,w;const s=e.querySelector(".fa-compress");s&&s.remove();const n=e.querySelector(".navbar-toggler");if(n){const u=e.createElement("div");u.className="navbar-toggler-replacement",u.style.setProperty("z-index","200000"),u.style.setProperty("cursor","pointer"),n.style.setProperty("cursor","default"),e.body.appendChild(u),u.addEventListener("click",()=>{n.click()})}const r=e.querySelector("ul.navbar-nav");r&&(r.classList.remove("ms-md-auto"),r.classList.add("flex-column"));const o="gba-demo-list-frame-script",l=`
      function showMusicPlayer() {
        console.log('overridden showMusicPlayer!')
      }
      function playOggClicked() {
        console.log('overridden playOggClicked!')
      }
    `;(p=document.getElementById(o))==null||p.remove();let a=e.getElementById(o);a||(a=e.createElement("script"),a.id=o,e.head.appendChild(a)),a.textContent=l;const c="gba-demo-list-frame-style",d=`
      #navbar:has(.navbar-collapse:not(.show):not(.collapsing)) { height: 10vh;}
      #navbar:has(.navbar-collapse.show:not(.collapsing)) { height: 50vh;}
      .navbar-toggler-replacement:hover { 
        border-color: white; 
        transition-duration: 0.15s 0.15s 0.15s 0.15s;
      }

      #navbar {
        margin-top: 0;
        margin-left: 0;
        margin-right: 0;
      }

      #navbar > .container {
        margin-left: 0;
        margin-right: 0;
        padding-left: 0;
        padding-top: 0;
      }

      .navbar-brand {
        top: 0px;
        left: 0px;
      }

      .demo-row span {
        background-color: rgba(255,255,255,.5);
        border: rgb(52, 58, 64);
      }

      .demo-row {
        transition-duration: 0.15s, 0.15s, 0.15s, 0.15s;
        border: rgb(136,136,136);
      } 

      .demo-row:hover {
        transition-duration: 0.15s, 0.15s, 0.15s, 0.15s;
        border: #ccc;
      }

      label {
        transition-duration: 0.15s, 0.15s, 0.15s, 0.15s;
        border: rgb(136,136,136);
      } 

      label:hover {
        transition-duration: 0.15s, 0.15s, 0.15s, 0.15s;
        border: #ccc;
      }
    `;(w=document.getElementById(c))==null||w.remove();let h=e.getElementById(c);h||(h=e.createElement("style"),h.id=c,e.head.appendChild(h)),h.textContent=d}registerElements(e){var r;const i={};function s(o,l,a=!0){o&&(o.removeAttribute(`data-relem-${l}`),a&&Array.from(o.children).forEach(c=>s(c,l)))}function n(o,l,a=!0,c="1"){o&&(o.setAttribute(`data-relem-${l}`,c),a&&Array.from(o.children).forEach(d=>n(d,l,a,c)))}if(e&&e.contentDocument){const o=e.contentDocument;s(o.body,"reserved"),s(o.body,"registered");const l=document.getElementById("innerFrameContainer").getBoundingClientRect(),a=l.width,c=l.height;if(this.name!=="demo-frame"){const d=document.getElementById("gameFrame");d==null||d.remove()}this.init(o,l),(r=o.body)==null||r.style.setProperty("overflow-x","hidden");for(const d of Object.keys(this.flavors))o.querySelectorAll("*").forEach(h=>{if(h.hasAttribute("data-relem-reserved")||h.hasAttribute("data-relem-registered"))return;const p=this.flavors[d];if(p.detector(h)){for(const[E,v]of Object.entries(p.overrides)){let m=h.getAttribute("style")||"";if(E==="margin"&&typeof v=="number"&&(m=m.replace(/\bmargin\s*:[^;]*;?/g,""),m=`margin:${v*a/240}px;`+m),E==="margin-left"&&typeof v=="number"&&(m=m.replace(/\bmargin-left\s*:[^;]*;?/g,""),m=`margin-left:${v*a/240}px;`+m),E==="padding"&&typeof v=="number"&&(m=m.replace(/\bpadding\s*:[^;]*;?/g,""),m=`padding:${v*a/240}px;`+m),E==="left"&&typeof v=="number"&&(m=m.replace(/\bleft\s*:[^;]*;?/g,""),m=m.replace(/\bposition\s*:[^;]*;?/g,""),m=`left:${v*a/240}px;position:absolute;`+m),E==="right"&&typeof v=="number"&&(m=m.replace(/\bright\s*:[^;]*;?/g,""),m=m.replace(/\bposition\s*:[^;]*;?/g,""),m=`right:${v*a/240}px;position:absolute;`+m),E==="top"&&typeof v=="number"&&(m=m.replace(/\btop\s*:[^;]*;?/g,""),m=m.replace(/\bposition\s*:[^;]*;?/g,""),m=`top:${v*a/240}px;position:absolute;`+m),E==="bottom"&&typeof v=="number"&&(m=m.replace(/\bbottom\s*:[^;]*;?/g,""),m=m.replace(/\bposition\s*:[^;]*;?/g,""),m=`bottom:${v*a/240}px;position:absolute;`+m),E==="width")if(m=m.replace(/\bwidth\s*:[^;]*;?/g,""),typeof v=="number")m=`width:${v*a/240}px;`+m;else if(v==="text")m=`width:${st(h.innerHTML)*a/240}px;`+m;else if(typeof v=="string"&&v.startsWith("text+"))m=`width:${(parseInt(v.substring(5))+st(h.innerHTML))*a/240}px;`+m;else throw new Error(`unrecognized width value ${v}`);if(E==="height"&&typeof v=="number"&&(m=m.replace(/\bheight\s*:[^;]*;?/g,""),m=`height:${v*c/160}px;`+m,h.tagName==="SPAN"&&(m=m.replace("display:inline-block;",""),m="display:inline-block;"+m)),E==="addClasses"&&typeof v=="object")for(const P of v)h.classList.add(P);if(E==="removeClasses"&&typeof v=="object")for(const P of v)h.classList.remove(P);h.setAttribute("style",m)}const w=h.getBoundingClientRect(),u=w.left,b=w.top,x=w.width,y=w.height,g=u*(240/a),C=b*(160/c),_=x*(240/a),B=y*(160/c);i[d]||(i[d]=[]);const O={flavor:d,htmlElem:h,rect:[g,C,_,B]};if(p.frame){if(h.tagName!=="IFRAME")throw new Error("flavor with frame detected non-iframe node");const E=o.getElementById(h.id);O.innerFrame=J.create(p.frame),E.onload=()=>{O.innerFrame.registerElements(E)}}i[d].push(O),n(h,"registered",!1,d),p.doesReserveChildren&&n(h,"reserved",!0);return}});this.iframeRect=l,this.relems=i}else throw new Error("Iframe or its content document not found, or cross-origin restrictions apply.")}update(){const{iframeRect:e}=this;if(e)for(const i in this.flavors)for(const s of this.relems[i]??[]){if(!s.htmlElem.checkVisibility())continue;const n=s.htmlElem.getBoundingClientRect(),r=n.left,o=n.top,l=n.width,a=n.height,c=r*(240/e.width),d=o*(160/e.height),h=l*(240/e.width),p=a*(160/e.height);s.rect=[c,d,h,p],s.innerFrame&&s.innerFrame.update()}}static register(e,i){if(e in this._registry)throw new Error(`Frame already registered: '${e}'`);this._registry[e]=i,this._preloaded[e]=i(),this._preloaded[e].name=e}static create(e){if(e in this._preloaded)return this._preloaded[e];throw new Error(`Frame '${e}' was not preloaded`)}};f(J,"_registry",{}),f(J,"_preloaded",{});let L=J;function bi(t){return t.replaceAll("&nbsp;","").replaceAll("<br>","").trim()}function xi(t,e,i,s,n){const r=window.getComputedStyle(e.htmlElem),o=0,[l,a,c,d]=e.rect.map(h=>Math.round(h));t.lineWidth=1,t.strokeStyle=r.borderColor,t.fillStyle=r.backgroundColor,t.globalAlpha=1,t.fillRect(l+.5,a+.5,c-1,d-1),t.strokeRect(l+.5,a+.5,c-1,d-1),U(t,i.toUpperCase(),l+3+o,a+3),U(t,s.toUpperCase(),l+50+o,a+3),U(t,n.toUpperCase(),l+3+o,a+14)}const vi={h1:{overrides:{height:22},detector:t=>t.tagName==="H1",renderer:S},li:{overrides:{height:22},detector:t=>t.tagName==="LI"&&!t.matches("details>ul>li")&&!t.classList.contains("nav-item"),renderer:(t,e)=>{const i=e.htmlElem.innerHTML,s=i.indexOf("<b>"),n=i.indexOf("</b> "),r=i.substring(0,s).trim(),o=i.substring(s+3,n).trim(),l=bi(i.substring(n+4));xi(t,e,r,o,l)}},"details-li":{overrides:{height:11},detector:t=>t.matches("details>ul>li"),renderer:(t,e)=>{var s,n;(n=(s=e.htmlElem.parentElement)==null?void 0:s.parentElement)!=null&&n.hasAttribute("open")&&S(t,e,{fillStyle:"white"})}},...re},He=class He extends L{constructor(){super(...arguments);f(this,"flavors",vi)}detect(i){return i.endsWith("/changelog")}init(i,s){var n,r;super.init(i,s),(n=i.querySelector(".page-content"))==null||n.setAttribute("style",""),(r=i.querySelector(".page-content"))==null||r.classList.remove("container")}};L.register("changelog-frame",()=>new He);let nt=He;/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class M{constructor(e,i,s,n,r="div"){this.parent=e,this.object=i,this.property=s,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(r),this.domElement.classList.add("controller"),this.domElement.classList.add(n),this.$name=document.createElement("div"),this.$name.classList.add("name"),M.nextNameID=M.nextNameID||0,this.$name.id=`lil-gui-name-${++M.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",o=>o.stopPropagation()),this.domElement.addEventListener("keyup",o=>o.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(s)}name(e){return this._name=e,this.$name.textContent=e,this}onChange(e){return this._onChange=e,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(e){return this._onFinishChange=e,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(e=!0){return this.disable(!e)}disable(e=!0){return e===this._disabled?this:(this._disabled=e,this.domElement.classList.toggle("disabled",e),this.$disable.toggleAttribute("disabled",e),this)}show(e=!0){return this._hidden=!e,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(e){const i=this.parent.add(this.object,this.property,e);return i.name(this._name),this.destroy(),i}min(e){return this}max(e){return this}step(e){return this}decimals(e){return this}listen(e=!0){return this._listening=e,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const e=this.save();e!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=e}getValue(){return this.object[this.property]}setValue(e){return this.getValue()!==e&&(this.object[this.property]=e,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(e){return this.setValue(e),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class Ci extends M{constructor(e,i,s){super(e,i,s,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function we(t){let e,i;return(e=t.match(/(#|0x)?([a-f0-9]{6})/i))?i=e[2]:(e=t.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?i=parseInt(e[1]).toString(16).padStart(2,0)+parseInt(e[2]).toString(16).padStart(2,0)+parseInt(e[3]).toString(16).padStart(2,0):(e=t.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(i=e[1]+e[1]+e[2]+e[2]+e[3]+e[3]),i?"#"+i:!1}const Ai={isPrimitive:!0,match:t=>typeof t=="string",fromHexString:we,toHexString:we},Z={isPrimitive:!0,match:t=>typeof t=="number",fromHexString:t=>parseInt(t.substring(1),16),toHexString:t=>"#"+t.toString(16).padStart(6,0)},Ei={isPrimitive:!1,match:t=>Array.isArray(t),fromHexString(t,e,i=1){const s=Z.fromHexString(t);e[0]=(s>>16&255)/255*i,e[1]=(s>>8&255)/255*i,e[2]=(s&255)/255*i},toHexString([t,e,i],s=1){s=255/s;const n=t*s<<16^e*s<<8^i*s<<0;return Z.toHexString(n)}},_i={isPrimitive:!1,match:t=>Object(t)===t,fromHexString(t,e,i=1){const s=Z.fromHexString(t);e.r=(s>>16&255)/255*i,e.g=(s>>8&255)/255*i,e.b=(s&255)/255*i},toHexString({r:t,g:e,b:i},s=1){s=255/s;const n=t*s<<16^e*s<<8^i*s<<0;return Z.toHexString(n)}},Li=[Ai,Z,Ei,_i];function Si(t){return Li.find(e=>e.match(t))}class $i extends M{constructor(e,i,s,n){super(e,i,s,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=Si(this.initialValue),this._rgbScale=n,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const r=we(this.$text.value);r&&this._setValueFromHexString(r)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(e){if(this._format.isPrimitive){const i=this._format.fromHexString(e);this.setValue(i)}else this._format.fromHexString(e,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(e){return this._setValueFromHexString(e),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class he extends M{constructor(e,i,s){super(e,i,s,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",n=>{n.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class ki extends M{constructor(e,i,s,n,r,o){super(e,i,s,"number"),this._initInput(),this.min(n),this.max(r);const l=o!==void 0;this.step(l?o:this._getImplicitStep(),l),this.updateDisplay()}decimals(e){return this._decimals=e,this.updateDisplay(),this}min(e){return this._min=e,this._onUpdateMinMax(),this}max(e){return this._max=e,this._onUpdateMinMax(),this}step(e,i=!0){return this._step=e,this._stepExplicit=i,this}updateDisplay(){const e=this.getValue();if(this._hasSlider){let i=(e-this._min)/(this._max-this._min);i=Math.max(0,Math.min(i,1)),this.$fill.style.width=i*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?e:e.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const i=()=>{let g=parseFloat(this.$input.value);isNaN(g)||(this._stepExplicit&&(g=this._snap(g)),this.setValue(this._clamp(g)))},s=g=>{const C=parseFloat(this.$input.value);isNaN(C)||(this._snapClampSetValue(C+g),this.$input.value=this.getValue())},n=g=>{g.key==="Enter"&&this.$input.blur(),g.code==="ArrowUp"&&(g.preventDefault(),s(this._step*this._arrowKeyMultiplier(g))),g.code==="ArrowDown"&&(g.preventDefault(),s(this._step*this._arrowKeyMultiplier(g)*-1))},r=g=>{this._inputFocused&&(g.preventDefault(),s(this._step*this._normalizeMouseWheel(g)))};let o=!1,l,a,c,d,h;const p=5,w=g=>{l=g.clientX,a=c=g.clientY,o=!0,d=this.getValue(),h=0,window.addEventListener("mousemove",u),window.addEventListener("mouseup",b)},u=g=>{if(o){const C=g.clientX-l,_=g.clientY-a;Math.abs(_)>p?(g.preventDefault(),this.$input.blur(),o=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(C)>p&&b()}if(!o){const C=g.clientY-c;h-=C*this._step*this._arrowKeyMultiplier(g),d+h>this._max?h=this._max-d:d+h<this._min&&(h=this._min-d),this._snapClampSetValue(d+h)}c=g.clientY},b=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",u),window.removeEventListener("mouseup",b)},x=()=>{this._inputFocused=!0},y=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",i),this.$input.addEventListener("keydown",n),this.$input.addEventListener("wheel",r,{passive:!1}),this.$input.addEventListener("mousedown",w),this.$input.addEventListener("focus",x),this.$input.addEventListener("blur",y)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const e=(y,g,C,_,B)=>(y-g)/(C-g)*(B-_)+_,i=y=>{const g=this.$slider.getBoundingClientRect();let C=e(y,g.left,g.right,this._min,this._max);this._snapClampSetValue(C)},s=y=>{this._setDraggingStyle(!0),i(y.clientX),window.addEventListener("mousemove",n),window.addEventListener("mouseup",r)},n=y=>{i(y.clientX)},r=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",n),window.removeEventListener("mouseup",r)};let o=!1,l,a;const c=y=>{y.preventDefault(),this._setDraggingStyle(!0),i(y.touches[0].clientX),o=!1},d=y=>{y.touches.length>1||(this._hasScrollBar?(l=y.touches[0].clientX,a=y.touches[0].clientY,o=!0):c(y),window.addEventListener("touchmove",h,{passive:!1}),window.addEventListener("touchend",p))},h=y=>{if(o){const g=y.touches[0].clientX-l,C=y.touches[0].clientY-a;Math.abs(g)>Math.abs(C)?c(y):(window.removeEventListener("touchmove",h),window.removeEventListener("touchend",p))}else y.preventDefault(),i(y.touches[0].clientX)},p=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",h),window.removeEventListener("touchend",p)},w=this._callOnFinishChange.bind(this),u=400;let b;const x=y=>{if(Math.abs(y.deltaX)<Math.abs(y.deltaY)&&this._hasScrollBar)return;y.preventDefault();const C=this._normalizeMouseWheel(y)*this._step;this._snapClampSetValue(this.getValue()+C),this.$input.value=this.getValue(),clearTimeout(b),b=setTimeout(w,u)};this.$slider.addEventListener("mousedown",s),this.$slider.addEventListener("touchstart",d,{passive:!1}),this.$slider.addEventListener("wheel",x,{passive:!1})}_setDraggingStyle(e,i="horizontal"){this.$slider&&this.$slider.classList.toggle("active",e),document.body.classList.toggle("lil-gui-dragging",e),document.body.classList.toggle(`lil-gui-${i}`,e)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(e){let{deltaX:i,deltaY:s}=e;return Math.floor(e.deltaY)!==e.deltaY&&e.wheelDelta&&(i=0,s=-e.wheelDelta/120,s*=this._stepExplicit?1:10),i+-s}_arrowKeyMultiplier(e){let i=this._stepExplicit?1:10;return e.shiftKey?i*=10:e.altKey&&(i/=10),i}_snap(e){let i=0;return this._hasMin?i=this._min:this._hasMax&&(i=this._max),e-=i,e=Math.round(e/this._step)*this._step,e+=i,e=parseFloat(e.toPrecision(15)),e}_clamp(e){return e<this._min&&(e=this._min),e>this._max&&(e=this._max),e}_snapClampSetValue(e){this.setValue(this._clamp(this._snap(e)))}get _hasScrollBar(){const e=this.parent.root.$children;return e.scrollHeight>e.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class Ii extends M{constructor(e,i,s,n){super(e,i,s,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(n)}options(e){return this._values=Array.isArray(e)?e:Object.values(e),this._names=Array.isArray(e)?e:Object.keys(e),this.$select.replaceChildren(),this._names.forEach(i=>{const s=document.createElement("option");s.textContent=i,this.$select.appendChild(s)}),this.updateDisplay(),this}updateDisplay(){const e=this.getValue(),i=this._values.indexOf(e);return this.$select.selectedIndex=i,this.$display.textContent=i===-1?e:this._names[i],this}}class Mi extends M{constructor(e,i,s){super(e,i,s,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",n=>{n.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var Ri=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function Fi(t){const e=document.createElement("style");e.innerHTML=t;const i=document.querySelector("head link[rel=stylesheet], head style");i?document.head.insertBefore(e,i):document.head.appendChild(e)}let ot=!1;class Ie{constructor({parent:e,autoPlace:i=e===void 0,container:s,width:n,title:r="Controls",closeFolders:o=!1,injectStyles:l=!0,touchStyles:a=!0}={}){if(this.parent=e,this.root=e?e.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(r),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),a&&this.domElement.classList.add("allow-touch-styles"),!ot&&l&&(Fi(Ri),ot=!0),s?s.appendChild(this.domElement):i&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),n&&this.domElement.style.setProperty("--width",n+"px"),this._closeFolders=o}add(e,i,s,n,r){if(Object(s)===s)return new Ii(this,e,i,s);const o=e[i];switch(typeof o){case"number":return new ki(this,e,i,s,n,r);case"boolean":return new Ci(this,e,i);case"string":return new Mi(this,e,i);case"function":return new he(this,e,i)}console.error(`gui.add failed
	property:`,i,`
	object:`,e,`
	value:`,o)}addColor(e,i,s=1){return new $i(this,e,i,s)}addFolder(e){const i=new Ie({parent:this,title:e});return this.root._closeFolders&&i.close(),i}load(e,i=!0){return e.controllers&&this.controllers.forEach(s=>{s instanceof he||s._name in e.controllers&&s.load(e.controllers[s._name])}),i&&e.folders&&this.folders.forEach(s=>{s._title in e.folders&&s.load(e.folders[s._title])}),this}save(e=!0){const i={controllers:{},folders:{}};return this.controllers.forEach(s=>{if(!(s instanceof he)){if(s._name in i.controllers)throw new Error(`Cannot save GUI with duplicate property "${s._name}"`);i.controllers[s._name]=s.save()}}),e&&this.folders.forEach(s=>{if(s._title in i.folders)throw new Error(`Cannot save GUI with duplicate folder "${s._title}"`);i.folders[s._title]=s.save()}),i}open(e=!0){return this._setClosed(!e),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(e){this._closed!==e&&(this._closed=e,this._callOnOpenClose(this))}show(e=!0){return this._hidden=!e,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(e=!0){return this._setClosed(!e),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const i=this.$children.clientHeight;this.$children.style.height=i+"px",this.domElement.classList.add("transition");const s=r=>{r.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",s))};this.$children.addEventListener("transitionend",s);const n=e?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!e),requestAnimationFrame(()=>{this.$children.style.height=n+"px"})}),this}title(e){return this._title=e,this.$title.textContent=e,this}reset(e=!0){return(e?this.controllersRecursive():this.controllers).forEach(s=>s.reset()),this}onChange(e){return this._onChange=e,this}_callOnChange(e){this.parent&&this.parent._callOnChange(e),this._onChange!==void 0&&this._onChange.call(this,{object:e.object,property:e.property,value:e.getValue(),controller:e})}onFinishChange(e){return this._onFinishChange=e,this}_callOnFinishChange(e){this.parent&&this.parent._callOnFinishChange(e),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:e.object,property:e.property,value:e.getValue(),controller:e})}onOpenClose(e){return this._onOpenClose=e,this}_callOnOpenClose(e){this.parent&&this.parent._callOnOpenClose(e),this._onOpenClose!==void 0&&this._onOpenClose.call(this,e)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(e=>e.destroy())}controllersRecursive(){let e=Array.from(this.controllers);return this.folders.forEach(i=>{e=e.concat(i.controllersRecursive())}),e}foldersRecursive(){let e=Array.from(this.folders);return this.folders.forEach(i=>{e=e.concat(i.foldersRecursive())}),e}}let be={},z;function Ti(t){const e=t.config.tree;be={},z&&z.destroy(),z=new Ie({closeFolders:!0,container:document.getElementById("controls-container")}),Ot(z,e,t),z.onOpenClose(()=>{z._closed&&setTimeout(()=>{z.destroy()},200)})}function Ot(t,e,i){const s=e.children;for(const n in s){const r=s[n];if(!("isHidden"in r&&r.isHidden))if("action"in r){const o=r,l=r.label??Q(n),a={[l]:async()=>{await o.action(i)}};t.add(a,l)}else if("options"in r&&Array.isArray(r.options)){const o=r,l={};for(const c of o.options)typeof c=="string"&&(l[c]=c);const a=t.add(o,"value",l).name(o.label??Q(n)).listen();a.onChange(c=>{o.value=c,o.onChange&&o.onChange(i,c)}),de(a,o.tooltip),be[n]=a}else if("value"in r&&typeof r.value=="number"){const o=r,l=t.add(o,"value",o.min,o.max).name(o.label??Q(n));o.step&&l.step(o.step),l.onChange(a=>{typeof a=="number"&&(o.value=a,o.onChange&&o.onChange(i,a))}),de(l,o.tooltip),be[n]=l}else{const o=t.addFolder(r.label??Q(n));de(o,r.tooltip),Ot(o,r,i)}}}function de(t,e){if(typeof e!="string"||e.trim()==="")return;t.domElement.setAttribute("title",e)}function Q(t){return/^[A-Z0-9_]+$/.test(t)?t.toLowerCase().split("_").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ").trim():t.replace(/([A-Z])/g," $1").replace(/^./,e=>e.toUpperCase()).trim()}function Oi(t){t.isLandscape,t.isPortrait}function Pi(t){return Object.entries(t)}function Bi(t,e){return new xe(t,e)._computedRects}const I=class I{constructor(e,i){f(this,"_computedRects",{});f(this,"isPortrait",!1);f(this,"isLandscape",!1);f(this,"parent");f(this,"_currentLayoutKey","");f(this,"_childrenToParse",{});e[2]>e[3]?this.isLandscape=!0:this.isPortrait=!0;const s=600;e[2]<s||e[3]<s?I.isSmall=!0:I.isSmall=!1,Oi(this),this.parent=e;for(const[r,o]of Object.entries(i))this.parent=e,this._currentLayoutKey=r,this._computedRects[r]=this.computeRect(o);const n=this._childrenToParse;for(;Object.keys(n).length>0;){const r=Object.keys(n)[0],o=n[r];delete n[r];const l=this._computedRects[r],{_computedRects:a}=new I(l,o);for(const c in a)this._computedRects[`${r}.${c}`]=a[c]}}computeRect(e){let i=[...this.parent];for(const[s,n]of Pi(e))if(s==="parent"){if(!(n in this._computedRects))throw new Error(`layout parent '${n}' not defined by any previous rulesets`);this.parent=this._computedRects[n],i=[...this.parent]}else if(s.startsWith("parent@")){const[r,o]=s.split("@");if(typeof n!="string"||!(n in this._computedRects))throw new Error(`layout parent '${n}' not defined by any previous rulesets`);if(o==="portrait")this.isPortrait&&(this.parent=this._computedRects[n],i=[...this.parent]);else if(o==="landscape")this.isLandscape&&(this.parent=this._computedRects[n],i=[...this.parent]);else if(o==="sm-portrait")this.isPortrait&&I.isSmall&&(this.parent=this._computedRects[n],i=[...this.parent]);else if(o==="sm-landscape")this.isLandscape&&I.isSmall&&(this.parent=this._computedRects[n],i=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else if(s==="children")this._childrenToParse[this._currentLayoutKey]=n;else if(s.includes("@")){const[r,o]=s.split("@");if(o==="portrait")this.isPortrait&&(i=this.applyRule(i,r,n));else if(o==="landscape")this.isLandscape&&(i=this.applyRule(i,r,n));else if(o==="sm-portrait")this.isPortrait&&I.isSmall&&(i=this.applyRule(i,r,n));else if(o==="sm-landscape")this.isLandscape&&I.isSmall&&(i=this.applyRule(i,r,n));else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else i=this.applyRule(i,s,n);return[i[0],i[1],i[2],i[3]]}applyRule(e,i,s){const[n,r,o,l]=e,[a,c,d,h]=this.parent,p=(u,b)=>{if(typeof b=="function"&&(b=b()),typeof b=="string"&&b.endsWith("%")){const x=parseFloat(b)/100;return["left","right","width","margin"].includes(u)?d*x:h*x}else{if(b==="auto")return u==="width"?a+d-n:u==="height"?c+h-r:["left","right"].includes(u)?(d-o)/2:(h-l)/2;if(typeof b=="number"&&b<0){if(u==="width")return d+b;if(u==="height")return h+b}}return Number(b)},w=i.split("-");if(w.length===2){const[u,b]=w;let x;if(u==="min")x=Math.max;else if(u==="max")x=Math.min;else throw new Error("only min- or max- prefixed allowed");if(b==="width")return[n,r,x(o,p("width",s)),l];if(b==="height")return[n,r,o,x(l,p("height",s))];if(b==="left")return[x(n,p("left",s)),r,o,l];throw new Error("only min/max-width, -height, or -left allowed")}switch(i){case"left":return[a+p("left",s),r,o,l];case"right":return[a+d-o-p("right",s),r,o,l];case"top":return[n,c+p("top",s),o,l];case"bottom":return[n,c+h-l-p("bottom",s),o,l];case"width":return[n,r,p("width",s),l];case"height":return[n,r,o,p("height",s)];case"margin":{const u=p("margin",s);return[n+u,r+u,o-2*u,l-2*u]}default:return e}}};f(I,"isSmall",!1);let xe=I;function zi(t,e){const i=e.display.draw?"canvas":e.display.type==="button"?"button":"div",s=e.display.classes??[],n=s.filter(l=>l.startsWith("fa-")),r=s.filter(l=>!l.startsWith("fa-"));e.display.type!=="button"&&r.push("noselect");const o=Hi(`
    <${i} id="${t}" 
       class="
          hidden
          gui-element 
          ${e.display.type} 
          ${r.join(" ")}
        ">

      <span class="${n.join(" ")}">${e.display.label??""}</span>
    </${i}>
  `);for(const[l,a]of Object.entries(e.display.styles??{}))o.style.setProperty(l,a);return e.id=t,e.htmlElem=o,o}function Pt(t){let e;typeof t=="string"?e=document.getElementById(t):e=t.htmlElem,e&&e&&e.classList.contains("gui-element")&&e.classList.add("hidden")}function Bt(t){const e=document.getElementById(t);e&&e.classList.contains("gui-element")&&e.classList.remove("hidden")}function Wi(t,e,i){if(!i){t.classList.add("hidden");return}t.style.opacity="0";const[s,n,r,o]=i;t.style.display="",t.style.left=`${s}px`,t.style.top=`${n}px`,t.style.width=`${r}px`,t.style.height=`${o}px`;const l=t;l.width=r*window.devicePixelRatio,l.height=o*window.devicePixelRatio}function Hi(t){const e=document.createElement("div");return e.innerHTML=t.trim(),e.firstChild}const rt={};let Di=0;class ${constructor(){f(this,"guiLayout");f(this,"gbaRectangles",{});f(this,"layoutRectangles",{});f(this,"elements",{});f(this,"layoutFactory")}init(e,i,s){this.layoutFactory=i;for(const n of s)if(typeof n.id=="string")this.elements[n.id]=n;else{const r=`_${Di++}`;this.elements[r]=n;const o=zi(r,n);let l=!1;o.onmousedown=a=>{var c;l=!0,(c=document.getElementById("innerFrame"))==null||c.style.setProperty("pointer-events","none"),this.clickElem(n,{elementId:r,recursio:e,inputEvent:{screenPos:[a.pageX,a.pageY]}}),o.blur()},document.addEventListener("mousemove",a=>{l&&(this.clickElem(n,{elementId:r,recursio:e,inputEvent:{screenPos:[a.pageX,a.pageY]}}),o.blur())}),document.addEventListener("mouseup",()=>{var a;l=!1,(a=document.getElementById("innerFrame"))==null||a.style.setProperty("pointer-events","")}),o.style.display="none",document.body.appendChild(o),rt[r]=o,n.id=r}}refreshLayout(e){const{pxScreenRectangle:i}=e.layeredViewport;this.guiLayout=this.layoutFactory(e);{this.layoutRectangles=Bi([0,0,240,160],this.guiLayout),this.gbaRectangles={};const[s,n,r,o]=i;for(const l in this.layoutRectangles){const[a,c,d,h]=this.layoutRectangles[l];this.gbaRectangles[l]=[a,c,d,h],this.layoutRectangles[l][0]=s+r*(a/240),this.layoutRectangles[l][1]=n+o*(c/160),this.layoutRectangles[l][2]=r*(d/240),this.layoutRectangles[l][3]=o*(h/160)}}for(const s in this.elements){const n=this.elements[s],r=this.layoutRectangles[n.layoutKey];if(n.rectangle=r,n.rectangle){const o=parseInt(e.layeredViewport.canvas.style.width)/e.layeredViewport.w;n.dprRectangle=n.rectangle.map(l=>l/o)}Wi(rt[s],n,r)}}click(e){const{recursio:i,lvPos:s}=e,n=this.pickElementAtPoint(s);return n?(this._click({recursio:i,inputEvent:e,elementId:n}),!0):!1}pickElementAtPoint(...e){const i=this.layoutRectangles.screen;if(!i)return;const[s,n,r,o]=i;for(const l in this.elements){const a=this.elements[l].layoutKey,c=this.layoutRectangles[a];if(!c)continue;const[d,h,p,w]=c,u=(d-s)*240/r,b=(h-n)*160/o,x=240*p/r,y=160*w/o;for(const g of e)if(g[0]>u&&g[0]<u+x&&g[1]>b&&g[1]<b+y)return l}}_click(e){const i=this.elements[e.elementId];this.clickElem(i,e)}clickElem(e,i){const{clickAction:s}=e;s&&s(i,e.rectangle)}keydown(e,i){for(const s in this.elements){const n=this.elements[s],{hotkeys:r}=n;if(r!=null&&r.includes(i))return this._click({elementId:s,recursio:e,buttonCode:i}),!0}return!1}static register(e,i){if(e in this._registry)throw new Error(`Game already registered: '${e}'`);this._registry[e]=i}static preload(e,i){const{factory:s,layoutFactory:n,elements:r}=this._registry[i],o=s();this._preloaded[i]=o,o.init(e,n,r)}static create(e){if(e in this._preloaded)return this._preloaded[e];throw new Error(`gui '${e}' was not preloaded`)}}f($,"_registry",{}),f($,"_preloaded",{});class oe extends ${constructor(){super(...arguments);f(this,"_isShowing",!1)}get isShowing(){return this._isShowing}toggle(i,s){typeof s=="boolean"?this._isShowing=s:this._isShowing=!this._isShowing;for(const n in this.elements)this._isShowing?(this.elements[n].display.classes??[]).includes("hidden")||Bt(n):Pt(n);this._isShowing&&this.refreshLayout(i),this.onToggle(i)}}const zt=[...j.NAMES];zt.reverse();class W{constructor(){f(this,"gui");f(this,"helper")}keydown(e,i){for(const s of zt){const n=$.create(s);if(n instanceof oe&&n.isShowing&&n.keydown(e,i))return}this.gui.keydown(e,i)}static register(e,i){if(e in this._registry)throw new Error(`Game already registered: '${e}'`);this._registry[e]=i}static preload(e){const{factory:i,guiName:s}=this._registry[e],n=i();this._preloaded[e]=n,n.gui=$.create(s)}static create(e,i){var n;const s=this._preloaded[e];if(!s)throw new Error(`game '${e}' was not preloaded`);return s.helper=s.reset(i),(n=s.gui)==null||n.refreshLayout(i),i.game=s,s.helper.init(i),s}}f(W,"_registry",{}),f(W,"_preloaded",{});let ie=!1;const Vi=[{on:["mouseleave"],action:(t,e)=>{}},{on:["touchmove"],action:(t,e)=>{ie||e.game.helper.click(t.lvPos,t.recursio)}},{on:["mousedown","touchstart"],action:(t,e)=>{e.game.helper.click(t.lvPos,t.recursio)}},{on:["mouseup","touchend","touchcancel"],action:(t,e)=>{}}];function Ni(t){const{layeredViewport:e}=t,{canvas:i}=e;for(const{on:s,action:n}of Vi)for(const r of s)i.addEventListener(r,o=>{lt(t,o,n)}),document.getElementById("gbaScreen").addEventListener(r,o=>{lt(t,o,n)}),window.addEventListener("wheel",o=>{o.preventDefault(),document.getElementById("innerFrame").contentWindow.scrollBy(o.deltaX,o.deltaY*10)},{passive:!1});navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",s=>{window.mouseXForTestSupport=s.clientX,window.mouseYForTestSupport=s.clientY;const n=window.getComputedStyle(s.target).cursor;n==="auto"?window.mouseCursorTestSupport="default":window.mouseCursorTestSupport=n,s.stopPropagation()})}function lt(t,e,i){if(ie&&e.type.startsWith("mouse"))return;const s=Yi(e);for(const n of s){const r=n.screenPos;!ie&&e.type.startsWith("touch")&&(ie=!0);const o=t.layeredViewport.w/parseInt(t.layeredViewport.canvas.style.width),l=[(r[0]-parseInt(t.layeredViewport.canvas.style.left))*o,(r[1]-parseInt(t.layeredViewport.canvas.style.top))*o];i({recursio:t,event:e,screenPos:r,lvPos:l,inputId:n.touchId},t)}}function Yi(t){const e=[];if("changedTouches"in t&&t.changedTouches.length>0)for(const i of t.changedTouches)typeof i.clientX=="number"&&typeof i.clientY=="number"?e.push({screenPos:[i.clientX,i.clientY],touchId:i.identifier}):e.push({screenPos:[i.pageX,i.pageY],touchId:i.identifier});else"clientX"in t&&"clientY"in t&&e.push({screenPos:[t.clientX,t.clientY],touchId:"mouse"});return e}const Gi=[170,170,170],Xi=[100,100,100];let ve=0;function ji(t){return t<=.5?t=t*2:t=(1-t)*2,t}function Ui(){const t=Le.flatConfig.flashPeriod,e=performance.now(),i=ji(e%t/t),s=Gi.map((n,r)=>Math.round(n+(Xi[r]-n)*i));ve=i,`${s[0]}${s[1]}${s[2]}`}class Wt{constructor(){f(this,"canvas");f(this,"ctx");f(this,"w");f(this,"h");f(this,"screenRectangle");f(this,"pxScreenRectangle")}handleResize(e){const i=window.devicePixelRatio;this.w=this.canvas.offsetWidth*i,this.h=this.canvas.offsetHeight*i,this.screenRectangle=[0,0,this.w,this.h],this.pxScreenRectangle=[0,0,this.canvas.offsetWidth,this.canvas.offsetHeight],this.canvas.width=this.w,this.canvas.height=this.h}init(e,i){this.canvas=i,this.ctx=this.canvas.getContext("2d"),this.handleResize(e)}}class Ki extends Wt{handleResize(e){this.w=240,this.h=160;const i=window.devicePixelRatio,s=document.getElementById("gbaScreenContainer");this.screenRectangle=[parseInt(s.style.left)*i,parseInt(s.style.top)*i,this.w,this.h],this.pxScreenRectangle=[parseInt(s.style.left),parseInt(s.style.top),s.offsetWidth,s.offsetHeight],this.canvas.width=this.w,this.canvas.height=this.h}}const K={"fa-rotate-left":new Path2D(`

    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 168.3C277.6
     109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 259.3 530.7 184.3 
     455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 412.9C98.8 422.4 94.4 
     442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 501C601 401 601 239 501
      139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 78.8 65.8C69.8 69.5 64 78.3 
      64 88L64 232C64 245.3 74.7 256 88 256z
  
  
      `),"fa-rotate-right":new Path2D(`

    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 168.3C362.4
     109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 380.7 530.7 455.7
      455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 421.7C536.7 431.8 540.2
       451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 139 501C39.1 401 39 239 139 
       139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 62.1 561.2 65.8C570.2 69.5 576 
       78.3 576 88L576 232C576 245.3 565.3 256 552 256z

  
      `),"fa-arrow-up":new Path2D(`


    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z

  
  
      `),left:new Path2D(`
    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 
    168.3C277.6 109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 
    259.3 530.7 184.3 455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 
    412.9C98.8 422.4 94.4 442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 
    501C601 401 601 239 501 139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 
    78.8 65.8C69.8 69.5 64 78.3 64 88L64 232C64 245.3 74.7 256 88 256z
  `),forward:new Path2D(`
    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z
  `),right:new Path2D(`
    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 
    168.3C362.4 109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 
    380.7 530.7 455.7 455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 
    421.7C536.7 431.8 540.2 451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 
    139 501C39.1 401 39 239 139 139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 
    62.1 561.2 65.8C570.2 69.5 576 78.3 576 88L576 232C576 245.3 565.3 256 552 256z
  `),"triangle-ex":new Path2D(`
        M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 
        550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 
        85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320
        480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 
        288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 
        257.7C352.5 239.5 338.1 224 319.8 224z
    `),"square-check":new Path2D(`
        M480 96C515.3 96 544 124.7 544 160L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 
        515.3 96 480L96 160C96 124.7 124.7 96 160 96L480 96zM438 209.7C427.3 201.9 412.3 204.3 404.5 
        215L285.1 379.2L233 327.1C223.6 317.7 208.4 317.7 199.1 327.1C189.8 336.5 189.7 351.7 199.1 
        361L271.1 433C276.1 438 283 440.5 289.9 440C296.8 439.5 303.3 435.9 307.4 430.2L443.3 243.2C451.1 
        232.5 448.7 217.5 438 209.7z
    `),"fa-gear":new Path2D(`

      M259.1 73.5C262.1 58.7 275.2 48 290.4 48L350.2 48C365.4 48 378.5 58.7 381.5 73.5L396 143.5C410.1
       149.5 423.3 157.2 435.3 166.3L503.1 143.8C517.5 139 533.3 145 540.9 158.2L570.8 210C578.4 223.2
        575.7 239.8 564.3 249.9L511 297.3C511.9 304.7 512.3 312.3 512.3 320C512.3 327.7 511.8 335.3 511
         342.7L564.4 390.2C575.8 400.3 578.4 417 570.9 430.1L541 481.9C533.4 495 517.6 501.1 503.2 
         496.3L435.4 473.8C423.3 482.9 410.1 490.5 396.1 496.6L381.7 566.5C378.6 581.4 365.5 592 350.4
          592L290.6 592C275.4 592 262.3 581.3 259.3 566.5L244.9 496.6C230.8 490.6 217.7 482.9 205.6
           473.8L137.5 496.3C123.1 501.1 107.3 495.1 99.7 481.9L69.8 430.1C62.2 416.9 64.9 400.3 76.3
            390.2L129.7 342.7C128.8 335.3 128.4 327.7 128.4 320C128.4 312.3 128.9 304.7 129.7 297.3L76.3
             249.8C64.9 239.7 62.3 223 69.8 209.9L99.7 158.1C107.3 144.9 123.1 138.9 137.5 143.7L205.3 
             166.2C217.4 157.1 230.6 149.5 244.6 143.4L259.1 73.5zM320.3 400C364.5 399.8 400.2 363.9 400
              319.7C399.8 275.5 363.9 239.8 319.7 240C275.5 240.2 239.8 276.1 240 320.3C240.2 364.5 276.1
               400.2 320.3 400z

      
    `),"fa-trash":new Path2D(`


      M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 
      160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 
      48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576
       197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z
      
    `),"fa-list-check":new Path2D(`

      M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 
      224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4
       106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 
       379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 
       95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 
       302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 
       192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576
        337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 
        448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 
        440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 
        440 128 440z

      
    `),"fa-x":new Path2D(`

      M504.6 148.5C515.9 134.9 514.1 114.7 500.5 103.4C486.9 92.1 466.7 93.9 455.4 107.5L320 270L184.6
       107.5C173.3 93.9 153.1 92.1 139.5 103.4C125.9 114.7 124.1 134.9 135.4 148.5L278.3 320L135.4
        491.5C124.1 505.1 125.9 525.3 139.5 536.6C153.1 547.9 173.3 546.1 184.6 532.5L320 370L455.4
         532.5C466.7 546.1 486.9 547.9 500.5 536.6C514.1 525.3 515.9 505.1 504.6 491.5L361.7 320L504.6 148.5z

      
    `),"fa-arrow-pointer":new Path2D(`


      M173.3 66.5C181.4 62.4 191.2 63.3 198.4 68.8L518.4 308.7C526.7 314.9 530 325.7 
      526.8 335.5C523.6 345.3 514.4 351.9 504 351.9L351.7 351.9L440.6 529.6C448.5
       545.4 442.1 564.6 426.3 572.5C410.5 580.4 391.3 574 383.4 558.2L294.5 380.5L203.2 
       502.3C197 510.6 186.2 513.9 176.4 510.7C166.6 507.5 160 498.3 160 488L160
        88C160 78.9 165.1 70.6 173.3 66.5z
      
    `)},F=11,qi=1,Ji=["black","white"],De=class De extends T{constructor(){super(...arguments);f(this,"keys",Ji)}generateImage(i){const s=F*Object.keys(K).length,n=new OffscreenCanvas(s,F),r=n.getContext("2d");r.fillStyle="black";let o=0;for(const c in K){r.save(),r.translate(o+F/2,F/2);const d=-320,h=F/640*qi;r.scale(h,h),r.translate(d,d),r.beginPath(),r.fill(K[c]),r.restore(),o+=F}const l=r.getImageData(0,0,n.width,n.height),a=l.data;for(let c=0;c<a.length;c+=4)a[c+3]<128?a[c+3]=0:(i==="white"?(a[c]=255,a[c+1]=255,a[c+2]=255):(a[c]=0,a[c+1]=0,a[c+2]=0),a[c+3]=255);return r.putImageData(l,0,0),n}};T.register("icons-preloader",()=>new De);let at=De;function Zi(t,e,i,s,n=!1){const r=Object.keys(K).indexOf(e);if(r===-1)throw new Error(`Key ${e} not found in SVG_PATHS`);const o=r*F,l=0,a=F,c=F,{black:d,white:h}=T.create("icons-preloader").images;t.drawImage(n?h:d,o,l,a,c,i,s,a,c)}function ct(t,e,i,s){var d,h,p,w;if(!i.htmlElem||((d=i.htmlElem)==null?void 0:d.style.display)==="none"||(h=i.htmlElem)!=null&&h.classList.contains("hidden"))return;const n=i.rectangle;if(!n)return;const[r,o,l,a]=Qi(n,s);if(i.display.draw){i.display.draw(t,e,[r,o,l,a]);return}const c=window.getComputedStyle(i.htmlElem,null);if(t.fillStyle=c.getPropertyValue("background-color"),t.strokeStyle=c.getPropertyValue("border-color"),i.display.type==="transparent"?t.globalAlpha=.5:t.globalAlpha=1,t.fillRect(r,o,l,a),(p=i.display.classes)!=null&&p.includes("loading-bar")){t.fillStyle="rgb(150,150,200)";const b=window.getComputedStyle(i.htmlElem).getPropertyValue("--progress"),y=parseFloat(b)/100;t.fillRect(r,o,l*y,a)}if((w=i.display.styles)!=null&&w.outline&&(t.lineWidth=1,t.strokeStyle="black",t.globalAlpha=1,t.strokeRect(r+.5,o+.5,l-1,a-1)),c.getPropertyValue("border").startsWith("0px")||(t.globalAlpha=1,t.lineWidth=1,t.strokeStyle="gray",t.globalAlpha=1,t.strokeRect(r+.5,o+.5,l-1,a-1),t.strokeStyle="gray",t.globalAlpha=.5,t.strokeRect(r-.5,o-.5,l+1,a+1),t.globalAlpha=1),i.display.label){const u=i.display.textAlign==="center";es(i,t,[r,o,l,a],u)}i.display.draw&&t.drawImage(i.htmlElem,r,o,l,a);for(const u of i.display.classes??[])if(u in K){Zi(t,u,r,o,Ht(i));break}}function Qi(t,e){const[i,s,n,r]=e,[o,l,a,c]=t,d=240/n,h=(o-i)*d,p=(l-s)*d,w=a*d,u=c*d;return[h,p,w,u]}function es(t,e,i,s=!1){let n=3;i[3]===9?n=2:i[3]===7?n=1:i[3]<=80?n=Math.round((i[3]-5)/2):n=3;let r=3;const o=(t.display.label??"").toUpperCase();if(s){const l=(t.display.label??"").length*5;r=Math.round((i[2]-l)/2)}U(e,o,Math.round(i[0])+r,Math.round(i[1])+n,Ht(t))}function Ht(t){if(!t.htmlElem)return!1;const i=window.getComputedStyle(t.htmlElem).getPropertyValue("color");return i.trim()==="rgb(255, 255, 255)"||i.trim()==="rgba(255, 255, 255, 1)"}let ht=!1,dt=!1;class ts{constructor(e){f(this,"didLoadAssets",!1);f(this,"config",_t);f(this,"layeredViewport");f(this,"gbaViewport",null);f(this,"currentFrame",L.create("demo-list-frame"));f(this,"game");f(this,"isFinished",!1);f(this,"interludeCountdown",0);f(this,"didBuildControls",!1);if(this.defaultLayeredViewport=e,this.layeredViewport=e,ht)throw new Error("Recursio constructed multiple times");ht=!0;for(const i of j.NAMES)$.preload(this,i);for(const i of Et.NAMES)W.preload(i)}get gui(){return this.game.gui}switchToGame(e){if(this.config.refreshConfig(),this.config.flatConfig.game!==e)throw new Error("config game does not match argument");for(const i in this.game.gui.elements)Pt(i);W.create(e,this),this.onResize()}init(){if(dt)throw new Error("Recursio initialized multiple times");dt=!0,window.recursio=this;for(const n of j.NAMES){const r=$.create(n);r instanceof oe&&r.toggle(this,!1)}this.game=W.create(this.config.flatConfig.game,this),Ni(this),window.addEventListener("resize",()=>this.onResize());const e=document.getElementById("innerFrame"),i=document.getElementById("blocker");function s(){console.log("inner frame STARTED loading page"),i.style.display=""}e.onload=()=>{console.log("inner frame FINISHED loading page");const n=document.getElementById("innerFrame");let r="";if(n&&n.contentWindow){n.contentWindow.onpagehide=s;const{pathname:c,search:d,hash:h}=n.contentWindow.location;let p=c+d+h;for(;p.startsWith("%2F");)p=p.substring(3);for(;p.startsWith("%252");)p=p.substring(4);for(;p.startsWith("/");)p=p.substring(1);r=p}const{origin:o,pathname:l}=window.location,a=`${o}${l}?q=/${encodeURIComponent(r)}`;window.history.replaceState({},"",a),this.onResize(),console.log("finished onresize after inner frame loaded new page"),i.style.display="none"},window.addEventListener("message",function(n){if(n.data.type==="updateUrlSuffix"){const r=document.getElementById("innerFrame");let o="";if(r&&r.contentWindow){const{pathname:h,search:p,hash:w}=r.contentWindow.location;let u=h+p+w;for(;u.startsWith("%2F");)u=u.substring(3);for(;u.startsWith("%252");)u=u.substring(4);for(;u.startsWith("/");)u=u.substring(1);o=u}const l=o.indexOf("?");l>-1&&(o=o.substring(0,l));const{origin:a,pathname:c}=window.location;o+=n.data.suffix;const d=`${a}${c}?q=/${encodeURIComponent(o)}`;window.history.pushState({},"",d)}}),window.addEventListener("keydown",n=>{this.game.keydown(this,n.code)})}update(e){Ui(),this.game.helper.update({recursio:this,dt:e}),this.currentFrame.update()}draw(){const{ctx:e,w:i,h:s}=this.layeredViewport;e.clearRect(0,0,i,s),this.game.helper.draw(this),ai();const{flavors:n,relems:r}=this.currentFrame;for(const a in n)for(const c of r[a]??[])c.htmlElem.checkVisibility()&&n[c.flavor].renderer(e,c);ci();const o=this.layeredViewport.pxScreenRectangle,l=this.game.gui;for(const a in l.elements){const c=l.elements[a];ct(e,this,c,o)}for(const a of j.NAMES){const c=$.create(a);if(c instanceof oe&&c.isShowing)for(const d in c.elements){const h=c.elements[d];ct(e,this,h,o)}}}onResize(){var C;const e=document.getElementById("gbaScreen"),i=240/160,s=window.innerWidth,n=window.innerHeight;let r=s,o=s/i;o>n&&(o=n,r=n*i);const l=window.devicePixelRatio||1,a=Math.floor(r/240*l),c=Math.floor(o/160*l);se=Math.min(a,c)/l;const d=se*240,h=se*160;e.width=240,e.height=160,e.style.width=`${d}px`,e.style.height=`${h}px`,e.style.display="";const p=document.getElementById("gbaScreenContainer");p.style.width=`${d}px`,p.style.height=`${h}px`,p.style.position="absolute",p.style.left=`${(s-d)/2}px`,p.style.top=`${(n-h)/2}px`,p.style.display="";const w=document.getElementById("innerFrameContainer");w.style.width=`${d}px`,w.style.height=`${h}px`,w.style.position="absolute",w.style.left=`${(s-d)/2}px`,w.style.top=`${(n-h)/2}px`,w.style.display="",pt=22,pe=Math.round(h*pt/240),Ce=h,Ee=d,Ae=(s-d)/2,_e=(n-h)/2,Dt=`
      width:${Ee}px;
      height:${Ce-pe}px;
      position:absolute;
      left:${Ae}px;
      top:${_e+pe}px;
      border: none;
      z-index: 4;
    `;const u=document.getElementById("innerFrame");u.setAttribute("width",`${d+15}`),u.setAttribute("height",`${h}`),this.gbaViewport=new Ki,this.gbaViewport.init(this,document.getElementById("gbaScreen")),this.layeredViewport=this.gbaViewport;const{layeredViewport:b}=this;b.handleResize(this);const x=document.getElementById("innerFrame");if(!x.contentWindow)return;const y=x.contentWindow.location.href;if(!y.startsWith("http"))return;this.currentFrame=is(y),this.currentFrame.registerElements(x);const g=x.contentDocument||((C=x.contentWindow)==null?void 0:C.document);g&&g.body&&(g.body.style.opacity="0",g.body.style.background="transparent");for(const _ in this.game.gui.elements)Bt(_);this.game.gui.refreshLayout(this)}rebuildControls(){this.didBuildControls=!0,Ti(this)}}function is(t){for(const e of jt.NAMES){const i=L.create(e);if(i.detect(t))return i}return L.create("demo-list-frame")}let se=1,Ce=1,Ae=1,Ee=1,_e=1,pt=0,pe=0,Dt="";const ss={...re},Ve=class Ve extends L{constructor(){super(...arguments);f(this,"flavors",ss)}detect(i){return!0}init(i,s){super.init(i,s);const n=i.getElementById("gameFrame");if(n){const r=document.getElementById("gameFrame");if(r&&r.src===n.src){n.remove();return}else r&&(r==null||r.remove());n.remove(),document.body.appendChild(n),n.setAttribute("style",Dt)}}update(){super.update(),document.getElementById("gbaScreen");const i=document.getElementById("gbaScreenContainer"),s=document.getElementById("gameFrame");if(N&&s){const n=N[3]*se;i.style.height=`${n}px`,s.style.left=`${Ae}px`,s.style.top=`${_e+n}px`,s.style.width=`${Ee}px`,s.style.height=`${Ce-n}px`}}};L.register("demo-frame",()=>new Ve);let ut=Ve;const ne=document.createElement("canvas"),ns=ne.getContext("2d");function os(t,e){t.fillStyle="rgba(100,100,100,.5)",t.fillRect(0,0,240,160),V(t,e,{fillStyle:"white"});const[i,s,n,r]=e.rect;if(ne.width=n,ne.height=r,e.innerFrame){const{flavors:o,relems:l}=e.innerFrame;for(const a in o)for(const c of l[a]??[])c.htmlElem.checkVisibility()&&o[c.flavor].renderer(ns,c)}t.drawImage(ne,Math.round(i),Math.round(s))}const rs={"demo-item":{overrides:{addClasses:["col-lg-12","col-md-12"],removeClasses:["col-lg-6","col-md-6"]},detector:t=>t.classList.contains("demo-item"),renderer:()=>{}},"demo-row":{overrides:{width:200,padding:2},detector:t=>t.classList.contains("demo-row"),renderer:function(t,e){const[i,s,n,r]=e.rect,o=e.htmlElem.querySelector("img");o.tagName==="IMG"&&o.src&&(t.globalAlpha=.4,t.drawImage(o,50,50,1,1,i,s,n,r)),V(t,e)}},img:{overrides:{width:54,height:54},detector:t=>t.tagName==="IMG",renderer:function(t,e){const[i,s,n,r]=e.rect,o=e.htmlElem;if(o.tagName==="IMG"&&o.src){t.globalAlpha=1,t.drawImage(o,i,s,n,r);const l=window.getComputedStyle(o);t.lineWidth=1,t.strokeStyle=l.borderColor,t.strokeRect(i+.5,s+.5,n-1,r-1)}else t.lineWidth=1,t.strokeStyle="#ccc",t.fillStyle="#eee",t.globalAlpha=1,t.fillRect(i+.5,s+.5,n-1,r-1),t.strokeRect(i+.5,s+.5,n-1,r-1)}},"play-button":{overrides:{height:11,width:"text+8",margin:1},detector:t=>t.matches(".btn:has(span.fa-play)"),renderer:(t,e)=>{S(t,e,{padLeft:8,isRounded:!0});const[i,s,n,r]=e.rect,o=window.getComputedStyle(e.htmlElem).color==="rgb(255, 255, 255)";t.drawImage(k("png/icons/9x9-play.png",o?"white":"black"),Math.round(i+1),Math.round(s+1))},doesReserveChildren:!0},"sort-button":{overrides:{height:11,width:"text+8",margin:1},detector:t=>t.classList.contains("btn")&&t.classList.contains("btn-primary"),renderer:(t,e)=>{var a;S(t,e,{isRounded:!0});const[i,s,n,r]=e.rect,o=(a=e.htmlElem.querySelector("span"))==null?void 0:a.classList;let l="png/icons/9x9-sort.png";o!=null&&o.contains("fa-sort-up")?l="png/icons/9x9-sort-up.png":o!=null&&o.contains("fa-sort-down")&&(l="png/icons/9x9-sort-down.png"),t.drawImage(k(l),Math.round(i+n-10),Math.round(s+1))},doesReserveChildren:!0},"reports-button":{overrides:{height:11,width:"text+8",margin:1},detector:t=>t.matches("button:has(span.fa-check)"),renderer:(t,e)=>{S(t,e,{padLeft:8,isRounded:!0});const[i,s,n,r]=e.rect,o=window.getComputedStyle(e.htmlElem).color==="rgb(255, 255, 255)";t.drawImage(k("png/icons/9x9-check.png",o?"white":"black"),Math.round(i+1),Math.round(s+1))},doesReserveChildren:!0},"music-icon":{overrides:{width:11,height:11,margin:1},detector:t=>t.matches("button:has(span.fa-music)"),renderer:(t,e)=>{V(t,e,{});const[i,s,n,r]=e.rect,o=window.getComputedStyle(e.htmlElem).color==="rgb(255, 255, 255)";t.drawImage(k("png/icons/9x9-music.png",o?"white":"black"),Math.round(i+1),Math.round(s+1))},doesReserveChildren:!0},"sound-icon":{overrides:{width:11,height:11,margin:1},detector:t=>t.matches("button:has(span.fa-volume-up)"),renderer:(t,e)=>{V(t,e,{});const[i,s,n,r]=e.rect,o=window.getComputedStyle(e.htmlElem).color==="rgb(255, 255, 255)";t.drawImage(k("png/icons/9x9-sound.png",o?"white":"black"),Math.round(i+1),Math.round(s+1))},doesReserveChildren:!0},button:{overrides:{height:11,width:"text",margin:1},detector:t=>t.classList.contains("btn"),renderer:(t,e)=>{S(t,e,{isRounded:!0})},doesReserveChildren:!0},"checkbox-label":{overrides:{height:11,width:"text+8",margin:1},detector:t=>t.tagName==="LABEL",renderer:(t,e)=>{var l;S(t,e,{padLeft:8}),t.lineWidth=1,t.strokeStyle="black",t.globalAlpha=1;const[i,s,n,r]=e.rect.map(a=>Math.round(a));t.strokeRect(i+2.5,s+2.5,6,6),((l=e.htmlElem.querySelector("input"))==null?void 0:l.checked)&&(t.fillStyle="black",t.fillRect(i+4,s+4,3,3))}},icon:{overrides:{width:11,height:11,margin:1},detector:t=>t.matches(".fa"),renderer:S},span:{overrides:{height:11,width:"text",margin:1},detector:t=>{var e;return t.tagName==="SPAN"&&!((e=t.parentElement)!=null&&e.matches(".navbar-toggler"))},renderer:S},"demo-details":{overrides:{width:200},detector:t=>t.classList.contains("demo-details"),renderer:V},"changelog-entry":{overrides:{height:11},detector:t=>{var e;return t.tagName==="LI"&&!!((e=t.parentElement)!=null&&e.matches(".changelog"))},renderer:(t,e)=>{Tt(t,e)}},"changelog-entry-inner":{overrides:{height:0},detector:t=>{var e,i;return t.tagName==="LI"&&!!((i=(e=t.parentElement)==null?void 0:e.parentElement)!=null&&i.matches("details"))},renderer:()=>{}},"reports-iframe":{overrides:{},detector:t=>t.tagName==="IFRAME",frame:"reports-frame",renderer:os},...re},Ne=class Ne extends L{constructor(){super(...arguments);f(this,"flavors",rs)}detect(i){return i.endsWith("/demo_list")}init(i,s){var o,l,a,c;super.init(i,s),i.querySelectorAll(".col-lg-8").forEach(d=>{d.classList.remove("col-lg-8"),d.classList.add("col-lg-12","col-sm-12","col-xs-12","col-xl-12")});const n=i.getElementById("modal");n&&n.style.setProperty("overflow","hidden");const r=10;(l=(o=i.querySelector(".page-content"))==null?void 0:o.parentElement)==null||l.classList.remove("py-5"),(a=i.querySelector(".page-content"))==null||a.setAttribute("style","margin:0px !important;"),(c=i.querySelector(".page-content>.container"))==null||c.setAttribute("style",`margin:${r*s.width/240}px;`)}};L.register("demo-list-frame",()=>new Ne);let ft=Ne;const ls={li:{overrides:{height:11,margin:-1},detector:t=>{var e;return t.tagName==="LI"&&!t.matches("details>ul>li")&&!t.matches("nav-item")&&!((e=t.parentElement)!=null&&e.matches(".screenshots"))},renderer:(t,e)=>{Tt(t,e);const[i,s,n,r]=e.rect;t.drawImage(k("png/icons/9x9-check.png","black"),Math.round(i+1),Math.round(s+1))}},summary:{overrides:{height:11,margin:-.5,width:"text+8"},detector:t=>t.matches("summary"),renderer:(t,e)=>{var l;const i=(l=e.htmlElem.parentElement)==null?void 0:l.hasAttribute("open");S(t,e,{padLeft:8});const[s,n,r,o]=e.rect;i?t.drawImage(k("png/icons/9x9-expanded.png","black"),Math.round(s+1),Math.round(n+1)):t.drawImage(k("png/icons/9x9-collapsed.png","black"),Math.round(s+1),Math.round(n+1))}},screenshot:{overrides:{width:40,height:30},detector:t=>t.tagName==="IMG",renderer:function(t,e){const[i,s,n,r]=e.rect.map(l=>Math.round(l)),o=e.htmlElem;if(o.tagName==="IMG"&&o.src){t.globalAlpha=1,t.drawImage(o,i,s,n,r);const l=window.getComputedStyle(o);t.lineWidth=1,t.strokeStyle=l.borderColor,t.strokeRect(i+.5,s+.5,n-1,r-1)}else t.lineWidth=1,t.strokeStyle="#ccc",t.fillStyle="#eee",t.globalAlpha=1,t.fillRect(i+.5,s+.5,n-1,r-1),t.strokeRect(i+.5,s+.5,n-1,r-1)}},"cursor-overlay":{overrides:{},detector:t=>t.classList.contains("cursor-overlay"),renderer:(t,e)=>{var x;t.lineWidth=1,t.strokeStyle="red",t.globalAlpha=1-ve;const s=e.htmlElem.getAttribute("style");function n(y){var O,Y,E,v;if(!y)return[0,0,0,0];const g=parseInt(((O=y.match(/left:\s*([\d.]+)px/))==null?void 0:O[1])??"0",10),C=parseInt(((Y=y.match(/top:\s*([\d.]+)px/))==null?void 0:Y[1])??"0",10),_=parseInt(((E=y.match(/width:\s*([\d.]+)px/))==null?void 0:E[1])??"0",10),B=parseInt(((v=y.match(/height:\s*([\d.]+)px/))==null?void 0:v[1])??"0",10);return[g,C,_,B]}const[r,o,l,a]=n(s),c=(x=L.create("reports-frame").relems.screenshot)==null?void 0:x.find(y=>{var g;return(g=y.htmlElem.parentElement)==null?void 0:g.contains(e.htmlElem)});if(!c)throw new Error("no parent for cursor overlay");const[d,h,p,w]=c.rect,u=Math.round(d+r*40/200),b=Math.round(h+o*30/150);e.htmlElem.matches(".cursor-pointer")?t.drawImage(k("png/icons/9x9-cursor-pointer.png","red"),u-4,b-2):t.drawImage(k("png/icons/9x9-cursor-default.png","red"),u-3,b-2)}},"rectangle-overlay":{overrides:{},detector:t=>t.classList.contains("rectangle-overlay"),renderer:(t,e)=>{var g;t.lineWidth=1,t.strokeStyle="red",t.globalAlpha=ve;const s=e.htmlElem.getAttribute("style");function n(C){var E,v,m,P;if(!C)return[0,0,0,0];const _=parseInt(((E=C.match(/left:\s*([\d.]+)px/))==null?void 0:E[1])??"0",10),B=parseInt(((v=C.match(/top:\s*([\d.]+)px/))==null?void 0:v[1])??"0",10),O=parseInt(((m=C.match(/width:\s*([\d.]+)px/))==null?void 0:m[1])??"0",10),Y=parseInt(((P=C.match(/height:\s*([\d.]+)px/))==null?void 0:P[1])??"0",10);return[_,B,O,Y]}const[r,o,l,a]=n(s),c=(g=L.create("reports-frame").relems.screenshot)==null?void 0:g.find(C=>{var _;return(_=C.htmlElem.parentElement)==null?void 0:_.contains(e.htmlElem)});if(!c)throw new Error("no parent");const[d,h,p,w]=c.rect,u=Math.round(d+r*40/200),b=Math.round(h+o*30/150),x=Math.round(l*40/200),y=Math.round(a*30/150);t.strokeRect(u-.5,b-.5,x+1,y+1)}},...re},Ye=class Ye extends L{constructor(){super(...arguments);f(this,"flavors",ls)}detect(i){return i.endsWith("/reports")}init(i,s){super.init(i,s);const n=i.querySelectorAll(".content"),o=`min-height:${33*s.width/240}px;`;for(const l of n)l.setAttribute("style",o)}};L.register("reports-frame",()=>new Ye);let gt=Ye;class as{init(e){}}class cs extends as{constructor(i){super();f(this,"currentPhase","default");f(this,"_lastMouseX",0);f(this,"_lastMouseY",0);this.params=i}init(i){}update(i){}hover([i,s]){this._lastMouseX=i,this._lastMouseY=s}click(i,s){}draw(i){}}const Ge=class Ge extends W{reset(e){const{gridSize:i}=R.flatConfig;return new cs({gridSize:i})}};W.register("zero-game",{factory:()=>new Ge,guiName:"zero-gui"});let mt=Ge;const hs={_sr:{margin:3},topLeftListBtn:{parent:"_sr",width:11,height:11},topLeftBtn:{parent:"_sr",left:14,width:125,height:11},settingsBtn:{parent:"_sr",width:11,height:11,right:0}},ds={...hs,gameBoardRegion:{width:100,height:100,left:"auto",top:"auto"},analyzeLoopBtn:{parent:"_sr",width:80,height:11,right:0,bottom:0},resetBtn:{parent:"_sr",width:38,height:11,bottom:0},screen:{left:0,top:0,width:240,height:160},scrollbar:{width:11,right:0}},Xe=class Xe extends ${};$.register("empty-gui",{factory:()=>new Xe,layoutFactory:()=>({}),elements:[]});let yt=Xe,ue=.5;const ps={layoutKey:"scrollbar",display:{type:"diagram",draw:(t,e,i)=>{const s=bt();if(!s)return;const n=s.contentWindow.document,r=s.clientHeight,o=Math.max(n.body.scrollHeight,n.documentElement.scrollHeight),l=s.contentWindow.scrollY;ue=r/o;const a=l/(o-r/2),[c,d,h,p]=i;if(r>=o)return;t.fillStyle="white",t.fillRect(...i),ge(t,i,{strokeStyle:"rgb(100,100,100)",fillStyle:"rgb(200,200,200)"});const w=[c,p*a,h,p*ue],u=160-w[3];w[1]=Math.min(w[1],u),ge(t,w,{strokeStyle:"black",fillStyle:"rgb(100,100,100)"})}},clickAction:(t,e)=>{var x;if(!e||!((x=t.inputEvent)!=null&&x.screenPos))return;const i=bt();if(!i)return;const s=i.contentWindow.document,[n,r,o,l]=e,[a,c]=t.inputEvent.screenPos,d=i.clientHeight,h=Math.max(s.body.scrollHeight,s.documentElement.scrollHeight),w=Math.max(0,Math.min(c-r,l))/l-ue/2,u=h-d/2,b=Math.round(u*w);i.contentWindow.scrollTo({top:b,behavior:"instant"})}},je=class je extends ${refreshLayout(e){super.refreshLayout(e)}};$.register("zero-gui",{factory:()=>new je,layoutFactory:()=>ds,elements:[ps]});let wt=je;function bt(){let t=document.getElementById("innerFrame");if(!t||!t.contentWindow)return;let e=t.contentWindow.document;if(!e.body)return;const i=e.getElementById("modalIframe");if(i!=null&&i.checkVisibility()&&(t=i),!(!t||!t.contentWindow)&&(e=t.contentWindow.document,!!e.body))return t}function us(t){return{getSetting:e=>t.config.flatConfig[e],applySetting:(e,i)=>{e in t.config.tree.children?t.config.tree.children[e].value=i:e in t.config.tree.children.two.children&&(t.config.tree.children.two.children[e].value=i),t.config.flatConfig[e]=i,t.onResize()},getGameState:()=>t.didLoadAssets?"playing":"loading",getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.mouseCursorTestSupport}),locateElement(e){const i=[t.game.gui];for(const s of j.NAMES){const n=$.create(s);n instanceof oe&&n.isShowing&&i.push(n)}for(const s of i){const n=s.layoutRectangles[e];if(!n)continue;const[r,o,l,a]=n,c=1;return[r*c,o*c,l*c,a*c]}}}}async function fs(){var r;const t=new Wt;vt.refreshConfig();const e=new ts(t);e.config.refreshConfig(),t.init(e,document.getElementById("midCanvas")),window.TestSupport=us(e);const i=document.getElementById("loading-label");i&&(i.innerHTML=`
      <div>Loading...</div>
      <div id="progress-bar-container" style="width: 300px; height: 24px; 
      background: #eee; border-radius: 12px; overflow: hidden; margin-top: 16px;">
        <div id="progress-bar" style="width: 0%; height: 100%; 
        background: rgba(76, 175, 80, 1); transition: width 0.2s;"></div>
      </div>
    `),i&&(i.innerHTML=`
      <div>Loading...</div>
      <div id="progress-bar-container" style="width: 300px; height: 24px; 
      background: #eee; border-radius: 12px; overflow: hidden; margin-top: 16px;">
        <div id="progress-bar" style="width: 0%; height: 100%; 
        background: rgba(76, 175, 80, 1); transition: width 0.2s;"></div>
      </div>
    `),await oi(),await Promise.all(Xt.NAMES.map(o=>T.preload(o,Ut))),(r=document.getElementById("loading-label"))==null||r.remove(),e.didLoadAssets=!0,e.init(),e.onResize();let s=performance.now();function n(){requestAnimationFrame(n);const o=performance.now(),l=Math.min(50,o-s);s=o,e.update(l),e.draw()}n()}fs();
