/**
 * @file common sound effects data objects
 *
 * loaded in src/audio/sound_effect.js
 */
SOUND_EFFECTS = {

  // glass tiles sound
  glassTiles: {
    duration: 0.2,
    freq: 300,
    wave: 'sh',
    env: 'zipper',
    volume: 0.1,
  },

  // played 3 times during race countdown
  countdownBeep: {
    duration: 0.1,
    freq: 300,
    wave: 'square',
    volume: 0.08,
    env: 'dropEnd',
  },

  // played when countdown finishes and "GO!" appears
  goBeep: {
    duration: 0.1,
    freq: 400,
    wave: 'square',
    volume: 0.08,
    env: 'dropEnd',
  },

  // thud sound at the end of piece moving animation
  thud: {
    duration: 0.1,
    freq: 200,
    wave: 'sine',
    volume: 0.8,
    env: 'attack',
  },

  // used in button.js
  // when a button clicked
  click: {
    duration: 0.05,
    freq: 400,
    wave: 'sine',
    volume: 0.05,
    env: 'attack',
  },

  // clicked non-clickable element
  dullClick: {
    duration: 0.1,
    startFreq: 100,
    endFreq: 50,
    wave: 'sine',
    volume: 0.8,
    env: 'attack',
  },

  // used in button.js
  // when a button is newly hovered
  hover: {
    duration: 0.1,
    freq: 100,
    wave: 'sine',
    volume: 0.1,
    env: 'attack',
  },

  // used in default_tool.js
  // when a particle is collected and "+1" appears
  collect: {
    duration: 0.02,
    minDelay: 0.04, // ignore play() calls if too rapid
    startFreq: 800,
    endFreq: 1000,
    wave: 'sine',
    volume: 0.05,
  },

  //
  hooray: {
    duration: 0.5,
    scale: 'A4_majorArp',
    wave: 'square',
    volume: 0.02,
  },
};
