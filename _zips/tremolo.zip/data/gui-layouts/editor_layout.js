/**
 * @file Editor GUI layout
 * js code editor panel in center
 */
EDITOR_LAYOUT = {
  editorPanel: {
    margin: 0.1,
  },

  saveBtn: {
    width: 0.2,
    height: 0.07,
    bottom: 0.02,
    right: 0.02,
  },

  resetBtn: {
    width: 0.2,
    height: 0.07,
    bottom: 0.02,
    left: 0.02,
  },
};
