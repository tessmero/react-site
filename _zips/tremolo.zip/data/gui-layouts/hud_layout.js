/**
 * @file hud layout for common buttons
 */
HUD_LAYOUT = {

  // helper
  _mid: {
    width: 0.02,
    left: 'auto',
  },

  // main menu on top left
  mainMenuBtn: {
    width: 0.1,
    height: 0.1,
    top: 0.02,
    left: 0.02,
  },

  // volume control on top right
  volumeCtrl: {
    width: 0.3,
    height: 0.1,
    top: 0.02,

    // left: .14,
    right: 0.03,
  },

  // // lock/unlock editor on top right
  // unlockCtrl: {
  //   width: 0.1,
  //   height: 0.1,
  //   top: 0.02,
  //   right: 0.22,
  // },

  // // song select on top right
  // songsBtn: {
  //   width: 0.1,
  //   height: 0.1,
  //   top: 0.02,
  //   right: 0.02,
  // },

  // _topRow: {
  //   height: 0.1,
  //   width: 0.6,
  //   right: 0,
  // },
  // topBtns: {
  //   parent: '_topRow',
  //   width: 0.3,
  //   repeat: 'right',
  //   margin: 0.01,
  // },
};
