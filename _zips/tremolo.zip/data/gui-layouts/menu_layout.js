/**
 * @file main menu layout data
 */
MENU_LAYOUT = {
  main: {
    width: 0.9,
    height: 0.9,
    left: 'auto',
    top: 'auto',
  },

  titleBar: {
    parent: 'main',
    height: 0.1,
    margin: 0.005,
  },

  _settingRowsContainer: {
    parent: 'main',
    top: 0.1,
    height: 'auto',
  },

  settingRows: {
    parent: '_settingRowsContainer',
    height: 0.15,
    repeat: 'down',
    margin: 0.01,
  },

  // edit buttons to right of settings
  _editBtnsContainer: {
    parent: '_settingRowsContainer',
    width: 0.15,
    left: '100%',
  },
  editBtns: {
    parent: '_editBtnsContainer',
    height: 0.15,
    repeat: 'down',
    margin: 0.03,
  },
};

// layout within one row
SELECT_ROW = {
  prevBtn: {
    width: 0.1,
  },

  label: {
    left: 0.1,
    width: 0.68,
  },

  nextBtn: {
    width: 0.1,
    right: 0,
  },
};
