/**
 * @file training report layout
 */
TRAINING_REPORT_LAYOUT = {

  // config buttons at top
  _config: {
    height: 0.12,
    bottom: 0.01,
    left: 0.01,
  },
  configBtns: {
    parent: '_config',
    width: 0.4,
    repeat: 'right',
    margin: 0.01,
  },

  rowsContainer: {
    width: 0.9,
    height: 0.7,
    left: 'auto',
    top: 'auto',
  },

  title: {
    parent: 'rowsContainer',
    width: 0.9,
    height: 0.12,
    margin: 0.02,
  },

  rows: {
    parent: 'rowsContainer',
    height: 0.1,
    repeat: 'down',
    margin: 0.03,
  },

  resetBtn: {
    parent: 'rowsContainer',
    width: 0.25,
    height: 0.07,
    bottom: 0.02,
    left: 0.02,
  },

  resumeBtn: {
    width: 0.3,
    height: 0.1,
    bottom: 0.02,
    right: 0.02,
  },
};

// layout within one detail row
REPORT_DETAIL_ROW = {
  cells: {
    width: '25%',
    repeat: 'right',
  },
};
