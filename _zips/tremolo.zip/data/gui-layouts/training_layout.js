/**
 * @file training gui layout
 */
TRAINING_LAYOUT = {

  // exercise title
  title: {
    height: 0.1,
    width: 0.4,
    left: 'auto',
    top: 0.1,
  },

  // exercise text prompt
  prompt: {

    height: 0.1,
    width: 0.8,
    left: 'auto',

    // top: 0.225,
    bottom: 0.02,
  },

  // training accuracy report
  // top middle
  score: {
    width: 0.3,
    height: 0.1,
    top: 0.02,
    left: 'auto',
  },

  // next  button
  // bottom right
  nextBtn: {
    width: 0.3,
    height: 0.1,
    bottom: 0.02,
    right: 0.02,
  },

  // root note control for intervals
  // bottom left
  rootNote: {
    width: 0.3,
    height: 0.1,
    bottom: 0.02,
    left: 0.02,
  },
};

// layout within root note control
TRAINING_ROOT_NOTE_CONTROL = {

  prevBtn: {
    width: 0.075,
  },

  label: {
    width: 0.15,
    left: 0.075,
  },

  nextBtn: {
    width: 0.075,
    right: 0,
  },
};
