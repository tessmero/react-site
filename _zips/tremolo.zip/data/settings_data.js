/**
 * @file Settings
 * list of setting names and possible values
 */
SETTINGS_DATA = {
  preset: ['chess', 'piano', 'orbital-launch', 'grove-tender', 'fight-cub', 'wheely', 'space-quest'],
  layout: ['piano', 'qwerty'],
  style: ['grove', 'orbit', 'sudo'],
  colors: ['dark', 'medium', 'light'],

  // 'note-format': ['hertz', 'number', 'name'],
};
