/**
 * @file Colors data
 */
COLORS_DATA = {

  dark: {
    background: '#333', // dark gray background
    edge: '#AAA', // light gray lines
    text: '#CCA', // light yellow text

    // default button fill color
    btn: '#222', // darker gray

    // fill colors for different button states
    hoveredBtn: '#555', // gray
    pressedBtn: '#550', // dark yellow
    greenBtn: '#050', // dark green
    redBtn: '#500', // dark red
  },

  medium: {
    background: '#AAA', // light gray background
    edge: '#000', // black lines
    text: '#000', // black text

    // default button fill color
    btn: '#888', // gray

    // fill colors for different button states
    hoveredBtn: '#999', // lighter gray
    pressedBtn: '#DDA', // dull yellow
    greenBtn: '#ADA', // dull green
    redBtn: '#DAA', // dull red
  },

  light: {
    background: '#F0F0F0', // off-white background
    edge: '#000', // black lines
    text: '#000', // black text

    // default button fill color
    btn: '#D2C8CD', // reddish gray

    // fill colors for different button states
    hoveredBtn: '#AAA', // gray
    pressedBtn: '#FFC', // light yellow
    greenBtn: '#CFC', // light green
    redBtn: '#FCC', // light red
  },
};
