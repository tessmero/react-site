/**
 * @file binding presets data
 */
BINDING_DATA = {
  piano: { // binding name
    'piano': { // supported layout
      'KeyZ': { // bound button in layout
        note: 'A2',
        right: {
          scale: 'majorScale',
          scaleIndex: 5,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
    'qwerty': { // supported layout
      'KeyZ': { // bound button in layout
        note: 'A2',
        right: {
          scale: 'majorScale',
          limit: 14,
          scaleIndex: 5,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyQ': { // bound button in layout
        note: 'D4',
        limit: 'A5',
        right: {
          scale: 'majorScale',
          limit: 12,
          scaleIndex: 1,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
  },

  'chess': {
    'qwerty': { // supported layout
      'KeyQ': { // bound button in layout
        note: 'G4',
        right: {
          scale: 'majorScale',
          scaleIndex: 4,
          limit: 12,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyZ': { // bound button in layout
        note: 'C3',
        right: {
          scale: 'majorScale',
          limit: 11,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
  },

  'grove-tender': {
    'qwerty': { // supported layout
      'KeyQ': { // bound button in layout
        note: 'F4',
        right: {
          scale: 'majorScale',
          scaleIndex: 3,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
        limit: 'A5',
      },
      'KeyZ': { // bound button in layout
        note: 'C3',
        right: {
          scale: 'majorScale',
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
        limit: 'E4',
      },
    },
  },

  'orbital-launch': {
    'numpad': {
      'Numpad7': {
        currentKey: true,
        note: 'A3',
        right: {
          scale: 'majorArp',
        },
      },
      'Numpad4': {
        currentKey: true,
        currentKeyOffset: -12,
        note: 'A2',
        right: {
          scale: 'majorArp',
          limit: 3,
        },
      },
      Numpad1: {
        chord: [15, 17, 19],
        key: [27, 29, 31, 34],
      },
      Numpad2: {
        chord: [12, 15, 20],
        key: [24, 27, 32, 34],
      },
      NumpadDecimal: {
        chord: [12, 15, 17],
        key: [24, 27, 29, 32],
      },
      Numpad3: {
        chord: [12, 15, 19],
        key: [24, 27, 31, 34],
      },
      NumpadEnter: {
        chord: [10, 14, 17],
        key: [22, 26, 29, 34],
      },
    },
    'qwerty': { // supported layout
      'KeyQ': { // bound button in layout
        note: 'F4',
        right: {
          scale: 'majorScale',
          scaleIndex: 3,
          limit: 12,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyZ': { // bound button in layout
        note: 'C3',
        right: {
          scale: 'majorScale',
          limit: 9,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
  },

  'fight-cub': {
    'qwerty': {
      'KeyD': {
        note: 'A2',
        right: {
          scale: 'majorScale',
          scaleIndex: 5,
          limit: 20,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyZ': {
        'chord': [0, 7, 10],
        'key': [0, 7, 10],
      },
      'KeyX': {
        'chord': [2, 7, 9],
        'key': [2, 7, 9],
      },
      'KeyC': {
        'chord': [2, 5, 9],
        'key': [2, 5, 9],
      },
      'KeyV': {
        'chord': [2, 5, 7],
        'key': [2, 5, 7],
      },
    },
  },

  'wheely': {
    'qwerty': { // supported layout
      'KeyT': { // bound button in layout
        note: 'C4',
        right: {
          scale: 'majorScale',
          scaleIndex: 0,
          limit: 7,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyZ': { // bound button in layout
        note: 'A2',
        right: {
          scale: 'majorScale',
          scaleIndex: 5,
          limit: 12,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
  },

  'space-quest': {
    'qwerty': { // supported layout
      'KeyQ': { // bound button in layout
        note: 'C4',
        right: {
          scale: 'majorScale',
          scaleIndex: 0,
          limit: 10,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
      'KeyZ': { // bound button in layout
        note: 'A2',
        right: {
          scale: 'majorScale',
          scaleIndex: 5,
          limit: 10,
        },
        up: {
          scale: 'chromaticScale',
          limit: 1,
        },
      },
    },
  },

};
