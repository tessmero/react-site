/**
 * @file base data
 * first loaded data file
 * (other data files are loaded in arbitrary order)
 */
SONGS = []; // populated in data/songs/*.js
