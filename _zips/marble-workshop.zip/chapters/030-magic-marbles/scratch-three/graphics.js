/**
 * @file three.js marbles and boxes graphics
 */

const GFX_SPHERE_RADIUS = 3.5; // size of spheres

/**
 *
 */
class Graphics {

  static _outlineThickness = 0.4;

  static _meshes = {

    spheres: { // colored balls
      count: ({ spheres }) => spheres.length,
      geometry: new THREE.SphereGeometry(GFX_SPHERE_RADIUS, 16, 16), // detail level
      material: new THREE.MeshLambertMaterial(),
    },

    disks: { // outlines around spheres
      count: ({ spheres }) => spheres.length,
      geometry: new THREE.CylinderGeometry(
        GFX_SPHERE_RADIUS + Graphics._outlineThickness, // a bit wider than sphere
        GFX_SPHERE_RADIUS + Graphics._outlineThickness,
        Graphics._outlineThickness, 32) // detail level
        .rotateX(Math.PI / 2),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    },

    walls: {
      count: ({ walls }) => walls.length,
      geometry: new THREE.BoxGeometry(),
      material: Graphics._m('MeshBasicMaterial', {
        color: 0xbbbbbb,
        opacity: 0.5,
      }),
    },

    rods: {
      count: ({ rods }) => rods.length,
      geometry: new THREE.BoxGeometry(),
      material: Graphics._m('MeshBasicMaterial', {
        color: 0x9955dd,
        opacity: 1,
      }),
    },

    edges: { // box edge segments
      count: ({ boxes }) => boxes.length * 12, // 12 edges per box
      geometry: new THREE.BoxGeometry(),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    },

    holes: { // extra edges where rods intersect walls
      count: ({ rods }) => rods.length * 4 * 4, // 4 squares per rod
      geometry: new THREE.BoxGeometry(),
      material: new THREE.MeshBasicMaterial({ color: 0x000000 }),
    },
  };

  /**
   *
   * @param physObjects
   */
  static _initInstancedMeshes(physObjects) {
    const im = {};
    for (const [name, params] of Object.entries(Graphics._meshes)) {
      const { count, geometry, material } = params;
      const n = count(physObjects);
      const mesh = new THREE.InstancedMesh(geometry, material, n);
      Graphics.scene.add(mesh);
      im[name] = mesh;
    }
    Graphics._instancedMeshes = im;
    return im;
  }

  /**
   *
   * @param sceneParams
   */
  static init(sceneParams) {
    const canvas = document.getElementsByTagName('canvas')[0];
    Graphics.canvas = canvas



    // always build new scene
    const scene = new THREE.Scene();
    Graphics.scene = scene;

    let camera = Graphics.camera;
    if (!camera) {

      // start one-time camera setup
      camera = new THREE.PerspectiveCamera(
        30, // FOV in degrees
        window.innerWidth / window.innerHeight, // aspect ratio
        0.1, // near
        10000, // far
      );

      const camScale = 30;
      camera.position.set(10 * camScale, 12 * camScale, 14 * camScale);
      camera.lookAt(50, 50, 50);

      Graphics.camera = camera; // finished one-time setup
    }

    // light everything
    scene.add(new THREE.AmbientLight(0xffffff, 1));

    // light from one direction
    scene.add(Graphics._l({
      color: 0xffffff,
      intensity: 2,
      position: [-500, 1000, 500],
      target: [50, 50, 50],
    }));

    let renderer = Graphics.renderer
    if( !renderer ){

      // start one-time renderer setup
      const renderer = new THREE.WebGLRenderer({ alpha: true, canvas });
      function updateScreenShape() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
      }
      window.addEventListener('resize', updateScreenShape); // update when necessary
      updateScreenShape() // update now

      const controls = new THREE.OrbitControls(camera, renderer.domElement);
      controls.target.set(50, 50, 50);
      controls.update();

      Graphics.renderer = renderer // finished one-time setup



    }
    // assume there is only one canvas in the document, and use it

    const { boxes, spheres, rods, walls } = sceneParams;
    const im = this._initInstancedMeshes({ boxes, walls, rods, spheres });

    const dummy = new THREE.Object3D();

    // init all boxes (rods and walls) and their edges
    Graphics._initBoxes({ boxes, rods, spheres });

    // init holes - extra edges where rods cross walls
    Graphics._initHoles(rods);

    // init spheres
    spheres.forEach((sphere, i) => {
      const { position: { x, y, z } } = sphere;
      dummy.position.set(x, y, z);
      dummy.updateMatrix();
      im.spheres.setMatrixAt(i, dummy.matrix);
    });
    im.spheres.visible = false; // set to true when animated
    im.disks.visible = false;

    // hide translucent walls for better performance
    // im.walls.visible = false


  }

  /**
   * @param params
   */
  static drawScene(params) {
    const { boxes, spheres, enter, exit } = params;

    if (!enter) {
      Graphics.updateSpherePositions(spheres);
    }
    Graphics.updateBoxPositions(params);

    const { renderer, scene, camera } = Graphics;

    // fix objects popping in and out
    for (const mesh of Object.values(Graphics._instancedMeshes)) {
      mesh.frustumCulled = false;
    }

    renderer.render(scene, camera);

  }

  /**
   *
   * @param spheres
   */
  static updateSphereColors(spheres) {
    const im = Graphics._instancedMeshes;
    spheres.forEach(({ color }, i) => {
      im.spheres.setColorAt(i, new THREE.Color(color));
    });
  }

  /**
   *
   * @param sphereMesh
   * @param spheres
   */
  static updateSpherePositions(spheres) {
    const im = Graphics._instancedMeshes;

    const dummy = new THREE.Object3D();

    spheres.forEach((sphere, i) => {
      const {x,y,z} = sphere.getPosition()
      dummy.position.set(x, y, z);
      dummy.lookAt(Graphics.camera.position); // Make disk face camera
      dummy.updateMatrix();
      im.spheres.setMatrixAt(i, dummy.matrix);
      im.disks.setMatrixAt(i, dummy.matrix);
    });

    im.spheres.visible = true;
    im.disks.visible = true;
    im.spheres.instanceMatrix.needsUpdate = true;
    im.disks.instanceMatrix.needsUpdate = true;
  }

  /**
   *
   * @param sphereMesh
   * @param spheres
   * @param sphereMesh.boxes
   * @param sphereMesh.enter
   * @param sphereMesh.exit
   */
  static updateBoxPositions({ boxes, enter, exit }) {
    const im = Graphics._instancedMeshes;
    const dummy = new THREE.Object3D();

    for (const box of boxes) {
      const { gfxIm, gfxImIndex, gfxScale, gfxEdgeChildren } = box;

      // position mesh for box
      const { x, y, z } = box.getPosition({ enter, exit });
      dummy.scale.set(...gfxScale);
      dummy.position.set(x, y, z);
      dummy.updateMatrix();
      gfxIm.setMatrixAt(gfxImIndex, dummy.matrix);

      // position edge meshes for box
      for (const { segmentIndex, scale, offset } of gfxEdgeChildren) {
        dummy.scale.set(...scale);
        dummy.position.set(x + offset[0], y + offset[1], z + offset[2]);
        dummy.updateMatrix();
        im.edges.setMatrixAt(segmentIndex, dummy.matrix);
      }
    }

    im.rods.instanceMatrix.needsUpdate = true;
    im.walls.instanceMatrix.needsUpdate = true;
    im.edges.instanceMatrix.needsUpdate = true;

  }

  /**
   *
   * @param rods
   */
  static _initHoles(rods) {
    const { tall, width, thick, inner } = Scene.params;

    // coords for x or z axis
    const slideAxisVals = [
      50 - width / 2,
      50 - width / 2 + thick,
      50 + width / 2 - thick,
      50 + width / 2,
    ];

    // coords for other two axis should be square centered around rod center, with side length = thick

    const dummy = new THREE.Object3D();
    const im = Graphics._instancedMeshes;
    const edgeThickness = Graphics._outlineThickness;

    rods.forEach((rod, rodIndex) => {
      const { center: { x: rodX, y: rodY, z: rodZ }, dimensions: { x: rodWidth, y: rodHeight, z: rodDepth } } = rod;
      const slideX = (rodWidth > rodDepth);

      let holeIndex = 0;
      for (const saxVal of slideAxisVals) {

        if (slideX) {

          const bands = [

            {
              offset: [-rodHeight / 2, 0],
              scale: [edgeThickness, edgeThickness, rodDepth],
            },
            {
              offset: [rodHeight / 2, 0],
              scale: [edgeThickness, edgeThickness, rodDepth],
            },
            {
              offset: [0, -rodDepth / 2],
              scale: [edgeThickness, rodHeight, edgeThickness],
            },
            {
              offset: [0, rodDepth / 2],
              scale: [edgeThickness, rodHeight, edgeThickness],
            },
          ];

          // 4 squares for rod along x axis
          bands.forEach(({ offset: [yOff, zOff], scale }) => {
            dummy.position.set(saxVal, rodY + yOff, rodZ + zOff);
            dummy.scale.set(...scale); // Example scale, adjust as needed
            dummy.updateMatrix();
            im.holes.setMatrixAt(rodIndex * 16 + holeIndex, dummy.matrix);
            holeIndex++;
          });
        }
        else {

          // 4 squares for rod along z axis
          const bands = [

            {
              offset: [-rodHeight / 2, 0],
              scale: [rodWidth, edgeThickness, edgeThickness],
            },
            {
              offset: [rodHeight / 2, 0],
              scale: [rodWidth, edgeThickness, edgeThickness],
            },
            {
              offset: [0, -rodWidth / 2],
              scale: [edgeThickness, rodHeight, edgeThickness],
            },
            {
              offset: [0, rodWidth / 2],
              scale: [edgeThickness, rodHeight, edgeThickness],
            },
          ];

          bands.forEach(({ offset: [yOff, xOff], scale }) => {
            dummy.position.set(rodX + xOff, rodY + yOff, saxVal);
            dummy.scale.set(...scale); // Example scale, adjust as needed
            dummy.updateMatrix();
            im.holes.setMatrixAt(rodIndex * 16 + holeIndex, dummy.matrix);
            holeIndex++;
          });
        }
      }
    });
  }

  /**
   *
   * @param boxes.boxes
   * @param boxes
   */
  static _initBoxes({ boxes }) {

    const dummy = new THREE.Object3D();
    const im = Graphics._instancedMeshes;
    let rodIndex = 0;
    let wallIndex = 0;
    boxes.forEach((box, boxIndex) => {
      box.gfxEdgeChildren = [];

      const { dimensions: { x: width, y: height, z: depth } } = box;
      const { x, y, z } = box.getPosition();
      dummy.position.set(x, y, z);
      dummy.scale.set(width, height, depth);
      box.gfxScale = [width, height, depth];
      dummy.updateMatrix();

      // im.boxes.setMatrixAt(boxIndex++, dummy.matrix);
      if (box.display === 'rod') {
        im.rods.setMatrixAt(rodIndex, dummy.matrix);
        box.gfxIm = im.rods;
        box.gfxImIndex = rodIndex;
        rodIndex++;
      }
      else {
        im.walls.setMatrixAt(wallIndex, dummy.matrix);
        box.gfxIm = im.walls;
        box.gfxImIndex = wallIndex;
        wallIndex++;
      }

      // Edge thickness
      const edgeThickness = Graphics._outlineThickness;

      const edgeParams = [
        { // 4 edges along x axis
          scale: [width, edgeThickness, edgeThickness],
          offsets: [
            [0, height / 2, depth / 2],
            [0, height / 2, -depth / 2],
            [0, -height / 2, depth / 2],
            [0, -height / 2, -depth / 2],
          ],
        },
        { // 4 edges along y axis
          scale: [edgeThickness, height, edgeThickness],
          offsets: [
            [width / 2, 0, depth / 2],
            [width / 2, 0, -depth / 2],
            [-width / 2, 0, depth / 2],
            [-width / 2, 0, -depth / 2],
          ],
        },
        { // 4 edges along z axis
          scale: [edgeThickness, edgeThickness, depth],
          offsets: [
            [width / 2, height / 2, 0],
            [width / 2, -height / 2, 0],
            [-width / 2, height / 2, 0],
            [-width / 2, -height / 2, 0],
          ],
        },
      ];

      let edgeIndex = 0;
      edgeParams.forEach(({ scale, offsets }) => {

        offsets.forEach((offset) => {
          const [xOff, yOff, zOff] = offset;
          dummy.position.set(x + xOff, y + yOff, z + zOff);
          dummy.scale.set(...scale);
          dummy.rotation.set(0, 0, 0);
          dummy.updateMatrix();

          const segmentIndex = boxIndex * 12 + (edgeIndex++);
          im.edges.setMatrixAt(segmentIndex, dummy.matrix);
          box.gfxEdgeChildren.push({ segmentIndex, offset, scale });
        });
      });

    });
  }

  /**
   *
   * @param type
   * @param params
   */
  static _m(type, params = {}) {
    const Clazz = THREE[type];
    const result = new Clazz(params);

    // handle params that don't work in constructor
    const { opacity = 1 } = params;
    result.opacity = opacity;
    if (opacity < 1) {
      result.transparent = true;
    }

    return result;
  }

  /**
   *
   * @param params
   */
  static _l(params = {}) {

    const { color = 0xffffff, intensity = 3, position, target } = params;

    const type = position ? 'DirectionalLight' : 'AmbientLight';
    const Clazz = THREE[type];
    const result = new Clazz(color, intensity);

    if (position) {
      result.position.set(...position);
    }

    if (target) {
      const dummy = new THREE.Object3D();
      dummy.position.set(...target);
      result.target = dummy;
    }

    return result;
  }

}
