/**
 * @file Sphere
 * moving sphere in 3d pong
 */
class Sphere {

  /**
   * Construct a moving sphere
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   */
  constructor(params) {
    const { position, velocity } = params;

    this.position = position;
    this.velocity = velocity;

    // color will be changed if this sphere is predicted
    // to end up in a color-coded target region
    this.color = 'white';
  }

  /**
   * Get position for purposes of drawing, recording, coloring
   * @returns {Vector}
   */
  getPosition() {
    return this.position;
  }

  /**
   * Set position. called when playing back recording
   */
  setPosition(position){
    this.position = position
  }

  /**
   * Implement homebrew physics step and update this.position.
   * We add robustness by checking collisions three times.
   * 1. start of step, using current position
   * 2. start of step, using anticipated next position
   * 3. end of step, using new position
   * Typically check #2 is the only necessary check. It triggers the bouncing behavior.
   * @param {object[]} boxes The array of Box instances to collide with
   */
  step(boxes) {

    this.velocity = VectorMath.add(this.velocity, GRAVITY);
    this.velocity = VectorMath.multiply(this.velocity, 1 - AIR_RESISTANCE);

    const futureSelf = new Sphere(this); // copy self
    futureSelf.position = VectorMath.add(this.position, VectorMath.multiply(this.velocity, STEP_DURATION));

    for (const box of boxes) {

      // 1. check if colliding at current position
      const currentCollision = box.checkCollision(this);
      if (currentCollision) {

        // attempt to force into valid position
        this.position = currentCollision.adjustedPosition;
      }

      // 2. anticipate collision at next position
      const nextCollision = box.checkCollision(futureSelf);
      if (nextCollision) {

        const { normal } = nextCollision;
        this.velocity = this._bounce(this.velocity, normal);

        break; // break loop to prevent bouncing more than once per step
      }
    }

    // execute step and advance to next position
    this.position = VectorMath.add(this.position, VectorMath.multiply(this.velocity, STEP_DURATION));

    // 3. check if colliding after advancing
    const afterCollision = boxes.map((box) => box.checkCollision(this)).find(Boolean);
    if (afterCollision) {

      // attempt to force into valid position
      this.position = afterCollision.adjustedPosition;
    }
  }

  /**
   *
   * @param vel
   * @param normal
   */
  _bounce(vel, normal) {

    // Velocity reflection formula: v' = v - 2*(v·n)*n
    const dot = vel.x * normal.x +
                           vel.y * normal.y +
                           vel.z * normal.z;

    const result = {
      x: RESTITUTION * (vel.x - 2 * dot * normal.x),
      y: RESTITUTION * (vel.y - 2 * dot * normal.y),
      z: RESTITUTION * (vel.z - 2 * dot * normal.z),
    };

    return result;
  }

  /**
   * collide with another sphere instance
   * apply forces to both this sphere and the other
   * @param {object} neighbor The nearby sphere instance to collide with
   */
  collideSphere(neighbor) {

    // compute delta
    const dx = neighbor.position.x - this.position.x;
    const dy = neighbor.position.y - this.position.y;
    const dz = neighbor.position.z - this.position.z;
    const distSq = dx * dx + dy * dy + dz * dz;

    if (distSq === 0) {
      return; // positions are the same, do nothing
    }

    const minDist = 2 * SPHERE_RADIUS;

    if (distSq < minDist * minDist) {

      // yes colliding
      //
      // check state of spring
      const restLength = minDist * (1 - SPHERE_COHESION); // if no cohesion, can only push
      const dist = Math.sqrt(distSq);
      const displacement = restLength - dist;
      const springForce = SPHERE_STIFFNESS * displacement;

      // compute normalized direction vector
      const nx = dx / dist;
      const ny = dy / dist;
      const nz = dz / dist;

      // compute damping, which apposes relative speed along spring axis
      const rvx = neighbor.velocity.x - this.velocity.x;
      const rvy = neighbor.velocity.y - this.velocity.y;
      const rvz = neighbor.velocity.z - this.velocity.z;
      const relVelAlongNormal = rvx * nx + rvy * ny + rvz * nz;
      const dampingForce = -SPHERE_DAMPING * relVelAlongNormal;

      // apply net force to both spheres
      const totalForce = springForce + dampingForce;
      this.velocity.x -= nx * totalForce;
      this.velocity.y -= ny * totalForce;
      this.velocity.z -= nz * totalForce;
      neighbor.velocity.x += nx * totalForce;
      neighbor.velocity.y += ny * totalForce;
      neighbor.velocity.z += nz * totalForce;
    }
  }

}
