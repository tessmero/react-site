/**
 * @file magic marbles scene
 */

/**
 *
 */
class Scene {

  /**
   *
   */
  static get params() {
    const thick = 2; // thickness of walls
    const width = 50;
    const tall = 200;
    const inner = width - 2 * thick; // inner dimension after accounting for both walls
    return { tall, width, thick, inner };
  }

  /**
   *
   */
  constructor() {
    this._params = Scene.params;
    const { tall, width, thick, inner } = this._params;

    // stack of spheres above scene
    this._spheres = [
      {
        stack: SPHERE_COUNT,
        position: { x: 50, y: 200, z: 50 },
        velocity: { x: 0, y: 0, z: 0 },
        radius: 5,
      },
    ];
    this.spheres = this._buildSpheres();

    // master list of rectangular obstacles
    const boxParams = [
      ...this._buildWalls(),
      ...this._buildRods(),
    ];
    this.boxes = boxParams.map((p) => new Box(p));

    // for convenience, also prepare categorized groups of boxes
    this.rods = this.boxes.filter((box) => box.display === 'rod');
    this.walls = this.boxes.filter((box) => box.display !== 'rod');

    // validate scene
    if (this.rods.length !== ROD_COUNT) {
      throw new Error(`ROD_COUNT is ${ROD_COUNT} but scene has ${this.rods.length} rods`);
    }
    if (this.spheres.length !== SPHERE_COUNT) {
      throw new Error(`SPHERE_COUNT is ${SPHERE_COUNT} but scene has ${this.spheres.length} spheres`);
    }

    // prepare to check if marbles are caught on rods or fell outside
    this._sphereTargetParams = {
      yCutoff: Math.min(...this.rods.map((rod) => rod.center.y)), // stuck on rods
      minY: (50 - tall / 2), // fell outside
      minXZ: 50 - width / 2,
      maxXZ: 50 + width / 2,
    };

  }

  /**
   *
   * @param position
   */
  pickSphereColor(position) {

    const { yCutoff, minY, minXZ, maxXZ } = this._sphereTargetParams;

    if ((position.y < minY) ||
        (position.x < minXZ) || (position.x > maxXZ) ||
        (position.z < minXZ) || (position.z > maxXZ)) {

      // fell outside
      return '#FFFFFF';
    }

    if (position.y > yCutoff) {

      // stuck on rods
      return '#FFFFFF';
    }

    const x = (position.x > 50);
    const z = (position.z > 50);

    // pick color based on 4 divided segments at bottom
    if (x && z) { return '#0079FF'; }
    if (!x && z) { return '#00DFA2'; }
    if (!x && !z) { return '#F6FA70'; }
    if (x && !z) { return '#FF0060'; }

  }

  /**
   *
   * @param axis
   * @param dir
   * @param entrTime
   */
  static _rodEntrance(axis, dir, entrTime) {

    const duration = 1000;
    const t = Math.min(entrTime / duration, 1); // Normalize to [0,1]
    const progress = 1 - Math.pow(1 - t, 3);
    const axisVal = dir * (1 - progress) * duration;

    // return vector with zero in other axis
    return { x: 0, y: 0, z: 0, [axis]: axisVal };
  }

  /**
   *
   * @param axis
   * @param dir
   * @param exitTime
   */
  static _rodExit(axis, dir, exitTime) {
    return Scene._rodEntrance(axis, dir, 1000 - exitTime);
  }

  /**
   *
   */
  _buildRods() {

    const { tall, width, thick, inner } = this._params;
    const noiseAmp = inner / 2 - thick;

    const y0 = 50 - tall / 6;
    const y1 = 50 + tall / 6;

    const rods = [];

    for (let i = 0; i < ROD_COUNT; i++) {
      const y = VectorMath.avg(y0, y1, i / ROD_COUNT);
      const noise = (2 * Math.random() - 1) * noiseAmp;

      const dir = Math.sign(Math.random() - 0.5);

      const rod = Math.random() > 0.5 ? {

        // horizontal along x axis
        center: { x: 50, y, z: 50 + noise },
        dimensions: { x: 1.5 * width, y: thick, z: thick },
        display: 'rod',
        entrAnim: (entrTime) => Scene._rodEntrance('x', dir, entrTime),
        exitAnim: (exitTime) => Scene._rodExit('x', dir, exitTime),

      } : {

        // horizontal along z axis
        center: { x: 50 + noise, y, z: 50 },
        dimensions: { x: thick, y: thick, z: 1.5 * width },
        display: 'rod',
        entrAnim: (entrTime) => Scene._rodEntrance('z', dir, entrTime),
        exitAnim: (exitTime) => Scene._rodExit('z', dir, exitTime),
      };

      rods.push(rod);
    }

    return rods;
  }

  /**
   *
   */
  _buildSpheres() {

    const gMag = VectorMath.getLength(GRAVITY);

    // construct Sphere instances
    const spheres = [];
    for (const proto of this._spheres) {
      const count = proto.stack || 1;
      for (let i = 0; i < count; ++i) {
        const sphere = { ...proto };

        // build offset between spheres by multiplying gravity
        // (ensures all will fall in the same spot)
        const offsetInStack = VectorMath.multiply(GRAVITY, -1e4 * i);

        // extra random offset
        const noiseAngle = i * 1.618;// Math.random() * Math.PI * 2
        const noiseAmp = 7 + Math.random() * 7;
        const noiseOffset = {
          x: Math.cos(noiseAngle) * noiseAmp,
          y: 0,
          z: Math.sin(noiseAngle) * noiseAmp,
        };

        sphere.position = VectorMath.add(
          proto.position, offsetInStack, noiseOffset);

        spheres.push(new Sphere(sphere));
      }
    }
    return spheres;
  }

  /**
   *
   */
  _buildWalls() {
    const { tall, width, thick, inner } = this._params;

    const divHeight = 40; // height of divider
    const bottomY = 50 - tall / 2 + divHeight / 2; // y at top of divider

    return [

      // Bottom Wall (Y- axis)
      {
        center: { x: 50, y: 50 - tall / 2 - thick / 2, z: 50 },
        dimensions: { x: inner, y: thick, z: inner },
        exitAnim: (exitTime) => ({ x: 0, y: 0, z: exitTime * 1e0 }),
      },

      // Top Wall (Y+ axis)
      // {
      //   center: { x: 50, y: 100 - thick / 2, z: 50 },
      //   dimensions: { x: inner, y: thick, z: inner },
      //   hidden: true,
      // },

      // Back Left Wall (X- axis)
      {
        center: { x: 50 - width / 2 + thick / 2, y: 50, z: 50 },
        dimensions: { x: thick, y: tall, z: inner },
        display: 'wall',
      },

      // Back right Wall (Z- axis)
      {
        center: { x: 50, y: 50, z: 50 - width / 2 + thick / 2 },
        dimensions: { x: inner, y: tall, z: thick },
        display: 'wall',
      },

      // Front Left Wall (Z+ axis)
      {
        center: { x: 50, y: 50, z: 50 + width / 2 - thick / 2 },
        dimensions: { x: inner, y: tall, z: thick },
        display: 'wall',
        hidden: true, // only used for iso graphics
      },

      // front Right Wall (X+ axis, right)
      {
        center: { x: 50 + width / 2 - thick / 2, y: 50, z: 50 },
        dimensions: { x: thick, y: tall, z: inner },
        display: 'wall',
        hidden: true, // only used for iso graphics
      },

      // dividers at bottom
      // // X-
      {
        center: { x: 50 - (inner - thick) / 4 - thick / 2, y: bottomY, z: 50 },
        dimensions: { x: (inner - thick) / 2, y: divHeight, z: thick },
        display: 'wall',
        hidden: true,
      },

      // X+
      {
        center: { x: 50 + (inner - thick) / 4 + thick / 2, y: bottomY, z: 50 },
        dimensions: { x: (inner - thick) / 2, y: divHeight, z: thick },
        display: 'wall',
        hidden: true,
      },

      // Z-
      {
        center: { x: 50, y: bottomY, z: 50 - (inner - thick) / 4 - thick / 2 },
        dimensions: { x: thick, y: divHeight, z: (inner - thick) / 2 },
        display: 'wall',
        hidden: true,
      },

      // Z+
      {
        center: { x: 50, y: bottomY, z: 50 + (inner - thick) / 4 + thick / 2 },
        dimensions: { x: thick, y: divHeight, z: (inner - thick) / 2 },
        display: 'wall',
        hidden: true,
      },

    ];
  }

}
