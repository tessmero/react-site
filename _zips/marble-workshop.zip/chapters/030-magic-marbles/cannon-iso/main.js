/**
 * @file main.js entry point
 * top-level objects and main loop
 */


const SPHERE_COUNT = 100; // number of marbles
const STEP_DURATION = 15; // (milliseconds) simulation time resolution

const GRAVITY = { x: 1e-6, y: -3e-4, z: 1e-6 }; // change in velocity per step
const AIR_RESISTANCE = 2e-3; // linear damping
const RESTITUTION = 1; // fraction of speed maintained in bounce

// cannon.js physics material categories
const SPHERE_CONTACT_MATERIAL = new CANNON.Material('sphere')
const BOX_CONTACT_MATERIAL = new CANNON.Material('box')

const SPHERE_RADIUS = 3.5; // size of spheres

// settings for springs between neighboring spheres
const SPHERE_STIFFNESS = 0.03;
const SPHERE_DAMPING = 0.1;
const SPHERE_COHESION = 0; // how much spheres stick together

const ROD_COUNT = 25; // number of horizontal sliding rods

const PREDICT_STEPS = 10000/STEP_DURATION; // milliseconds -> total steps to predict

// phase 'enter' shows animation during background prediction
const ENTR_MAX_STEPS = 30; // (number of physics steps) attempt to predict per displayed frame
const ENTR_MAX_DELAY = 10; // (milliseconds) max time investment per displayed frame
const ENTR_FINISH_DELAY = 1000; // (milliseconds) extra wait between prediction and playback
const RESET_DELAY = 5000; // (milliseconds) duration of exit phase, after playback

// prepare to store pre-determined simulation
const record = new Record(PREDICT_STEPS, SPHERE_COUNT);

let scene;
let phase = 'enter'; // enter, playback, exit
let entranceTriggers;
let playbackStepIndex;
let entranceStartTime;
let indexInRecord;

let cannonWorld

function reset() {
  scene = new Scene();
  phase = 'enter';

  // build physics world
  cannonWorld = new CANNON.World();
  cannonWorld.gravity.set(GRAVITY.x, GRAVITY.y, GRAVITY.z);
  for( const {body} of [...scene.boxes,...scene.spheres] ){
    cannonWorld.addBody(body)
  }

  // plan to start drop-in animations as prediction progresses
  entranceTriggers = {};
  for (let i = 0; i < ROD_COUNT; i++) {

    // const stepIndex = Math.floor( PREDICT_STEPS * i/ROD_COUNT ) // regular
    const stepIndex = Math.floor(Math.random() * PREDICT_STEPS); // random
    if (!Object.hasOwn(entranceTriggers, stepIndex)) {
      entranceTriggers[stepIndex] = [];
    }
    entranceTriggers[stepIndex].push(scene.rods[i]);
  }

  Graphics.init(scene);

  indexInRecord = 0;
  playbackStepIndex = 0;
  entranceStartTime = Date.now();
}
reset();



// settings for sphere-box collision
cannonWorld.addContactMaterial(new CANNON.ContactMaterial(
  SPHERE_CONTACT_MATERIAL, BOX_CONTACT_MATERIAL, 
  {
    friction: 0,
    restitution: RESTITUTION,
  }
));

// settings for sphere-sphere collision 
cannonWorld.addContactMaterial(new CANNON.ContactMaterial(
  SPHERE_CONTACT_MATERIAL, SPHERE_CONTACT_MATERIAL, 
  {
    friction: 0,
    restitution: RESTITUTION,
  }
));

function step() {
  cannonWorld.step(STEP_DURATION)

  // check for special case
  if( phase === 'exit' ){
    const params = {exit: true}
    for( const box of scene.boxes ){

      // update box physics body during exit animation
      const {x,y,z} = box.getPosition(params)
      box.body.position.set(x,y,z)
    }
  }
}

let time = Date.now() // (milliseconds) system time

// called after finishing prediction and entrance animations
function startPlayback() {
  phase = 'playback';
  playbackStepIndex = 0;
  time = Date.now();
}

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop


  // console.log(phase);

  const { spheres, boxes, rods, walls } = scene;

  if (phase === 'enter') {

    // predict until (max steps) or (time deadline)
    const deadline = Date.now() + ENTR_MAX_DELAY;
    for (let i = 0; i < ENTR_MAX_STEPS && Date.now() < deadline; i++) {

      // advance one step and take snapshot
      step();
      record.saveSnapshot(indexInRecord, spheres);

      // check if any entrance animation should be started
      const triggerBoxes = entranceTriggers[indexInRecord];
      if (triggerBoxes) {
        triggerBoxes.forEach((box) => box.entrStartTime = Date.now());
      }

      indexInRecord++;
      if (indexInRecord >= PREDICT_STEPS) {

        // finish enter phase
        phase = 'finishEnter';
        setTimeout(startPlayback, ENTR_FINISH_DELAY);

        // now spheres are in their final recorded state
        // check their positions and apply colors
        for (const sphere of spheres) {
          sphere.color = scene.pickSphereColor(sphere.getPosition());
        }

        // pass updated colors to graphics module if necessary
        if (Graphics.updateSphereColors) {
          Graphics.updateSphereColors(spheres);
        }

        break;
      }
    }

    // (enter phase) draw one frame with entrance animations
    Graphics.drawScene({ boxes, rods, walls, enter: true });

  }

  else if (phase === 'finishEnter') {

    // draw one frame with final entrance animations
    Graphics.drawScene({ boxes, rods, walls, enter: true });
  }

  else if (phase === 'playback') {

    // check how much time has passed since the last frame was drawn
    const newTime = Date.now();
    const nSteps = Math.round((newTime - time) / STEP_DURATION);
    time = newTime;
    playbackStepIndex = playbackStepIndex + nSteps;

    if (playbackStepIndex < PREDICT_STEPS) {

      // set the sphere positions based on the record
      record.loadSnapshot(playbackStepIndex, spheres);
    }
    else {

      // finish playback phase
      phase = 'exit';
      boxes.forEach((box) => { box.exitStartTime = Date.now(); });

      setTimeout(reset, RESET_DELAY);
    }

    // draw one frame with played-back physics
    Graphics.drawScene(scene);
  }

  else if (phase === 'exit') {

    // check how much time has passed since the last frame was drawn
    const newTime = Date.now();
    const dt = newTime - time;
    time = newTime;
    if (dt > 200) {
      return; // lagging or regained focus, do nothing this frame
    }
    const nSteps = Math.round(dt / STEP_DURATION);

    // advance live physics
    for (let i = 0; i < nSteps; i++) {
      step();
    }

    // draw one frame with live physics
    Graphics.drawScene({ ...scene, exit: true });
  }
}
requestAnimationFrame(animationLoop); // queue first loop
