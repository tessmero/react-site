/**
 * @file Box
 * A solid box that spheres can collide with.
 * May be animated by sliding along one axis.
 */
class Box {

  /**
   * Construct a box
   * @param {object} params The parameters
   * @param {Vector} params.center The x,y,x center position
   * @param {Vector} params.dimensions The width,height,depth
   * @param {boolean} params.hidden Set to true to skip rendering
   */
  constructor(params) {

    const {
      center,
      dimensions,
      hidden, // only used for iso graphics

      display = 'wall', // wall or rod

      // animations
      entrAnim, // entrance, trigger any time during loading, no physics
      exitAnim, // exit, effects both gfx and physics
    } = params;

    this.center = center;
    this.dimensions = dimensions;
    this.hidden = hidden;
    this.display = display;

    this.entrAnim = entrAnim;
    this.exitAnim = exitAnim;

    this.bounds = Box.getBounds({ center, dimensions });

    // construct body to be registered in cannon.js engine
    const {x,y,z} = center
    const {x:width,y:height,z:depth} = dimensions
    this.body = new CANNON.Body({
      mass: 0, // static obstacle
      position: new CANNON.Vec3(x,y,z),
      shape: new CANNON.Box( // shape in terms of half-extents
        new CANNON.Vec3(width/2,height/2,depth/2)), 
      material: BOX_CONTACT_MATERIAL,
    });
  }

  /**
   *
   * @param params
   */
  static getBounds(params) {
    const center = params.center || params.position;
    const { dimensions } = params;
    return {
      minX: center.x - dimensions.x / 2,
      maxX: center.x + dimensions.x / 2,
      minY: center.y - dimensions.y / 2,
      maxY: center.y + dimensions.y / 2,
      minZ: center.z - dimensions.z / 2,
      maxZ: center.z + dimensions.z / 2,
    };
  }

  /**
     *
     * @param params
     */
    getPosition(params = {}) {
      const { enter, exit } = params;
  
      if (exit && this.exitAnim && this.exitStartTime) {
  
        // exit animation
        const exitTime = Date.now() - this.exitStartTime;
        const offset = this.exitAnim(exitTime);
        const result = VectorMath.add(this.center, offset);
  
        // make displayed position also effect physics
        this.bounds = Box.getBounds({ center: result, dimensions: this.dimensions });
  
        return result;
  
      }
      else if (enter && this.entrAnim) {
  
        let offset;
        if (this.entrStartTime) {
  
          // entrance animation
          const entrTime = Date.now() - this.entrStartTime;
          offset = this.entrAnim(entrTime);
  
        }
        else {
  
          // has entrance animation, but hasn't started yet
          offset = { x: 0, y: 10000, z: 0 }; // hide by positioning out of view
        }
  
        return VectorMath.add(this.center, offset);
      }
  
      // no animation
      return this.center;
    }
}
