/**
 * @file Sphere
 * moving sphere in 3d pong
 */
class Sphere {

  /**
   * Construct a moving sphere
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   */
  constructor(params) {
    const { position, velocity } = params;

    this.position = position;
    this.velocity = velocity;

    // color will be changed if this sphere is predicted
    // to end up in a color-coded target region
    this.color = 'white';

    // construct body to be registered in cannon.js engine
    const {x,y,z} = position
    this.body = new CANNON.Body({
      shape: new CANNON.Sphere(SPHERE_RADIUS),
      position: new CANNON.Vec3(x,y,z),
      material: SPHERE_CONTACT_MATERIAL,
      mass: 1, 
      linearDamping: AIR_RESISTANCE,
    });
  }


  /**
   * Get position for purposes of drawing, recording, coloring
   * @returns {Vector}
   */
  getPosition() {
    const {x,y,z} = this.body.position
    return {x,y,z}
  }

  /**
   * Set position. called when playing back recording
   */
  setPosition(position){
    const {x,y,z} = position
    this.body.position.set(x,y,z)
  }

}
