/**
 * @file VectorMath
 * utility functions involving 3D vectors
 * Vectors are objects with properties x,y, and z
 */
class VectorMath {

  /**
   * Compute a weighted average between two vectors or numbers.
   * @param {number|Vector} a
   * @param {number|Vector} b
   * @param {number} r Optional ratio
   */
  static avg(a, b, r = 0.5) {
    if (typeof a === 'number') {
      return a * (1 - r) + b * r; // average numbers
    }

    // average vectors
    return {
      x: VectorMath.avg(a.x, b.x, r),
      y: VectorMath.avg(a.y, b.y, r),
      z: VectorMath.avg(a.z || 0, b.z || 0, r), // make it work for 2d
    };
  }

  /**
   *
   * @param {Vector} vector
   * @returns {number}
   */
  static getLengthSquared(vector) {
    const { x, y, z } = vector;
    return x * x + y * y + z * z;
  }

  /**
   * Get the magnitude/length/distance of the vector.
   * @param {Vector} vector
   * @returns {number}
   */
  static getLength(vector) {
    return Math.sqrt(VectorMath.getLengthSquared(vector));
  }

  /**
   * Add together two or more vectors.
   * @param {...Vector} vectors
   * @returns {Vector}
   */
  static add(...vectors) {
    let totalX = 0;
    let totalY = 0;
    let totalZ = 0;
    for (const { x, y, z } of vectors) {
      totalX = totalX + x;
      totalY = totalY + y;
      totalZ = totalZ + z;
    }
    return { x: totalX, y: totalY, z: totalZ };
  }

  /**
   * Compute the difference between two vectors
   * @param {Vector} a
   * @param {Vector} b
   * @returns {Vector} The difference a-b
   */
  static subtract(a, b) {
    return {
      x: a.x - b.x,
      y: a.y - b.y,
      z: a.z - b.z,
    };
  }

  /**
   * Multiply a vector by a number
   * @param {Vector} vector
   * @param {number} scalar
   */
  static multiply(vector, scalar) {
    const { x, y, z } = vector;
    return {
      x: x * scalar,
      y: y * scalar,
      z: z * scalar,
    };
  }

}
