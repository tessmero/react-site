/**
 * @file Graphics
 *
 * Routines for drawing the air hockey scene on the
 * canvas 2d graphics context.
 */

const GFX_SPHERE_RADIUS = 2.5; // size of spheres

// positions in 3d world
const UNIT_CUBE_3D = [
  { x: 50, y: 50, z: 50 }, // origin
  { x: 51, y: 50, z: 50 }, // right +x
  { x: 50, y: 51, z: 50 }, // up +y
  { x: 50, y: 50, z: 51 }, // left +z
];

const UNIT_CUBE_2D = [
  { x: 50, y: 50 }, // origin
  { x: 50.4, y: 50.2 }, // right (+x)
  { x: 50, y: 49.5 }, // up (+y)
  { x: 49.5, y: 50.15 }, // left (+z)
];

const d2x = {
  x: UNIT_CUBE_2D[1].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[1].y - UNIT_CUBE_2D[0].y,
};
const d2y = {
  x: UNIT_CUBE_2D[2].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[2].y - UNIT_CUBE_2D[0].y,
};
const d2z = {
  x: UNIT_CUBE_2D[3].x - UNIT_CUBE_2D[0].x,
  y: UNIT_CUBE_2D[3].y - UNIT_CUBE_2D[0].y,
};

// Compute the magnitude of each 2D direction
function mag2D(v) {
  return Math.sqrt(v.x * v.x + v.y * v.y);
}

const mx = mag2D(d2x);
const my = mag2D(d2y);
const mz = mag2D(d2z);

// Camera direction inversely proportional to 2D projection lengths
const camDir = {
  x: 1 / mx,
  y: 1 / my,
  z: 1 / mz,
};

// Normalize the direction
const len = VectorMath.getLength(camDir);
const normDir = {
  x: camDir.x / len,
  y: camDir.y / len,
  z: camDir.z / len,
};

// Place camera far along this direction
const scale = 1000;
const CAMERA = {
  x: UNIT_CUBE_3D[0].x + normDir.x * scale,
  y: UNIT_CUBE_3D[0].y + normDir.y * scale,
  z: UNIT_CUBE_3D[0].z + normDir.z * scale,
};

/**
 *
 */
class Graphics {

  /**
   *
   */
  static init() {

    // assume there is only one canvas in the document, and use it
    const canvas = document.getElementsByTagName('canvas')[0];
    canvas.width = canvas.offsetWidth * devicePixelRatio;
    canvas.height = canvas.offsetHeight * devicePixelRatio;

    // set up graphics context with standard coordinate system
    // where (50,50) is the center of the display area
    const canvasSize = Math.min(canvas.width, canvas.height);
    const offsetX = (canvas.width - canvasSize) / 2;
    const offsetY = (canvas.height - canvasSize) / 2;
    const ctx = canvas.getContext('2d');
    const scale = canvasSize / 100;
    ctx.setTransform(scale, 0, 0, scale, offsetX, offsetY);

    Graphics.ctx = ctx;

    // compute x,y,w,h of the whole display in standard coordinates
    Graphics.clearRect = [
      (0 - offsetX) / scale,
      (0 - offsetY) / scale,
      canvas.width / scale,
      canvas.height / scale,
    ];

  }

  /**
   * Draw an array of Sphere instances
   * @param {object} ctx The graphics context
   * @param {object} params The parameters
   * @param {object[]} params.boxes The Box instances to draw
   * @param {object[]} params.spheres The Sphere instances to draw
   */
  static drawScene(params) {
    const ctx = Graphics.ctx;
    ctx.clearRect(...Graphics.clearRect);
    const { boxes, walls, rods, spheres = [] } = params;

    const rodDots = [];
    const dotsPerRod = 20;
    for (const rod of rods) {
      const center = rod.getPosition(params);
      const { dimensions } = rod;

      const alongX = dimensions.x > dimensions.z;
      const delta = alongX ? { x: dimensions.x / 2, y: 0, z: 0 } : { x: 0, y: 0, z: dimensions.z / 2 };

      // get terminals in 2d and 3d coords
      const a3 = VectorMath.add(center, delta);
      const a2 = Graphics._isoProject(a3);
      const b3 = VectorMath.subtract(center, delta);
      const b2 = Graphics._isoProject(b3);

      // place dots along rod
      for (let di = 0; di < dotsPerRod; di++) {
        const r = di / dotsPerRod;
        rodDots.push({
          position: VectorMath.avg(a3, b3, r), // for occlusion with balls
          screenPos: VectorMath.avg(a2, b2, r), // for drawing
        });
      }
    }

    const allEnts = [...spheres, ...rodDots];

    // sort spheres by their distance from the camera
    // (used for spheres to occlude other spheres)
    const sortedEnts = allEnts
      .map((ent) => ({
        ent,
        dist: (
          Math.pow(ent.position.x - CAMERA.x, 2) +
          Math.pow(ent.position.y - CAMERA.y, 2) +
          Math.pow(ent.position.z - CAMERA.z, 2)
        ),
      }))
      .sort((a, b) => b.dist - a.dist)
      .map((obj) => obj.ent);

    // draw all boxes
    // (assume they are sorted to occlude eachother)
    for (const box of walls) {
      if (!box.hidden) {
        this._drawWall(ctx, box, params);
      }
    }

    // draw spheres in front of boxes, starting with those farthest away
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = 'black';
    ctx.setLineDash([]);
    for (const ent of sortedEnts) {
      if (ent instanceof Sphere) {
        this._drawSphere(ctx, ent);
      }
      else {
        this._drawRodDot(ctx, ent);
      }
    }

    // draw hidden boxes as wireframes
    for (const box of walls) {
      if (box.hidden) {
        this._drawWall(ctx, box, params);
      }
    }
  }

  /**
   *
   * @param ctx
   * @param sphere
   */
  static _drawSphere(ctx, sphere) {

    // project 3d position onto 2d isometric screen
    const center2D = Graphics._isoProject(sphere.getPosition());
    ctx.fillStyle = sphere.color;
    ctx.beginPath();
    ctx.arc(center2D.x, center2D.y, GFX_SPHERE_RADIUS, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  /**
   * Draw a solid box.
   * @param {object} ctx The graphics context
   * @param {object} box The Box instance to draw
   * @param params
   */
  static _drawWall(ctx, box, params) {

    const { left, right, top } = Graphics._getFaces(box, params);

    if (box.hidden) {

      // draw hidden box as wireframe
      ctx.lineWidth = 0.05;
      ctx.setLineDash([]);
      const style = { strokeStyle: 'black' };
      Graphics._drawFace(ctx, { face: top, ...style });
      Graphics._drawFace(ctx, { face: left, ...style });
      Graphics._drawFace(ctx, { face: right, ...style });

    }
    else {

      ctx.lineWidth = 0.05;
      ctx.setLineDash([]);
      const style = { strokeStyle: 'black' };

      // fill regular box
      Graphics._drawFace(ctx, { face: top, fillStyle: '#FBFBFB', ...style });
      Graphics._drawFace(ctx, { face: left, fillStyle: '#DDD', ...style });
      Graphics._drawFace(ctx, { face: right, fillStyle: '#CCC', ...style });
    }
  }

  /**
   *
   * @param ctx
   * @param rodDot
   */
  static _drawRodDot(ctx, rodDot) {
    const { position, screenPos: { x, y } } = rodDot;

    const rad = 0.5;

    ctx.fillStyle = '#9955dd';
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();
  }

  /**
   * Draw a solid box.
   * @param {object} ctx The graphics context
   * @param {object} box The Box instance to draw
   * @param params
   */
  static _drawRod(ctx, box, params) {

    const center = box.getPosition(params);
    const { dimensions } = box;

    const alongX = dimensions.x > dimensions.z;

    const delta = alongX ? { x: dimensions.x / 2, y: 0, z: 0 } : { x: 0, y: 0, z: dimensions.z / 2 };
    const a = Graphics._isoProject(VectorMath.subtract(center, delta));
    const b = Graphics._isoProject(VectorMath.add(center, delta));

    ctx.lineWidth = 2;
    ctx.setLineDash([2, 2]);
    ctx.strokeStyle = '#c0c';

    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  /**
   *
   * @param ctx
   * @param params
   */
  static _drawFace(ctx, params) {

    const { face, fillStyle, strokeStyle } = params;

    const vertices3D = face;
    const vertices2D = vertices3D.map((v) => Graphics._isoProject(v));

    ctx.beginPath();

    // Draw front face (first 4 vertices)
    for (const { x, y } of vertices2D) {
      ctx.lineTo(x, y);
    }
    ctx.closePath();

    if (fillStyle) {
      ctx.fillStyle = fillStyle;
      ctx.fill();
    }

    if (strokeStyle) {
      ctx.strokeStyle = strokeStyle;
      ctx.stroke();
    }
  }

  /**
   *
   * @param box
   * @param params
   */
  static _getFaces(box, params) {

    if (params.exit && box.exitStartTime) {
      const center = box.getPosition(params);
      const { dimensions } = box;

      // only for homebrew physics
      // make displayed position also effect physics
      box.bounds = Box.getBounds({ center, dimensions });
    }

    const b = box.bounds;
    return {
      'right': [
        { x: b.maxX, y: b.minY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.minY, z: b.maxZ },
      ],
      'left': [
        { x: b.minX, y: b.minY, z: b.maxZ },
        { x: b.minX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.maxX, y: b.minY, z: b.maxZ },
      ],
      'top': [
        { x: b.minX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.minZ },
        { x: b.maxX, y: b.maxY, z: b.maxZ },
        { x: b.minX, y: b.maxY, z: b.maxZ },
      ],
    };
  }

  /**
   *  project a 3D point to 2D canvas cube mapping
   * @param point3D
   */
  static _isoProject(point3D) {
    // Basis: origin, x+, y+, z+ (indices 0,1,2,3)
    const [p0, p1, p2, p3] = UNIT_CUBE_3D;
    const [q0, q1, q2, q3] = UNIT_CUBE_2D;

    // Compute weights for each axis
    const dx = point3D.x - p0.x;
    const dy = point3D.y - p0.y;
    const dz = point3D.z - p0.z;

    // For a unit cube, dx,dy,dz are in [0,1]
    // Interpolate along axes
    return {
      x: q0.x + (q1.x - q0.x) * dx + (q2.x - q0.x) * dy + (q3.x - q0.x) * dz,
      y: q0.y + (q1.y - q0.y) * dx + (q2.y - q0.y) * dy + (q3.y - q0.y) * dz,
    };
  }
}
