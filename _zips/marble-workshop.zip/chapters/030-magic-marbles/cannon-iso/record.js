/**
 * @file Record
 * used to store and recall positions of spheres
 */
class Record {

  /**
   *
   * @param nSteps
   * @param nSpheres
   */
  constructor(nSteps, nSpheres) {

    this.nSteps = nSteps;
    this.nSpheres = nSpheres;

    // prepare to store x,y,z for each sphere for each step
    this.buffer = new Float32Array(3 * nSpheres * nSteps);
  }

  /**
   *
   * @param stepIndex
   */
  _indexForStep(stepIndex) {

    // index in buffer where this step's snapshot should start
    return 3 * this.nSpheres * stepIndex;
  }

  /**
   *
   * @param stepIndex
   * @param spheres
   */
  saveSnapshot(stepIndex, spheres) {

    // pick starting address in buffer
    let i = this._indexForStep(stepIndex);

    for (const sphere of spheres) {

      // save position of one sphere and advance cursor
      const { x, y, z } = sphere.getPosition();
      this.buffer[i++] = x;
      this.buffer[i++] = y;
      this.buffer[i++] = z;

    }
  }

  /**
   *
   * @param stepIndex
   * @param spheres
   */
  loadSnapshot(stepIndex, spheres) {

    // pick starting address in buffer
    let i = this._indexForStep(stepIndex);

    for (const sphere of spheres) {

      // set position of one sphere and advance cursor
      sphere.setPosition({
        x: this.buffer[i++],
        y: this.buffer[i++],
        z: this.buffer[i++],
      });

    }
  }
}
